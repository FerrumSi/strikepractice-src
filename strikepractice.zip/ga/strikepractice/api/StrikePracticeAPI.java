package ga.strikepractice.api;

import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.fights.elo.EloCalculator;
import ga.strikepractice.fights.queue.DuelQueueRunnable;
import ga.strikepractice.party.Party;
import ga.strikepractice.playerkits.PlayerKits;
import ga.strikepractice.playersettings.PlayerSettings;
import ga.strikepractice.stats.PlayerStats;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@APIClass
public interface StrikePracticeAPI {
   @Nullable
   UUID getCurrentFightsPlaybackUUID(@NotNull Player var1);

   boolean startPlayback(@NotNull Player var1, @NotNull UUID var2);

   @Nullable
   Party getParty(@NotNull Player var1);

   Party createParty(@NotNull Player var1);

   void spawnBot(@NotNull Location var1, @NotNull String var2, @NotNull String var3, @NotNull List<UUID> var4, @NotNull String var5, @NotNull Fight var6);

   /** @deprecated */
   @Deprecated
   void forceWin(@NotNull Player var1);

   void forceWinFight(@NotNull Player var1);

   void forceWinRound(@NotNull Player var1);

   boolean isEditingKit(@NotNull Player var1);

   @Nullable
   BattleKit getEditingKit(@NotNull Player var1);

   void startEditing(@NotNull Player var1, @NotNull BattleKit var2);

   void joinQueue(@NotNull Player var1, @NotNull BattleKit var2, boolean var3);

   void joinQueue(@NotNull Player var1, @NotNull BattleKit var2);

   void joinPremiumQueue(@NotNull Player var1, @NotNull BattleKit var2);

   void cancelFight(@NotNull Player var1, @Nullable String var2);

   @NotNull
   PlayerStats getPlayerStats(@NotNull Player var1);

   @Nullable
   PlayerStats getPlayerStats(@NotNull UUID var1, boolean var2, boolean var3);

   void clear(@NotNull Player var1, boolean var2, boolean var3);

   Location getSpawnLocation();

   boolean isSpectator(@NotNull Player var1);

   @Nullable
   Fight getSpectating(@NotNull Player var1);

   void addSpectator(@NotNull Player var1);

   void addSpectator(@NotNull Player var1, @Nullable Player var2);

   void removeSpectator(@NotNull Player var1, boolean var2);

   boolean isInFight(@NotNull Player var1);

   boolean isInEvent(@NotNull Player var1);

   String getLanguage(@NotNull Player var1);

   boolean isRanked(@NotNull Player var1);

   @NotNull
   Map<BattleKit, String> getUnrankedQueue();

   @NotNull
   Map<BattleKit, Collection<DuelQueueRunnable>> getRankedQueue();

   @Nullable
   BattleKit getQueuedKit(@NotNull Player var1);

   boolean isInQueue(@NotNull Player var1);

   void setLanguage(@NotNull Player var1, String var2, boolean var3);

   @Nullable
   Fight getFight(@NotNull Player var1);

   @Nullable
   BattleKit getKit(@NotNull Player var1);

   @NotNull
   JavaPlugin getStrikePractice();

   @Nullable
   Player getDuelOpponent(@NotNull Player var1);

   @Nullable
   Arena getArena(@NotNull String var1);

   @NotNull
   List<Arena> getArenas();

   @Nullable
   BattleKit getKit(@NotNull String var1);

   @Nullable
   List<BattleKit> getKits(@NotNull ItemStack var1);

   @NotNull
   List<BattleKit> getKits();

   @NotNull
   EloCalculator getEloCalculator();

   void setEloCalculator(@NotNull EloCalculator var1);

   @NotNull
   PlayerSettings getPlayerSettings(@NotNull Player var1);

   @NotNull
   PlayerKits loadPlayerKits(@NotNull UUID var1);

   @NotNull
   PlayerKits getPlayerKits(@NotNull Player var1);

   @NotNull
   Duel sendDuelRequest(@NotNull Player var1, @NotNull Player var2, @NotNull BattleKit var3, @NotNull Arena var4, boolean var5);

   @NotNull
   Duel sendDuelRequest(@NotNull Player var1, @NotNull Player var2, @NotNull BattleKit var3, @NotNull Arena var4, int var5, boolean var6);

   @Nullable
   BattleKit getLastSelectedEditedKit(@NotNull Player var1);

   void respawnInFight(@NotNull Player var1);
}
