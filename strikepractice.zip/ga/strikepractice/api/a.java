package ga.strikepractice.api;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.botduel.BotDuel;
import ga.strikepractice.fights.duel.BestOf;
import ga.strikepractice.fights.duel.BestOfFight;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.fights.elo.EloCalculator;
import ga.strikepractice.fights.party.partyfights.PartyFFA;
import ga.strikepractice.fights.party.partyfights.PartySplit;
import ga.strikepractice.fights.party.partyfights.PartyVsBots;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.fights.queue.DuelQueueRunnable;
import ga.strikepractice.fights.requests.DuelRequest;
import ga.strikepractice.fights.requests.FightRequest;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.matchrecorder.RecordedMatch;
import ga.strikepractice.matchrecorder.replay.ReplayFight;
import ga.strikepractice.npc.CitizensNPC;
import ga.strikepractice.party.Party;
import ga.strikepractice.playerkits.PlayerKits;
import ga.strikepractice.playerkits.b.b;
import ga.strikepractice.playerkits.b.d;
import ga.strikepractice.playersettings.PlayerSettings;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.stats.PlayerStats;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.w;
import ga.strikepractice.utils.y;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class a implements StrikePracticeAPI {
   public UUID getCurrentFightsPlaybackUUID(@NotNull Player var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1);
      if (var2 instanceof Duel) {
         Duel var3 = (Duel)var2;
         if (var3.getRecorder() != null && var3.getRecorder().getRecordedMatch() != null) {
            return var3.getRecorder().getRecordedMatch().getUUID();
         }
      }

      return null;
   }

   public boolean startPlayback(@NotNull Player var1, @NotNull UUID var2) {
      Iterator var3 = StrikePractice.getInstance().ab().cU().values().iterator();

      while(var3.hasNext()) {
         List var4 = (List)var3.next();
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            RecordedMatch var6 = (RecordedMatch)var5.next();
            if (var6.getUUID().equals(var2)) {
               ReplayFight var7 = var6.startPlayback(0);
               if (var7 != null) {
                  var7.addSpectator(var1);
                  return true;
               }
            }
         }
      }

      return false;
   }

   @Nullable
   public Party getParty(@NotNull Player var1) {
      return Party.getParty(var1);
   }

   public Party createParty(@NotNull Player var1) {
      return new ga.strikepractice.party.a(var1, StrikePractice.getInstance());
   }

   public void spawnBot(@NotNull Location var1, @NotNull String var2, @NotNull String var3, @NotNull List<UUID> var4, @NotNull String var5, @NotNull Fight var6) {
      CitizensNPC var7 = new CitizensNPC(var2, var3, var1);
      var7.startCombatTask(var4, var6, CitizensNPC.Difficulty.valueOf(var5.toUpperCase()));
   }

   public void forceWin(@NotNull Player var1) {
      this.forceWinRound(var1);
   }

   public void forceWinFight(@NotNull Player var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1);
      if (var2 instanceof BestOfFight) {
         BestOfFight var3 = (BestOfFight)var2;
         var3.setBestOf((BestOf)null);
      }

      this.forceWinRound(var1);
   }

   public void forceWinRound(@NotNull Player var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1);
      if (var2 != null) {
         B.debug(var1.getName() + " set to force win in " + var2);
         if (var2 instanceof Duel) {
            String var3 = ((Duel)var2).getP1();
            if (var3 == null || var3.equals(var1.getName())) {
               var3 = ((Duel)var2).getP2();
            }

            var2.handleDeath(Bukkit.getPlayer(var3));
         } else {
            NPC var4;
            Fight var5;
            Iterator var7;
            if (var2 instanceof BotDuel) {
               var7 = w.fG().iterator();

               while(var7.hasNext()) {
                  var4 = (NPC)var7.next();
                  if (var4.getEntity() != null && !var4.getEntity().isDead()) {
                     var5 = AbstractFight.getCurrentFight(var1);
                     if (var5 != null && var5 == var2) {
                        ((BotDuel)var2).handleBotDeath(var4.getEntity());
                     }
                  }
               }
            } else if (var2 instanceof PartyVsBots) {
               var7 = w.fG().iterator();

               while(var7.hasNext()) {
                  var4 = (NPC)var7.next();
                  if (var4.getEntity() != null && !var4.getEntity().isDead()) {
                     var5 = AbstractFight.getCurrentFight(var1);
                     if (var5 != null && var5 == var2) {
                        ((PartyVsBots)var2).handleBotDeath(var4.getEntity());
                     }
                  }
               }

               this.teleportParty(Party.getParty(var1));
            } else {
               Player var6;
               Iterator var9;
               String var12;
               if (var2 instanceof PartyFFA) {
                  PartyFFA var8 = (PartyFFA)var2;
                  var9 = var8.getParty().getMembersNames().iterator();

                  while(var9.hasNext()) {
                     var12 = (String)var9.next();
                     var6 = y.W(var12);
                     if (var6 != null && var6 != var1) {
                        var2.handleDeath(var6);
                     }
                  }

                  this.teleportParty(Party.getParty(var1));
               } else if (var2 instanceof PartySplit) {
                  PartySplit var10 = (PartySplit)var2;
                  if (!var10.getTeam1().contains(var1.getName())) {
                     var9 = var10.getTeam1().iterator();

                     while(var9.hasNext()) {
                        var12 = (String)var9.next();
                        var6 = y.W(var12);
                        if (var6 != null) {
                           var2.handleDeath(var6);
                        }
                     }
                  } else if (!var10.getTeam2().contains(var1.getName())) {
                     var9 = var10.getTeam2().iterator();

                     while(var9.hasNext()) {
                        var12 = (String)var9.next();
                        var6 = y.W(var12);
                        if (var6 != null) {
                           var2.handleDeath(var6);
                        }
                     }
                  }

                  this.teleportParty(Party.getParty(var1));
               } else if (var2 instanceof PartyVsParty) {
                  PartyVsParty var11 = (PartyVsParty)var2;
                  if (!var11.getParty1().getMembersNames().contains(var1.getName())) {
                     var9 = (new HashSet(var11.getPartyAlive1())).iterator();

                     while(var9.hasNext()) {
                        var12 = (String)var9.next();
                        var6 = y.W(var12);
                        if (var6 != null) {
                           var2.handleDeath(var6);
                        }
                     }
                  }

                  if (!var11.getParty2().getMembersNames().contains(var1.getName())) {
                     var9 = (new HashSet(var11.getPartyAlive2())).iterator();

                     while(var9.hasNext()) {
                        var12 = (String)var9.next();
                        var6 = y.W(var12);
                        if (var6 != null) {
                           var2.handleDeath(var6);
                        }
                     }
                  }

                  this.teleportParty(var11.getParty1());
                  this.teleportParty(var11.getParty2());
               }
            }
         }
      }

   }

   private void teleportParty(final Party var1) {
      (new BukkitRunnable() {
         public void run() {
            Iterator var1x = var1.getMembersNames().iterator();

            while(var1x.hasNext()) {
               String var2 = (String)var1x.next();
               Player var3 = Bukkit.getPlayer(var2);
               if (var3 != null) {
                  a.this.removeSpectator(var3, false);
                  a.this.clear(var3, true, true);
               }
            }

         }
      }).runTaskLater(this.getStrikePractice(), (long)this.getStrikePractice().getConfig().getInt("wait-before-telepot") * 20L);
   }

   public boolean isEditingKit(@NotNull Player var1) {
      return d.aE(var1);
   }

   public BattleKit getEditingKit(@NotNull Player var1) {
      return d.aC(var1);
   }

   public void startEditing(@NotNull Player var1, @NotNull BattleKit var2) {
      if (!var2.isEditable()) {
         throw new IllegalStateException(var2.getName() + " is not editable kit. ");
      } else {
         d.startEditing(var1, var2);
      }
   }

   public void joinQueue(@NotNull Player var1, @NotNull BattleKit var2, boolean var3) {
      StrikePractice.getInstance().aj.a(var1, var2, var3);
   }

   public void joinQueue(@NotNull Player var1, @NotNull BattleKit var2) {
      StrikePractice.getInstance().aj.a(var1, var2, false);
   }

   public void joinPremiumQueue(@NotNull Player var1, @NotNull BattleKit var2) {
      StrikePractice.getInstance().aj.a(var1, var2, true);
   }

   public void cancelFight(@NotNull Player var1, String var2) {
      Fight var3 = AbstractFight.getCurrentFight(var1);
      if (var3 != null) {
         var3.forceEnd(var2);
      }

   }

   @NotNull
   public PlayerStats getPlayerStats(@NotNull Player var1) {
      return DefaultPlayerStats.getStats(var1.getUniqueId());
   }

   public PlayerStats getPlayerStats(@NotNull UUID var1, boolean var2, boolean var3) {
      return DefaultPlayerStats.getStats(var1, var2, var3);
   }

   public void clear(@NotNull Player var1, boolean var2, boolean var3) {
      StrikePractice.getInstance().clear(var1, var2, var3);
   }

   public Location getSpawnLocation() {
      return StrikePractice.getInstance().L.fN();
   }

   public boolean isSpectator(@NotNull Player var1) {
      return StrikePractice.getInstance().ac().isSpectator(var1);
   }

   public Fight getSpectating(@NotNull Player var1) {
      return (Fight)StrikePractice.getInstance().ac().eG().get(var1.getUniqueId());
   }

   public void addSpectator(@NotNull Player var1) {
      StrikePractice.getInstance().ac().addSpectator(var1);
   }

   public void addSpectator(@NotNull Player var1, Player var2) {
      StrikePractice.getInstance().ac().addSpectator(var1, var2);
   }

   public void removeSpectator(@NotNull Player var1, boolean var2) {
      StrikePractice.getInstance().ac().removeSpectator(var1, var2);
   }

   public boolean isInFight(@NotNull Player var1) {
      return AbstractFight.isInFight(var1);
   }

   public boolean isInEvent(@NotNull Player var1) {
      return PvPEvent.isInEvent(var1);
   }

   public String getLanguage(@NotNull Player var1) {
      return PlayerSettings.getPlayerSettings(var1.getUniqueId()).getLanguage();
   }

   public boolean isRanked(@NotNull Player var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1);
      if (var2 != null) {
         return var2.getKit().isElo();
      } else {
         if (this.isInQueue(var1)) {
            DuelQueueRunnable var3 = DuelQueueRunnable.getRanked(var1);
            if (var3 != null) {
               return var3.getKit() != null && var3.getKit().isElo();
            }
         }

         BattleKit var4 = BattleKit.getCurrentKit(var1);
         return var4 != null ? var4.isElo() : false;
      }
   }

   @NotNull
   public Map<BattleKit, String> getUnrankedQueue() {
      return Collections.unmodifiableMap(ga.strikepractice.fights.queue.d.gE);
   }

   @NotNull
   public Map<BattleKit, Collection<DuelQueueRunnable>> getRankedQueue() {
      return Collections.unmodifiableMap(ga.strikepractice.fights.queue.d.gF);
   }

   public BattleKit getQueuedKit(@NotNull Player var1) {
      DuelQueueRunnable var2 = DuelQueueRunnable.getRanked(var1);
      if (var2 != null) {
         return var2.getKit();
      } else {
         Iterator var3 = ga.strikepractice.fights.queue.d.gE.entrySet().iterator();

         Entry var4;
         do {
            if (!var3.hasNext()) {
               Party var5 = Party.getParty(var1);
               if (var5 != null) {
                  BattleKit var6 = (BattleKit)ga.strikepractice.fights.party.partyfights.partyqueue.a.gE.entrySet().stream().filter((var1x) -> {
                     return var1x.getValue() != null && ((Party)var1x.getValue()).equals(var5);
                  }).findFirst().map(Entry::getKey).orElse((Object)null);
                  if (var6 == null) {
                     var6 = (BattleKit)ga.strikepractice.fights.party.partyfights.partyqueue.a.gF.entrySet().stream().filter((var1x) -> {
                        return ((Collection)var1x.getValue()).stream().anyMatch((var1) -> {
                           return var1.getParty().equals(var5);
                        });
                     }).findFirst().map(Entry::getKey).orElse((Object)null);
                  }

                  return var6;
               }

               return null;
            }

            var4 = (Entry)var3.next();
         } while(var4.getValue() == null || !((String)var4.getValue()).equals(var1.getName()));

         return (BattleKit)var4.getKey();
      }
   }

   public boolean isInQueue(@NotNull Player var1) {
      return var1.hasMetadata("StrikePracticeWaitingQueue") || var1.hasMetadata("StrikePracticeWaiting2v2Queue");
   }

   public void setLanguage(@NotNull Player var1, String var2, boolean var3) {
      PlayerSettings.getPlayerSettings(var1.getUniqueId()).setLanguage(var2, StrikePractice.getInstance(), var3);
   }

   public Fight getFight(@NotNull Player var1) {
      return AbstractFight.getCurrentFight(var1);
   }

   public BattleKit getKit(@NotNull Player var1) {
      return BattleKit.getCurrentKit(var1);
   }

   @NotNull
   public StrikePractice getStrikePractice() {
      return StrikePractice.getInstance();
   }

   public Player getDuelOpponent(@NotNull Player var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1);
      if (var2 instanceof Duel) {
         Duel var3 = (Duel)var2;
         return var3.getP1().equals(var1.getName()) ? Bukkit.getPlayer(var3.getP2()) : Bukkit.getPlayer(var3.getP1());
      } else {
         return null;
      }
   }

   public Arena getArena(@NotNull String var1) {
      return c.getArena(var1);
   }

   @NotNull
   public List<Arena> getArenas() {
      Stream var10000 = StrikePractice.getInstance().M.stream();
      Objects.requireNonNull(Arena.class);
      return (List)var10000.map(Arena.class::cast).collect(Collectors.toList());
   }

   public BattleKit getKit(@NotNull String var1) {
      return BattleKit.getKit(var1);
   }

   public List<BattleKit> getKits(@NotNull ItemStack var1) {
      return BattleKit.getKits(var1);
   }

   @NotNull
   public List<BattleKit> getKits() {
      Stream var10000 = StrikePractice.getInstance().kits.stream();
      Objects.requireNonNull(BattleKit.class);
      return (List)var10000.map(BattleKit.class::cast).collect(Collectors.toList());
   }

   @NotNull
   public EloCalculator getEloCalculator() {
      return EloCalculator.getEloCalculator();
   }

   public void setEloCalculator(@NotNull EloCalculator var1) {
      EloCalculator.setEloCalculator(var1);
   }

   @NotNull
   public PlayerSettings getPlayerSettings(@NotNull Player var1) {
      return PlayerSettings.getPlayerSettings(var1.getUniqueId());
   }

   @NotNull
   public PlayerKits loadPlayerKits(@NotNull UUID var1) {
      return StrikePractice.getInstance().Y().g(var1);
   }

   @NotNull
   public PlayerKits getPlayerKits(@NotNull Player var1) {
      return StrikePractice.getInstance().Y().e(var1, true);
   }

   @NotNull
   public Duel sendDuelRequest(@NotNull Player var1, @NotNull Player var2, @NotNull BattleKit var3, @NotNull Arena var4, boolean var5) {
      return this.sendDuelRequest(var1, var2, var3, var4, var3.getBestOf(), var5);
   }

   @NotNull
   public Duel sendDuelRequest(@NotNull Player var1, @NotNull Player var2, @NotNull BattleKit var3, @NotNull Arena var4, int var5, boolean var6) {
      if (var3.isRandomKit()) {
         Bukkit.getLogger().warning("Currently random kits are not supported with API#sendDuelRequest because the system does not know which kits are allowed in this case.");
      }

      Duel var7 = new Duel(StrikePractice.getInstance(), var1.getName(), var2.getName());
      var7.setKit(var3);
      var7.setBestOf(new BestOf(var5));
      var7.setArena(var4);
      FightRequest.addDuelRequest(var2, new DuelRequest(var1, var2, var7));
      if (!var6) {
         ga.strikepractice.fights.duel.c.a(var1, var2, var7.getKit(), var4);
      }

      return var7;
   }

   @Nullable
   public BattleKit getLastSelectedEditedKit(@NotNull Player var1) {
      b.a var2 = (b.a)b.qQ.get(var1.getUniqueId());
      if (var2 != null) {
         PlayerKits var3 = this.getPlayerKits(var1);
         return var3.getEditedKit(var2.el());
      } else {
         return null;
      }
   }

   public void respawnInFight(@NotNull Player var1) {
      ga.strikepractice.fights.duel.a.w(var1);
   }
}
