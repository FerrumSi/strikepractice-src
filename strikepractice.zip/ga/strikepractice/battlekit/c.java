package ga.strikepractice.battlekit;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.r;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitRunnable;

public class c {
   private static final String cC = "kitdatabase";
   private static int lastIndex;
   private static String cD;
   private final List<BattleKit> cE = new ArrayList();
   private static final String[] cF = new String[]{"skywars", "sumo", "bridge", "bedwars", "sky"};

   public void a(ga.strikepractice.utils.c<Integer> var1) {
      C.c(() -> {
         try {
            YamlConfiguration var2 = YamlConfiguration.loadConfiguration(new InputStreamReader(StrikePractice.getInstance().getResource("kitdatabase.dat"), StandardCharsets.UTF_8));
            Iterator var3 = var2.getList("kits").iterator();

            while(var3.hasNext()) {
               Object var4 = var3.next();
               if (var4 instanceof BattleKit) {
                  this.cE.add((BattleKit)var4);
               }
            }

            (new BukkitRunnable() {
               public void run() {
                  try {
                     var1.run(c.this.cE.size());
                  } catch (Exception var2) {
                  }

               }
            }).runTask(StrikePractice.getInstance());
         } catch (Exception var5) {
         }

      });
   }

   public BattleKit b(String var1) {
      try {
         if (cD != null && !var1.equals(cD)) {
            lastIndex = 0;
         }

         cD = var1;
         ArrayList var2 = new ArrayList();

         Iterator var3;
         BattleKit var4;
         for(var3 = this.cE.iterator(); var3.hasNext(); this.a(var1, var2, var4)) {
            var4 = (BattleKit)var3.next();
            if (var4.getName().equalsIgnoreCase(var1)) {
               var4.setElo(var1.contains("ranked") || var1.contains("elo"));
               if (!var2.contains(var4)) {
                  var2.add(var4);
               }
            }
         }

         var3 = this.cE.iterator();

         while(true) {
            String var5;
            do {
               if (!var3.hasNext()) {
                  var3 = this.cE.iterator();

                  while(var3.hasNext()) {
                     var4 = (BattleKit)var3.next();
                     this.a(var1, var2, var4);
                  }

                  if (var2.size() > 1) {
                     if (var2.size() <= lastIndex) {
                        lastIndex = 0;
                     }

                     BattleKit var7 = (BattleKit)var2.get(lastIndex);
                     ++lastIndex;
                     return var7;
                  }

                  if (!var2.isEmpty()) {
                     return (BattleKit)var2.get(0);
                  }

                  return null;
               }

               var4 = (BattleKit)var3.next();
               var1 = var1.replace("1v1elo", "").replace("elo", "").replace("ranked", "");
               var5 = var4.getName().replace("1v1elo", "").replace("elo", "").replace("ranked", "");
            } while(!var5.equalsIgnoreCase(var1));

            var4.setElo(var1.contains("ranked") || var1.contains("elo"));
            if (!var2.contains(var4)) {
               var2.add(var4);
            }
         }
      } catch (Exception var6) {
         return null;
      }
   }

   private void a(String var1, List<BattleKit> var2, BattleKit var3) {
      String var4 = var3.getName().replace("1v1elo", "").replace("elo", "").replace("ranked", "");
      if (var4.contains(var1) || var1.contains(var4)) {
         var3.setElo(var1.contains("ranked") || var1.contains("elo"));
         if (!var2.contains(var3)) {
            var2.add(var3);
         }
      }

   }

   public BattleKit a(String var1, BattleKit var2) {
      try {
         String var3 = var1.length() > 1 ? var1.substring(0, 1).toUpperCase() + var1.substring(1) : var1.toUpperCase();
         var2.setIcon(r.a(r.h(var2.getIcon()) ? var2.getIcon().getType() : Material.DIAMOND_SWORD, ChatColor.BLUE + "" + ChatColor.BOLD + var3));
         if (!var2.isElo()) {
            var2.setMergedEditor((String)null);
         }

         if (var2.isEditable()) {
            var2.setMergedEditor((String)null);
         }

         Map var4 = var2.serialize();
         var4.put("name", var1);
         return new b(var4);
      } catch (Exception var5) {
         return var2;
      }
   }

   public static boolean c(String var0) {
      String[] var1 = cF;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String var4 = var1[var3];
         if (var0.toLowerCase().contains(var4.toLowerCase())) {
            return true;
         }
      }

      return false;
   }
}
