package ga.strikepractice.battlekit;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.B;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class e {
   public static BattleKit a(BattleKit var0, boolean var1, BattleKitType... var2) {
      List var3 = Arrays.asList(var2);
      return a(var0, (var2x) -> {
         boolean var3x;
         if (var2x.isElo() == var1) {
            Stream var10000 = var2x.getKitTypes().stream();
            Objects.requireNonNull(var3);
            if (var10000.anyMatch(var3::contains)) {
               var3x = true;
               return var3x;
            }
         }

         var3x = false;
         return var3x;
      });
   }

   public static BattleKit a(BattleKit var0, Predicate<BattleKit> var1) {
      if (!var0.isRandomKit()) {
         B.debug("Kit is not a random kit: " + var0.getName());
         return var0;
      } else {
         B.debug("Kit " + var0.getName() + " has random kit enabled... selecting a random one");
         StrikePractice var2 = StrikePractice.getInstance();
         List var3 = (List)var2.kits.stream().filter((var1x) -> {
            return var1x.getIcon() != null && !var1x.isRandomKit() && var1.test(var1x);
         }).collect(Collectors.toList());
         if (var3.isEmpty()) {
            throw new IllegalArgumentException("No kits found for random kit: " + var0.getName());
         } else {
            return (BattleKit)var3.get(StrikePractice.t.nextInt(var3.size()));
         }
      }
   }
}
