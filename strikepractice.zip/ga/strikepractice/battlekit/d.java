package ga.strikepractice.battlekit;

import ga.strikepractice.StrikePractice;
import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;

public class d {
   private final StrikePractice cI;
   private YamlConfiguration aO;
   private File aN;

   public d(StrikePractice var1) {
      this.cI = var1;
      this.at();
   }

   private void at() {
      this.aN = new File(this.cI.getDataFolder(), "kits.yml");
      if (!this.aN.exists()) {
         this.cI.saveResource("kits.yml", false);
      }

      this.aO = YamlConfiguration.loadConfiguration(this.aN);
   }

   public File av() {
      return this.aN;
   }

   public YamlConfiguration au() {
      return this.aO;
   }

   public void save() {
      try {
         this.au().save(this.av());
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }
}
