package ga.strikepractice.battlekit;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.events.KitDeselectEvent;
import ga.strikepractice.utils.l;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.potion.PotionEffect;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@APIClass
public interface BattleKit extends ConfigurationSerializable {
   String CURRENT_KIT = "StrikPracticeCurrentBattleKit";
   String BATTLE_KIT_HORSE = "StrikPracticeBattleKitHorse";

   @Nullable
   static BattleKit getKit(String var0) {
      Iterator var1 = StrikePractice.getInstance().kits.iterator();

      BattleKit var2;
      do {
         if (!var1.hasNext()) {
            return null;
         }

         var2 = (BattleKit)var1.next();
      } while(!var2.getName().equalsIgnoreCase(var0));

      return var2;
   }

   @Nullable
   static BattleKit getKit(Player var0, ItemStack var1, boolean var2) {
      StrikePractice var3 = StrikePractice.getInstance();
      BattleKit var4 = var3.Y().getPlayerKits(var0).getCustomKit();
      if (var4 != null && var4.getIcon() != null && var1.equals(var4.getIcon())) {
         return var4;
      } else {
         Iterator var5 = getKits(var1).iterator();

         BattleKit var6;
         do {
            if (!var5.hasNext()) {
               return null;
            }

            var6 = (BattleKit)var5.next();
         } while((!var6.isElo() || !var2) && var6.isElo());

         return var6;
      }
   }

   @Nullable
   static BattleKit getKit(ItemStack var0) {
      Iterator var1 = StrikePractice.getInstance().kits.iterator();

      BattleKit var2;
      do {
         do {
            do {
               do {
                  if (!var1.hasNext()) {
                     return null;
                  }

                  var2 = (BattleKit)var1.next();
               } while(var2.getIcon() == null);
            } while(!var2.getIcon().getType().equals(var0.getType()));
         } while(var2.getIcon().getDurability() != var0.getDurability());
      } while(var2.getIcon().getItemMeta().hasDisplayName() && var0.getItemMeta().hasDisplayName() && !var2.getIcon().getItemMeta().getDisplayName().equals(var0.getItemMeta().getDisplayName()));

      return var2;
   }

   static List<BattleKit> getKits(ItemStack var0) {
      ArrayList var1 = new ArrayList(1);
      if (var0 == null) {
         return var1;
      } else {
         Iterator var2 = StrikePractice.getInstance().kits.iterator();

         while(true) {
            BattleKit var3;
            do {
               do {
                  do {
                     do {
                        do {
                           if (!var2.hasNext()) {
                              return var1;
                           }

                           var3 = (BattleKit)var2.next();
                        } while(var3.getIcon() == null);
                     } while(var3.getIcon().getType() == null);
                  } while(!var3.getIcon().getType().equals(var0.getType()));
               } while(var3.getIcon().getDurability() != var0.getDurability());
            } while(var3.getIcon().getItemMeta().hasDisplayName() && !var3.getIcon().getItemMeta().getDisplayName().equals(var0.getItemMeta().getDisplayName()));

            var1.add(var3);
         }
      }
   }

   @Nullable
   static BattleKit getCurrentKit(@NotNull Metadatable var0) {
      if (var0.hasMetadata("StrikPracticeCurrentBattleKit")) {
         MetadataValue var1 = StrikePractice.getInstance().a(var0, "StrikPracticeCurrentBattleKit");
         if (var1 != null && var1.value() != null && var1.value() instanceof BattleKit) {
            return (BattleKit)var1.value();
         }
      }

      return null;
   }

   static void deselectKit(Player var0) {
      BattleKit var1 = getCurrentKit(var0);
      KitDeselectEvent var2 = new KitDeselectEvent(var0);
      Bukkit.getPluginManager().callEvent(var2);
      if (!var2.isCancelled()) {
         if (var1 != null && var1.isHorse()) {
            Iterator var3 = Bukkit.getWorlds().iterator();

            while(var3.hasNext()) {
               World var4 = (World)var3.next();
               Iterator var5 = var4.getEntitiesByClass(Horse.class).iterator();

               while(var5.hasNext()) {
                  Horse var6 = (Horse)var5.next();
                  if (var6.hasMetadata("StrikPracticeBattleKitHorse")) {
                     MetadataValue var7 = StrikePractice.getInstance().a((Metadatable)var6, (String)"StrikPracticeBattleKitHorse");
                     if (var7 != null && var7.value() != null && var7.asString().equals(var0.getName())) {
                        var6.remove();
                     }
                  }
               }
            }
         }

         StrikePractice var8 = StrikePractice.getInstance();
         var0.setMaximumNoDamageTicks(BattleKit.a.bI);
         var0.removeMetadata("StrikPracticeCurrentBattleKit", var8);
         ga.strikepractice.o.b.aL(var0);
      }
   }

   static BattleKit createKit(String var0) {
      return new b(var0);
   }

   void saveForStrikePractice();

   boolean removeFromStrikePractice();

   boolean isStrikePracticeKit();

   void giveKitMeta(Metadatable var1);

   void giveKit(Player var1);

   /** @deprecated */
   @Deprecated
   HashSet<Material> getBlocks();

   Set<Material> getBlockMaterials();

   void fillEmptySlotsWithAir();

   boolean canBreakBlock(Block var1);

   void setOnlyBow(boolean var1);

   void setBoots(ItemStack var1);

   /** @deprecated */
   @Deprecated
   HashSet<BattleKitType> getTypes();

   Set<BattleKitType> getKitTypes();

   void setTypes(Set<BattleKitType> var1);

   void setChestplate(ItemStack var1);

   void setHelmet(ItemStack var1);

   void setLeggings(ItemStack var1);

   boolean isChestAccess();

   void setChestAccess(boolean var1);

   String getMergedEditor();

   void setMergedEditor(String var1);

   void setInventory(List<ItemStack> var1);

   void setBestOf(int var1);

   int getBestOf();

   void setBlockDisappear(int var1);

   int getBlockDisappear();

   void setPearlCooldown(int var1);

   int getPearlCooldown();

   void setNoDamage(boolean var1);

   boolean isNoDamage();

   void setAutoTNT(boolean var1);

   boolean isAutoTNT();

   void setShootFireballs(boolean var1);

   boolean isShootFireballs();

   void setTNTJumps(boolean var1);

   boolean isTNTJumps();

   void setFireballJumps(boolean var1);

   boolean isFireballJumps();

   boolean isEditable();

   void setEditable(boolean var1);

   void setPotions(Collection<PotionEffect> var1);

   void setBuild(boolean var1);

   void setName(String var1);

   ItemStack getBoots();

   ItemStack getLeggings();

   ItemStack getChestplate();

   ItemStack getHelmet();

   List<ItemStack> getInventory();

   ItemStack[] getInv();

   Collection<PotionEffect> getPotions();

   ItemStack getIcon();

   boolean isAnticheatProtected();

   void setAnticheatProtected(boolean var1);

   void setIcon(ItemStack var1);

   String getName();

   boolean isOnlyBow();

   void setCombo(boolean var1);

   void setElo(boolean var1);

   void setHorse(boolean var1);

   boolean isCombo();

   /** @deprecated */
   @Deprecated
   HashSet<Material> getRollbackExtraMaterials();

   Set<Material> getExtraMaterials();

   Set<String> getExtraMaterialNames();

   void addExtraRollbackMaterial(Material var1);

   void addExtraRollbackMaterial(String var1);

   void setRollbackExtraMaterials(Set<Material> var1);

   boolean isElo();

   boolean isHorse();

   void setNoHunger(boolean var1);

   boolean isNoHunger();

   boolean isBuild();

   boolean isStickSpawn();

   boolean isBedwars();

   void setBedwars(boolean var1);

   boolean isBridges();

   void setBridges(boolean var1);

   boolean isParkour();

   void setParkour(boolean var1);

   boolean isHealthbar();

   void setHealthbar(boolean var1);

   boolean isNoFallDamage();

   void setNoFallDamage(boolean var1);

   void setStickSpawn(boolean var1);

   boolean isNoBestOfRollback();

   void setNoDeathCountdown(boolean var1);

   void setNoBestOfRollback(boolean var1);

   boolean isNoDeathCountdown();

   void sendFightInfo(Player var1);

   String getFancyName();

   void giveKitStuff(Player var1, BattleKit var2);

   boolean isBoxing();

   void setBoxing(boolean var1);

   void setBedExplosion(l var1);

   default boolean isRandomKit() {
      return this.getName().contains("randomkit");
   }

   @Nullable
   l getBedExplosion();

   void setKillRegen(boolean var1);

   boolean isKillRegen();

   public static final class a {
      public static int bH = 3;
      public static int bI = 20;

      private a() {
      }
   }
}
