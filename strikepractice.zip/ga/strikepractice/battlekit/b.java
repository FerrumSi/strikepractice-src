package ga.strikepractice.battlekit;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.ArenaLeaveRunnable;
import ga.strikepractice.events.KitSelectEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.l;
import ga.strikepractice.utils.q;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.x;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.Nullable;

@SerializableAs("BattleKit")
public class b implements BattleKit, ConfigurationSerializable {
   public static final String bO = "ALL_MATERIALS";
   private String name;
   private boolean bP;
   private boolean bQ;
   private boolean bR;
   private boolean bi;
   private boolean bS;
   private boolean bT;
   private boolean bU;
   private boolean bV;
   private boolean bW;
   private boolean bX;
   private boolean bY;
   private boolean bZ;
   private boolean ca;
   private boolean cb;
   private boolean cc;
   private boolean cd;
   private boolean ce;
   private boolean cf;
   private boolean cg;
   private boolean ch;
   private boolean ci;
   private boolean cj;
   private boolean ck;
   private boolean cl;
   private int cm;
   private int cn = 1;
   private int co;
   private l cp;
   private List<ItemStack> cq = new ArrayList(0);
   private String cr;
   private ItemStack helmet;
   private ItemStack chestplate;
   private ItemStack leggings;
   private ItemStack boots;
   private Collection<PotionEffect> cs = new ArrayList(0);
   private ItemStack bh;
   private Set<BattleKitType> ct = new HashSet(0);
   private Set<String> cu = new HashSet(0);
   private boolean cv;
   private Set<String> cw = Collections.emptySet();

   public b(String var1) {
      this.name = var1;
      this.ct.add(BattleKitType.ANY);
      this.fillEmptySlotsWithAir();
   }

   public b(Map<String, Object> var1) {
      if (var1 != null) {
         if (!var1.isEmpty()) {
            Object var2 = var1.get("inventory");
            if (var2 instanceof List) {
               this.cq = (List)var2;
               Iterator var3 = this.cq.iterator();

               while(var3.hasNext()) {
                  ItemStack var4 = (ItemStack)var3.next();
                  if (var4 != null && var4.getAmount() <= 0) {
                     var4.setAmount(1);
                  }
               }

               while(this.getInventory().size() < 36) {
                  this.getInventory().add(new ItemStack(Material.AIR));
               }

               this.cw = this.aF();
            }

            Object var39 = var1.get("helmet");
            if (var39 instanceof ItemStack) {
               if (((ItemStack)var39).getAmount() <= 0) {
                  ((ItemStack)var39).setAmount(1);
               }

               this.helmet = (ItemStack)var39;
            }

            Object var40 = var1.get("chestplate");
            if (var40 instanceof ItemStack) {
               if (((ItemStack)var40).getAmount() <= 0) {
                  ((ItemStack)var40).setAmount(1);
               }

               this.chestplate = (ItemStack)var40;
            }

            Object var5 = var1.get("legs");
            if (var5 instanceof ItemStack) {
               if (((ItemStack)var5).getAmount() <= 0) {
                  ((ItemStack)var5).setAmount(1);
               }

               this.leggings = (ItemStack)var5;
            }

            Object var6 = var1.get("leggings");
            if (var6 instanceof ItemStack) {
               if (((ItemStack)var6).getAmount() <= 0) {
                  ((ItemStack)var6).setAmount(1);
               }

               this.leggings = (ItemStack)var6;
            }

            Object var7 = var1.get("boots");
            if (var7 instanceof ItemStack) {
               if (((ItemStack)var7).getAmount() <= 0) {
                  ((ItemStack)var7).setAmount(1);
               }

               this.boots = (ItemStack)var7;
            }

            Object var8 = var1.get("types");
            if (var8 instanceof String) {
               String[] var9 = ((String)var8).split(", ");
               int var10 = var9.length;

               for(int var11 = 0; var11 < var10; ++var11) {
                  String var12 = var9[var11];

                  try {
                     this.ct.add(BattleKitType.valueOf(var12));
                  } catch (Exception var38) {
                  }
               }
            }

            Object var41 = var1.get("editable");
            if (var41 instanceof Boolean) {
               this.bT = (Boolean)var41;
            }

            Object var42 = var1.get("best-of");
            if (var42 instanceof Integer) {
               this.cn = (Integer)var42;
            }

            Object var43 = var1.get("block-disappear");
            if (var43 instanceof Integer) {
               this.co = (Integer)var43;
            }

            Object var44 = var1.get("pearl-cooldown");
            if (var44 instanceof Integer) {
               this.cm = (Integer)var44;
            }

            Object var13 = var1.get("build");
            if (var13 instanceof Boolean) {
               this.bi = (Boolean)var13;
            }

            Object var14 = var1.get("elo");
            if (var14 instanceof Boolean) {
               this.bS = (Boolean)var14;
            }

            Object var15 = var1.get("horse");
            if (var15 instanceof Boolean) {
               this.bQ = (Boolean)var15;
            }

            Object var16 = var1.get("combo");
            if (var16 instanceof Boolean) {
               this.bR = (Boolean)var16;
            }

            Object var17 = var1.get("stick-spawn");
            if (var17 instanceof Boolean) {
               this.bX = (Boolean)var17;
            }

            Object var18 = var1.get("bedwars");
            if (var18 instanceof Boolean) {
               this.bZ = (Boolean)var18;
            }

            Object var19 = var1.get("parkour");
            if (var19 instanceof Boolean) {
               this.cd = (Boolean)var19;
            }

            Object var20 = var1.get("health-bar");
            if (var20 instanceof Boolean) {
               this.bY = (Boolean)var20;
            }

            Object var21 = var1.get("only-bow");
            if (var21 instanceof Boolean) {
               this.bP = (Boolean)var21;
            }

            Object var22 = var1.get("no-hunger");
            if (var22 instanceof Boolean) {
               this.bW = (Boolean)var22;
            }

            Object var23 = var1.get("chest-access");
            if (var23 instanceof Boolean) {
               this.bU = (Boolean)var23;
            }

            Object var24 = var1.get("anticheat-protected");
            if (var24 instanceof Boolean) {
               this.bV = (Boolean)var24;
            }

            if (var1.get("no-damage") instanceof Boolean) {
               this.cf = (Boolean)var1.get("no-damage");
            }

            if (var1.get("no-fall-damage") instanceof Boolean) {
               this.cg = (Boolean)var1.get("no-fall-damage");
            }

            if (var1.get("kill-regen") instanceof Boolean) {
               this.cl = (Boolean)var1.get("kill-regen");
            }

            if (var1.get("auto-tnt") instanceof Boolean) {
               this.ch = (Boolean)var1.get("auto-tnt");
            }

            if (var1.get("shoot-fireballs") instanceof Boolean) {
               this.cj = (Boolean)var1.get("shoot-fireballs");
            }

            if (var1.get("tnt-jumps") instanceof Boolean) {
               this.ci = (Boolean)var1.get("tnt-jumps");
            }

            if (var1.get("fireball-jumps") instanceof Boolean) {
               this.ck = (Boolean)var1.get("fireball-jumps");
            }

            if (var1.get("bed-explosion") instanceof l) {
               this.cp = (l)var1.get("bed-explosion");
            }

            Object var25 = var1.get("name");
            if (var25 instanceof String) {
               this.name = (String)var25;
            }

            Object var26;
            if (!var1.containsKey("bridges")) {
               this.ca = this.isBedwars() && this.getName().toLowerCase().contains("bridge");
            } else {
               var26 = var1.get("bridges");
               if (var26 instanceof Boolean) {
                  this.ca = (Boolean)var26;
               }
            }

            this.ce = var1.containsKey("boxing") && (Boolean)var1.get("boxing");
            var26 = var1.get("no-death-countdown");
            if (var26 instanceof Boolean) {
               this.cb = (Boolean)var26;
            } else {
               this.cb = this.name.contains("mlg") || this.name.contains("bridge");
            }

            Object var27 = var1.get("no-bestof-rollback");
            if (var27 instanceof Boolean) {
               this.cc = (Boolean)var27;
            } else {
               this.cc = this.name.contains("bridge");
            }

            Object var28 = var1.get("merged-editable-kit");
            if (var28 instanceof String) {
               this.cr = (String)var28;
            }

            Object var29 = var1.get("potions");
            if (var29 instanceof Collection) {
               ArrayList var30 = new ArrayList();
               Iterator var31 = ((Collection)var29).iterator();

               while(var31.hasNext()) {
                  Object var32 = var31.next();
                  if (var32 instanceof PotionEffect) {
                     var30.add((PotionEffect)var32);
                  }
               }

               this.cs = var30;
            }

            Object var45 = var1.get("icon");
            if (var45 instanceof ItemStack) {
               this.bh = (ItemStack)var45;
               if (this.bh.getAmount() <= 0) {
                  this.bh.setAmount(1);
               }
            }

            Object var46 = var1.get("extra-rollback-materials");
            if (var46 instanceof String) {
               String[] var47 = ((String)var46).split(",");
               int var33 = var47.length;

               for(int var34 = 0; var34 < var33; ++var34) {
                  String var35 = var47[var34];

                  try {
                     this.cu.add(var35.trim());
                  } catch (Exception var37) {
                     Bukkit.getLogger().warning("Failed to load extra-rollback-materials:" + var14);
                  }
               }

               this.cw = this.aF();
               this.cv = this.cu.contains("ALL_MATERIALS");
            }

            q.f(this.bh);
         }
      }
   }

   public static BattleKit c(Map<String, Object> var0) {
      return new b(var0);
   }

   public static BattleKit d(Map<String, Object> var0) {
      return new b(var0);
   }

   public Map<String, Object> serialize() {
      HashMap var1 = new HashMap();
      var1.put("name", this.name);
      if (this.bh != null) {
         ItemMeta var2 = this.bh.getItemMeta();

         try {
            ItemMeta var3 = var2.clone();
            var3.getItemFlags().clear();
            this.bh.setItemMeta(var3);
         } catch (Throwable var5) {
         }

         var1.put("icon", this.bh.clone());
         this.bh.setItemMeta(var2);
      }

      if (this.bT) {
         var1.put("editable", this.bT);
      }

      if (this.bR) {
         var1.put("combo", this.bR);
      }

      if (this.bS) {
         var1.put("elo", this.bS);
      }

      if (this.bQ) {
         var1.put("horse", this.bQ);
      }

      if (this.bP) {
         var1.put("only-bow", this.bP);
      }

      if (this.bi) {
         var1.put("build", this.bi);
      }

      if (this.bW) {
         var1.put("no-hunger", this.bW);
      }

      if (this.bU) {
         var1.put("chest-access", this.bU);
      }

      if (this.bV) {
         var1.put("anticheat-protected", this.bV);
      }

      if (this.bX) {
         var1.put("stick-spawn", this.bX);
      }

      if (this.bZ) {
         var1.put("bedwars", this.bZ);
      }

      if (this.ca) {
         var1.put("bridges", this.ca);
      }

      if (this.cd) {
         var1.put("parkour", this.cd);
      }

      if (this.bY) {
         var1.put("health-bar", this.bY);
      }

      if (!this.cs.isEmpty()) {
         var1.put("potions", this.cs);
      }

      if (this.cr != null) {
         var1.put("merged-editable-kit", this.cr);
      }

      HashSet var6 = new HashSet();
      if (!this.ct.isEmpty()) {
         Iterator var7 = this.ct.iterator();

         while(var7.hasNext()) {
            BattleKitType var4 = (BattleKitType)var7.next();
            var6.add(var4.toString());
         }

         var1.put("types", var6.toString().replace("[", "").replace("]", ""));
      }

      if (!this.cu.isEmpty()) {
         var1.put("extra-rollback-materials", String.join(",", this.cu));
      }

      var1.put("no-bestof-rollback", this.cc);
      var1.put("no-death-countdown", this.cb);
      var1.put("helmet", this.helmet);
      var1.put("chestplate", this.chestplate);
      var1.put("leggings", this.leggings);
      var1.put("boots", this.boots);
      var1.put("inventory", this.cq);
      var1.put("best-of", this.cn);
      var1.put("block-disappear", this.co);
      var1.put("boxing", this.ce);
      var1.put("pearl-cooldown", this.cm);
      var1.put("no-damage", this.cf);
      var1.put("no-fall-damage", this.cg);
      var1.put("shoot-fireballs", this.cj);
      var1.put("auto-tnt", this.ch);
      var1.put("tnt-jumps", this.ci);
      var1.put("fireball-jumps", this.ck);
      var1.put("kill-regen", this.cl);
      if (this.cp != null) {
         var1.put("bed-explosion", this.cp);
      }

      return var1;
   }

   public void saveForStrikePractice() {
      StrikePractice.getInstance().kits.add(this);
   }

   public boolean removeFromStrikePractice() {
      StrikePractice var1 = StrikePractice.getInstance();
      if (var1.kits.contains(this)) {
         var1.kits.remove(this);
         return true;
      } else {
         return false;
      }
   }

   public boolean isStrikePracticeKit() {
      return StrikePractice.getInstance().kits.contains(this);
   }

   public void giveKitStuff(final Player var1, BattleKit var2) {
      if (StrikePractice.getInstance().getConfig().getStringList("custom-kit.replaces-kits").contains(var2.getName())) {
         B.debug("Giving custom kit to " + var1.getName() + " because it replaces a kit " + this.getName());
         var2 = StrikePractice.getInstance().Y().getPlayerKits(var1).getCustomKit();
      }

      KitSelectEvent var3 = new KitSelectEvent(var1, this, var2);
      Bukkit.getPluginManager().callEvent(var3);
      if (!var3.isCancelled()) {
         ga.strikepractice.fights.queue.d.b(var1, true);
         final StrikePractice var4 = StrikePractice.getInstance();
         var4.clear(var1, false, true);
         ItemStack[] var5 = var2.getInv();
         int var6 = var5.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            ItemStack var8 = var5[var7];
            if (var8 != null && var8.getAmount() <= 0) {
               var8.setAmount(1);
            }
         }

         var1.getInventory().setContents(var2.getInv());
         var1.getInventory().setHelmet(var2.getHelmet());
         var1.getInventory().setChestplate(var2.getChestplate());
         var1.getInventory().setLeggings(var2.getLeggings());
         var1.getInventory().setBoots(var2.getBoots());
         if (!this.getPotions().isEmpty()) {
            C.a(() -> {
               Iterator var2 = this.getPotions().iterator();

               while(var2.hasNext()) {
                  PotionEffect var3 = (PotionEffect)var2.next();
                  var1.addPotionEffect(var3);
               }

            }, 2L);
         }

         var1.setMaximumNoDamageTicks(this.isCombo() ? BattleKit.a.bH : BattleKit.a.bI);
         if (this.isBedwars() || var4.getConfig().getBoolean("any-kit-colored-armor")) {
            C.a(() -> {
               ga.strikepractice.fights.duel.a.u(var1);
            }, 5L);
         }

         if (this.isHorse()) {
            (new BukkitRunnable() {
               public void run() {
                  if (var1 != null) {
                     if (!var1.getLocation().getChunk().isLoaded()) {
                        var1.getLocation().getChunk().load();
                     }

                     Horse var1x = (Horse)var1.getWorld().spawn(var1.getLocation(), Horse.class);
                     var1x.setAdult();
                     var1x.getInventory().setSaddle(new ItemStack(Material.SADDLE));
                     var1x.getInventory().setArmor(new ItemStack(Material.DIAMOND_BARDING));
                     var1x.setTamed(true);
                     var1x.setOwner(var1);
                     var1x.setPassenger(var1);
                     var1x.setMetadata("StrikPracticeBattleKitHorse", new FixedMetadataValue(var4, var1.getName()));
                  }

               }
            }).runTaskLater(var4, 20L);
         }

         if (var1.getGameMode() != GameMode.SURVIVAL) {
            var1.setGameMode(GameMode.SURVIVAL);
         }

         var1.setMetadata("StrikPracticeCurrentBattleKit", new FixedMetadataValue(var4, this));
         if (this.isHealthbar()) {
            (new BukkitRunnable() {
               public void run() {
                  ga.strikepractice.o.b.aK(var1);
               }
            }).runTaskLater(var4, (long)StrikePractice.t.nextInt(20));
         }

         var1.updateInventory();
      }
   }

   public void giveKitMeta(Metadatable var1) {
      var1.setMetadata("StrikPracticeCurrentBattleKit", new FixedMetadataValue(StrikePractice.getInstance(), this));
   }

   public void giveKit(Player var1) {
      B.debug("giving kit " + this.getName() + " to " + var1.getName());
      if (var1.hasMetadata("ToppeStaffMeta")) {
         try {
            var1.removeMetadata("ToppeStaffVanishMe", Bukkit.getPluginManager().getPlugin("ToppeStaffMode"));
         } catch (Exception var11) {
            Bukkit.getLogger().warning("Couldn't remove ToppeStaffMode vanish metadata from " + var1.getName() + ": the plugin does not exist");
         }

         var1.sendMessage(StrikePractice.getInstance().X() + " Staff mode detected");
         var1.chat("/staff");
      }

      var1.removeMetadata(ArenaLeaveRunnable.aQ, StrikePractice.getInstance());
      KitSelectEvent var3 = new KitSelectEvent(var1, this);
      Bukkit.getPluginManager().callEvent(var3);
      if (!var3.isCancelled()) {
         if (StrikePractice.getInstance().ac().isSpectator(var1)) {
            StrikePractice.getInstance().ac().removeSpectator(var1, false);
         }

         var1.setFlying(false);
         var1.setAllowFlight(false);
         BattleKit var2 = var3.getKit();
         if (var2 != null) {
            Object var5 = null;
            if (this.bT) {
               var5 = this;
            } else if (this.cr != null) {
               BattleKit var6 = BattleKit.getKit(this.cr);
               if (var6 != null && var6.isEditable()) {
                  var5 = var6;
               }
            }

            this.giveKitMeta(var1);
            if (!x.fH() || Bukkit.getPlayer(var1.getUniqueId()) == null) {
               if (var5 != null) {
                  boolean var12 = false;
                  int var7 = 0;

                  for(int var8 = 0; var8 < 9; ++var8) {
                     if (var8 % 2 == 0) {
                        ++var7;
                        String var9 = ((BattleKit)var5).getName() + "-" + var7;
                        BattleKit var10 = StrikePractice.getInstance().Y().getPlayerKits(var1).getEditedKit(var9);
                        if (var10 != null) {
                           var12 = true;
                           var1.getInventory().setItem(var8 == 8 ? 7 : var8, r.a(Material.ENCHANTED_BOOK, var10.getFancyName()));
                        }
                     }
                  }

                  if (var12) {
                     var1.getInventory().setItem(8, r.a(Material.ENCHANTED_BOOK, ga.strikepractice.playerkits.b.b.m((BattleKit)var5)));
                  } else if (StrikePractice.getInstance().getConfig().getBoolean("give-kit-automatically")) {
                     ga.strikepractice.playerkits.b.b.qQ.put(var1.getUniqueId(), new ga.strikepractice.playerkits.b.b.a(AbstractFight.getCurrentFight(var1), var2.getName()));
                     this.giveKitStuff(var1, var2);
                  }

                  return;
               }

               ga.strikepractice.playerkits.b.b.qQ.remove(var1.getUniqueId());
               this.giveKitStuff(var1, var2);
            }

         }
      }
   }

   public HashSet<Material> getBlocks() {
      return (HashSet)this.cw.stream().map(Material::getMaterial).filter(Objects::nonNull).collect(Collectors.toCollection(HashSet::new));
   }

   private Set<String> aF() {
      HashSet var1 = new HashSet();
      boolean var2 = false;
      boolean var3 = false;
      ItemStack[] var4 = this.getInv();
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         ItemStack var7 = var4[var6];
         if (r.h(var7)) {
            if (var7.getType().isBlock()) {
               var1.add(var7.getType().name());
            } else if (var7.getType() != Material.WATER_BUCKET && var7.getType() != Material.WATER) {
               if (var7.getType() != Material.LAVA_BUCKET && var7.getType() != Material.LAVA) {
                  if (var7.getType() != Material.FLINT_AND_STEEL && var7.getType() != Material.FIREBALL) {
                     if (var7.getType() == Material.BOAT) {
                        var1.add(Material.WOOD.name());
                     }
                  } else {
                     var1.add(Material.FIRE.name());
                  }
               } else {
                  var1.add(Material.LAVA.name());
                  var1.add(Material.STATIONARY_LAVA.name());
                  if (var2) {
                     var1.add(Material.OBSIDIAN.name());
                     var1.add(Material.STONE.name());
                     var1.add(Material.COBBLESTONE.name());
                  }

                  var3 = true;
               }
            } else {
               var1.add(Material.WATER.name());
               var1.add(Material.STATIONARY_WATER.name());
               if (var3) {
                  var1.add(Material.OBSIDIAN.name());
                  var1.add(Material.STONE.name());
                  var1.add(Material.COBBLESTONE.name());
               }

               var2 = true;
            }
         }
      }

      var1.addAll(this.cu);
      return var1;
   }

   public Set<Material> getBlockMaterials() {
      return this.getBlocks();
   }

   public Set<String> aG() {
      return this.aF();
   }

   public void fillEmptySlotsWithAir() {
      while(this.getInventory().size() < 36) {
         this.getInventory().add(new ItemStack(Material.AIR));
      }

   }

   public boolean canBreakBlock(Block var1) {
      if (this.cv) {
         return true;
      } else {
         String var2 = r.i(var1);
         String var3 = var2.replace("LEGACY_", "");
         Set var4 = this.getExtraMaterialNames();
         if (!var4.contains(var2) && !var4.contains(var3)) {
            return this.cw.contains(var2) && !this.cw.contains(var3);
         } else {
            return true;
         }
      }
   }

   public void setOnlyBow(boolean var1) {
      this.bP = var1;
   }

   public boolean c(BattleKit var1) {
      if (!var1.getInventory().equals(this.getInventory())) {
         return false;
      } else if (var1.getHelmet() == null && this.getHelmet() != null || this.getHelmet() == null && var1.getHelmet() != null) {
         return false;
      } else if (var1.getChestplate() == null && this.getChestplate() != null || this.getChestplate() == null && var1.getChestplate() != null) {
         return false;
      } else if ((var1.getLeggings() != null || this.getLeggings() == null) && (this.getLeggings() != null || var1.getLeggings() == null)) {
         if ((var1.getBoots() != null || this.getBoots() == null) && (this.getBoots() != null || var1.getBoots() == null)) {
            if (var1.getHelmet().equals(this.getHelmet()) && var1.getChestplate().equals(this.getChestplate()) && var1.getLeggings().equals(this.getLeggings()) && var1.getBoots().equals(this.getBoots())) {
               if (var1.getPotions().size() != this.getPotions().size()) {
                  return false;
               } else if (var1.isNoDamage() == this.isNoDamage() && var1.getPearlCooldown() == this.getPearlCooldown() && var1.isAutoTNT() == this.isAutoTNT() && var1.isShootFireballs() == this.isShootFireballs() && var1.isNoFallDamage() == this.isNoFallDamage() && var1.isKillRegen() == this.isKillRegen()) {
                  if (var1.isBoxing() == this.isBoxing() && var1.isNoBestOfRollback() == this.isNoBestOfRollback() && var1.isNoDeathCountdown() == this.isNoDeathCountdown() && var1.getBlockDisappear() == this.getBlockDisappear()) {
                     Iterator var2 = this.getPotions().iterator();

                     boolean var4;
                     do {
                        if (!var2.hasNext()) {
                           return var1.isBuild() == this.isBuild() && var1.isCombo() == this.isCombo() && var1.isElo() == this.isElo() && var1.isNoHunger() == this.isNoHunger() && var1.isHorse() == this.isHorse() && var1.isOnlyBow() == this.isOnlyBow() && var1.isStickSpawn() == this.isStickSpawn() && var1.isParkour() == this.isParkour() && var1.isBedwars() == this.isBedwars() && var1.isHealthbar() == this.isHealthbar() && var1.isAnticheatProtected() == this.isAnticheatProtected() && var1.isChestAccess() == this.isChestAccess() && var1.isEditable() == this.isEditable();
                        }

                        PotionEffect var3 = (PotionEffect)var2.next();
                        var4 = false;
                        Iterator var5 = var1.getPotions().iterator();

                        while(var5.hasNext()) {
                           PotionEffect var6 = (PotionEffect)var5.next();
                           if (var3.equals(var6)) {
                              var4 = true;
                              break;
                           }
                        }
                     } while(var4);

                     return false;
                  } else {
                     return false;
                  }
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void setBoots(ItemStack var1) {
      this.boots = var1;
   }

   /** @deprecated */
   @Deprecated
   public HashSet<BattleKitType> getTypes() {
      return (HashSet)this.ct;
   }

   public Set<BattleKitType> getKitTypes() {
      return this.ct;
   }

   public void setTypes(Set<BattleKitType> var1) {
      this.ct = var1;
   }

   public void setChestplate(ItemStack var1) {
      this.chestplate = var1;
   }

   public void setHelmet(ItemStack var1) {
      this.helmet = var1;
   }

   public void setLeggings(ItemStack var1) {
      this.leggings = var1;
   }

   public boolean isChestAccess() {
      return this.bU;
   }

   public void setChestAccess(boolean var1) {
      this.bU = var1;
   }

   public String getMergedEditor() {
      return this.cr;
   }

   public void setMergedEditor(String var1) {
      this.cr = var1;
   }

   public void setInventory(List<ItemStack> var1) {
      this.cq = var1;
      this.cw = this.aF();
   }

   public void setBestOf(int var1) {
      this.cn = var1;
   }

   public int getBestOf() {
      return Math.max(this.cn, 1);
   }

   public int getBlockDisappear() {
      return this.co;
   }

   public void setBlockDisappear(int var1) {
      this.co = var1;
   }

   public boolean isEditable() {
      return this.bT;
   }

   public void setEditable(boolean var1) {
      this.bT = var1;
   }

   public void setPotions(Collection<PotionEffect> var1) {
      this.cs = var1;
   }

   public void setBuild(boolean var1) {
      this.bi = var1;
   }

   public void setName(String var1) {
      this.name = var1;
   }

   public ItemStack getBoots() {
      return this.boots;
   }

   public ItemStack getLeggings() {
      return this.leggings;
   }

   public ItemStack getChestplate() {
      return this.chestplate;
   }

   public ItemStack getHelmet() {
      return this.helmet;
   }

   public List<ItemStack> getInventory() {
      return this.cq;
   }

   public ItemStack[] getInv() {
      return (ItemStack[])this.getInventory().toArray(new ItemStack[36]);
   }

   public Collection<PotionEffect> getPotions() {
      return this.cs;
   }

   public ItemStack getIcon() {
      return this.bh;
   }

   public boolean isAnticheatProtected() {
      return this.bV;
   }

   public void setAnticheatProtected(boolean var1) {
      this.bV = var1;
   }

   public void setIcon(ItemStack var1) {
      this.bh = var1;
   }

   public String getName() {
      return this.name;
   }

   public boolean isOnlyBow() {
      return this.bP;
   }

   public void setCombo(boolean var1) {
      this.bR = var1;
   }

   public void setElo(boolean var1) {
      this.bS = var1;
   }

   public void setHorse(boolean var1) {
      this.bQ = var1;
   }

   public boolean isCombo() {
      return this.bR;
   }

   /** @deprecated */
   @Deprecated
   public HashSet<Material> getRollbackExtraMaterials() {
      return (HashSet)this.cu.stream().map(Material::valueOf).collect(Collectors.toCollection(HashSet::new));
   }

   public Set<Material> getExtraMaterials() {
      return (Set)this.cu.stream().map(Material::valueOf).collect(Collectors.toSet());
   }

   public Set<String> getExtraMaterialNames() {
      return this.cu;
   }

   public void addExtraRollbackMaterial(Material var1) {
      this.addExtraRollbackMaterial(var1.name());
   }

   public void addExtraRollbackMaterial(String var1) {
      if (!Objects.equals(var1, Material.WATER_BUCKET.name()) && !Objects.equals(var1, Material.WATER.name())) {
         if (!Objects.equals(var1, Material.LAVA_BUCKET.name()) && !Objects.equals(var1, Material.LAVA.name())) {
            if (!Objects.equals(var1, Material.FLINT_AND_STEEL.name()) && !Objects.equals(var1, Material.FIREBALL.name())) {
               if (Objects.equals(var1, Material.BOAT.name())) {
                  this.cu.add(Material.WOOD.name());
               }
            } else {
               this.cu.add(Material.FIRE.name());
            }
         } else {
            this.cu.add(Material.LAVA.name());
            this.cu.add(Material.STATIONARY_LAVA.name());
         }
      } else {
         this.cu.add(Material.WATER.name());
         this.cu.add(Material.STATIONARY_WATER.name());
      }

      this.cu.add(var1.trim());
      this.cw = this.aF();
      this.cv = this.cu.contains("ALL_MATERIALS");
   }

   public void setRollbackExtraMaterials(Set<Material> var1) {
      this.cu = (Set)var1.stream().map(Enum::name).collect(Collectors.toSet());
      this.cw = this.aF();
      this.cv = this.cu.contains("ALL_MATERIALS");
   }

   public boolean isElo() {
      return this.bS;
   }

   public boolean isHorse() {
      return this.bQ;
   }

   public void setNoHunger(boolean var1) {
      this.bW = var1;
   }

   public boolean isNoHunger() {
      return this.bW;
   }

   public boolean isBuild() {
      return this.bi;
   }

   public boolean isStickSpawn() {
      return this.bX;
   }

   public boolean isBedwars() {
      return this.bZ;
   }

   public void setBedwars(boolean var1) {
      this.bZ = var1;
   }

   public boolean isBridges() {
      return this.ca;
   }

   public void setBridges(boolean var1) {
      this.ca = var1;
   }

   public boolean isParkour() {
      return this.cd;
   }

   public void setParkour(boolean var1) {
      this.cd = var1;
   }

   public boolean isHealthbar() {
      return this.bY;
   }

   public void setHealthbar(boolean var1) {
      this.bY = var1;
   }

   public void setStickSpawn(boolean var1) {
      this.bX = var1;
   }

   public boolean isNoBestOfRollback() {
      return this.cc;
   }

   public void setNoDeathCountdown(boolean var1) {
      this.cb = var1;
   }

   public void setNoBestOfRollback(boolean var1) {
      this.cc = var1;
   }

   public boolean isNoDeathCountdown() {
      return this.cb;
   }

   public void setBoxing(boolean var1) {
      this.ce = var1;
   }

   public void setBedExplosion(l var1) {
      this.cp = var1;
   }

   @Nullable
   public l getBedExplosion() {
      return this.cp;
   }

   public boolean isBoxing() {
      return this.ce;
   }

   public int getPearlCooldown() {
      return this.cm;
   }

   public void setPearlCooldown(int var1) {
      this.cm = var1;
   }

   public void setNoDamage(boolean var1) {
      this.cf = var1;
   }

   public boolean isNoDamage() {
      return this.cf;
   }

   public void setNoFallDamage(boolean var1) {
      this.cg = var1;
   }

   public boolean isNoFallDamage() {
      return this.cg;
   }

   public void setAutoTNT(boolean var1) {
      this.ch = var1;
   }

   public boolean isAutoTNT() {
      return this.ch;
   }

   public boolean isShootFireballs() {
      return this.cj;
   }

   public void setShootFireballs(boolean var1) {
      this.cj = var1;
   }

   public void setTNTJumps(boolean var1) {
      this.ci = var1;
   }

   public boolean isTNTJumps() {
      return this.ci;
   }

   public void setFireballJumps(boolean var1) {
      this.ck = var1;
   }

   public boolean isFireballJumps() {
      return this.ck;
   }

   public void setKillRegen(boolean var1) {
      this.cl = var1;
   }

   public boolean isKillRegen() {
      return this.cl;
   }

   public void sendFightInfo(Player var1) {
      StrikePractice var2 = StrikePractice.getInstance();
      if (this.isBuild()) {
         var2.a(var1, "fight-start-message.build");
      }

      if (this.isHorse()) {
         var2.a(var1, "fight-start-message.horse");
      }

      if (this.isCombo()) {
         var2.a(var1, "fight-start-message.combo");
      }

      if (this.isOnlyBow()) {
         var2.a(var1, "fight-start-message.only-bow");
      }

   }

   public String getFancyName() {
      return this.bh != null && this.bh.hasItemMeta() && this.bh.getItemMeta().hasDisplayName() ? this.bh.getItemMeta().getDisplayName() : this.name;
   }
}
