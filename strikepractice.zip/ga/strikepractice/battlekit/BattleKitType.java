package ga.strikepractice.battlekit;

import ga.strikepractice.api.APIClass;
import java.util.Arrays;
import java.util.Optional;

@APIClass
public enum BattleKitType {
   ANY,
   DUEL,
   BOT_FIGHT,
   QUEUE,
   PARTY_VS_PARTY,
   PARTY_FFA,
   PARTY_SPLIT,
   PREMIUM_QUEUE,
   PARTY_QUEUE,
   BRACKETS,
   LMS,
   NONE;

   public static BattleKitType byName(String var0) {
      Optional var1 = Arrays.stream(values()).filter((var1x) -> {
         return var1x.toString().equalsIgnoreCase(var0);
      }).findFirst();
      if (var1.isPresent()) {
         return (BattleKitType)var1.get();
      } else if (var0.contains("any")) {
         return ANY;
      } else if (var0.contains("ffa")) {
         return PARTY_FFA;
      } else if (var0.contains("split")) {
         return PARTY_SPLIT;
      } else if (var0.contains("party")) {
         return PARTY_VS_PARTY;
      } else if (var0.contains("2v2") || var0.contains("party") && var0.contains("queue")) {
         return PARTY_QUEUE;
      } else if (var0.contains("duel")) {
         return DUEL;
      } else if (var0.contains("bot")) {
         return BOT_FIGHT;
      } else if (var0.contains("queue")) {
         return QUEUE;
      } else if (var0.contains("premium")) {
         return PREMIUM_QUEUE;
      } else {
         return var0.contains("none") ? NONE : null;
      }
   }

   // $FF: synthetic method
   private static BattleKitType[] $values() {
      return new BattleKitType[]{ANY, DUEL, BOT_FIGHT, QUEUE, PARTY_VS_PARTY, PARTY_FFA, PARTY_SPLIT, PREMIUM_QUEUE, PARTY_QUEUE, BRACKETS, LMS, NONE};
   }
}
