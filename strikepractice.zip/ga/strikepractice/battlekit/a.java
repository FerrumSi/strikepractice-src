package ga.strikepractice.battlekit;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.playerkits.PlayerKits;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.K;
import ga.strikepractice.utils.h;
import ga.strikepractice.utils.r;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class a implements CommandExecutor, TabCompleter {
   private static final String bJ = (String)Arrays.stream(BattleKitType.values()).map(Object::toString).collect(Collectors.joining("|"));
   private final StrikePractice bK;

   public a(StrikePractice var1) {
      this.bK = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 1 && var4[0].equalsIgnoreCase("give")) {
         BattleKit var18 = BattleKit.getKit(var4[1]);
         if (var18 == null) {
            var1.sendMessage(ChatColor.RED + "Kit not found.");
            return true;
         } else {
            Player var36 = var1 instanceof Player ? (Player)var1 : null;
            if (var4.length > 2) {
               var36 = Bukkit.getPlayer(var4[2]);
            }

            if (var36 == null) {
               var1.sendMessage(ChatColor.RED + "That player is not online");
               return true;
            } else {
               var1.sendMessage(ChatColor.RED + "Giving the kit to " + var36.getName() + ".");
               var18.giveKitStuff(var36, var18);
               return true;
            }
         }
      } else {
         if (var1 instanceof Player) {
            final Player var5 = (Player)var1;
            if (var4.length == 0) {
               var5.sendMessage(ChatColor.GRAY + "Remember to reload the plugin or restart the server to to take effect with queue system.");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit create <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit delete <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit setIcon <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit setinv <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit bow <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit elo <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit horse <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit combo <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit nohunger <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit editable <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit types <kit name> <" + bJ + ">");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit types <kit name> clear");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit extramaterial <kit name> [material or \"all\"] - Add extra material players can break (hold in hand or type in the command)");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit extramaterial <kit name> clear");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit info <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit preview <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit list");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit give <kit name> player");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit deleteeditedkits <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit mergeeditedkits <kit name> <editable kit>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit mergeeditedkits <kit name> clear");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit chestaccess <kit name> (access chests in kit editor)");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit copy <kit name> [1v1|premium|identifier]");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit moveup <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit movedown <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit stickspawn <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit healthbar <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit bridges <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit bedwars <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit parkour <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit bestof <kit name> <best of x rounds>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit deathcountdown <kit name> - (countdown when respawning)");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit bestofreset <kit name> - (whether arenas reset between rounds)");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit boxing <kit name> - (hit 100 times to kill)");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit nodamage <kit name> - (hit but deal no damage, e.g. for sumo)");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit pearlcooldown <kit name> <seconds | -1 | 0>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit blockdisappear <kit name> <seconds | 0> - (blocks disappear after x seconds)");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit autotnt <kit name> (TNT ignites automatically)");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit tntjumps <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit shootfireballs <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit fireballjumps <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit nofalldamage <kit name>");
               var5.sendMessage(ChatColor.GOLD + "/Battlekit killregen <kit name> (reset inventory and health on kill)");
               var5.sendMessage(ChatColor.RED + "NEW: Create a random queue kit by having 'randomkit' in the kit name");
            } else {
               BattleKit var7;
               if (var4.length > 1) {
                  String var6;
                  c var8;
                  if (var4[0].equalsIgnoreCase("redo")) {
                     var6 = var4[1].toLowerCase();
                     var7 = BattleKit.getKit(var6);
                     if (var7 == null) {
                        var5.sendMessage(ChatColor.RED + "Kit not found.");
                        return true;
                     }

                     this.bK.kits.remove(var7);
                     if (BattleKit.getKit(var6) != null) {
                        var5.sendMessage(ChatColor.RED + "That kit already exists.");
                        return true;
                     }

                     if (!K.ac(var4[1])) {
                        var5.sendMessage(ChatColor.RED + "The name must be alphanumeric!");
                        return true;
                     }

                     var5.sendMessage(ChatColor.BLUE + "Creating a new loadout: " + var4[1]);
                     var8 = new c();
                     var8.a((var4x) -> {
                        BattleKit var5x = var8.b(var6);
                        if (var5x != null) {
                           this.a(var5, var6, var8, var5x);
                        }

                     });
                  } else if (var4[0].equalsIgnoreCase("create")) {
                     var6 = var4[1].toLowerCase();
                     if (BattleKit.getKit(var6) != null) {
                        var5.sendMessage(ChatColor.RED + "That kit already exists.");
                        return true;
                     }

                     if (!K.ac(var4[1])) {
                        var5.sendMessage(ChatColor.RED + "The name must be alphanumeric!");
                        return true;
                     }

                     var5.sendMessage(ChatColor.BLUE + "Creating a new kit: " + var4[1]);
                     c var20 = new c();
                     var20.a((var4x) -> {
                        BattleKit var5x = var20.b(var6);
                        if (var5x != null) {
                           this.a(var5, var6, var20, var5x);
                        }

                     });
                  } else {
                     final BattleKit var19;
                     if (var4[0].equalsIgnoreCase("mergeeditedkits")) {
                        if (var4.length > 2) {
                           if (var4[2].equalsIgnoreCase("clear")) {
                              var19 = BattleKit.getKit(var4[1]);
                              if (var19 == null) {
                                 var5.sendMessage(ChatColor.RED + "Kit not found.");
                                 return true;
                              }

                              var19.setMergedEditor((String)null);
                              var5.sendMessage(ChatColor.BLUE + "Merged Kit editor cleared!");
                              return true;
                           }

                           var19 = BattleKit.getKit(var4[1]);
                           if (var19 == null) {
                              var5.sendMessage(ChatColor.RED + "Kit not found.");
                              return true;
                           }

                           var7 = BattleKit.getKit(var4[2]);
                           if (var7 == null) {
                              var5.sendMessage(ChatColor.RED + "Kit not found.");
                              return true;
                           }

                           var19.setMergedEditor(var7.getName());
                           var5.sendMessage(ChatColor.BLUE + "Edited versions of '" + var7.getName() + "' will load when giving '" + var19.getName() + "'.");
                        } else {
                           var5.sendMessage(ChatColor.GOLD + "/Battlekit mergeeditedkits <kit name> <editable kit>");
                        }
                     } else if (var4[0].equalsIgnoreCase("deleteeditedkits")) {
                        var19 = BattleKit.getKit(var4[1]);
                        if (var19 == null) {
                           var5.sendMessage(ChatColor.RED + "Kit not found.");
                           return true;
                        }

                        var5.sendMessage(ChatColor.GOLD + "Starting to delete edited kits...");
                        C.c(new Runnable() {
                           int counter = 0;

                           public void run() {
                              OfflinePlayer[] var1 = Bukkit.getOfflinePlayers();
                              int var2 = var1.length;

                              for(int var3 = 0; var3 < var2; ++var3) {
                                 OfflinePlayer var4 = var1[var3];
                                 PlayerKits var5x = a.this.bK.Y().g(var4.getUniqueId());
                                 if (var5x.removeEditedKits(var19.getName())) {
                                    var5x.savePlayerKitsToFile();
                                    B.debug("Deleted edited kit '" + var19.getName() + "' from " + var4.getName() + "'s playerkits and saved it.");
                                    UUID var6 = var5x.getPlayer();
                                    if (var6 != null) {
                                       Player var7 = Bukkit.getPlayer(var6);
                                       if (var7 != null) {
                                          a.this.bK.Y().a(var7, var5x);
                                       }
                                    }

                                    ++this.counter;
                                 }
                              }

                              Bukkit.getScheduler().runTask(a.this.bK, () -> {
                                 Bukkit.getLogger().info(ChatColor.GOLD + "Succesfully deleted " + this.counter + " edited kits!");
                                 if (var5 != null) {
                                    var5.sendMessage(ChatColor.GOLD + "Succesfully deleted " + this.counter + " edited kits!");
                                 }

                              });
                           }
                        });
                     } else {
                        String var23;
                        if (var4[0].equalsIgnoreCase("extramaterial")) {
                           var19 = BattleKit.getKit(var4[1]);
                           if (var19 == null) {
                              var5.sendMessage(ChatColor.RED + "Kit not found.");
                              return true;
                           }

                           if (var4.length >= 3 && var4[2].equalsIgnoreCase("clear")) {
                              var19.setRollbackExtraMaterials(new HashSet());
                              var5.sendMessage(ChatColor.RED + "Extra materials cleared!");
                           } else if (var4.length >= 3 && var4[2].equalsIgnoreCase("all")) {
                              var19.getExtraMaterialNames().clear();
                              var19.addExtraRollbackMaterial("ALL_MATERIALS");
                              var5.sendMessage(ChatColor.BLUE + "All current extra rollback materials of the kit: " + var19.getExtraMaterialNames().toString().replace("[", "").replace("]", ""));
                              var5.sendMessage(ChatColor.RED + "All blocks added!");
                              var5.sendMessage(ChatColor.RED + "Note this only added 1.8.8 items. Add newer ones manually!");
                           } else if (var4.length >= 3) {
                              Material var21 = Material.matchMaterial(var4[2].toUpperCase());
                              var19.addExtraRollbackMaterial(var4[2].toUpperCase());
                              var5.sendMessage(ChatColor.BLUE + "The extra material '" + var4[2].toUpperCase() + "' has been added! Player's can now break this block and it will rollback.");
                              var5.sendMessage(ChatColor.BLUE + "All current extra rollback materials of the kit: " + var19.getExtraMaterialNames().toString().replace("[", "").replace("]", ""));
                              if (var21 == null) {
                                 var5.sendMessage(ChatColor.RED + "Note: the item was unknown for 1.8 materials! This may be expected if you added a newer item. Otherwise, use correct names.");
                              }
                           } else {
                              var23 = r.i(var5.getItemInHand());
                              B.debug("Material in hand (raw): " + var23);
                              if (!var23.equals("AIR") && !var23.equals("LEGACY_AIR")) {
                                 var19.addExtraRollbackMaterial(var23);
                                 var5.sendMessage(ChatColor.BLUE + "The extra material '" + var23 + "' has been added! Player's can now break this block and it will rollback.");
                                 var5.sendMessage(ChatColor.BLUE + "All current extra rollback materials of the kit: " + var19.getExtraMaterialNames().toString().replace("[", "").replace("]", ""));
                              } else {
                                 var5.sendMessage(ChatColor.RED + "Hold something in your hand");
                                 var5.sendMessage(ChatColor.BLUE + "All current extra rollback materials of the kit: " + var19.getExtraMaterialNames().toString().replace("[", "").replace("]", ""));
                              }
                           }
                        } else {
                           int var22;
                           int var24;
                           if (var4[0].equalsIgnoreCase("moveup")) {
                              var19 = BattleKit.getKit(var4[1]);
                              if (var19 == null) {
                                 var5.sendMessage(ChatColor.RED + "Kit not found.");
                                 return true;
                              }

                              var24 = this.bK.kits.indexOf(var19);
                              var22 = var24 - 1;
                              if (var24 >= 0 && var24 < this.bK.kits.size() && var22 >= 0 && var22 < this.bK.kits.size()) {
                                 Collections.swap(this.bK.kits, var24, var22);
                                 var5.sendMessage(ChatColor.GOLD + "Moved the kit from " + var24 + " to " + var22 + "!");
                              } else {
                                 var5.sendMessage(ChatColor.RED + "Can not move the kit anymore, it already has the first position!");
                              }
                           } else if (var4[0].equalsIgnoreCase("movedown")) {
                              var19 = BattleKit.getKit(var4[1]);
                              if (var19 == null) {
                                 var5.sendMessage(ChatColor.RED + "Kit not found.");
                                 return true;
                              }

                              var24 = this.bK.kits.indexOf(var19);
                              var22 = var24 + 1;
                              if (var24 >= 0 && var24 < this.bK.kits.size() && var22 >= 0 && var22 < this.bK.kits.size()) {
                                 Collections.swap(this.bK.kits, var24, var22);
                                 var5.sendMessage(ChatColor.GOLD + "Moved the kit from " + var24 + " to " + var22 + "!");
                              } else {
                                 var5.sendMessage(ChatColor.RED + "Can not move the kit anymore, it already has the last position!");
                              }
                           } else if (!var4[0].equalsIgnoreCase("seticon") && !var4[0].equalsIgnoreCase("icon")) {
                              String var27;
                              if ((var4[0].equalsIgnoreCase("rankedcopy") || var4[0].equalsIgnoreCase("copy")) && var4.length > 1) {
                                 var19 = BattleKit.getKit(var4[1]);
                                 if (var19 == null) {
                                    var5.sendMessage(ChatColor.RED + "Kit not found.");
                                    return true;
                                 }

                                 if (var19.getIcon() == null) {
                                    var5.sendMessage(ChatColor.RED + "The kit doesn't have an icon.");
                                    return true;
                                 }

                                 var23 = var4[0].equalsIgnoreCase("copy") ? "copy" : "elo";
                                 if (var4.length > 2) {
                                    var23 = var23 + var4[2];
                                 }

                                 var27 = var19.getName() + var23;
                                 if (BattleKit.getKit(var27) != null) {
                                    var5.sendMessage(ChatColor.RED + "That kit already exists!");
                                    return true;
                                 }

                                 b var31 = new b(var27);
                                 var31.setInventory(new ArrayList(var19.getInventory()));
                                 var31.setHelmet(var19.getHelmet() == null ? null : var19.getHelmet().clone());
                                 var31.setChestplate(var19.getChestplate() == null ? null : var19.getChestplate().clone());
                                 var31.setLeggings(var19.getLeggings() == null ? null : var19.getLeggings().clone());
                                 var31.setBoots(var19.getBoots() == null ? null : var19.getBoots().clone());
                                 var31.setTypes(var19.getTypes());
                                 var31.setBuild(var19.isBuild());
                                 var31.setChestAccess(var19.isChestAccess());
                                 var31.setCombo(var19.isCombo());
                                 var31.setBedwars(var19.isBedwars());
                                 var31.setBridges(var19.isBridges());
                                 var31.setHorse(var19.isHorse());
                                 var31.setOnlyBow(var19.isOnlyBow());
                                 var31.setNoHunger(var19.isNoHunger());
                                 var31.setElo(var4[0].toLowerCase().contains("ranked"));
                                 var31.setBestOf(var19.getBestOf());
                                 var31.setNoDamage(var19.isNoDamage());
                                 var31.setShootFireballs(var19.isShootFireballs());
                                 var31.setTNTJumps(var19.isTNTJumps());
                                 var31.setFireballJumps(var19.isFireballJumps());
                                 var31.setAutoTNT(var19.isAutoTNT());
                                 var31.setNoFallDamage(var19.isNoFallDamage());
                                 var31.setKillRegen(var19.isKillRegen());
                                 var31.setPearlCooldown(var19.getPearlCooldown());
                                 if (var19.isEditable()) {
                                    var31.setMergedEditor(var19.getName());
                                    var5.sendMessage(ChatColor.BLUE + "Edited kits have been merged. Only " + var19.getName() + " is editable and the edited version will be given when giving " + var31.getName() + " (new copy).");
                                 }

                                 ItemStack var29 = var19.getIcon().clone();
                                 ItemMeta var32 = var29.getItemMeta();
                                 if (var32.hasDisplayName()) {
                                    var32.setDisplayName(var19.getIcon().getItemMeta().getDisplayName() + "");
                                 } else {
                                    var32.setDisplayName(var31.getFancyName());
                                 }

                                 var29.setItemMeta(var32);
                                 var31.setIcon(var29);
                                 var31.saveForStrikePractice();
                                 boolean var34 = false;
                                 Iterator var13 = this.bK.M.iterator();

                                 while(var13.hasNext()) {
                                    Arena var14 = (Arena)var13.next();
                                    if (var14.getKits().contains(var19.getName())) {
                                       var14.getKits().add(var27);
                                       var34 = true;
                                    }
                                 }

                                 if (var34) {
                                    var5.sendMessage(ChatColor.GREEN + "Arena kits have been updated automatically!");
                                 }

                                 var5.sendMessage(ChatColor.GREEN + "Successfully created a ranked copy of " + var19.getFancyName() + ChatColor.RESET + "" + ChatColor.GREEN + "(" + var19.getName() + ")");
                                 if (var27.contains("premium")) {
                                    var31.getTypes().add(BattleKitType.PREMIUM_QUEUE);
                                    var5.sendMessage(ChatColor.RED + "Automatically made the kit premium kit");
                                 }
                              } else if (var4[0].equalsIgnoreCase("preview")) {
                                 var19 = BattleKit.getKit(var4[1]);
                                 if (var19 == null) {
                                    var5.sendMessage(ChatColor.RED + "Kit not found.");
                                    return true;
                                 }

                                 ga.strikepractice.m.a.a(var5, var19, this.bK);
                              } else if (!var4[0].equalsIgnoreCase("info") && !var4[0].equalsIgnoreCase("show")) {
                                 if (var4[0].equalsIgnoreCase("setinv")) {
                                    var19 = BattleKit.getKit(var4[1]);
                                    if (var19 == null) {
                                       var5.sendMessage(ChatColor.RED + "Kit not found.");
                                       return true;
                                    }

                                    boolean var28 = var19.getInventory().stream().anyMatch(r::h);
                                    var19.setHelmet(var5.getInventory().getHelmet());
                                    var19.setChestplate(var5.getInventory().getChestplate());
                                    var19.setLeggings(var5.getInventory().getLeggings());
                                    var19.setBoots(var5.getInventory().getBoots());
                                    var19.getInventory().clear();
                                    var19.setInventory(new ArrayList(Arrays.asList(r.ba(var5))));
                                    var19.setPotions(var5.getActivePotionEffects());
                                    var5.sendMessage(ChatColor.BLUE + "You have updated potion effects, armor and inventory contents of the kit.");
                                    if (var28) {
                                       var5.sendMessage(ChatColor.RED + "The kit was edited but player kits (kit editor kits) weren't affected. Use \"/battlekit deleteeditedkits " + var19.getName() + "\" to delete all player kits.");
                                    }
                                 } else if (var4[0].equalsIgnoreCase("delete")) {
                                    var19 = BattleKit.getKit(var4[1]);
                                    if (var19 == null) {
                                       var5.sendMessage(ChatColor.RED + "Kit not found.");
                                       return true;
                                    }

                                    this.bK.kits.remove(var19);
                                    var5.sendMessage(ChatColor.BLUE + "Deleted a BattleKit.");
                                 } else if (var4[0].equalsIgnoreCase("bestof")) {
                                    var19 = BattleKit.getKit(var4[1]);
                                    if (var19 == null) {
                                       var5.sendMessage(ChatColor.RED + "Kit not found.");
                                       return true;
                                    }

                                    if (var4.length > 2) {
                                       try {
                                          var24 = Integer.parseInt(var4[2]);
                                          if (var24 < 1) {
                                             var5.sendMessage(ChatColor.RED + "The number should be greater than 0");
                                          } else {
                                             var19.setBestOf(var24);
                                             var5.sendMessage(ChatColor.BLUE + "The kit is now best of " + var24 + " (best of only works in duels)");
                                          }
                                       } catch (Exception var17) {
                                          var5.sendMessage(ChatColor.GRAY + "/battlekit bestof <kit name> <number>");
                                       }
                                    } else {
                                       var5.sendMessage(ChatColor.GRAY + "/battlekit bestof <kit name> <number>");
                                    }
                                 } else if (var4[0].equalsIgnoreCase("blockdisappear")) {
                                    var19 = BattleKit.getKit(var4[1]);
                                    if (var19 == null) {
                                       var5.sendMessage(ChatColor.RED + "Kit not found.");
                                       return true;
                                    }

                                    if (var4.length > 2) {
                                       try {
                                          var24 = Integer.parseInt(var4[2]);
                                          var19.setBlockDisappear(var24 * 20);
                                          if (var24 > 0) {
                                             var5.sendMessage(ChatColor.BLUE + "The blocks in the kit will disappear in " + var24 + " seconds");
                                             if (!var19.isBuild()) {
                                                var5.sendMessage(ChatColor.RED + "Note: use /battlekit build <kit> to enable build. Otherwise players won't be able to build with this kit.");
                                             }
                                          } else {
                                             var5.sendMessage(ChatColor.BLUE + "The blocks will no longer disappear.");
                                          }
                                       } catch (Exception var16) {
                                          var5.sendMessage(ChatColor.GRAY + "/battlekit blockdisappear <kit name> <seconds | 0>");
                                       }
                                    } else {
                                       var5.sendMessage(ChatColor.GRAY + "/battlekit blockdisappear <kit name> <seconds | 0>");
                                    }
                                 } else if (!var4[0].equalsIgnoreCase("cooldown") && !var4[0].equalsIgnoreCase("pearlcooldown")) {
                                    if (var4[0].equalsIgnoreCase("rename")) {
                                       var19 = BattleKit.getKit(var4[1]);
                                       if (var19 == null) {
                                          var5.sendMessage(ChatColor.RED + "Kit not found.");
                                          return true;
                                       }

                                       var23 = var19.getName();
                                       var19.setName(var4[2].toLowerCase());
                                       var5.sendMessage(ChatColor.RED + "Kit " + var23 + " was renamed: " + var19.getName());
                                       var5.sendMessage(ChatColor.GRAY + "This may cause issues with /arena kits, player kits (if editable), merged kits (e.g ranked and unranked kits) and other configurations. (Anyway, restarting is recommended)");
                                    } else if (var4[0].equalsIgnoreCase("types")) {
                                       var19 = BattleKit.getKit(var4[1]);
                                       if (var19 == null) {
                                          var5.sendMessage(ChatColor.RED + "Kit not found.");
                                          return true;
                                       }

                                       var7 = null;
                                       var8 = null;
                                       if (var4.length <= 2) {
                                          var5.sendMessage(ChatColor.GRAY + "/battlekit types <kit name> <" + bJ + ">");
                                          var5.sendMessage(ChatColor.GRAY + "/battlekit types <kit name> clear");
                                          return true;
                                       }

                                       var27 = var4[2].toLowerCase();
                                       if (var27.contains("clear")) {
                                          var19.getTypes().clear();
                                          var5.sendMessage(ChatColor.RED + "Kit types cleared!");
                                          return true;
                                       }

                                       BattleKitType var33 = BattleKitType.byName(var27.replace("!", ""));
                                       if (var33 == null) {
                                          var5.sendMessage(ChatColor.RED + "Invalid type!");
                                          var5.sendMessage(ChatColor.GRAY + "/battlekit types <kit name> <" + bJ + ">");
                                          var5.sendMessage(ChatColor.GRAY + "/battlekit types <kit name> clear");
                                       } else {
                                          var19.getTypes().remove(BattleKitType.ANY);
                                          if (!var27.startsWith("!")) {
                                             var19.getTypes().add(var33);
                                             var5.sendMessage(ChatColor.BLUE + "Kit type added! All types: " + var19.getTypes().toString().replace("[", "").replace("]", ""));
                                          } else {
                                             BattleKitType[] var30 = BattleKitType.values();
                                             int var10 = var30.length;

                                             for(int var11 = 0; var11 < var10; ++var11) {
                                                BattleKitType var12 = var30[var11];
                                                if (!var12.equals(var33) && !var12.equals(BattleKitType.ANY) && !var12.equals(BattleKitType.PREMIUM_QUEUE) && !var12.equals(BattleKitType.NONE)) {
                                                   var19.getTypes().add(var12);
                                                }
                                             }

                                             var5.sendMessage(ChatColor.BLUE + "Kit types added! All types: " + var19.getTypes().toString().replace("[", "").replace("]", ""));
                                          }

                                          if (var33 == BattleKitType.PREMIUM_QUEUE && !var19.isElo()) {
                                             var19.setElo(true);
                                             var5.sendMessage(ChatColor.RED + "The kit is now an elo kit. Premium matches are always ranked!");
                                          }
                                       }
                                    } else if (!var4[0].equalsIgnoreCase("toggleeditable") && !var4[0].equalsIgnoreCase("editable")) {
                                       if (!var4[0].equalsIgnoreCase("nodamage") && !var4[0].equalsIgnoreCase("damage")) {
                                          if (!var4[0].equalsIgnoreCase("nofalldamage") && !var4[0].equalsIgnoreCase("falldamage")) {
                                             if (var4[0].equalsIgnoreCase("killregen")) {
                                                var19 = BattleKit.getKit(var4[1]);
                                                if (var19 == null) {
                                                   var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                   return true;
                                                }

                                                var19.setKillRegen(!var19.isKillRegen());
                                                var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " reset inventory and heal on kill: " + var19.isKillRegen());
                                             } else if (var4[0].equalsIgnoreCase("autotnt")) {
                                                var19 = BattleKit.getKit(var4[1]);
                                                if (var19 == null) {
                                                   var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                   return true;
                                                }

                                                var19.setAutoTNT(!var19.isAutoTNT());
                                                var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " auto-TNT: " + var19.isAutoTNT());
                                             } else if (var4[0].equalsIgnoreCase("tntjumps")) {
                                                var19 = BattleKit.getKit(var4[1]);
                                                if (var19 == null) {
                                                   var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                   return true;
                                                }

                                                var19.setTNTJumps(!var19.isTNTJumps());
                                                var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " TNT Jumps: " + var19.isTNTJumps());
                                             } else if (var4[0].equalsIgnoreCase("shootfireballs")) {
                                                var19 = BattleKit.getKit(var4[1]);
                                                if (var19 == null) {
                                                   var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                   return true;
                                                }

                                                var19.setShootFireballs(!var19.isShootFireballs());
                                                var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " shoots fireballs: " + var19.isShootFireballs());
                                             } else if (var4[0].equalsIgnoreCase("fireballjumps")) {
                                                var19 = BattleKit.getKit(var4[1]);
                                                if (var19 == null) {
                                                   var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                   return true;
                                                }

                                                var19.setFireballJumps(!var19.isFireballJumps());
                                                var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " fireball jumps: " + var19.isFireballJumps());
                                             } else if (!var4[0].toLowerCase().contains("anticheat") && !var4[0].toLowerCase().contains("cheatbreaker") && !var4[0].toLowerCase().contains("strikecheat")) {
                                                if (!var4[0].equalsIgnoreCase("stickspawn") && !var4[0].toLowerCase().contains("freeze") && !var4[0].equalsIgnoreCase("stickyspawn")) {
                                                   if (!var4[0].equalsIgnoreCase("deathcountdown") && !var4[0].equalsIgnoreCase("respawncountdown")) {
                                                      if (var4[0].equalsIgnoreCase("bestofreset")) {
                                                         var19 = BattleKit.getKit(var4[1]);
                                                         if (var19 == null) {
                                                            var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                            return true;
                                                         }

                                                         var19.setNoBestOfRollback(!var19.isNoBestOfRollback());
                                                         var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is reset between rounds: " + !var19.isNoBestOfRollback());
                                                      } else if (!var4[0].equalsIgnoreCase("bridge") && !var4[0].equalsIgnoreCase("bridges") && !var4[0].equalsIgnoreCase("mlgrush")) {
                                                         if (var4[0].equalsIgnoreCase("bedwars")) {
                                                            var19 = BattleKit.getKit(var4[1]);
                                                            if (var19 == null) {
                                                               var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                               return true;
                                                            }

                                                            var19.setBedwars(!var19.isBedwars());
                                                            var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is bedwars: " + var19.isBedwars());
                                                            var5.sendMessage(ChatColor.YELLOW + "Place beds (or portals) near both spawn locations.");
                                                            ga.strikepractice.utils.d.b(var5, ChatColor.GRAY + "Click here to toggle whether there's countdown when you die", "/battlekit deathcountdown " + var19.getName());
                                                         } else if (var4[0].equalsIgnoreCase("parkour")) {
                                                            var19 = BattleKit.getKit(var4[1]);
                                                            if (var19 == null) {
                                                               var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                               return true;
                                                            }

                                                            var19.setParkour(!var19.isParkour());
                                                            var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is parkour: " + var19.isParkour());
                                                            var5.sendMessage(ChatColor.YELLOW + "Place pressure plates in the finish line.");
                                                         } else if (var4[0].equalsIgnoreCase("boxing")) {
                                                            var19 = BattleKit.getKit(var4[1]);
                                                            if (var19 == null) {
                                                               var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                               return true;
                                                            }

                                                            var19.setBoxing(!var19.isBoxing());
                                                            var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is boxing: " + var19.isBoxing());
                                                            var5.sendMessage(ChatColor.YELLOW + "If you hit someone 100 times they will die.");
                                                         } else if (var4[0].equalsIgnoreCase("healthbar")) {
                                                            var19 = BattleKit.getKit(var4[1]);
                                                            if (var19 == null) {
                                                               var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                            } else {
                                                               var19.setHealthbar(!var19.isHealthbar());
                                                               var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " has health bar activated: " + var19.isHealthbar());
                                                            }
                                                         } else if (!var4[0].equalsIgnoreCase("togglebow") && !var4[0].equalsIgnoreCase("bow")) {
                                                            if (!var4[0].equalsIgnoreCase("hunger") && !var4[0].equalsIgnoreCase("nohunger")) {
                                                               if (!var4[0].equalsIgnoreCase("chestaccess") && !var4[0].equalsIgnoreCase("chest")) {
                                                                  if (!var4[0].equalsIgnoreCase("toggleelo") && !var4[0].equalsIgnoreCase("elo")) {
                                                                     if (!var4[0].equalsIgnoreCase("togglehorse") && !var4[0].equalsIgnoreCase("horse")) {
                                                                        if (!var4[0].equalsIgnoreCase("togglecombo") && !var4[0].equalsIgnoreCase("combo")) {
                                                                           if (var4[0].equalsIgnoreCase("togglebuild") || var4[0].equalsIgnoreCase("build")) {
                                                                              var19 = BattleKit.getKit(var4[1]);
                                                                              if (var19 == null) {
                                                                                 var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                                                 return true;
                                                                              }

                                                                              var19.setBuild(!var19.isBuild());
                                                                              var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is build: " + var19.isBuild());
                                                                           }
                                                                        } else {
                                                                           var19 = BattleKit.getKit(var4[1]);
                                                                           if (var19 == null) {
                                                                              var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                                              return true;
                                                                           }

                                                                           var19.setCombo(!var19.isCombo());
                                                                           var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is combo: " + var19.isCombo());
                                                                        }
                                                                     } else {
                                                                        var19 = BattleKit.getKit(var4[1]);
                                                                        if (var19 == null) {
                                                                           var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                                           return true;
                                                                        }

                                                                        var19.setHorse(!var19.isHorse());
                                                                        var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is horse: " + var19.isHorse());
                                                                     }
                                                                  } else {
                                                                     var19 = BattleKit.getKit(var4[1]);
                                                                     if (var19 == null) {
                                                                        var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                                        return true;
                                                                     }

                                                                     var19.setElo(!var19.isElo());
                                                                     var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is elo: " + var19.isElo());
                                                                     if (var19.isElo() && this.bK.H) {
                                                                        this.bK.O.d(var19);
                                                                        var5.sendMessage(ChatColor.RED + "Restart the server to make sure SQL database works.");
                                                                        this.bK.aq().aK();
                                                                     }
                                                                  }
                                                               } else {
                                                                  var19 = BattleKit.getKit(var4[1]);
                                                                  if (var19 == null) {
                                                                     var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                                     return true;
                                                                  }

                                                                  var19.setChestAccess(!var19.isChestAccess());
                                                                  var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " has chest access: " + var19.isChestAccess());
                                                               }
                                                            } else {
                                                               var19 = BattleKit.getKit(var4[1]);
                                                               if (var19 == null) {
                                                                  var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                                  return true;
                                                               }

                                                               var19.setNoHunger(!var19.isNoHunger());
                                                               var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is no-hunger: " + var19.isNoHunger());
                                                            }
                                                         } else {
                                                            var19 = BattleKit.getKit(var4[1]);
                                                            if (var19 == null) {
                                                               var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                               return true;
                                                            }

                                                            var19.setOnlyBow(!var19.isOnlyBow());
                                                            var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is only bow: " + var19.isOnlyBow());
                                                         }
                                                      } else {
                                                         var19 = BattleKit.getKit(var4[1]);
                                                         if (var19 == null) {
                                                            var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                            return true;
                                                         }

                                                         var19.setBridges(!var19.isBridges());
                                                         var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is bridges: " + var19.isBridges());
                                                         var5.sendMessage(ChatColor.YELLOW + "Place portals near both spawn locations.");
                                                         var5.sendMessage(ChatColor.GRAY + "TIP: You can use /battlekit bestofreset <kit> to disable rollback between rounds.");
                                                      }
                                                   } else {
                                                      var19 = BattleKit.getKit(var4[1]);
                                                      if (var19 == null) {
                                                         var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                         return true;
                                                      }

                                                      var19.setNoDeathCountdown(!var19.isNoDeathCountdown());
                                                      var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is death countdown: " + !var19.isNoDeathCountdown());
                                                   }
                                                } else {
                                                   var19 = BattleKit.getKit(var4[1]);
                                                   if (var19 == null) {
                                                      var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                      return true;
                                                   }

                                                   var19.setStickSpawn(!var19.isStickSpawn());
                                                   var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is sticky spawn: " + var19.isStickSpawn());
                                                }
                                             } else {
                                                var19 = BattleKit.getKit(var4[1]);
                                                if (var19 == null) {
                                                   var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                   return true;
                                                }

                                                var19.setAnticheatProtected(!var19.isAnticheatProtected());
                                                var5.sendMessage(ChatColor.BLUE + "(removed feature) Kit " + var19.getName() + " is StrikeCheat protected: " + var19.isAnticheatProtected());
                                             }
                                          } else {
                                             var19 = BattleKit.getKit(var4[1]);
                                             if (var19 == null) {
                                                var5.sendMessage(ChatColor.RED + "Kit not found.");
                                                return true;
                                             }

                                             var19.setNoFallDamage(!var19.isNoFallDamage());
                                             var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " no fall damage: " + var19.isNoFallDamage());
                                          }
                                       } else {
                                          var19 = BattleKit.getKit(var4[1]);
                                          if (var19 == null) {
                                             var5.sendMessage(ChatColor.RED + "Kit not found.");
                                             return true;
                                          }

                                          var19.setNoDamage(!var19.isNoDamage());
                                          var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " no damage (but allow hits): " + var19.isNoDamage());
                                       }
                                    } else {
                                       var19 = BattleKit.getKit(var4[1]);
                                       if (var19 == null) {
                                          var5.sendMessage(ChatColor.RED + "Kit not found.");
                                          return true;
                                       }

                                       var19.setEditable(!var19.isEditable());
                                       var5.sendMessage(ChatColor.BLUE + "Kit " + var19.getName() + " is editable: " + var19.isEditable());
                                    }
                                 } else {
                                    var19 = BattleKit.getKit(var4[1]);
                                    if (var19 == null) {
                                       var5.sendMessage(ChatColor.RED + "Kit not found.");
                                       return true;
                                    }

                                    if (var4.length > 2) {
                                       try {
                                          var24 = Integer.parseInt(var4[2]);
                                          var5.sendMessage(ChatColor.GRAY + "-1 to disable pearl cooldown for this kit");
                                          var5.sendMessage(ChatColor.GRAY + "0 to use the default cooldown");
                                          if (var24 < -1) {
                                             var5.sendMessage(ChatColor.RED + "Invalid option: " + var24 + " (must be -1 or greater)");
                                          } else {
                                             var19.setPearlCooldown(var24);
                                             var5.sendMessage(ChatColor.BLUE + "Kit pearl cooldown set to " + var24);
                                          }
                                       } catch (Exception var15) {
                                          var5.sendMessage(ChatColor.GRAY + "/battlekit pearlcooldown <kit name> <number>");
                                       }
                                    } else {
                                       var5.sendMessage(ChatColor.GRAY + "/battlekit pearlcooldown <kit name> <number>");
                                    }
                                 }
                              } else {
                                 var19 = BattleKit.getKit(var4[1]);
                                 if (var19 == null) {
                                    var5.sendMessage(ChatColor.RED + "Kit not found.");
                                    return true;
                                 }

                                 var5.sendMessage(ChatColor.GOLD + "BattleKit Info: " + var19.getName());
                                 var5.sendMessage(ChatColor.YELLOW + "Types: " + var19.getTypes().toString().replace("[", "").replace("]", ""));
                                 var5.sendMessage(ChatColor.YELLOW + "Merged Editor: " + var19.getMergedEditor());
                                 var5.sendMessage(ChatColor.YELLOW + "Build: " + var19.isBuild());
                                 var5.sendMessage(ChatColor.YELLOW + "Combo: " + var19.isCombo());
                                 var5.sendMessage(ChatColor.YELLOW + "Horse: " + var19.isHorse());
                                 var5.sendMessage(ChatColor.YELLOW + "Bow Only: " + var19.isOnlyBow());
                                 var5.sendMessage(ChatColor.YELLOW + "Elo: " + var19.isElo());
                                 var5.sendMessage(ChatColor.YELLOW + "Players can edit: " + var19.isEditable());
                                 var5.sendMessage(ChatColor.YELLOW + "Chest access: " + var19.isChestAccess());
                                 var5.sendMessage(ChatColor.YELLOW + "No hunger: " + var19.isNoHunger());
                                 var5.sendMessage(ChatColor.YELLOW + "Best of: " + var19.getBestOf());
                                 var5.sendMessage(ChatColor.YELLOW + "Stick spawn: " + var19.isStickSpawn());
                                 var5.sendMessage(ChatColor.YELLOW + "Health bar: " + var19.isHealthbar());
                                 var5.sendMessage(ChatColor.YELLOW + "Parkour: " + var19.isParkour());
                                 var5.sendMessage(ChatColor.YELLOW + "Bedwars: " + var19.isBedwars());
                                 var5.sendMessage(ChatColor.YELLOW + "Respawn countdown: " + !var19.isNoDeathCountdown());
                                 var5.sendMessage(ChatColor.YELLOW + "Bridges: " + var19.isBridges());
                                 var5.sendMessage(ChatColor.YELLOW + "No damage (e.g sumo): " + var19.isNoDamage());
                                 var5.sendMessage(ChatColor.YELLOW + "No fall damage: " + var19.isNoFallDamage());
                                 var5.sendMessage(ChatColor.YELLOW + "Auto Ignite TNT: " + var19.isAutoTNT());
                                 var5.sendMessage(ChatColor.YELLOW + "Shoot Fireballs: " + var19.isShootFireballs());
                                 var5.sendMessage(ChatColor.YELLOW + "Reset inventory and heal on kill: " + var19.isKillRegen());
                                 var5.sendMessage(ChatColor.YELLOW + "Pearl Cooldown: " + var19.getPearlCooldown() + "s " + ChatColor.GRAY + (var19.getPearlCooldown() == 0 ? "(default " + ga.strikepractice.e.b.aZ() + "s, -1 to disable)" : "(-1 to disable)"));
                                 var23 = var19.getBlockDisappear() == 0 ? "(disabled)" : "";
                                 var5.sendMessage(ChatColor.YELLOW + "Blocks disappear: " + var19.getBlockDisappear() / 20 + "s " + var23);
                              }
                           } else {
                              var19 = BattleKit.getKit(var4[1]);
                              if (var19 == null) {
                                 var5.sendMessage(ChatColor.RED + "Kit not found.");
                                 return true;
                              }

                              if (!r.h(var5.getItemInHand())) {
                                 var5.sendMessage(ChatColor.RED + "Hold something in your hand.");
                                 return true;
                              }

                              ItemStack var26 = var5.getItemInHand().clone();
                              ItemMeta var25 = var26.getItemMeta();
                              if (!var25.hasDisplayName()) {
                                 var5.sendMessage(ChatColor.RED + "The item does not have a name. Using " + var19.getFancyName() + ChatColor.RESET + ChatColor.GRAY + ". You can rename the icon with /sprac rename &6example_name");
                              }

                              if (!var25.hasDisplayName()) {
                                 String var9 = var19.getName();
                                 if (var9.length() > 1) {
                                    var9 = var9.substring(0, 1).toUpperCase() + var9.substring(1);
                                 }

                                 var9 = var9.replace("uhc", "UHC").replace("_", " ").replace("ranked", "Ranked");
                                 var25.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + var9);
                                 var5.sendMessage(ChatColor.RED + "The item doesn't have a displayname. Creating default: " + var25.getDisplayName());
                              }

                              var26.setItemMeta(var25);
                              var19.setIcon(var26);
                              var5.sendMessage(ChatColor.BLUE + "Icon set.");
                           }
                        }
                     }
                  }
               } else if (var4.length == 1 && var4[0].equalsIgnoreCase("list")) {
                  if (this.bK.kits.size() == 0) {
                     var5.sendMessage(ChatColor.RED + "No kits found!");
                     return true;
                  }

                  var1.sendMessage(ChatColor.GOLD + "BattleKit List - Total Kits: " + this.bK.kits.size());
                  Iterator var35 = this.bK.kits.iterator();

                  while(var35.hasNext()) {
                     var7 = (BattleKit)var35.next();
                     var1.sendMessage(ChatColor.YELLOW + "- " + var7.getName() + ChatColor.RESET + "(" + ChatColor.RESET + var7.getFancyName() + ChatColor.RESET + ")");
                  }
               }
            }
         }

         return true;
      }
   }

   private void a(Player var1, String var2, c var3, BattleKit var4) {
      b var5 = new b(var2);
      var5.setHelmet(var1.getInventory().getHelmet());
      var5.setChestplate(var1.getInventory().getChestplate());
      var5.setLeggings(var1.getInventory().getLeggings());
      var5.setBoots(var1.getInventory().getBoots());
      var5.getInventory().clear();
      var5.setInventory(new ArrayList(Arrays.asList(r.ba(var1))));
      var5.setPotions(var1.getActivePotionEffects());
      BattleKit var10 = var3.a(var2, var4);
      var10.giveKitStuff(var1, var10);
      var10.saveForStrikePractice();
      var1.updateInventory();
      var1.sendMessage(ChatColor.YELLOW + "--------------------------------");
      var1.sendMessage(ChatColor.GREEN + "Automatically created a kit based on its name. You can edit it with /Battlekit commands.");
      var1.chat("/battlekit info " + var2);
      ga.strikepractice.utils.d.b(var1, ChatColor.RED + "" + ChatColor.BOLD + "Click here to get generate a new loadout", "/battlekit redo " + var2);
      var1.sendMessage("");
      ga.strikepractice.utils.d.b(var1, ChatColor.GOLD + "Click here to save the loadout.", "/battlekit setinv " + var2);
      var1.sendMessage("");
      if (!var10.isElo()) {
         ga.strikepractice.utils.d.b(var1, ChatColor.GOLD + "Or click here to create ranked version of the kit.", "/battlekit rankedcopy " + var2);
      }

      if (var2.contains("build")) {
         var10.setBuild(true);
         var1.sendMessage(ChatColor.RED + "Automatically set 'build: true' because the kit name contains 'build'.");
      }

      if (var2.contains("bedwars")) {
         var10.setBedwars(true);
         var1.sendMessage(ChatColor.RED + "Automatically set 'bedwars: true' because the kit name contains 'bedwars'.");
      }

      if (var2.contains("parkour")) {
         var10.setParkour(true);
         var1.sendMessage(ChatColor.RED + "Automatically set 'parkour: true' because the kit name contains 'parkour'.");
      }

      if (var2.endsWith("bo3") || var2.contains("bestof")) {
         var10.setBestOf(3);
         var1.sendMessage(ChatColor.RED + "Automatically set the kit to be best of 3 rounds.");
      }

      if (var10.isElo() && this.bK.H) {
         var1.sendMessage(ChatColor.RED + "Restart the server to make sure SQL database works.");
         this.bK.aq().aK();
      }

      String[] var6 = ga.strikepractice.arena.a.aH;
      int var7 = var6.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         String var9 = var6[var8];
         if (var2.contains(var9)) {
            var1.sendMessage(ChatColor.GREEN + "Seems like this kit will need its own arenas. Do not forget to set /arena kits. Otherwise this kit may use any arena.");
            return;
         }
      }

   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length == 2) {
         return (List)this.bK.kits.stream().map(BattleKit::getName).filter((var1x) -> {
            return var1x.toLowerCase().contains(var4[1].toLowerCase());
         }).sorted(new h(var4[1])).collect(Collectors.toList());
      } else {
         return var4.length == 1 ? (List)Stream.of("create", "delete", "seticon", "setinv", "bow", "elo", "horse", "combo", "nohunger", "editable", "types", "extramaterial", "info", "preview", "list", "give", "deleteeditedkits", "chestaccess", "copy", "moveup", "movedown", "stickspawn", "healthbar", "bridges", "bedwars", "mergeeditedkits", "deathcountdown", "bestofreset", "pearlcooldown", "nodamage", "nofalldamage", "shootfireballs", "fireballjumps", "tntjumps", "autotnt", "blockdisappear", "killregen", "build", "parkour").filter((var1x) -> {
            return var1x.toLowerCase().contains(var4[0].toLowerCase());
         }).sorted(new h(var4[0])).collect(Collectors.toList()) : null;
      }
   }
}
