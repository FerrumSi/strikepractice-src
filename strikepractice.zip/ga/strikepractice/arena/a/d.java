package ga.strikepractice.arena.a;

import net.minecraft.server.v1_8_R3.Block;
import net.minecraft.server.v1_8_R3.BlockPosition;
import net.minecraft.server.v1_8_R3.Chunk;
import net.minecraft.server.v1_8_R3.IBlockData;
import net.minecraft.server.v1_8_R3.WorldServer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;

public class d implements ga.strikepractice.arena.a.a {
   private int br = 0;

   public void a(Location var1, Material var2, byte var3) {
      if (!var1.getChunk().isLoaded()) {
         ++this.br;
         var1.getChunk().load(false);
         if (this.br % 250 == 0 && this.br > 5000) {
            Bukkit.getLogger().warning("StrikePractice needs to do a lot of chunk loading when resetting arenas. Consider changing chunk gc/unload settings or trying 'experimental-chunk-updater: false'");
         }
      }

      World var4 = var1.getWorld();
      int var5 = var1.getBlockX();
      int var6 = var1.getBlockY();
      int var7 = var1.getBlockZ();
      WorldServer var8 = ((CraftWorld)var4).getHandle();
      Chunk var9 = var8.getChunkAt(var5 >> 4, var7 >> 4);
      BlockPosition var10 = new BlockPosition(var5, var6, var7);
      IBlockData var11 = Block.getByCombinedId(var2.getId() + (var3 << 12));
      var9.a(var10, var11);
   }
}
