package ga.strikepractice.arena.a;

import ga.strikepractice.arena.CachedBlockChange;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.D;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

public interface a {
   void a(Location var1, Material var2, byte var3);

   default void a(CachedBlockChange var1) {
      Location var2 = var1.getLocation();
      if (B.fR()) {
         Block var3 = var2.getBlock();
         B.trace("Resetting block change " + var1 + " at " + new D(var2) + " from " + var3.getType() + ":" + var3.getData() + " to " + var1.getOldMaterial() + ":" + var1.getOldData());
      }

      this.a(var2, var1.getOldMaterial(), (byte)var1.getOldData());
   }
}
