package ga.strikepractice.arena.a;

import org.bukkit.Location;
import org.bukkit.Material;

public class c implements ga.strikepractice.arena.a.a {
   public void a(Location var1, Material var2, byte var3) {
      var1.getBlock().setType(var2);
      var1.getBlock().setData(var3);
      var1.getBlock().getState().update(false);
   }
}
