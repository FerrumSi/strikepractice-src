package ga.strikepractice.arena.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.Q;
import org.bukkit.Bukkit;

public final class b {
   private static final ga.strikepractice.arena.a.a bp = new c();
   private static ga.strikepractice.arena.a.a bq;

   public static ga.strikepractice.arena.a.a d(boolean var0) {
      if (var0) {
         return bp;
      } else {
         if (bq == null) {
            if (aB()) {
               bq = new d();
               if (ga.strikepractice.arena.c.aV < 5) {
                  Bukkit.getLogger().info(String.format("The experimental block updater has about x4 better performance. It's recommended you increase the current reset value (max-block-changes-per-tick-per-arena in the config.yml) from %d to between %d and 50. You may decrease it if it causes lag.", ga.strikepractice.arena.c.aV, ga.strikepractice.arena.c.aV * 5));
               }
            } else {
               Bukkit.getLogger().info("Not using NMS block resetting even though it's available.experimental-block-updater is set to false");
            }

            if (bq == null) {
               bq = bp;
            }

            Bukkit.getLogger().info("Using " + bq.getClass().getName() + " block updater");
            Bukkit.getLogger().warning("If you experience problems with arena rollback, toggle 'experimental-block-updater: <false/true>' in the config.yml");
         }

         return bq;
      }
   }

   public static boolean aB() {
      StrikePractice var0 = StrikePractice.getInstance();
      return Q.vX.contains("1_8_R3") && var0.getConfig().getBoolean("experimental-block-updater");
   }
}
