package ga.strikepractice.arena;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.Fight;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

@APIClass
public interface Arena extends ConfigurationSerializable {
   void saveForStrikePractice();

   boolean removeFromStrikePractice();

   boolean canRollback();

   void rollbackArena(Fight var1);

   void quickRollback();

   void setUsing(boolean var1, Fight var2);

   boolean isUsing();

   boolean isBuild();

   boolean isFFA();

   boolean isEventArena();

   void setFFA(boolean var1);

   boolean needsRollback();

   void setBuild(boolean var1);

   Location getLoc1();

   Location getLoc2();

   Location getCenter();

   boolean hasWall();

   List<String> getKits();

   void setUsing(boolean var1);

   void setKits(List<String> var1);

   String getName();

   String getOriginalName();

   String getDisplayName();

   void setDisplayName(String var1);

   void setLoc1(Location var1);

   void setLoc2(Location var1);

   void setCorner1(Location var1);

   void setCorner2(Location var1);

   Location getCorner1();

   Location getCorner2();

   boolean hasCornersSet();

   void setCurrentFight(Fight var1);

   void setCenter(Location var1);

   Fight getCurrentFight();

   int getCustomMaxChangesPerTick();

   void setCustomMaxChangesPerTick(int var1);

   void sendPossibleWrongWorldInfo(Player var1);

   void removeItems();

   ItemStack getIcon();

   void setIcon(ItemStack var1);
}
