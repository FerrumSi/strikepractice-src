package ga.strikepractice.arena;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.duel.BestOfFight;
import ga.strikepractice.fights.other.FFAFight;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.q;
import ga.strikepractice.utils.t;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Explosive;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Item;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

@SerializableAs("Arena")
public class c implements Arena, ConfigurationSerializable {
   private static final String[] aT = new String[]{"brackets", "sumoevent", "koth"};
   private static final String aU;
   public static int aV;
   public static boolean aW;
   public static boolean aX;
   public static int aY;
   public static BattleKit aZ;
   private int ba;
   private Location bb;
   private Location bc;
   private Location bd;
   private Location be;
   private Location bf;
   private String name;
   private String bg;
   private ItemStack bh;
   private boolean bi;
   private boolean bj;
   private List<String> kits = new ArrayList();
   private transient boolean bk;
   private transient boolean bl;
   private transient Fight bm;
   private transient Set<Chunk> bn = Collections.emptySet();
   private final transient boolean bo = StrikePractice.getInstance().getConfig().getBoolean("remove-drops-on-fight-start", true);

   public c(String var1) {
      this.name = var1;
   }

   public c(Map<String, Object> var1) {
      if (var1 != null) {
         if (!var1.isEmpty()) {
            if (var1.containsKey("name") && var1.get("name") instanceof String) {
               this.name = (String)var1.get("name");
            }

            if (var1.containsKey("display-name") && var1.get("display-name") instanceof String) {
               this.bg = f.K((String)var1.get("display-name"));
            }

            if (var1.containsKey("loc1") && var1.get("loc1") instanceof D) {
               this.bb = ((D)var1.get("loc1")).ga();
            }

            if (var1.containsKey("loc2") && var1.get("loc2") instanceof D) {
               this.bc = ((D)var1.get("loc2")).ga();
            }

            if (var1.containsKey("corner1") && var1.get("corner1") instanceof D) {
               this.be = ((D)var1.get("corner1")).ga();
            }

            if (var1.containsKey("corner2") && var1.get("corner2") instanceof D) {
               this.bf = ((D)var1.get("corner2")).ga();
            }

            if (var1.containsKey("center") && var1.get("center") instanceof D) {
               this.bd = ((D)var1.get("center")).ga();
            }

            if (var1.containsKey("build") && var1.get("build") instanceof Boolean) {
               this.bi = (Boolean)var1.get("build");
            }

            if (var1.containsKey("ffa") && var1.get("ffa") instanceof Boolean) {
               this.bj = (Boolean)var1.get("ffa");
            }

            if (var1.containsKey("kits") && var1.get("kits") instanceof List) {
               Iterator var2 = ((List)var1.get("kits")).iterator();

               while(var2.hasNext()) {
                  Object var3 = var2.next();
                  if (var3 instanceof String) {
                     this.kits.add(((String)var3).toLowerCase());
                  }
               }
            }

            if (var1.get("icon") instanceof ItemStack) {
               this.bh = (ItemStack)var1.get("icon");
               q.f(this.bh);
            }

            if (this.bg == null) {
               this.bg = ChatColor.YELLOW + this.name.replaceAll("[0-9]", "");
               if (ChatColor.stripColor(this.bg).length() == 0) {
                  this.bg = ChatColor.YELLOW + this.name;
               }
            }

            StrikePractice var5 = StrikePractice.getInstance();
            if (var5.getConfig().getBoolean("no-arenas-in-default-world")) {
               String var6 = ((World)Bukkit.getWorlds().get(0)).getName();
               if (this.bb != null && (this.bb.getWorld() == null || this.bb.getWorld().getName().equals(var6))) {
                  this.bb.setWorld(Bukkit.getWorld(StrikePractice.A));
               }

               if (this.bc != null && (this.bc.getWorld() == null || this.bc.getWorld().getName().equals(var6))) {
                  this.bc.setWorld(Bukkit.getWorld(StrikePractice.A));
               }

               if (this.bd != null && (this.bd.getWorld() == null || this.bd.getWorld().getName().equals(var6))) {
                  this.bd.setWorld(Bukkit.getWorld(StrikePractice.A));
               }

               if (this.be != null && (this.be.getWorld() == null || this.be.getWorld().getName().equals(var6))) {
                  this.be.setWorld(Bukkit.getWorld(StrikePractice.A));
               }

               if (this.bf != null && (this.bf.getWorld() == null || this.bf.getWorld().getName().equals(var6))) {
                  this.bf.setWorld(Bukkit.getWorld(StrikePractice.A));
               }
            }

            if (this.name.toLowerCase().contains("brackets")) {
               this.ba = 20;
            }

            try {
               this.aA();
            } catch (Exception var4) {
            }

         }
      }
   }

   public static Arena a(Arena var0, World var1, String var2) {
      try {
         c var3 = new c(var2);
         Location var4 = var0.getLoc1().clone();
         var4.setWorld(var1);
         var3.setLoc1(var4);
         Location var5;
         if (var0.getCorner1() != null) {
            var5 = var0.getCorner1().clone();
            var5.setWorld(var1);
            var3.setCorner1(var5);
         }

         if (var0.getCorner2() != null) {
            var5 = var0.getCorner2().clone();
            var5.setWorld(var1);
            var3.setCorner2(var5);
         }

         var3.setCustomMaxChangesPerTick(var0.getCustomMaxChangesPerTick());
         var5 = var0.getLoc2().clone();
         var5.setWorld(var1);
         var3.setLoc2(var5);
         var3.setBuild(var0.isBuild());
         Location var6 = var0.getCenter().clone();
         var6.setWorld(var1);
         var3.setCenter(var6);
         var3.setFFA(var0.isFFA());
         var3.setKits(var0.getKits());
         var3.setIcon(var0.getIcon());
         Location var7 = var3.getCenter();
         var3.setDisplayName(var0.getDisplayName());
         if (var1 != null && var3.getCenter() != null && var3.getLoc1() != null && var3.getLoc2() != null && var3.getCenter().getWorld().getName().equals(var1.getName()) && var3.getLoc1().getWorld().getName().equals(var1.getName()) && var3.getLoc1().getWorld().getName().equals(var1.getName()) && var7 != null && var7.getWorld() != null && Bukkit.getWorld(var7.getWorld().getName()) != null) {
            var3.aA();
            return var3;
         } else {
            return null;
         }
      } catch (Exception var8) {
         Bukkit.getLogger().warning("Failed to copy an arena");
         var8.printStackTrace();
         return null;
      }
   }

   private static List<Arena> aw() {
      ArrayList var0 = new ArrayList();
      Iterator var1 = StrikePractice.getInstance().M.iterator();

      while(var1.hasNext()) {
         Arena var2 = (Arena)var1.next();
         if (var2.isBuild() && !var2.isEventArena() && !var2.isFFA() && var2.getCenter() != null && var2.getCenter().getWorld() != null) {
            var0.add(var2);
         }
      }

      return var0;
   }

   public static List<Arena> a(Player var0, BattleKit var1) {
      List var2 = aw();
      ArrayList var3 = new ArrayList();
      boolean var4 = false;
      StrikePractice var5 = StrikePractice.getInstance();
      BattleKit var6 = var5.Y().getPlayerKits(var0).getCustomKit();
      Iterator var7 = var2.iterator();

      while(true) {
         Arena var8;
         do {
            if (!var7.hasNext()) {
               if (!var4) {
                  var7 = var2.iterator();

                  while(true) {
                     do {
                        if (!var7.hasNext()) {
                           return var3;
                        }

                        var8 = (Arena)var7.next();
                     } while(var8.getKits() != null && !var8.getKits().isEmpty());

                     if (!var8.isUsing() && var8.getCenter() != null && !var8.isFFA() && var8.getLoc1() != null && var8.getLoc2() != null && !var8.needsRollback() && !var8.isEventArena()) {
                        var3.add(var8);
                     }
                  }
               }

               return var3;
            }

            var8 = (Arena)var7.next();
         } while((!var8.getKits().contains("customkit") || !var1.equals(var6)) && (var8.getKits() == null || !var8.getKits().contains(var1.getName().toLowerCase())));

         if (var8.getCenter() != null && var8.getLoc1() != null && var8.getLoc2() != null && var8.canRollback() && !var8.isFFA()) {
            var4 = true;
            if (!var8.isUsing() && !var8.needsRollback() && !var8.isFFA() && !var8.isEventArena()) {
               var3.add(var8);
            }
         }
      }
   }

   public static Arena b(Player var0, BattleKit var1) {
      Arena var2 = a(a(var0, var1), var1, var0, true);
      if (aZ != null && aZ == var1 && var2 != null) {
         aZ = null;
      }

      if (var2 == null) {
         aZ = var1;
      }

      return var2;
   }

   private static Arena a(List<Arena> var0, BattleKit var1, Player var2, boolean var3) {
      if (var0.isEmpty()) {
         return null;
      } else {
         return var0.size() == 1 ? (Arena)var0.get(0) : (Arena)var0.get(StrikePractice.t.nextInt(var0.size()));
      }
   }

   public static Arena getArena(String var0) {
      Iterator var1 = StrikePractice.getInstance().M.iterator();

      Arena var2;
      do {
         if (!var1.hasNext()) {
            return null;
         }

         var2 = (Arena)var1.next();
      } while(!var2.getName().equals(var0));

      return var2;
   }

   public static List<Arena> ax() {
      ArrayList var0 = new ArrayList();
      Iterator var1 = StrikePractice.getInstance().M.iterator();

      while(var1.hasNext()) {
         Arena var2 = (Arena)var1.next();
         if (var2.isBuild()) {
            var0.add(var2);
         }
      }

      return var0;
   }

   public static Set<Arena> a(World var0, boolean var1) {
      HashSet var2 = new HashSet();
      Iterator var3 = StrikePractice.getInstance().M.iterator();

      while(true) {
         Arena var4;
         do {
            do {
               do {
                  do {
                     do {
                        do {
                           if (!var3.hasNext()) {
                              return var2;
                           }

                           var4 = (Arena)var3.next();
                        } while(var4.getCenter() == null);
                     } while(var4.getLoc1() == null);
                  } while(var4.getLoc2() == null);
               } while(var4.getCenter().getWorld() == null);
            } while(!var4.getCenter().getWorld().getName().equals(var0.getName()));
         } while((!var1 || !var4.isBuild()) && (var1 || var4.isBuild()));

         var2.add(var4);
      }
   }

   public static List<Arena> c(Player var0, BattleKit var1) {
      StrikePractice var2 = StrikePractice.getInstance();
      Set var3 = var2.M;
      ArrayList var4 = new ArrayList();
      boolean var5 = false;
      BattleKit var6 = var2.Y().getPlayerKits(var0).getCustomKit();
      Iterator var7 = var3.iterator();

      while(true) {
         Arena var8;
         do {
            if (!var7.hasNext()) {
               if (!var5) {
                  var7 = var3.iterator();

                  while(true) {
                     do {
                        if (!var7.hasNext()) {
                           return var4;
                        }

                        var8 = (Arena)var7.next();
                     } while(var8.getKits() != null && !var8.getKits().isEmpty());

                     if (!var8.isUsing() && !var8.isBuild() && !var8.isEventArena()) {
                        var4.add(var8);
                     }
                  }
               }

               return var4;
            }

            var8 = (Arena)var7.next();
         } while((!var8.getKits().contains("customkit") || !var1.equals(var6)) && (var8.getKits() == null || !var8.getKits().contains(var1.getName())));

         if (var8.getCenter() != null && var8.getLoc1() != null && var8.getLoc2() != null && !var8.isFFA()) {
            var5 = true;
            if (!var8.isUsing() && !var8.isBuild() && !var8.isEventArena()) {
               var4.add(var8);
            }
         }
      }
   }

   public static Arena d(Player var0, BattleKit var1) {
      Arena var2 = a(c(var0, var1), var1, var0, false);
      if (aZ != null && aZ == var1 && var2 != null) {
         aZ = null;
      }

      if (var2 == null) {
         aZ = var1;
      }

      return var2;
   }

   public static Arena a(Map<String, Object> var0) {
      return new c(var0);
   }

   public static Arena b(Map<String, Object> var0) {
      return new c(var0);
   }

   public static void e(Player var0) {
      StrikePractice.getInstance().a(var0, "no-arenas-found");
      if (ga.strikepractice.k.b.a(var0, ga.strikepractice.k.a.pz)) {
         boolean var1 = false;
         boolean var2 = false;
         Iterator var3 = StrikePractice.getInstance().M.iterator();

         while(var3.hasNext()) {
            Arena var4 = (Arena)var3.next();
            if (var4.isBuild()) {
               var1 = true;
            } else {
               var2 = true;
            }
         }

         if (!var1) {
            var0.sendMessage(ChatColor.RED + "Hint: There are no build arenas! Use /arena build <arena name>.");
         }

         if (!var2) {
            var0.sendMessage(ChatColor.RED + "Hint: There are no non-build arenas!");
         }
      }

   }

   public static void a(StrikePractice var0) {
      aV = var0.getConfig().getInt("max-block-changes-per-tick-per-arena");
      aV = var0.getConfig().getInt("max-block-changes-per-tick-per-arena");
   }

   public static void a(Collection<Arena> var0) {
      Iterator var1 = var0.iterator();

      while(var1.hasNext()) {
         Arena var2 = (Arena)var1.next();
         var2.removeItems();
      }

   }

   public Map<String, Object> serialize() {
      HashMap var1 = new HashMap();
      StrikePractice var2 = StrikePractice.getInstance();
      if (var2.getConfig().getBoolean("no-arenas-in-default-world")) {
         String var3 = ((World)Bukkit.getWorlds().get(0)).getName();
         if (this.bb != null && (this.bb.getWorld() == null || this.bb.getWorld().getName().equals(var3))) {
            this.bb.setWorld(Bukkit.getWorld(StrikePractice.A));
         }

         if (this.bc != null && (this.bc.getWorld() == null || this.bc.getWorld().getName().equals(var3))) {
            this.bc.setWorld(Bukkit.getWorld(StrikePractice.A));
         }

         if (this.bd != null && (this.bd.getWorld() == null || this.bd.getWorld().getName().equals(var3))) {
            this.bd.setWorld(Bukkit.getWorld(StrikePractice.A));
         }

         if (this.be != null && (this.be.getWorld() == null || this.be.getWorld().getName().equals(var3))) {
            this.be.setWorld(Bukkit.getWorld(StrikePractice.A));
         }

         if (this.bf != null && (this.bf.getWorld() == null || this.bf.getWorld().getName().equals(var3))) {
            this.bf.setWorld(Bukkit.getWorld(StrikePractice.A));
         }
      }

      var1.put("name", this.name);
      var1.put("display-name", this.bg);
      var1.put("loc1", new D(this.bb));
      var1.put("loc2", new D(this.bc));
      var1.put("center", new D(this.bd));
      var1.put("icon", this.getIcon());
      if (this.bi) {
         var1.put("build", this.bi);
      }

      if (this.bj) {
         var1.put("ffa", this.bj);
      }

      if (!this.kits.isEmpty()) {
         var1.put("kits", this.kits);
      }

      if (this.be != null) {
         var1.put("corner1", new D(this.be));
      }

      if (this.bf != null) {
         var1.put("corner2", new D(this.bf));
      }

      return var1;
   }

   public void saveForStrikePractice() {
      StrikePractice.getInstance().M.add(this);
   }

   public boolean removeFromStrikePractice() {
      StrikePractice var1 = StrikePractice.getInstance();
      return var1.M.remove(this);
   }

   public boolean canRollback() {
      return true;
   }

   public ItemStack getIcon() {
      if (this.bh == null) {
         if (this.bi) {
            this.bh = new ItemStack(Material.LAVA_BUCKET);
         }

         if (this.bh == null) {
            this.bh = new ItemStack(Material.WOOL);
         }
      }

      ItemMeta var1 = this.bh.getItemMeta();
      if (!var1.hasDisplayName()) {
         var1.setDisplayName(this.getDisplayName());
         this.bh.setItemMeta(var1);
      }

      return this.bh;
   }

   public void setIcon(ItemStack var1) {
      this.bh = var1;
   }

   public void rollbackArena(Fight var1) {
      this.removeItems();
      if (!(var1 instanceof BestOfFight) || !((BestOfFight)var1).isBreakTime() || !var1.getKit().isNoBestOfRollback()) {
         if (this.bi && !var1.getBlockChangesMap().isEmpty()) {
            this.ay();
            if (StrikePractice.u) {
               this.quickRollback();
            } else {
               try {
                  int var2 = this.a(var1);
                  ArrayList var6 = new ArrayList(var1.getBlockChangesMap().values());
                  var6.sort(Comparator.comparingDouble(DefaultCachedBlockChange::getY));
                  ga.strikepractice.arena.b.b.a var7 = new ga.strikepractice.arena.b.b.a(this, var2, var6.iterator(), this::az);
                  StrikePractice.getInstance().ar().b(var7);
               } catch (Exception var5) {
                  Bukkit.getLogger().warning("An error occurred while resetting " + this.name + " arena (#2). Resetting all at once, expect little lag.");
                  this.quickRollback();
                  var5.printStackTrace();
                  Iterator var3 = Bukkit.getOnlinePlayers().iterator();

                  while(var3.hasNext()) {
                     Player var4 = (Player)var3.next();
                     if (ga.strikepractice.k.b.a(var4, ga.strikepractice.k.a.pz)) {
                        var4.sendMessage(aU);
                     }
                  }

                  this.az();
               }

            }
         } else {
            this.c(false);
         }
      }
   }

   public void quickRollback() {
      Fight var1 = this.getCurrentFight();
      if (var1 != null && var1.getKit() != null) {
         if (!this.bi) {
            this.c(false);
         } else {
            try {
               this.ay();
               Iterator var2 = var1.getBlockChangesMap().values().iterator();

               while(var2.hasNext()) {
                  CachedBlockChange var6 = (CachedBlockChange)var2.next();
                  var6.reset();
                  Block var7 = var6.getLocation().getBlock();
                  var7.removeMetadata("StrikePracticePlacedInFight", StrikePractice.getInstance());
                  var7.removeMetadata("StrikePracticePlacedInFightNonBreakableBlock", StrikePractice.getInstance());
               }

               var1.clearBlockChanges();
               this.az();
            } catch (Exception var5) {
               var5.printStackTrace();
               Iterator var3 = Bukkit.getOnlinePlayers().iterator();

               while(var3.hasNext()) {
                  Player var4 = (Player)var3.next();
                  if (ga.strikepractice.k.b.a(var4, ga.strikepractice.k.a.pz)) {
                     var4.sendMessage(aU);
                  }
               }
            }

         }
      }
   }

   private void ay() {
      this.bl = true;
      int var1 = this.bm == null ? 0 : this.bm.getBlockChangesMap().size();
      if (aX) {
         Iterator var2 = Bukkit.getOnlinePlayers().iterator();

         while(var2.hasNext()) {
            Player var3 = (Player)var2.next();
            if (var3.hasMetadata("StrikePracticeRollbackRateAlerts")) {
               var3.sendMessage(f.K(StrikePractice.getInstance().getConfig().getString("prefix")) + ChatColor.GRAY + "Rolling back the arena '" + this.name + "' (blocks to change: " + var1 + ") (resetting " + ga.strikepractice.arena.b.b.aE() + " arenas concurrently)");
            }
         }
      }

   }

   private void az() {
      this.c(false);
      if (aX) {
         Iterator var1 = Bukkit.getOnlinePlayers().iterator();

         while(var1.hasNext()) {
            Player var2 = (Player)var1.next();
            if (var2.hasMetadata("StrikePracticeRollbackRateAlerts")) {
               var2.sendMessage(f.K(StrikePractice.getInstance().getConfig().getString("prefix")) + ChatColor.GRAY + "The arena '" + this.name + "' has been rolled back. Arenas resetting: " + ga.strikepractice.arena.b.b.aE());
            }
         }
      }

   }

   public void setUsing(boolean var1, Fight var2) {
      if (!var1) {
         if (this.getCurrentFight().getKit().isBuild()) {
            this.rollbackArena(this.getCurrentFight());
         } else {
            this.c(false);
         }
      } else {
         this.bm = var2;
      }

      if (this.bo || !var1) {
         this.b(true);
      }

      this.bk = var1;
      if (var2 != null && this.bi) {
         this.bm = var2;
         this.c(true);
         StrikePractice.getInstance().ar().a(this);
      }

   }

   public boolean isUsing() {
      return this.bk;
   }

   public boolean isBuild() {
      return this.bi;
   }

   public boolean isFFA() {
      return this.bj;
   }

   public boolean isEventArena() {
      String[] var1 = aT;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String var4 = var1[var3];
         if (this.getName().endsWith(var4)) {
            return true;
         }
      }

      return false;
   }

   public void setFFA(boolean var1) {
      this.bj = var1;
   }

   public boolean needsRollback() {
      return this.bl;
   }

   public void setBuild(boolean var1) {
      this.bi = var1;
   }

   public Location getLoc1() {
      return this.bb;
   }

   public Location getLoc2() {
      return this.bc;
   }

   public Location getCenter() {
      return this.bd;
   }

   public boolean hasWall() {
      return false;
   }

   public List<String> getKits() {
      return this.kits;
   }

   public void setKits(List<String> var1) {
      this.kits = var1;
   }

   public String getName() {
      return this.name;
   }

   public String getOriginalName() {
      return this.name.substring(this.name.lastIndexOf(":") + 1);
   }

   public String getDisplayName() {
      return this.bg != null ? this.bg : this.name;
   }

   public void setDisplayName(String var1) {
      this.bg = var1;
   }

   public void setCenter(Location var1) {
      this.bd = var1;
      this.aA();
   }

   public Fight getCurrentFight() {
      return this.bm;
   }

   public void setCorner1(Location var1) {
      this.be = var1;
      this.aA();
   }

   public void setCorner2(Location var1) {
      this.bf = var1;
      this.aA();
   }

   public void setCurrentFight(Fight var1) {
      this.bm = var1;
   }

   public int getCustomMaxChangesPerTick() {
      return this.ba;
   }

   public void setCustomMaxChangesPerTick(int var1) {
      this.ba = var1;
   }

   public void sendPossibleWrongWorldInfo(Player var1) {
      if (this.bb != null && this.bc != null && this.bd != null && this.be != null && this.bf != null && a(this.bb, this.bc, this.bd, this.be, this.bf)) {
         this.f(var1);
         var1.sendMessage(ChatColor.RED + "Corner1: " + this.be.getWorld().getName());
         var1.sendMessage(ChatColor.RED + "Corner2: " + this.bf.getWorld().getName());
      } else if (this.bb != null && this.bc != null && this.bd != null && a(this.bb, this.bc, this.bd)) {
         this.f(var1);
      }

   }

   private void f(Player var1) {
      var1.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "WARNING! All locations are not in the same world!");
      var1.sendMessage(ChatColor.RED + "Position1: " + this.bb.getWorld().getName());
      var1.sendMessage(ChatColor.RED + "Position2: " + this.bc.getWorld().getName());
      var1.sendMessage(ChatColor.RED + "Center: " + this.bd.getWorld().getName());
   }

   public void removeItems() {
      this.b(false);
   }

   private void aA() {
      if (this.be != null && this.bf != null) {
         this.bn = t.a(this.be.getWorld(), this.be.getBlockX(), this.be.getBlockZ(), this.bf.getBlockX(), this.bf.getBlockZ());
      } else if (this.bd != null) {
         this.bn = new HashSet();
         Chunk var1 = this.getCenter().getChunk();
         byte var2 = 10;

         for(int var3 = 0; var3 < var2; ++var3) {
            for(int var4 = 0; var4 < var2; ++var4) {
               int var5 = var2 / 2;
               Chunk var6 = this.getCenter().getWorld().getChunkAt(var1.getX() + var3 - var5, var1.getZ() + var4 - var5);
               this.bn.add(var6);
            }
         }
      } else {
         this.bn = Collections.emptySet();
      }

   }

   public boolean a(Chunk var1) {
      Iterator var2 = this.bn.iterator();

      Chunk var3;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         var3 = (Chunk)var2.next();
      } while(var1.getWorld() != var3.getWorld() || var3.getX() != var1.getX() || var3.getZ() != var1.getZ());

      return true;
   }

   private void b(boolean var1) {
      Iterator var2 = this.bn.iterator();

      while(true) {
         Chunk var3;
         do {
            do {
               if (!var2.hasNext()) {
                  return;
               }

               var3 = (Chunk)var2.next();
            } while(var3 == null);

            if (!var1) {
               var3.load();
            }
         } while(!var3.isLoaded());

         Entity[] var4 = var3.getEntities();
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            Entity var7 = var4[var6];
            if (B.fR()) {
               B.trace("Saw entity " + var7.getType().name() + " at " + var7.getLocation().toString());
            }

            if (var7 instanceof Item || var7 instanceof EnderCrystal || var7 instanceof Explosive || var7 instanceof Minecart || var7 instanceof Projectile || var7 instanceof FallingBlock) {
               var7.remove();
               if (B.fR()) {
                  B.trace("Removed entity " + var7.getType().name() + " at " + var7.getLocation().toString());
               }
            }
         }
      }
   }

   public void setLoc1(Location var1) {
      this.bb = var1;
   }

   public void setLoc2(Location var1) {
      this.bc = var1;
   }

   public Location getCorner1() {
      return this.be;
   }

   public Location getCorner2() {
      return this.bf;
   }

   public boolean hasCornersSet() {
      return this.be != null && this.bf != null;
   }

   public void setUsing(boolean var1) {
      this.bk = var1;
   }

   private int a(Fight var1) {
      boolean var2 = var1 instanceof BestOfFight && ((BestOfFight)var1).isBreakTime();
      int var3;
      if (this.ba > 0) {
         var3 = this.ba;
      } else {
         if (aV <= 0) {
            aV = 2;
            Bukkit.getLogger().warning("max-block-changes-per-tick-per-arena config value is 0. Using 2!");
         }

         var3 = aV;
      }

      if (var2) {
         var3 = var1.getBlockChangesMap().size() / 4;
         if (var3 * 3 > aV) {
            var3 = aV * 3;
         }
      }

      if (var3 < aV) {
         var3 = aV;
      }

      if (this.isFFA() || var1 instanceof FFAFight && var3 < 30) {
         var3 = 30;
      }

      return var3;
   }

   private void c(boolean var1) {
      this.bl = var1;
   }

   private static boolean a(Location... var0) {
      if (var0.length == 0) {
         return false;
      } else {
         World var1 = var0[0].getWorld();
         Location[] var2 = var0;
         int var3 = var0.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Location var5 = var2[var4];
            if (var5.getWorld() != var1) {
               return true;
            }
         }

         return false;
      }
   }

   static {
      aU = ChatColor.RED + "Failed to reset an arena. Check console for the error!";
      aV = 2;
   }
}
