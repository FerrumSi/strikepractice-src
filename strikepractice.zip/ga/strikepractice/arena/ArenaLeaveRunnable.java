package ga.strikepractice.arena;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.utils.I;
import ga.strikepractice.utils.t;
import ga.strikepractice.utils.z;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.WeatherType;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class ArenaLeaveRunnable extends BukkitRunnable {
   private final StrikePractice aP;
   public static String aQ = "StrikePracticeInStorm";

   public ArenaLeaveRunnable(StrikePractice var1) {
      this.runTaskTimerAsynchronously(this.aP = var1, 200L, 200L);
   }

   public void run() {
      Iterator var1 = Bukkit.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player var2 = (Player)var1.next();
         if (!var2.hasMetadata(aQ)) {
            Fight var3 = AbstractFight.getCurrentFight(var2);
            if (var3 != null && var3.getArena() != null) {
               Arena var4 = var3.getArena();
               if (var4.hasCornersSet()) {
                  if (var4 instanceof c) {
                     if (!((c)var4).a(var2.getLocation().getChunk())) {
                        new ArenaLeaveRunnable.ForcefieldDamage(var2);
                     }
                  } else if (!t.a(var2.getLocation(), var4.getCorner1(), var4.getCorner2())) {
                     new ArenaLeaveRunnable.ForcefieldDamage(var2);
                  }
               }
            }
         }
      }

   }

   private class ForcefieldDamage extends BukkitRunnable {
      private final Player aR;
      int counter = 0;

      public ForcefieldDamage(Player var2) {
         this.aR = var2;
         var2.setMetadata(ArenaLeaveRunnable.aQ, new FixedMetadataValue(ArenaLeaveRunnable.this.aP, true));
         this.runTaskTimer(ArenaLeaveRunnable.this.aP, 10L, 10L);
      }

      public void run() {
         if (this.aR != null && !this.aR.isDead()) {
            Fight var1 = AbstractFight.getCurrentFight(this.aR);
            if (var1 != null && !var1.hasEnded()) {
               Arena var2 = var1.getArena();
               if (var2.hasCornersSet() && !t.a(this.aR.getLocation(), var2.getCorner1(), var2.getCorner2())) {
                  ++this.counter;
                  if (this.counter > 60 || this.counter % 2 == 0) {
                     if (this.counter > 5) {
                        int var3 = 1;
                        if (this.aR.hasPotionEffect(PotionEffectType.REGENERATION)) {
                           var3 += z.a(this.aR, PotionEffectType.REGENERATION);
                        }

                        this.aR.damage((double)var3);
                        if (this.aR.getPlayerWeather() == WeatherType.CLEAR) {
                           this.aR.setPlayerWeather(WeatherType.DOWNFALL);
                        }
                     }

                     if (this.counter % 5 == 0 || this.counter == 2) {
                        this.aR.sendMessage(ChatColor.RED + "You are not allowed to leave the arena!");
                     }

                     if (this.counter > 15 && StrikePractice.t.nextInt(3) == 0) {
                        this.aR.setVelocity(this.aR.getVelocity().add(new Vector(StrikePractice.t.nextDouble() - 0.5D, StrikePractice.t.nextDouble() - 0.5D, StrikePractice.t.nextDouble() - 0.5D)));
                     }

                     if (this.counter % 3 == 0 && StrikePractice.t.nextBoolean()) {
                        Location var4 = t.a(this.aR.getLocation(), 24, false);
                        ArenaLeaveRunnable.this.aP.ao().dH().c(this.aR, var4);
                        I.a(this.aR, var4, "AMBIENCE_THUNDER", 2.0F, 1.0F);
                     }
                  }

                  return;
               }

               this.aR.removeMetadata(ArenaLeaveRunnable.aQ, ArenaLeaveRunnable.this.aP);
               this.aR.setPlayerWeather(WeatherType.CLEAR);
            }

            this.aR.removeMetadata(ArenaLeaveRunnable.aQ, ArenaLeaveRunnable.this.aP);
            this.aR.setPlayerWeather(WeatherType.CLEAR);
         }

         this.cancel();
      }
   }
}
