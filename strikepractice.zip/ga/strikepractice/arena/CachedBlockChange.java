package ga.strikepractice.arena;

import ga.strikepractice.api.APIClass;
import org.bukkit.Location;
import org.bukkit.Material;

@APIClass
public interface CachedBlockChange {
   default void reset() {
      this.reset(false);
   }

   void reset(boolean var1);

   Location getLocation();

   Material getOldMaterial();

   short getOldData();

   int getX();

   int getY();

   int getZ();

   String toString();

   boolean isResetSupported();
}
