package ga.strikepractice.arena;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.r;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.Nullable;

@APIClass
public class DefaultCachedBlockChange implements CachedBlockChange {
   private final Material oldMaterial;
   private final byte oldData;
   private final Location location;
   @Nullable
   private Object blockData;
   private ItemStack[] chestInventory;
   private boolean isResetSupported;

   public DefaultCachedBlockChange(Location var1, Block var2) {
      this(var1, var2.getType(), var2.getData());
      this.blockData = ga.strikepractice.utils.a.f(var2);
      this.isResetSupported = !r.j(var2) || this.blockData != null;
      if (!this.isResetSupported) {
         B.debug("Change not supported for resetting, possibly because it's a new material: " + this);
      } else if (B.fR()) {
         B.trace("Change supported for resetting: " + this);
      }

   }

   public DefaultCachedBlockChange(Location var1, Material var2, byte var3) {
      this.isResetSupported = true;
      if (var2 == null) {
         var2 = Material.AIR;
      }

      this.oldMaterial = var2;
      this.oldData = var3;
      this.location = var1;
      this.saveChest(var1);
      if (B.fR()) {
         B.trace("Created block change " + this);
      }

   }

   /** @deprecated */
   @Deprecated
   public static CachedBlockChange getByLocation(Location var0, Collection<DefaultCachedBlockChange> var1) {
      Iterator var2 = var1.iterator();

      CachedBlockChange var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (CachedBlockChange)var2.next();
      } while(!var0.equals(var3.getLocation()));

      return var3;
   }

   private void saveChest(Location var1) {
      try {
         Block var2 = var1.getBlock();
         if (var2.getType() == Material.CHEST || var2.getType() == Material.TRAPPED_CHEST) {
            Chest var3 = (Chest)var2.getState();
            InventoryHolder var4 = var3.getInventory().getHolder();
            this.chestInventory = (ItemStack[])Arrays.stream(var4.getInventory().getContents()).map((var0) -> {
               return var0 == null ? new ItemStack(Material.AIR) : var0.clone();
            }).toArray((var0) -> {
               return new ItemStack[var0];
            });
            ItemStack[] var5 = this.chestInventory;
            int var6 = var5.length;

            for(int var7 = 0; var7 < var6; ++var7) {
               ItemStack var8 = var5[var7];
               if (var8 != null && var8.getAmount() == 0) {
                  var8.setAmount(1);
               }
            }
         }
      } catch (Exception var9) {
         Bukkit.getLogger().info("StrikePractice >> Arena regen failed to save chest contents");
         if (B.fQ()) {
            var9.printStackTrace();
         }
      }

   }

   public void reset(boolean var1) {
      try {
         if (this.location != null && this.oldMaterial != null) {
            if (this.blockData != null) {
               if (B.fR()) {
                  B.trace("Resetting blockdata only: " + this.blockData);
               }

               ga.strikepractice.utils.a.a(this.location.getBlock(), this.blockData);
            } else {
               ga.strikepractice.arena.a.b.d(var1).a(this);
               if (this.chestInventory != null && (this.oldMaterial == Material.CHEST || this.oldMaterial == Material.TRAPPED_CHEST)) {
                  Block var2 = this.location.getBlock();
                  Chest var3 = (Chest)var2.getState();
                  InventoryHolder var4 = var3.getInventory().getHolder();
                  var4.getInventory().setContents(this.chestInventory);
                  ItemStack[] var5 = var4.getInventory().getContents();
                  int var6 = var5.length;

                  for(int var7 = 0; var7 < var6; ++var7) {
                     ItemStack var8 = var5[var7];
                     if (var8 != null && var8.getAmount() <= 0) {
                        var8.setAmount(1);
                     }
                  }
               }
            }
         }
      } catch (Exception var9) {
         Bukkit.getLogger().warning("Failed to reset arena block " + this);
         var9.printStackTrace();
      }

   }

   public Location getLocation() {
      return this.location;
   }

   public Material getOldMaterial() {
      return this.oldMaterial;
   }

   public short getOldData() {
      return (short)this.oldData;
   }

   public int getX() {
      return this.location.getBlockX();
   }

   public int getY() {
      return this.location.getBlockY();
   }

   public int getZ() {
      return this.location.getBlockZ();
   }

   public boolean isResetSupported() {
      return this.isResetSupported;
   }

   public String toString() {
      return (new D(this.getLocation())).gb() + ":" + this.getOldMaterial() + ":" + this.getOldData() + ", blockData=" + this.blockData + ", chestInventory=" + Arrays.toString(this.chestInventory) + ", isResetSupported=" + this.isResetSupported;
   }
}
