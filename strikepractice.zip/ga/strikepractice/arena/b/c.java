package ga.strikepractice.arena.b;

import com.fastasyncworldedit.core.extent.clipboard.DiskOptimizedClipboard;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitWorld;
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.function.operation.ForwardExtentCopy;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.world.World;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.CachedBlockChange;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;

public class c implements ga.strikepractice.arena.b.a {
   private final Map<Arena, Clipboard> bz = Collections.synchronizedMap(new WeakHashMap());
   private final ga.strikepractice.arena.b.a bA;

   public c(ga.strikepractice.arena.b.a var1) {
      this.bA = var1;
   }

   public void a(Arena var1, Iterator<? extends CachedBlockChange> var2, int var3, Runnable var4) {
      B.debug("FAWE reset for arena " + var1.getName());
      Location var5 = var1.getCorner1();
      Location var6 = var1.getCorner2();
      if (var5 != null && var6 != null) {
         Clipboard var7 = (Clipboard)this.bz.get(var1);
         if (var7 == null) {
            Bukkit.getLogger().warning("FAWE arena reset failed: no cached copy found for arena " + var1.getName());
            this.bA.a(var1, var2, var3, var4);
         } else {
            C.c(() -> {
               World var6 = this.b(var1.getCenter());

               try {
                  EditSession var7x = WorldEdit.getInstance().newEditSession(var6);

                  try {
                     var7.paste(var7x, var7.getMinimumPoint(), true);
                  } catch (Throwable var11) {
                     if (var7x != null) {
                        try {
                           var7x.close();
                        } catch (Throwable var10) {
                           var11.addSuppressed(var10);
                        }
                     }

                     throw var11;
                  }

                  if (var7x != null) {
                     var7x.close();
                  }
               } catch (Exception var12) {
                  Bukkit.getLogger().warning("Failed to reset arena " + var1.getName() + " with FAWE");
                  var12.printStackTrace();
                  this.bA.a(var1, var2, var3, var4);
               }

               B.debug("FAWE reset done for arena " + var1.getName());
               C.d(var4);
               this.bz.remove(var1);
               this.a(var7);
            });
         }

      } else {
         Bukkit.getLogger().warning("FAWE arena reset failed: corners not set for arena " + var1.getName());
         this.bA.a(var1, var2, var3, var4);
      }
   }

   public void b(Arena var1) {
      B.debug("FAWE onFightStart for arena " + var1.getName());
      Location var2 = var1.getCorner1();
      Location var3 = var1.getCorner2();
      if (var2 != null && var3 != null) {
         World var4 = this.b(var1.getCenter());
         CuboidRegion var5 = new CuboidRegion(var4, this.c(var2), this.c(var3));
         C.c(() -> {
            BlockArrayClipboard var4x = null;

            try {
               EditSession var5x = WorldEdit.getInstance().newEditSession(var4);

               try {
                  var4x = new BlockArrayClipboard(var5);
                  ForwardExtentCopy var6 = new ForwardExtentCopy(var5x, var5, var4x, var5.getMinimumPoint());
                  Operations.complete(var6);
               } catch (Throwable var9) {
                  if (var5x != null) {
                     try {
                        var5x.close();
                     } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                     }
                  }

                  throw var9;
               }

               if (var5x != null) {
                  var5x.close();
               }
            } catch (Exception var10) {
               Bukkit.getLogger().warning("Failed to copy arena " + var1.getName() + " for FAWE reset");
               var10.printStackTrace();
               this.bA.b(var1);
            }

            this.bz.put(var1, var4x);
            B.debug("Cached copy of arena " + var1.getName() + " for FAWE reset");
         });
      } else {
         Bukkit.getLogger().warning("FAWE arena reset failed: corners not set for arena " + var1.getName());
         this.bA.b(var1);
      }
   }

   private void a(Clipboard var1) {
      try {
         DiskOptimizedClipboard var2 = null;
         if (var1 instanceof DiskOptimizedClipboard) {
            var2 = (DiskOptimizedClipboard)var1;
         } else if (var1 instanceof BlockArrayClipboard && ((BlockArrayClipboard)var1).getParent() instanceof DiskOptimizedClipboard) {
            var2 = (DiskOptimizedClipboard)((BlockArrayClipboard)var1).getParent();
         }

         B.trace("#cleanupFAWEDataFiles doc type = " + (var2 != null ? var2.getClass().getSimpleName() : "null"));
         if (var2 == null || !var2.getFile().exists()) {
            B.debug("No FAWE data files to cleanup for clipboard: " + var1);
            return;
         }

         var2.close();
         B.debug("Cleaning up FAWE clipboard data files: " + var2.getFile().getAbsolutePath());
         var2.getFile().delete();
      } catch (Exception var3) {
         Bukkit.getLogger().warning("Failed to cleanup FAWE data files for clipboard: " + var1);
         if (B.fQ()) {
            var3.printStackTrace();
         }
      }

   }

   private World b(Location var1) {
      return new BukkitWorld(var1.getWorld());
   }

   private BlockVector3 c(Location var1) {
      return BlockVector3.at(var1.getBlockX(), var1.getBlockY(), var1.getBlockZ());
   }
}
