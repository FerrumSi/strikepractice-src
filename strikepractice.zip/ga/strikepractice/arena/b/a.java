package ga.strikepractice.arena.b;

import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.CachedBlockChange;
import java.util.Iterator;

public interface a {
   void a(Arena var1, Iterator<? extends CachedBlockChange> var2, int var3, Runnable var4);

   void b(Arena var1);
}
