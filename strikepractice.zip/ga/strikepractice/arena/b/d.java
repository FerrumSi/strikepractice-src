package ga.strikepractice.arena.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.CachedBlockChange;
import ga.strikepractice.fights.duel.BestOfFight;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class d implements ga.strikepractice.arena.b.a {
   private final StrikePractice bB;

   public d(StrikePractice var1) {
      this.bB = var1;
   }

   public void a(Arena var1, Iterator<? extends CachedBlockChange> var2, int var3, Runnable var4) {
      boolean var5 = var1.getName().equals("brackets") || var1.isFFA() || var1.getCurrentFight() instanceof BestOfFight && ((BestOfFight)var1.getCurrentFight()).isBreakTime();
      Bukkit.getScheduler().runTaskTimer(this.bB, () -> {
         this.a(var1, var2, var3, var5, var4);
      }, 1L, 1L);
   }

   private void a(Arena var1, Iterator<? extends CachedBlockChange> var2, int var3, boolean var4, Runnable var5) {
      try {
         int var6 = 0;

         while(var2.hasNext()) {
            if (var6 >= var3) {
               return;
            }

            CachedBlockChange var12 = (CachedBlockChange)var2.next();
            if (var12 != null) {
               ++var6;
               var12.reset(var4);
               Block var8 = var12.getLocation().getBlock();
               var8.removeMetadata("StrikePracticePlacedInFight", this.bB);
               var8.removeMetadata("StrikePracticePlacedInFightNonBreakableBlock", this.bB);
            }
         }

         var5.run();
      } catch (Exception var11) {
         Bukkit.getLogger().warning("An error occurred while resetting " + var1.getName() + " arena. Resetting all at once, expect a little lag.");
         long var7 = System.currentTimeMillis();
         var1.quickRollback();
         Bukkit.getLogger().warning("Quick reset (see above) took " + (System.currentTimeMillis() - var7) + " ms");
         Iterator var9 = Bukkit.getOnlinePlayers().iterator();

         while(var9.hasNext()) {
            Player var10 = (Player)var9.next();
            if (ga.strikepractice.k.b.a(var10, ga.strikepractice.k.a.pz)) {
               var10.sendMessage(ChatColor.RED + "Seems like something went wrong and failed to reset arena '" + var1.getName() + "'. Check console for errors.");
            }
         }

         var11.printStackTrace();
         var5.run();
      }

   }

   public void b(Arena var1) {
   }
}
