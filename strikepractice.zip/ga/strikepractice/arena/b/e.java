package ga.strikepractice.arena.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.DefaultCachedBlockChange;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.jvm.JvmStatic;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.t;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.material.Bed;
import org.bukkit.material.MaterialData;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010!\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 '2\u00020\u0001:\u0001'B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002J\u0012\u0010\u000b\u001a\u0004\u0018\u00010\f2\u0006\u0010\r\u001a\u00020\u000eH\u0002J$\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00110\u00102\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0011H\u0002J\u001e\u0010\u0015\u001a\u00020\u00062\u0006\u0010\u0016\u001a\u00020\f2\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00110\u0018H\u0002J\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u0007\u001a\u00020\u001bH\u0007J\u0010\u0010\u001c\u001a\u00020\u001a2\u0006\u0010\u0007\u001a\u00020\bH\u0007J\u0010\u0010\u001d\u001a\u00020\u001a2\u0006\u0010\u0007\u001a\u00020\u001eH\u0007J\u0010\u0010\u001f\u001a\u00020\u001a2\u0006\u0010\u0007\u001a\u00020 H\u0007J\u0010\u0010!\u001a\u00020\u001a2\u0006\u0010\u0007\u001a\u00020\"H\u0007J\u0010\u0010#\u001a\u00020\u001a2\u0006\u0010\u0007\u001a\u00020$H\u0007J\u0010\u0010%\u001a\u00020\u001a2\u0006\u0010\u0007\u001a\u00020&H\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006("},
   d2 = {"Lga/strikepractice/arena/reset/RollbackListener;", "Lorg/bukkit/event/Listener;", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "addBlockMove", "", "e", "Lorg/bukkit/event/block/BlockFromToEvent;", "fight", "Lga/strikepractice/fights/Fight;", "findArena", "Lga/strikepractice/arena/Arena;", "loc", "Lorg/bukkit/Location;", "getHeadParts", "Lga/strikepractice/kotlin/Pair;", "Lorg/bukkit/block/Block;", "bed", "Lorg/bukkit/material/Bed;", "block", "handleExplode", "arena", "blocks", "", "onBlockExplode", "", "Lorg/bukkit/event/block/BlockExplodeEvent;", "onBlockFromTo", "onBreak", "Lorg/bukkit/event/block/BlockBreakEvent;", "onBucketEmpty", "Lorg/bukkit/event/player/PlayerBucketEmptyEvent;", "onExplosion", "Lorg/bukkit/event/entity/EntityExplodeEvent;", "onInteract", "Lorg/bukkit/event/player/PlayerInteractEvent;", "onPlace", "Lorg/bukkit/event/block/BlockPlaceEvent;", "Companion", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nRollbackListener.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RollbackListener.kt\nga/strikepractice/arena/reset/RollbackListener\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,315:1\n1#2:316\n88#3,4:317\n88#3,4:321\n81#3,4:325\n81#3,4:329\n81#3,4:333\n81#3,4:337\n81#3,4:341\n81#3,4:345\n81#3,4:349\n81#3,4:353\n81#3,4:357\n81#3,4:361\n81#3,4:365\n81#3,4:369\n81#3,4:373\n81#3,4:377\n81#3,4:381\n81#3,2:385\n84#3:391\n1549#4:387\n1620#4,3:388\n1855#4,2:392\n*S KotlinDebug\n*F\n+ 1 RollbackListener.kt\nga/strikepractice/arena/reset/RollbackListener\n*L\n72#1:317,4\n75#1:321,4\n76#1:325,4\n78#1:329,4\n86#1:333,4\n117#1:337,4\n123#1:341,4\n138#1:345,4\n147#1:349,4\n152#1:353,4\n156#1:357,4\n157#1:361,4\n162#1:365,4\n168#1:369,4\n174#1:373,4\n176#1:377,4\n185#1:381,4\n211#1:385,2\n211#1:391\n213#1:387\n213#1:388,3\n215#1:392,2\n*E\n"})
public final class e implements Listener {
   @NotNull
   public static final e.a bC = new e.a((DefaultConstructorMarker)null);
   @NotNull
   private final StrikePractice bD;
   @NotNull
   public static final String bE = "StrikePracticePlacedInFight";
   @NotNull
   public static final String bF = "StrikePracticePlacedInFightNonBreakableBlock";

   public e(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.bD = var1;
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public final void a(@NotNull BlockFromToEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      Fight var2 = bC.b(var1.getBlock());
      if (var2 != null) {
         if (var2.hasEnded()) {
            var1.setCancelled(true);
         } else if (!var1.getToBlock().getType().isSolid()) {
            this.a(var1, var2);
         }
      } else {
         var2 = bC.b(var1.getBlock());
         if (var2 != null) {
            boolean var4 = false;
            this.a(var1, var2);
         }
      }

   }

   private final boolean a(BlockFromToEvent var1, Fight var2) {
      Block var3 = var1.getToBlock();
      if (!var2.addBlockChange(new DefaultCachedBlockChange(var3.getLocation(), Material.AIR, (byte)0))) {
         var1.setCancelled(true);
         return true;
      } else {
         var3.setMetadata("StrikePracticePlacedInFight", (MetadataValue)(new FixedMetadataValue((Plugin)this.bD, var2)));
         Block var4 = var3.getLocation().subtract(0.0D, 1.0D, 0.0D).getBlock();
         e.a var10000 = bC;
         Intrinsics.checkNotNullExpressionValue(var4, "b2");
         if (var10000.c(var4)) {
            boolean var5 = var2.getBlockChangesMap().get(var4.getLocation()) == null;
            if (!var2.addBlockChange(new DefaultCachedBlockChange(var4.getLocation(), var4))) {
               var1.setCancelled(true);
            } else if (var5) {
               var4.setMetadata("StrikePracticePlacedInFightNonBreakableBlock", (MetadataValue)(new FixedMetadataValue((Plugin)this.bD, true)));
            }
         }

         return false;
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public final void a(@NotNull PlayerBucketEmptyEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null) {
         Block var3 = var1.getBlockClicked();
         BlockFace var4 = var1.getBlockFace();
         ga.strikepractice.utils.a.a var10000 = ga.strikepractice.utils.a.ud;
         Intrinsics.checkNotNullExpressionValue(var3, "clicked");
         boolean var5 = var10000.g(var3) && var1.getBucket() == Material.WATER_BUCKET;
         Block var6 = var3.getRelative(var4);
         Block var7 = !var5 ? var6 : var3;
         B.a var8 = B.vj;
         boolean var9 = false;
         boolean var10;
         Logger var13;
         StringBuilder var14;
         String var15;
         Logger var18;
         if (var8.fX()) {
            var18 = Bukkit.getLogger();
            var14 = (new StringBuilder()).append("[SP TRACE] ");
            var13 = var18;
            var10 = false;
            var15 = var1.getBucket() + " empty event: " + var1.getPlayer().getName() + ' ' + var3.getType() + ' ' + var3.getLocation() + ", water loc=" + var7.getLocation() + ", waterloggable=" + var5;
            var13.info(var14.append(var15).toString());
         }

         var8 = B.vj;
         var9 = false;
         if (var8.fX()) {
            var18 = Bukkit.getLogger();
            var14 = (new StringBuilder()).append("[SP TRACE] ");
            var13 = var18;
            var10 = false;
            var15 = "clicked == liquidBlock: " + Intrinsics.areEqual((Object)var3.getLocation(), (Object)var7.getLocation());
            var13.info(var14.append(var15).toString());
         }

         var8 = B.vj;
         var9 = false;
         if (var8.fV()) {
            StringBuilder var19;
            Material var21;
            label58: {
               var18 = Bukkit.getLogger();
               var14 = (new StringBuilder()).append("[SP DEBUG] ");
               var13 = var18;
               var10 = false;
               var19 = (new StringBuilder()).append(var1.getPlayer().getName()).append(" emptied a bucket inside block ");
               Location var10001 = var7.getLocation();
               if (var10001 != null) {
                  Block var20 = var10001.getBlock();
                  if (var20 != null) {
                     var21 = var20.getType();
                     break label58;
                  }
               }

               var21 = null;
            }

            var15 = var19.append(var21).toString();
            var13.info(var14.append(var15).toString());
         }

         if (!var2.addBlockChange(new DefaultCachedBlockChange(var7.getLocation(), var7))) {
            var8 = B.vj;
            var9 = false;
            if (var8.fV()) {
               var18 = Bukkit.getLogger();
               var14 = (new StringBuilder()).append("[SP DEBUG] ");
               var13 = var18;
               var10 = false;
               var15 = "cancelled bucket empty event: cannot add block change (liquidBlock)";
               var13.info(var14.append(var15).toString());
            }

            var1.setCancelled(true);
            return;
         }

         Block var16 = var7.getLocation().subtract(0.0D, 1.0D, 0.0D).getBlock();
         e.a var22 = bC;
         Intrinsics.checkNotNullExpressionValue(var16, "b2");
         if (var22.c(var16)) {
            var9 = var2.getBlockChangesMap().get(var16.getLocation()) == null;
            if (!var2.addBlockChange(new DefaultCachedBlockChange(var16.getLocation(), var16))) {
               B.a var17 = B.vj;
               boolean var11 = false;
               if (var17.fV()) {
                  var18 = Bukkit.getLogger();
                  var14 = (new StringBuilder()).append("[SP DEBUG] ");
                  var13 = var18;
                  boolean var12 = false;
                  var15 = "cancelled bucket empty event: cannot add block change (block below)";
                  var13.info(var14.append(var15).toString());
               }

               var1.setCancelled(true);
               return;
            }

            if (var9) {
               var16.setMetadata("StrikePracticePlacedInFightNonBreakableBlock", (MetadataValue)(new FixedMetadataValue((Plugin)this.bD, true)));
            }
         }

         var7.setMetadata("StrikePracticePlacedInFight", (MetadataValue)(new FixedMetadataValue((Plugin)this.bD, var2)));
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public final void a(@NotNull PlayerInteractEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
         Block var2 = var1.getClickedBlock();
         if (var2.getType() != Material.CHEST && var2.getType() != Material.TRAPPED_CHEST) {
            if (AbstractFight.isInFight(var1.getPlayer())) {
               Material var12;
               boolean var14;
               label50: {
                  Player var10000 = var1.getPlayer();
                  if (var10000 != null) {
                     ItemStack var11 = var10000.getItemInHand();
                     if (var11 != null) {
                        var12 = var11.getType();
                        if (var12 != null) {
                           String var13 = var12.toString();
                           if (var13 != null) {
                              var14 = StringsKt.contains$default((CharSequence)var13, (CharSequence)"AXE", false, 2, (Object)null);
                              break label50;
                           }
                        }
                     }
                  }

                  var14 = false;
               }

               if (var14) {
                  var12 = var2.getType();
                  String var10 = var12 != null ? var12.toString() : null;
                  if (var10 != null && (StringsKt.contains$default((CharSequence)var10, (CharSequence)"LOG", false, 2, (Object)null) || StringsKt.contains$default((CharSequence)var10, (CharSequence)"WOOD", false, 2, (Object)null))) {
                     B.a var4 = B.vj;
                     boolean var5 = false;
                     if (var4.fV()) {
                        Logger var15 = Bukkit.getLogger();
                        StringBuilder var8 = (new StringBuilder()).append("[SP DEBUG] ");
                        Logger var7 = var15;
                        boolean var6 = false;
                        String var9 = "cancelling wood strip " + var1.getPlayer().getName() + ' ' + var10;
                        var7.info(var8.append(var9).toString());
                     }

                     var1.setCancelled(true);
                  }
               }
            }
         } else {
            Fight var3 = AbstractFight.getCurrentFight(var1.getPlayer());
            if (var3 != null && !var3.addBlockChange(new DefaultCachedBlockChange(var2.getLocation(), var2))) {
               var1.setCancelled(true);
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public final void a(@NotNull EntityExplodeEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      Location var2 = var1.getLocation();
      Entity var3 = var1.getEntity();
      Fight var10000;
      if (var3 instanceof Projectile && ((Projectile)var3).getShooter() instanceof Player) {
         ProjectileSource var15 = ((Projectile)var3).getShooter();
         Intrinsics.checkNotNull(var15, "null cannot be cast to non-null type org.bukkit.entity.Player");
         var10000 = AbstractFight.getCurrentFight((Player)var15);
      } else {
         var10000 = bC.b(var1.getLocation().getBlock());
      }

      Fight var4 = var10000;
      B.a var6;
      boolean var7;
      boolean var8;
      Logger var9;
      StringBuilder var10;
      String var11;
      Logger var16;
      List var10002;
      if (var4 != null) {
         label66: {
            boolean var5 = Intrinsics.areEqual((Object)var3.getType().name(), (Object)"WIND_CHARGE");
            if (!var4.hasEnded()) {
               if (var5 || var4.getArena() == null) {
                  break label66;
               }

               Arena var10001 = var4.getArena();
               Intrinsics.checkNotNullExpressionValue(var10001, "fight.arena");
               var10002 = var1.blockList();
               Intrinsics.checkNotNullExpressionValue(var10002, "e.blockList()");
               if (!this.a(var10001, var10002)) {
                  break label66;
               }
            }

            var6 = B.vj;
            var7 = false;
            if (var6.fV()) {
               var16 = Bukkit.getLogger();
               var10 = (new StringBuilder()).append("[SP DEBUG] ");
               var9 = var16;
               var8 = false;
               var11 = "cancelled EntityExplodeEvent: in arena but cannot reset or fight finished";
               var9.info(var10.append(var11).toString());
            }

            var1.setCancelled(true);
         }
      } else {
         Intrinsics.checkNotNullExpressionValue(var2, "loc");
         Arena var12 = this.d(var2);
         if (var12 != null && var12.isBuild() && var12.getCurrentFight() != null) {
            var10002 = var1.blockList();
            Intrinsics.checkNotNullExpressionValue(var10002, "e.blockList()");
            if (this.a(var12, var10002)) {
               var6 = B.vj;
               var7 = false;
               if (var6.fV()) {
                  var16 = Bukkit.getLogger();
                  var10 = (new StringBuilder()).append("[SP DEBUG] ");
                  var9 = var16;
                  var8 = false;
                  var11 = "cancelled EntityExplodeEvent: in arena but cannot reset";
                  var9.info(var10.append(var11).toString());
               }

               var1.setCancelled(true);
            }

            return;
         }

         if (this.bD.getConfig().getBoolean("cancel-explosions")) {
            var6 = B.vj;
            var7 = false;
            if (var6.fV()) {
               var16 = Bukkit.getLogger();
               var10 = (new StringBuilder()).append("[SP DEBUG] ");
               var9 = var16;
               var8 = false;
               var11 = "cancelled EntityExplodeEvent: outside arenas or arena is missing corners";
               var9.info(var10.append(var11).toString());
            }

            var1.setCancelled(true);
         }
      }

      B.a var13 = B.vj;
      boolean var14 = false;
      if (var13.fV()) {
         var16 = Bukkit.getLogger();
         var10 = (new StringBuilder()).append("[SP DEBUG] ");
         var9 = var16;
         var7 = false;
         var11 = "Explosion at " + (new D(var2)).gb();
         var9.info(var10.append(var11).toString());
      }

      var13 = B.vj;
      var14 = false;
      if (var13.fV()) {
         var16 = Bukkit.getLogger();
         var10 = (new StringBuilder()).append("[SP DEBUG] ");
         var9 = var16;
         var7 = false;
         var11 = "Explosion status: cancelled=" + var1.isCancelled();
         var9.info(var10.append(var11).toString());
      }

   }

   @EventHandler
   public final void a(@NotNull BlockExplodeEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      B.a var2 = B.vj;
      boolean var3 = false;
      boolean var4;
      Logger var6;
      StringBuilder var7;
      String var8;
      Logger var10000;
      if (var2.fV()) {
         var10000 = Bukkit.getLogger();
         var7 = (new StringBuilder()).append("[SP DEBUG] ");
         var6 = var10000;
         var4 = false;
         var8 = "BlockExplodeEvent detected";
         var6.info(var7.append(var8).toString());
      }

      var2 = null;
      Fight var11 = bC.b(var1.getBlock());
      Arena var9 = var11 != null ? var11.getArena() : null;
      if ((var9 != null ? var9.getCurrentFight() : null) == null) {
         Location var10001 = var1.getBlock().getLocation();
         Intrinsics.checkNotNullExpressionValue(var10001, "e.block.location");
         var9 = this.d(var10001);
      }

      boolean var12;
      label53: {
         if (var9 != null) {
            var11 = var9.getCurrentFight();
            if (var11 != null) {
               var12 = var11.hasEnded();
               break label53;
            }
         }

         var12 = false;
      }

      boolean var5;
      B.a var10;
      if (var12) {
         var10 = B.vj;
         var4 = false;
         if (var10.fV()) {
            var10000 = Bukkit.getLogger();
            var7 = (new StringBuilder()).append("[SP DEBUG] ");
            var6 = var10000;
            var5 = false;
            var8 = "cancelled BlockExplodeEvent in " + var9.getName() + ": fight had already ended";
            var6.info(var7.append(var8).toString());
         }

         var1.setCancelled(true);
      }

      if (var9 != null) {
         List var10002 = var1.blockList();
         Intrinsics.checkNotNullExpressionValue(var10002, "e.blockList()");
         this.a(var9, var10002);
      } else {
         var10 = B.vj;
         var4 = false;
         if (var10.fV()) {
            var10000 = Bukkit.getLogger();
            var7 = (new StringBuilder()).append("[SP DEBUG] ");
            var6 = var10000;
            var5 = false;
            var8 = "BlockExplodeEvent - did not find any arena for the location";
            var6.info(var7.append(var8).toString());
         }

         if (this.bD.getConfig().getBoolean("cancel-explosions")) {
            var10 = B.vj;
            var4 = false;
            if (var10.fV()) {
               var10000 = Bukkit.getLogger();
               var7 = (new StringBuilder()).append("[SP DEBUG] ");
               var6 = var10000;
               var5 = false;
               var8 = "cancelled BlockExplodeEvent";
               var6.info(var7.append(var8).toString());
            }

            var1.setCancelled(true);
         }
      }

   }

   private final Arena d(Location var1) {
      Iterator var2 = this.bD.M.iterator();

      Arena var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (Arena)var2.next();
      } while(var3.getCorner1() == null || var3.getCorner2() == null || !t.a(var1, var3.getCorner1(), var3.getCorner2()));

      B.a var4 = B.vj;
      boolean var5 = false;
      if (var4.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var8 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var7 = var10000;
         boolean var6 = false;
         String var9 = "inside arena detected: " + var3.getName() + ", build=" + var3.isBuild() + ", isFight=" + (var3.getCurrentFight() != null);
         var7.info(var8.append(var9).toString());
      }

      return var3;
   }

   private final boolean a(Arena var1, List<Block> var2) {
      if (var1.getCurrentFight() != null && !var1.getCurrentFight().hasEnded() && var1.isBuild()) {
         final BattleKit var3 = var1.getCurrentFight().getKit();
         var2.removeIf(e::b);
         B.a var4 = B.vj;
         boolean var5 = false;
         boolean var9;
         if (var4.fV()) {
            Logger var10000 = Bukkit.getLogger();
            StringBuilder var19 = (new StringBuilder()).append("[SP DEBUG] ");
            Logger var18 = var10000;
            boolean var6 = false;
            StringBuilder var25 = (new StringBuilder()).append("Saving explosion blocks for a later reset (total of ").append(var2.size()).append(" blocks):");
            Iterable var7 = (Iterable)var2;
            StringBuilder var8 = var25;
            var9 = false;
            Collection var11 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var7, 10)));
            boolean var12 = false;
            Iterator var13 = var7.iterator();

            while(var13.hasNext()) {
               Object var14 = var13.next();
               Block var15 = (Block)var14;
               boolean var17 = false;
               var11.add(var15.getType() + " / " + (new D(var15.getLocation())).gb());
            }

            String var20 = var8.append((List)var11).toString();
            var18.info(var19.append(var20).toString());
         }

         Iterable var21 = (Iterable)var2;
         var5 = false;
         Iterator var22 = var21.iterator();

         Block var24;
         do {
            if (!var22.hasNext()) {
               return false;
            }

            Object var23 = var22.next();
            var24 = (Block)var23;
            var9 = false;
         } while(var1.getCurrentFight().addBlockChange(new DefaultCachedBlockChange(var24.getLocation(), var24)));

         return true;
      } else {
         var2.clear();
         return true;
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public final void a(@NotNull BlockPlaceEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null) {
         Block var3 = var1.getBlockPlaced();
         BlockState var4 = var1.getBlockReplacedState();
         if (r.k(var3)) {
            B.vj.Y("Bed break event for rollback: " + var1.getPlayer().getName() + ' ' + var3.getType() + ' ' + var3.getLocation());
            MaterialData var9 = var3.getLocation().getBlock().getState().getData();
            if (var9 instanceof Bed) {
               Bed var10001 = (Bed)var9;
               Intrinsics.checkNotNullExpressionValue(var3, "placed");
               Pair var6 = this.a(var10001, var3);
               Block var7 = (Block)var6.component1();
               Block var8 = (Block)var6.component2();
               if (!var2.addBlockChange(new DefaultCachedBlockChange(var7.getLocation(), var4.getType(), var4.getRawData())) || !var2.addBlockChange(new DefaultCachedBlockChange(var8.getLocation(), var4.getType(), var4.getRawData()))) {
                  var1.setCancelled(true);
               }
            }

            return;
         }

         if (!var2.addBlockChange(new DefaultCachedBlockChange(var3.getLocation(), var4.getType(), var4.getRawData()))) {
            var1.setCancelled(true);
            return;
         }

         Block var5 = var3.getLocation().subtract(0.0D, 1.0D, 0.0D).getBlock();
         e.a var10000 = bC;
         Intrinsics.checkNotNullExpressionValue(var5, "b2");
         if (var10000.c(var5) && !var2.addBlockChange(new DefaultCachedBlockChange(var5.getLocation(), var5))) {
            var1.setCancelled(true);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public final void a(@NotNull BlockBreakEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      Player var2 = var1.getPlayer();
      Fight var3 = AbstractFight.getCurrentFight(var2);
      if (var3 != null) {
         Block var4 = var1.getBlock();
         if (r.k(var4)) {
            B.vj.Y("Bed break event for rollback: " + var2.getName() + ' ' + var4.getType() + ' ' + var4.getLocation());
            MaterialData var9 = var4.getLocation().getBlock().getState().getData();
            if (var9 instanceof Bed) {
               Bed var10001 = (Bed)var9;
               Intrinsics.checkNotNullExpressionValue(var4, "block");
               Pair var6 = this.a(var10001, var4);
               Block var7 = (Block)var6.component1();
               Block var8 = (Block)var6.component2();
               if (!var3.addBlockChange(new DefaultCachedBlockChange(var7.getLocation(), var7)) || !var3.addBlockChange(new DefaultCachedBlockChange(var8.getLocation(), var8))) {
                  var1.setCancelled(true);
               }
            }

            return;
         }

         if (!var3.addBlockChange(new DefaultCachedBlockChange(var4.getLocation(), var4))) {
            var1.setCancelled(true);
            return;
         }

         Block var5 = var4.getLocation().subtract(0.0D, 1.0D, 0.0D).getBlock();
         if (var5.getType() == Material.DIRT && !var3.addBlockChange(new DefaultCachedBlockChange(var5.getLocation(), var5))) {
            var1.setCancelled(true);
         }
      }

   }

   private final Pair<Block, Block> a(Bed var1, Block var2) {
      Block var3 = var1.isHeadOfBed() ? var2 : var2.getRelative(var1.getFacing());
      Block var4 = var1.isHeadOfBed() ? var2.getRelative(var1.getFacing().getOppositeFace()) : var2;
      return new Pair(var4, var3);
   }

   private static final boolean b(Function1 var0, Object var1) {
      Intrinsics.checkNotNullParameter(var0, "$tmp0");
      return (Boolean)var0.invoke(var1);
   }

   @JvmStatic
   public static final boolean a(@NotNull Block var0) {
      return bC.c(var0);
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0006\u001a\u0004\u0018\u00010\u00072\b\u0010\b\u001a\u0004\u0018\u00010\tJ\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\tH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\r"},
      d2 = {"Lga/strikepractice/arena/reset/RollbackListener$Companion;", "", "()V", "PLACED_IN_FIGHT", "", "PLACED_IN_FIGHT_NON_BREAKABLE", "placedInFight", "Lga/strikepractice/fights/Fight;", "block", "Lorg/bukkit/block/Block;", "turnsToDirt", "", "b", "strikepractice-core"}
   )
   public static final class a {
      private a() {
      }

      @Nullable
      public final Fight b(@Nullable Block var1) {
         MetadataValue var2 = StrikePractice.getInstance().a((Metadatable)var1, "StrikePracticePlacedInFight");
         if ((var2 != null ? var2.value() : null) instanceof Fight) {
            Object var10000 = var2.value();
            Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type ga.strikepractice.fights.Fight");
            return (Fight)var10000;
         } else {
            return null;
         }
      }

      @JvmStatic
      public final boolean c(@NotNull Block var1) {
         Intrinsics.checkNotNullParameter(var1, "b");
         Material var2 = var1.getType();
         return var2 == Material.GRASS || var2 == Material.MYCEL || var2 == Material.DIRT && var1.getData() == 2;
      }

      // $FF: synthetic method
      public a(DefaultConstructorMarker var1) {
         this();
      }
   }
}
