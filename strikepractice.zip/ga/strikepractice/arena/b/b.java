package ga.strikepractice.arena.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.CachedBlockChange;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;

public class b {
   private static final Set<b.a> bs = Collections.newSetFromMap(new ConcurrentHashMap());
   private final StrikePractice bt;
   private final ga.strikepractice.arena.b.a bu;
   private final ga.strikepractice.arena.b.a bv;

   public b(StrikePractice var1) {
      this.bt = var1;
      this.bu = new d(var1);
      this.bv = this.aC() ? new c(this.bu) : null;
   }

   private boolean aC() {
      if (this.bt.getConfig().getBoolean("use-fawe-reset")) {
         if (Bukkit.getPluginManager().isPluginEnabled("FastAsyncWorldEdit")) {
            return true;
         }

         Bukkit.getLogger().warning("FAWE reset is enabled but FastAsyncWorldEdit is not enabled. Falling back to legacy reset.");
      }

      Bukkit.getLogger().info("FAWE reset is disabled. Using legacy arena reset.");
      return false;
   }

   public static int aD() {
      return bs.stream().mapToInt((var0) -> {
         return var0.bw;
      }).sum();
   }

   private void a(b.a var1) {
      bs.remove(var1);
      var1.by.run();
   }

   public void b(b.a var1) {
      bs.add(var1);
      ga.strikepractice.arena.b.a var2 = this.aC() ? this.bv : this.bu;
      var2.a(var1.arena, var1.bx, var1.bw, () -> {
         this.a(var1);
      });
      if (bs.size() > 200 && bs.size() % 10 == 0) {
         String var3 = "A possible bug detected: arena reset task has " + bs.size() + " entries (concurrently resetting arenas).";
         Bukkit.getLogger().warning(var3);
         Bukkit.broadcast(var3, ga.strikepractice.k.a.pz.dY());
      }

   }

   public static int aE() {
      return bs.size();
   }

   public void a(ga.strikepractice.arena.c var1) {
      ga.strikepractice.arena.b.a var2 = this.aC() ? this.bv : this.bu;
      var2.b(var1);
   }

   public static class a {
      final Arena arena;
      final int bw;
      final Iterator<? extends CachedBlockChange> bx;
      final Runnable by;

      public a(Arena var1, int var2, Iterator<? extends CachedBlockChange> var3, Runnable var4) {
         this.arena = var1;
         this.bw = var2;
         this.bx = var3;
         this.by = var4;
      }
   }
}
