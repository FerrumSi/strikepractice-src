package ga.strikepractice.arena;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.utils.B;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.plugin.Plugin;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"},
   d2 = {"Lga/strikepractice/arena/KeepArenasLoaded;", "", "()V", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nKeepArenasLoaded.kt\nKotlin\n*S Kotlin\n*F\n+ 1 KeepArenasLoaded.kt\nga/strikepractice/arena/KeepArenasLoaded\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,53:1\n1#2:54\n81#3,4:55\n81#3,4:60\n81#3,4:64\n1855#4:59\n1856#4:68\n*S KotlinDebug\n*F\n+ 1 KeepArenasLoaded.kt\nga/strikepractice/arena/KeepArenasLoaded\n*L\n17#1:55,4\n33#1:60,4\n42#1:64,4\n31#1:59\n31#1:68\n*E\n"})
public final class d {
   public d() {
      StrikePractice var1 = StrikePractice.getInstance();
      Set var2 = var1.M;
      Integer var5 = var1.getConfig().getInt("arena-chunk-radius");
      int var6 = ((Number)var5).intValue();
      boolean var7 = false;
      int var3 = (var6 > 0 ? var5 : null) != null ? var6 > 0 ? var5 : null : 10;
      B.a var4 = B.vj;
      boolean var26 = false;
      Logger var10000;
      boolean var29;
      if (var4.fV()) {
         var10000 = Bukkit.getLogger();
         StringBuilder var21 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var20 = var10000;
         var29 = false;
         String var22 = "Enabling chunk keeping (chunkRadius=" + var3 + ", " + var2.size() + " arenas, =" + var2.size() * var3 * var3 + " chunks)";
         var20.info(var21.append(var22).toString());
      }

      Method var27;
      try {
         Class[] var28 = new Class[]{Plugin.class};
         var27 = Chunk.class.getMethod("addPluginChunkTicket", var28);
      } catch (Exception var24) {
         if (B.vj.fV()) {
            var24.printStackTrace();
         }

         Bukkit.getLogger().warning("keep-arenas-loaded could not be enabled! Probably old server software.");
         var27 = null;
      }

      Method var25 = var27;
      if (var27 != null) {
         Intrinsics.checkNotNullExpressionValue(var2, "arenas");
         Iterable var30 = (Iterable)var2;
         var29 = false;
         Iterator var31 = var30.iterator();

         while(var31.hasNext()) {
            Object var8 = var31.next();
            Arena var9 = (Arena)var8;
            boolean var10 = false;

            try {
               B.a var11 = B.vj;
               boolean var12 = false;
               StringBuilder var13;
               Logger var14;
               boolean var15;
               String var16;
               if (var11.fV()) {
                  var10000 = Bukkit.getLogger();
                  var13 = (new StringBuilder()).append("[SP DEBUG] ");
                  var14 = var10000;
                  var15 = false;
                  var16 = "Keeping " + var9.getName() + " loaded";
                  var14.info(var13.append(var16).toString());
               }

               Chunk var36 = var9.getCenter().getChunk();
               Intrinsics.checkNotNullExpressionValue(var36, "arena.center.chunk");
               Chunk var32 = var36;

               for(int var33 = 0; var33 < var3; ++var33) {
                  for(int var35 = 0; var35 < var3; ++var35) {
                     int var17 = var3 / 2;
                     Chunk var18 = var9.getCenter().getWorld().getChunkAt(var32.getX() + var33 - var17, var32.getZ() + var35 - var17);
                     Object[] var19 = new Object[]{var1};
                     var25.invoke(var18, var19);
                  }
               }

               B.a var34 = B.vj;
               var15 = false;
               if (var34.fV()) {
                  var10000 = Bukkit.getLogger();
                  var13 = (new StringBuilder()).append("[SP DEBUG] ");
                  var14 = var10000;
                  boolean var37 = false;
                  var16 = var9.getName() + " should be kept loaded now";
                  var14.info(var13.append(var16).toString());
               }
            } catch (Exception var23) {
               Bukkit.getLogger().warning("keep-arenas-loaded failed for arena " + var9.getName() + "! probably invalid world or center.");
               var23.printStackTrace();
            }
         }
      }

   }
}
