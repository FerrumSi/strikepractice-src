package ga.strikepractice.arena;

import ga.strikepractice.StrikePractice;
import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;

public class b {
   private final StrikePractice aM;
   private File aN;
   private YamlConfiguration aO;

   public b(StrikePractice var1) {
      this.aM = var1;
      this.at();
   }

   private void at() {
      this.aN = new File(this.aM.getDataFolder(), File.separator + "arenas.yml");
      if (!this.aN.exists()) {
         try {
            this.aN.createNewFile();
         } catch (IOException var2) {
            var2.printStackTrace();
            return;
         }
      }

      this.aO = YamlConfiguration.loadConfiguration(this.aN);
   }

   public YamlConfiguration au() {
      return this.aO;
   }

   public File av() {
      return this.aN;
   }

   public void save() {
      try {
         this.au().save(this.av());
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }
}
