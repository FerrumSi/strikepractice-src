package ga.strikepractice.arena;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.K;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.h;
import ga.strikepractice.utils.r;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

public class a implements CommandExecutor, TabCompleter {
   private final StrikePractice aF;
   private final Map<UUID, Long> aG = new HashMap();
   public static String[] aH = new String[]{"sumo", "skywars", "spleef", "parkour"};

   public a(StrikePractice var1) {
      this.aF = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player) {
         final Player var5 = (Player)var1;
         if (var4.length == 0) {
            var5.sendMessage(ChatColor.GOLD + "/arena create <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena delete <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena pos1 <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena pos2 <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena center <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena corner1 <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena corner2 <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena build <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena kits <arena> <kit>");
            var5.sendMessage(ChatColor.GOLD + "/arena ffa <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena clearkits <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena removekit <arena> <kit>");
            var5.sendMessage(ChatColor.GOLD + "/arena teleport <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena info <arena>");
            var5.sendMessage(ChatColor.GOLD + "/arena list [filter text]");
            var5.sendMessage(ChatColor.GOLD + "/arena list all (shows copies too)");
            var5.sendMessage(ChatColor.GOLD + "/arena alerts");
            var5.sendMessage(ChatColor.GOLD + "/arena displayname <name> <displayname>");
            var5.sendMessage(ChatColor.GOLD + "/arena copypaste <name>");
            var5.sendMessage(ChatColor.RED + "NEW: /arena icon <name>" + ChatColor.GRAY + " (hold the icon in your hand)");
            return true;
         }

         if (var4.length >= 1) {
            if (!var4[0].equalsIgnoreCase("all") && !var4[0].equalsIgnoreCase("list")) {
               if (var4[0].toLowerCase().contains("alerts")) {
                  if (var5.hasMetadata("StrikePracticeRollbackRateAlerts")) {
                     var5.removeMetadata("StrikePracticeRollbackRateAlerts", this.aF);
                     var5.sendMessage(ChatColor.RED + "Rollback alerts turned off.");
                     c.aX = false;
                  } else {
                     var5.setMetadata("StrikePracticeRollbackRateAlerts", new FixedMetadataValue(this.aF, true));
                     var5.sendMessage(ChatColor.RED + "Rollback alerts turned on.");
                     c.aX = true;
                  }
               }
            } else {
               if (this.aF.M.isEmpty()) {
                  var5.sendMessage(ChatColor.RED + "No arenas found!");
                  return true;
               }

               String var6 = var4.length > 1 ? var4[1].toLowerCase() : null;
               var1.sendMessage(ChatColor.GOLD + "Arena List - Total Arenas: " + this.aF.M.size());
               Iterator var7 = this.aF.M.iterator();

               label440:
               while(true) {
                  Arena var8;
                  do {
                     if (!var7.hasNext()) {
                        break label440;
                     }

                     var8 = (Arena)var7.next();
                  } while((var6 != null || var8.getName().contains(":")) && (var6 == null || !var6.equals("all") && !var8.getName().contains(var6)));

                  var1.sendMessage(ChatColor.YELLOW + "- " + var8.getName() + " (Displayname: " + ChatColor.RESET + var8.getDisplayName() + ChatColor.YELLOW + ")");
               }
            }
         }

         if (var4.length > 1) {
            final Arena var18 = this.a((String)var4[1], (CommandSender)var5);
            String var19 = var4[0].toLowerCase();
            byte var20 = -1;
            switch(var19.hashCode()) {
            case -1364013995:
               if (var19.equals("center")) {
                  var20 = 16;
               }
               break;
            case -1364013605:
               if (var19.equals("centre")) {
                  var20 = 15;
               }
               break;
            case -1360201941:
               if (var19.equals("teleport")) {
                  var20 = 23;
               }
               break;
            case -1352294148:
               if (var19.equals("create")) {
                  var20 = 0;
               }
               break;
            case -1335458389:
               if (var19.equals("delete")) {
                  var20 = 1;
               }
               break;
            case -1270217686:
               if (var19.equals("clearkits")) {
                  var20 = 21;
               }
               break;
            case -934610812:
               if (var19.equals("remove")) {
                  var20 = 2;
               }
               break;
            case -642711654:
               if (var19.equals("togglebuild")) {
                  var20 = 18;
               }
               break;
            case 3708:
               if (var19.equals("tp")) {
                  var20 = 24;
               }
               break;
            case 101281:
               if (var19.equals("ffa")) {
                  var20 = 19;
               }
               break;
            case 3226745:
               if (var19.equals("icon")) {
                  var20 = 25;
               }
               break;
            case 3237038:
               if (var19.equals("info")) {
                  var20 = 3;
               }
               break;
            case 3292253:
               if (var19.equals("kits")) {
                  var20 = 20;
               }
               break;
            case 3327217:
               if (var19.equals("loc1")) {
                  var20 = 5;
               }
               break;
            case 3327218:
               if (var19.equals("loc2")) {
                  var20 = 9;
               }
               break;
            case 3373707:
               if (var19.equals("name")) {
                  var20 = 8;
               }
               break;
            case 3446877:
               if (var19.equals("pos1")) {
                  var20 = 6;
               }
               break;
            case 3446878:
               if (var19.equals("pos2")) {
                  var20 = 10;
               }
               break;
            case 3529469:
               if (var19.equals("show")) {
                  var20 = 4;
               }
               break;
            case 94094958:
               if (var19.equals("build")) {
                  var20 = 17;
               }
               break;
            case 155069561:
               if (var19.equals("forceusing")) {
                  var20 = 11;
               }
               break;
            case 955046012:
               if (var19.equals("corner1")) {
                  var20 = 13;
               }
               break;
            case 955046013:
               if (var19.equals("corner2")) {
                  var20 = 14;
               }
               break;
            case 1282385874:
               if (var19.equals("removekit")) {
                  var20 = 22;
               }
               break;
            case 1520816190:
               if (var19.equals("copypaste")) {
                  var20 = 12;
               }
               break;
            case 1715102285:
               if (var19.equals("displayname")) {
                  var20 = 7;
               }
               break;
            case 1985607643:
               if (var19.equals("seticon")) {
                  var20 = 26;
               }
            }

            switch(var20) {
            case 0:
               if (var18 != null) {
                  var5.sendMessage(ChatColor.RED + "That arena already exists!");
                  return true;
               }

               if (!K.ac(var4[1])) {
                  var5.sendMessage(ChatColor.RED + "The name must be alphanumeric!");
                  return true;
               }

               String var9 = var4[1].toLowerCase();
               c var10 = new c(var9);
               var10.saveForStrikePractice();
               var5.sendMessage(ChatColor.BLUE + "Created a new arena!");
               if (var9.contains("build")) {
                  var5.sendMessage(ChatColor.RED + "Arena name contains 'build'. Arena build enabled. You can change that with /arena build " + var9);
                  var10.setBuild(true);
               }

               if (!var9.equals("sumoevent")) {
                  String[] var23 = aH;
                  int var24 = var23.length;

                  for(int var25 = 0; var25 < var24; ++var25) {
                     String var14 = var23[var25];
                     if (var9.contains(var14)) {
                        Iterator var15 = this.aF.kits.iterator();

                        while(var15.hasNext()) {
                           BattleKit var16 = (BattleKit)var15.next();
                           String var17 = var16.getName();
                           if (var17 != null && var17.toLowerCase().contains(var14)) {
                              ga.strikepractice.utils.d.b(var5, ChatColor.RED + "Click here if you want to force '" + var17 + "' kit to use this arena. Otherwise all kits (that aren't set to other arenas) can use this arena.", "/arena kits " + var9 + " " + var17);
                           }
                        }
                     }
                  }
               }
               break;
            case 1:
            case 2:
               if (this.a(var18, var4[1], var1)) {
                  if (var18.removeFromStrikePractice()) {
                     var5.sendMessage(ChatColor.RED + "Deleted the arena " + var18.getName() + ".");
                  } else {
                     var5.sendMessage(ChatColor.RED + "Deleted the arena " + var18.getName() + " (was not found anyways).");
                  }
               }
               break;
            case 3:
            case 4:
               if (var18 == null) {
                  var5.sendMessage(ChatColor.RED + "That arena does not exist!");
               } else {
                  var5.sendMessage(ChatColor.GOLD + "Arena Info: " + var18.getName());
                  var5.sendMessage(ChatColor.YELLOW + "Display name: " + ChatColor.RESET + var18.getDisplayName());
                  var5.sendMessage(ChatColor.YELLOW + "Pos1: " + (var18.getLoc1() == null ? null : (new D(var18.getLoc1())).gb()));
                  var5.sendMessage(ChatColor.YELLOW + "Pos2: " + (var18.getLoc2() == null ? null : (new D(var18.getLoc2())).gb()));
                  var5.sendMessage(ChatColor.YELLOW + "Center: " + (var18.getCenter() == null ? null : (new D(var18.getCenter())).gb()));
                  var5.sendMessage(ChatColor.YELLOW + "Corner1: " + (var18.getCorner1() == null ? null : (new D(var18.getCorner1())).gb()));
                  var5.sendMessage(ChatColor.YELLOW + "Corner2: " + (var18.getCorner2() == null ? null : (new D(var18.getCorner2())).gb()));
                  var5.sendMessage(ChatColor.YELLOW + "Kits: " + var18.getKits().toString().replace("[", "").replace("]", ""));
                  var5.sendMessage(ChatColor.YELLOW + "Build: " + var18.isBuild());
                  var5.sendMessage(ChatColor.YELLOW + "FFA: " + var18.isFFA());
                  var5.sendMessage(ChatColor.YELLOW + "Available: " + !var18.isUsing() + (var18.isUsing() && var18.isBuild() && !this.aF.getConfig().getBoolean("build-fights-in-main-arenas-world") && var18.getCenter().getWorld().getName().equals(StrikePractice.A) ? " (config.yml has build-fights-in-main-arenas-world: false)" : ""));
                  var5.sendMessage(ChatColor.YELLOW + "Needs rollback: " + var18.needsRollback());
                  var5.sendMessage(ChatColor.YELLOW + "Rollback rate: " + (var18.getCustomMaxChangesPerTick() <= 0 ? c.aV : var18.getCustomMaxChangesPerTick()) + " blocks/tick");
               }
               break;
            case 5:
            case 6:
               if (this.a(var18, var4[1], var1) && this.d(var5)) {
                  var18.setLoc1(var5.getLocation());
                  var5.sendMessage(ChatColor.BLUE + "You have set the pos1 of the arena " + var18.getName() + ".");
                  var18.sendPossibleWrongWorldInfo(var5);
                  this.a(var5, var18);
               }
               break;
            case 7:
            case 8:
               if (this.a(var18, var4[1], var1)) {
                  if (var4.length > 2) {
                     var18.setDisplayName(f.K(var4[2]));
                     var5.sendMessage(ChatColor.BLUE + "You have set a new displayname: " + ChatColor.RESET + var18.getDisplayName());
                  } else {
                     var5.sendMessage(ChatColor.YELLOW + "/arena displayname <arena> <displayname>");
                  }
               }
               break;
            case 9:
            case 10:
               if (this.a(var18, var4[1], var1)) {
                  if (this.aF.getConfig().getBoolean("no-arenas-in-default-world") && !var5.getWorld().getName().equals(StrikePractice.A)) {
                     var5.sendMessage(ChatColor.RED + "Arena creation is only available in the '" + StrikePractice.A + "' world. If you wish to create arenas in other worlds change 'no-arenas-in-default-world' in the config.yml. You do it at your own risk!");
                  } else if (this.d(var5)) {
                     var18.setLoc2(var5.getLocation());
                     var5.sendMessage(ChatColor.BLUE + "You have set the pos2 of the arena " + var4[1] + ".");
                     var18.sendPossibleWrongWorldInfo(var5);
                     this.a(var5, var18);
                  }
               }
               break;
            case 11:
               if (this.a(var18, var4[1], var1)) {
                  var18.setUsing(!var18.isUsing());
                  var5.sendMessage(ChatColor.RED + var18.getName() + " is available: " + !var18.isUsing());
               }
               break;
            case 12:
               if (this.a(var18, var4[1], var1)) {
                  if (var18.getCorner1() == null) {
                     var5.sendMessage(ChatColor.RED + "The corner1 of the arena is missing!");
                  } else if (var18.getCorner2() == null) {
                     var5.sendMessage(ChatColor.RED + "The corner2 of the arena is missing!");
                  } else if (var18.getCenter() == null) {
                     var5.sendMessage(ChatColor.RED + "The center of the arena is missing!");
                  } else if (!var18.getCenter().getWorld().getName().equals(var5.getWorld().getName())) {
                     var5.sendMessage(ChatColor.RED + "You're not in the same world!");
                  } else {
                     var5.sendMessage(ChatColor.RED + "Copy pasting in 3 seconds. " + ChatColor.BOLD + "Move to cancel!");
                     final Location var22 = var5.getLocation();
                     (new BukkitRunnable() {
                        public void run() {
                           if (var5.getLocation().distanceSquared(var22) > 0.5D) {
                              var5.sendMessage(ChatColor.RED + "Cancelled because you moved!");
                           } else {
                              Location var1 = var18.getCorner1();
                              Location var2 = var18.getCorner2();
                              int var3 = Math.max(var1.getBlockX(), var2.getBlockX());
                              int var4 = Math.min(var1.getBlockX(), var2.getBlockX());
                              int var5x = Math.max(var1.getBlockY(), var2.getBlockY());
                              int var6 = Math.min(var1.getBlockY(), var2.getBlockY());
                              int var7 = Math.max(var1.getBlockZ(), var2.getBlockZ());
                              int var8 = Math.min(var1.getBlockZ(), var2.getBlockZ());
                              World var9 = var1.getWorld();
                              if (!var9.getName().equals(var5.getWorld().getName())) {
                                 var5.sendMessage(ChatColor.RED + "You're not in the same world!");
                              } else {
                                 var5.sendMessage(ChatColor.BLUE + "Copy pasting...");

                                 int var13;
                                 for(int var12 = var4; var12 <= var3; ++var12) {
                                    for(var13 = var6; var13 <= var5x; ++var13) {
                                       for(int var14 = var8; var14 <= var7; ++var14) {
                                          Location var10 = new Location(var9, (double)var12, (double)var13, (double)var14);
                                          Location var11 = var10.clone().subtract(var18.getCenter()).add(var22);
                                          if (var11.getBlockY() >= 0 && var10.getBlock() != null) {
                                             if (var10.getBlock().getType() != null) {
                                                var11.getBlock().setType(var10.getBlock().getType());
                                                var11.getBlock().setData(var10.getBlock().getData());
                                             }

                                             Object var15 = ga.strikepractice.utils.a.f(var10.getBlock());
                                             if (var15 != null) {
                                                ga.strikepractice.utils.a.a(var11.getBlock(), var15);
                                             }

                                             try {
                                                var11.getBlock().setBiome(var10.getBlock().getBiome());
                                             } catch (Exception var17) {
                                                if (B.fQ()) {
                                                   B.debug("Failed to set biome " + var10.getBlock().getBiome() + " at " + var11);
                                                }

                                                if (B.fR()) {
                                                   var17.printStackTrace();
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }

                                 var5.sendMessage(ChatColor.BLUE + "Region pasted!");
                                 String var18x = null;

                                 for(var13 = 0; var13 < 1000; ++var13) {
                                    var18x = var18.getName() + var13;
                                    if (c.getArena(var18x) == null) {
                                       break;
                                    }
                                 }

                                 c var19 = new c(var18x);
                                 var19.saveForStrikePractice();
                                 var5.sendMessage(ChatColor.BLUE + "Created a new arena '" + var18x + "'");
                                 var19.setBuild(var18.isBuild());
                                 var22.setDirection(var18.getCenter().getDirection());
                                 var19.setCenter(var22);
                                 Location var20 = new Location(var18.getCenter().getWorld(), (double)var18.getCenter().getBlockX(), (double)var18.getCenter().getBlockY(), (double)var18.getCenter().getBlockZ());
                                 Location var21 = new Location(var22.getWorld(), (double)var22.getBlockX(), (double)var22.getBlockY(), (double)var22.getBlockZ());
                                 var19.setLoc1(var18.getLoc1().clone().subtract(var20).add(var21));
                                 var19.setLoc2(var18.getLoc2().clone().subtract(var20).add(var21));
                                 var19.setCorner1(var18.getCorner1().clone().subtract(var20).add(var21));
                                 var19.setCorner2(var18.getCorner2().clone().subtract(var20).add(var21));
                                 if (!var18.getDisplayName().equals(var18.getName())) {
                                    var19.setDisplayName(var18.getDisplayName());
                                 }

                                 var19.setKits(var18.getKits());
                                 var5.sendMessage(ChatColor.BLUE + "Positions, names, correct build mode and kits set.");
                                 var5.sendMessage(ChatColor.GOLD + "Everything done!");
                              }
                           }

                        }
                     }).runTaskLater(this.aF, 60L);
                  }
               }
               break;
            case 13:
               if (this.a(var18, var4[1], var1)) {
                  if (this.aF.getConfig().getBoolean("no-arenas-in-default-world") && !var5.getWorld().getName().equals(StrikePractice.A)) {
                     StrikePractice.getInstance();
                     var5.sendMessage(ChatColor.RED + "Arena creation is only available in the '" + StrikePractice.A + "' world. If you wish to create arenas in other worlds change 'no-arenas-in-default-world' in the config.yml. You do it at your own risk!");
                  } else {
                     var18.setCorner1(var5.getLocation());
                     var5.sendMessage(ChatColor.BLUE + "You have set the corner1 of the arena " + var18.getName() + ".");
                     var18.sendPossibleWrongWorldInfo(var5);
                     this.a(var5, var18);
                  }
               }
               break;
            case 14:
               if (this.a(var18, var4[1], var1)) {
                  if (this.aF.getConfig().getBoolean("no-arenas-in-default-world") && !var5.getWorld().getName().equals(StrikePractice.A)) {
                     StrikePractice.getInstance();
                     var5.sendMessage(ChatColor.RED + "Arena creation is only available in the '" + StrikePractice.A + "' world. If you wish to create arenas in other worlds change 'no-arenas-in-default-world' in the config.yml. You do it at your own risk!");
                  } else {
                     var18.setCorner2(var5.getLocation());
                     var5.sendMessage(ChatColor.BLUE + "You have set the corner2 of the arena " + var4[1] + ".");
                     var18.sendPossibleWrongWorldInfo(var5);
                     this.a(var5, var18);
                  }
               }
               break;
            case 15:
            case 16:
               if (this.a(var18, var4[1], var1) && this.d(var5)) {
                  var18.setCenter(var5.getLocation());
                  var5.sendMessage(ChatColor.BLUE + "You have set the center of the arena " + var18.getName() + ".");
                  var18.sendPossibleWrongWorldInfo(var5);
                  this.a(var5, var18);
               }
               break;
            case 17:
            case 18:
               if (this.a(var18, var4[1], var1)) {
                  var18.setBuild(!var18.isBuild());
                  if (var18.isBuild()) {
                     var5.sendMessage(ChatColor.BLUE + "The arena " + var18.getName() + " is now a build arena.");
                     var5.sendMessage(ChatColor.RED + "Only kits that have 'build: true' can use this arena.");
                  } else {
                     var5.sendMessage(ChatColor.BLUE + "The arena " + var18.getName() + " is no longer a build arena.");
                     var5.sendMessage(ChatColor.RED + "Only kits that have 'build: false' can use this arena.");
                  }
               }
               break;
            case 19:
               if (this.a(var18, var4[1], var1)) {
                  if (!var18.isFFA() && !this.aF.af().d(var18)) {
                     var5.sendMessage(ChatColor.RED + "This arena is not valid for FFA!");
                     var5.sendMessage(ChatColor.RED + "Make sure it has: center, pos1, pos2, at least 1 kit");
                     if (this.aF.af().fX) {
                        var5.sendMessage(ChatColor.RED + "Also, make sure the arena is in /sprac arenasworld");
                     }

                     return true;
                  }

                  var18.setFFA(!var18.isFFA());
                  if (var18.isFFA()) {
                     var5.sendMessage(ChatColor.BLUE + "The arena " + var18.getName() + " is now an ffa arena.");
                     var5.sendMessage(ChatColor.GREEN + "Join the arena with /" + var18.getName() + ". Remember to restart the server first!");
                     var5.sendMessage(ChatColor.RED + "Please note that this arena is no longer used for normal fights (queue, duel, party). Do the command again to cancel it.");
                  } else {
                     var5.sendMessage(ChatColor.BLUE + "The arena " + var18.getName() + " is no longer an ffa arena.");
                  }

                  if (var18.isFFA() && var18.getKits().isEmpty()) {
                     var5.sendMessage(ChatColor.RED + "Remember to add at least 1 kit with /arena kits <arena> <kit>!");
                  }
               }
               break;
            case 20:
               if (this.a(var18, var4[1], var1)) {
                  if (var4.length > 2) {
                     if (!K.ac(var4[2])) {
                        var5.sendMessage(ChatColor.RED + "The name must be alphanumeric!");
                        return true;
                     }

                     var18.getKits().add(var4[2].toLowerCase());
                     var5.sendMessage(ChatColor.BLUE + "Current specified kits of the arena '" + var18.getName() + "': " + var18.getKits().toString().replace("[", "").replace("]", ""));
                     BattleKit var21 = BattleKit.getKit(var4[2].toLowerCase());
                     if (var21 == null) {
                        var5.sendMessage(ChatColor.RED + "Couldn't find that kit but it was still added.");
                     } else if (var21.isBuild() && !var18.isBuild()) {
                        ga.strikepractice.utils.d.b(var5, ChatColor.RED + "The kit is build but the arena is not build. Click here or do /arena build " + var18.getName() + " or /battlekit build " + var21.getName(), "/arena build " + var18.getName());
                     } else if (var21.isBuild() && !var18.isBuild()) {
                        ga.strikepractice.utils.d.b(var5, ChatColor.RED + "The arena is build but the kit is not build. Click here or do /battlekit build " + var18.getName() + " or /arena build " + var18.getName(), "/battlekit build " + var21.getName());
                     }
                  } else {
                     var5.sendMessage(ChatColor.BLUE + "/arena kits <name> <kit> - add a kit");
                     var5.sendMessage(ChatColor.BLUE + "Current specified kits of the arena '" + var18.getName() + "': " + var18.getKits().toString().replace("[", "").replace("]", ""));
                  }
               }
               break;
            case 21:
               if (this.a(var18, var4[1], var1)) {
                  var18.getKits().clear();
                  var5.sendMessage(ChatColor.BLUE + "The arena doesn't have specified kits anymore.");
               }
               break;
            case 22:
               if (this.a(var18, var4[1], var1)) {
                  if (var4.length > 2) {
                     var18.getKits().remove(var4[2].toLowerCase());
                  }

                  var5.sendMessage(ChatColor.BLUE + "Current specified kits of the arena '" + var18.getName() + "': " + var18.getKits().toString().replace("[", "").replace("]", ""));
               }
               break;
            case 23:
            case 24:
               if (this.a(var18, var4[1], var1)) {
                  UUID var11 = var5.getUniqueId();
                  if ((Long)this.aG.getOrDefault(var11, 0L) + 5000L > System.currentTimeMillis()) {
                     var5.sendMessage(ChatColor.GREEN + "Trying to find a specific arena? Use /sprac findarena to find nearby arenas.");
                  }

                  this.aG.put(var11, System.currentTimeMillis());
                  Location var12 = var18.getCenter();
                  var5.sendMessage("Teleporting...");
                  if (var12 != null && var12.getWorld() != null && Bukkit.getWorld(var12.getWorld().getName()) != null) {
                     N.e(var5, var18.getCenter());
                  } else {
                     var5.sendMessage(ChatColor.RED + "Invalid location!");
                  }
               }
               break;
            case 25:
            case 26:
               if (this.a(var18, var4[1], var1)) {
                  if (!r.h(var5.getItemInHand())) {
                     var5.sendMessage(ChatColor.RED + "Hold something in your hand.");
                     return true;
                  }

                  ItemStack var13 = var5.getItemInHand().clone();
                  if (!var13.getItemMeta().hasDisplayName()) {
                     var5.sendMessage(ChatColor.RED + "The item does not have a name. Using " + var18.getDisplayName() + ChatColor.RESET + ChatColor.GRAY + ". You can rename the icon with /sprac rename &6example_name");
                  }

                  var18.setIcon(var13);
                  var5.sendMessage(ChatColor.BLUE + "Icon set.");
               }
            }
         }
      }

      return true;
   }

   private void a(Player var1, Arena var2) {
      String var3 = ChatColor.RED + "Do not forget to set";
      int var4 = 0;
      if (var2.getCenter() == null) {
         var3 = var3 + " center";
         ++var4;
      }

      if (var2.getLoc1() == null) {
         var3 = var3 + (var4 > 0 ? (var2.getLoc2() != null ? " and pos1" : ", pos1") : " pos1");
         ++var4;
      }

      if (var2.getLoc2() == null) {
         var3 = var3 + (var4 > 0 ? " and pos2" : " pos2");
         ++var4;
      }

      if (var4 > 0) {
         var3 = var3 + "!";
         var1.sendMessage(var3);
      } else {
         var1.sendMessage(ChatColor.GREEN + "Arena successfully created!");
         this.aF.Z().F();
      }

   }

   private boolean a(Arena var1, String var2, CommandSender var3) {
      if (var1 != null) {
         return true;
      } else {
         var3.sendMessage(ChatColor.RED + "That arena does not exist!");
         String var4 = var2.toLowerCase();
         int var5 = 0;
         Iterator var6 = this.aF.M.iterator();

         while(var6.hasNext()) {
            Arena var7 = (Arena)var6.next();
            if (this.a(var7.getName().toLowerCase(), var4)) {
               if (var5 == 0) {
                  var3.sendMessage(ChatColor.GOLD + "Arenas with similar name:");
               }

               ++var5;
               if (var5 < 10) {
                  var3.sendMessage(ChatColor.YELLOW + "- " + var7.getName());
               }
            }
         }

         return false;
      }
   }

   private boolean a(String var1, String var2) {
      if (!var1.contains(var2) && !var2.contains(var1)) {
         return K.d(var1, var2) > 0.8D;
      } else {
         return true;
      }
   }

   private Arena a(String var1, CommandSender var2) {
      Iterator var3 = this.aF.M.iterator();

      Arena var4;
      do {
         if (!var3.hasNext()) {
            return null;
         }

         var4 = (Arena)var3.next();
      } while(!var4.getName().equalsIgnoreCase(var1));

      return var4;
   }

   private boolean d(Player var1) {
      if (this.aF.getConfig().getBoolean("no-arenas-in-default-world") && !var1.getWorld().getName().equals(StrikePractice.A)) {
         var1.sendMessage(ChatColor.RED + "Arena creation is only available in the '" + StrikePractice.A + "' world. If you wish to create arenas in other worlds change 'no-arenas-in-default-world' in the config.yml. You do it at your own risk!");
         return false;
      } else if (var1.getLocation().getY() < 0.0D) {
         var1.sendMessage(ChatColor.RED + "You cannot set the position below y=0.");
         return false;
      } else {
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length == 2) {
         List var6 = (List)this.aF.M.stream().map(Arena::getName).collect(Collectors.toList());
         var6.removeIf((var1x) -> {
            return !var1x.toLowerCase().contains(var4[1].toLowerCase());
         });
         var6.sort(new h(var4[1]));
         return var6;
      } else if (var4.length == 1) {
         ArrayList var5 = new ArrayList(Arrays.asList("create", "delete", "pos1", "pos2", "center", "build", "corner1", "corner2", "kits", "ffa", "removekit", "clearkits", "teleport", "info", "list", "copypaste", "displayname", "alerts", "seticon"));
         var5.sort(new h(var4[0]));
         var5.removeIf((var1x) -> {
            return !var1x.toLowerCase().contains(var4[0].toLowerCase());
         });
         return var5;
      } else {
         return null;
      }
   }
}
