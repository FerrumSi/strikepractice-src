package ga.strikepractice.e;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.u;
import ga.strikepractice.utils.x;
import java.util.Objects;
import org.bukkit.Material;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.scheduler.BukkitRunnable;

public class a implements Listener {
   public static final String dX = "StrikePracticeEnderPearlCooldown";
   private final StrikePractice dY;
   private final boolean dZ;
   private final boolean ea;

   public a(StrikePractice var1) {
      this.dY = var1;
      this.dZ = var1.getConfig().getBoolean("enderpearl-cooldown.modify-exp-level") && !x.fH();
      this.ea = var1.getConfig().getBoolean("enderpearl-cooldown.change-item-name") && !x.fH();
   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      var1.getPlayer().removeMetadata("StrikePracticeEnderPearlCooldown", this.dY);
      if (this.ea) {
         ItemStack[] var2 = var1.getPlayer().getInventory().getContents();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            ItemStack var5 = var2[var4];
            if (var5 != null && var5.getType() == Material.ENDER_PEARL && var5.hasItemMeta()) {
               ItemMeta var6 = var5.getItemMeta();
               var6.setDisplayName((String)null);
               var5.setItemMeta(var6);
            }
         }
      }

   }

   @EventHandler
   public void a(PlayerJoinEvent var1) {
      if (this.dZ) {
         var1.getPlayer().setLevel(0);
         var1.getPlayer().setExp(0.0F);
      }

   }

   @EventHandler
   public void b(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      Objects.requireNonNull(this.dY);
      if (var2.hasMetadata("StrikePracticeProtected") && var1.getItem() != null && var1.getItem().getType().equals(Material.ENDER_PEARL)) {
         var1.setCancelled(true);
      } else {
         if (var1.getItem() != null && var1.getItem().getType() == Material.ENDER_PEARL && (var1.getAction() == Action.RIGHT_CLICK_AIR || var1.getAction() == Action.RIGHT_CLICK_BLOCK) && var2.hasMetadata("StrikePracticeEnderPearlCooldown")) {
            MetadataValue var3 = this.dY.a((Metadatable)var2, (String)"StrikePracticeEnderPearlCooldown");
            if (var3 != null && var3.value() != null) {
               double var4 = b.p(var2) * 1000.0D;
               double var6 = (double)var3.asLong();
               double var8 = (double)System.currentTimeMillis();
               if (var6 + var4 > var8) {
                  var1.setCancelled(true);
                  double var10 = (var6 + var4 - var8) / 1000.0D;
                  this.dY.a(var2, "cooldown-message", u.a("<time>", b.aW().format(var10)));
                  return;
               }
            }
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true,
      priority = EventPriority.MONITOR
   )
   public void a(ProjectileLaunchEvent var1) {
      if (var1.getEntity() instanceof EnderPearl && var1.getEntity().getShooter() instanceof Player) {
         Player var2 = (Player)var1.getEntity().getShooter();
         var2.setMetadata("StrikePracticeEnderPearlCooldown", new FixedMetadataValue(this.dY, System.currentTimeMillis()));
         if (this.ea || this.dZ) {
            new ga.strikepractice.e.a.a(var2);
         }

         StrikePractice.getInstance().ap().a(var2, "Enderpearl", Material.ENDER_PEARL, (long)(b.p(var2) * 1000.0D));
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void a(PlayerPickupItemEvent var1) {
      this.a(var1.getItem().getItemStack(), var1.getPlayer());
   }

   @EventHandler
   public void a(PlayerItemHeldEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var2.getInventory().getItem(var1.getNewSlot());
      if (var3 != null && var3.getType() == Material.ENDER_PEARL) {
         this.a(var3, var2);
      }

   }

   private void a(ItemStack var1, Player var2) {
      if (this.ea) {
         if (var1.getType() == Material.ENDER_PEARL) {
            if (var2.hasMetadata("StrikePracticeEnderPearlCooldown")) {
               MetadataValue var3 = this.dY.a((Metadatable)var2, (String)"StrikePracticeEnderPearlCooldown");
               if (var3 != null && var3.value() != null) {
                  double var4 = b.p(var2) * 1000.0D;
                  double var6 = (double)var3.asLong();
                  double var8 = (double)System.currentTimeMillis();
                  if (var6 + var4 > var8) {
                     double var10 = (var6 + var4 - var8) / 1000.0D;
                     var1.setItemMeta(this.a(var1, b.aW().format(var10)));
                     var2.updateInventory();
                     return;
                  }
               }
            }

            ItemMeta var12 = var1.getItemMeta();
            var12.setDisplayName((String)null);
            var1.setItemMeta(var12);
            var2.updateInventory();
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void a(InventoryClickEvent var1) {
      ItemStack var2 = var1.getCurrentItem();
      if (var2 != null && var2.getType() == Material.ENDER_PEARL && this.ea) {
         ItemMeta var3 = var2.getItemMeta();
         var3.setDisplayName((String)null);
         var2.setItemMeta(var3);
      }

   }

   private ItemMeta a(ItemStack var1, String var2) {
      String var3 = f.K(b.aX());
      ItemMeta var4 = var1.getItemMeta();
      var4.setDisplayName(var3.replace("<time>", var2));
      return var4;
   }

   public static boolean n(Player var0) {
      return var0.hasMetadata("StrikePracticeEnderPearlCooldown");
   }

   private long o(Player var1) {
      if (var1.hasMetadata("StrikePracticeEnderPearlCooldown")) {
         MetadataValue var2 = this.dY.a((Metadatable)var1, (String)"StrikePracticeEnderPearlCooldown");
         if (var2 != null && var2.value() != null) {
            double var3 = b.p(var1) * 1000.0D;
            double var5 = (double)var2.asLong();
            long var7 = System.currentTimeMillis();
            if (var5 + var3 > (double)var7) {
               return (long)(var5 + var3 - (double)var7);
            }
         }
      }

      return 0L;
   }

   private class a extends BukkitRunnable {
      private Player aR;
      private int counter;

      public a(Player var2) {
         this.aR = var2;
         this.counter = b.aY();
         this.runTaskTimerAsynchronously(a.this.dY, 0L, 1L);
      }

      public void run() {
         if (this.aR != null && this.aR.isOnline()) {
            long var1 = a.this.o(this.aR);
            if (a.this.dZ) {
               this.aR.setLevel((int)(var1 / 1000L));
               double var3 = b.p(this.aR) * 1000.0D;
               if (var3 > 0.0D) {
                  this.aR.setExp((float)((double)var1 / var3));
               } else {
                  this.aR.setExp(0.0F);
               }
            }

            --this.counter;
            if (this.counter == 0) {
               this.counter = b.aY();
               if (this.aR.getItemInHand().getType() == Material.ENDER_PEARL) {
                  if (this.aR.hasMetadata("StrikePracticeEnderPearlCooldown")) {
                     MetadataValue var11 = a.this.dY.a((Metadatable)this.aR, (String)"StrikePracticeEnderPearlCooldown");
                     if (var11 != null && var11.value() != null) {
                        if (var1 > 0L) {
                           if (a.this.ea) {
                              double var4 = (double)(var1 / 1000L);
                              String var6 = b.aW().format(var4);
                              ItemStack[] var7 = this.aR.getInventory().getContents();
                              int var8 = var7.length;

                              for(int var9 = 0; var9 < var8; ++var9) {
                                 ItemStack var10 = var7[var9];
                                 if (var10 != null && var10.getType() == Material.ENDER_PEARL) {
                                    var10.setItemMeta(a.this.a(var10, var6));
                                 }
                              }
                           }
                        } else {
                           this.aR.removeMetadata("StrikePracticeEnderPearlCooldown", a.this.dY);
                           this.aV();
                        }
                     } else {
                        this.aV();
                     }
                  } else {
                     this.cancel();
                  }
               }
            }
         } else {
            this.cancel();
         }

      }

      private void aV() {
         if (a.this.ea) {
            ItemStack[] var1 = this.aR.getInventory().getContents();
            int var2 = var1.length;

            for(int var3 = 0; var3 < var2; ++var3) {
               ItemStack var4 = var1[var3];
               if (var4 != null && var4.getType() == Material.ENDER_PEARL) {
                  ItemMeta var5 = var4.getItemMeta();
                  var5.setDisplayName((String)null);
                  var4.setItemMeta(var5);
               }
            }

            this.cancel();
         }
      }

      public synchronized void cancel() {
         super.cancel();
         this.aR = null;
      }
   }
}
