package ga.strikepractice.e;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import java.text.DecimalFormat;
import org.bukkit.entity.Player;

public class b {
   private static String ec;
   private static double ed;
   private static int ee;
   private static DecimalFormat ef;

   public static void c(StrikePractice var0) {
      a(new DecimalFormat(var0.getConfig().getString("enderpearl-cooldown.format")));
      i(var0.getConfig().getString("enderpearl-cooldown.pearl-name"));
      a(var0.getConfig().getDouble("enderpearl-cooldown.cooldown"));
      e(var0.getConfig().getInt("enderpearl-cooldown.interval"));
   }

   public static DecimalFormat aW() {
      return ef;
   }

   public static void a(DecimalFormat var0) {
      ef = var0;
   }

   public static double p(Player var0) {
      BattleKit var1 = BattleKit.getCurrentKit(var0);
      if (var1 != null) {
         int var2 = var1.getPearlCooldown();
         if (var2 < 0) {
            return 0.0D;
         }

         if (var2 > 0) {
            return (double)var2;
         }
      }

      return ed;
   }

   public static void a(double var0) {
      ed = var0;
   }

   public static String aX() {
      return ec;
   }

   public static void i(String var0) {
      ec = var0;
   }

   public static int aY() {
      return ee;
   }

   public static void e(int var0) {
      ee = var0;
   }

   public static double aZ() {
      return ed;
   }
}
