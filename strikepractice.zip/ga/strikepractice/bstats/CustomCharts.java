package ga.strikepractice.bstats;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.TuplesKt;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.collections.MapsKt;
import ga.strikepractice.kotlin.collections.SetsKt;
import ga.strikepractice.kotlin.jvm.JvmStatic;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.o.f;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\u0018\u0000 \u00032\u00020\u0001:\u0001\u0003B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0004"},
   d2 = {"Lga/strikepractice/bstats/CustomCharts;", "", "()V", "Companion", "strikepractice-core"}
)
public final class CustomCharts {
   @NotNull
   public static final CustomCharts.Companion Companion = new CustomCharts.Companion((DefaultConstructorMarker)null);
   @NotNull
   private static final Set<String> kitIdentifiers;

   @JvmStatic
   @NotNull
   public static final List<Metrics.CustomChart> getCustomCharts() {
      return Companion.getCustomCharts();
   }

   static {
      String[] var0 = new String[]{"nodebuff", "builduhc", "bedwars", "sumo", "spleef", "mlgrush", "soup", "bridge", "gapple", "combo", "noenchant", "sg", "axe", "skywars", "onehit"};
      kitIdentifiers = SetsKt.setOf(var0);
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0007J\u0010\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"},
      d2 = {"Lga/strikepractice/bstats/CustomCharts$Companion;", "", "()V", "kitIdentifiers", "", "", "getCustomCharts", "", "Lga/strikepractice/bstats/Metrics$CustomChart;", "totalFights", "", "plugin", "Lga/strikepractice/StrikePractice;", "strikepractice-core"}
   )
   @SourceDebugExtension({"SMAP\nCustomCharts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CustomCharts.kt\nga/strikepractice/bstats/CustomCharts$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,95:1\n2976#2,5:96\n1549#2:101\n1620#2,3:102\n1549#2:105\n1620#2,2:106\n766#2:108\n857#2,2:109\n2976#2,5:111\n1622#2:116\n1549#2:117\n1620#2,2:118\n1747#2,3:120\n1622#2:123\n1238#2,4:126\n442#3:124\n392#3:125\n*S KotlinDebug\n*F\n+ 1 CustomCharts.kt\nga/strikepractice/bstats/CustomCharts$Companion\n*L\n88#1:96,5\n44#1:101\n44#1:102,3\n56#1:105\n56#1:106,2\n57#1:108\n57#1:109,2\n57#1:111,5\n56#1:116\n66#1:117\n66#1:118,2\n67#1:120,3\n66#1:123\n83#1:126,4\n83#1:124\n83#1:125\n*E\n"})
   public static final class Companion {
      private Companion() {
      }

      @JvmStatic
      @NotNull
      public final List<Metrics.CustomChart> getCustomCharts() {
         StrikePractice var1 = StrikePractice.getInstance();
         Metrics.CustomChart[] var2 = new Metrics.CustomChart[]{new Metrics.SimplePie("database_type", CustomCharts.Companion::getCustomCharts$lambda$0), new Metrics.SimplePie("players_rounded_v2", CustomCharts.Companion::getCustomCharts$lambda$1), new Metrics.SingleLineChart("concurrent_fights_v2", CustomCharts.Companion::getCustomCharts$lambda$3), new Metrics.SingleLineChart("total_fights", CustomCharts.Companion::getCustomCharts$lambda$4), new Metrics.AdvancedPie("popular_kits", CustomCharts.Companion::getCustomCharts$lambda$8), new Metrics.AdvancedPie("has_kit", CustomCharts.Companion::getCustomCharts$lambda$11), new Metrics.SimplePie("use_player_items", CustomCharts.Companion::getCustomCharts$lambda$12), new Metrics.AdvancedPie("features_enabled", CustomCharts.Companion::getCustomCharts$lambda$14)};
         return CollectionsKt.listOf(var2);
      }

      private final int totalFights(StrikePractice var1) {
         List var10000 = var1.kits;
         Intrinsics.checkNotNullExpressionValue(var10000, "plugin.kits");
         Iterable var2 = (Iterable)CollectionsKt.distinct((Iterable)var10000);
         boolean var3 = false;
         int var4 = 0;

         int var10;
         for(Iterator var5 = var2.iterator(); var5.hasNext(); var4 += var10) {
            Object var6 = var5.next();
            BattleKit var7 = (BattleKit)var6;
            boolean var8 = false;
            YamlConfiguration var11 = var1.Z().p();
            Intrinsics.checkNotNull(var11);
            var10 = var11.getInt(var7.getName());
         }

         return var4;
      }

      private static final String getCustomCharts$lambda$0(StrikePractice var0) {
         return var0.H ? "MySQL" : "Flat-file";
      }

      private static final String getCustomCharts$lambda$1() {
         int var0 = Bukkit.getOnlinePlayers().size();
         String var10000;
         if (var0 <= 5) {
            var10000 = "0-5";
         } else if (var0 <= 10) {
            var10000 = "5-10";
         } else {
            int var1 = var0 / 10 * 10;
            var10000 = "" + var1 + '-' + (var1 + 10);
         }

         return var10000;
      }

      private static final Integer getCustomCharts$lambda$3() {
         Collection var10000 = Bukkit.getOnlinePlayers();
         Intrinsics.checkNotNullExpressionValue(var10000, "getOnlinePlayers()");
         Iterable var0 = (Iterable)var10000;
         boolean var1 = false;
         Collection var3 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var0, 10)));
         boolean var4 = false;
         Iterator var5 = var0.iterator();

         while(var5.hasNext()) {
            Object var6 = var5.next();
            Player var7 = (Player)var6;
            boolean var8 = false;
            var3.add(AbstractFight.getCurrentFight(var7));
         }

         return CollectionsKt.distinct((Iterable)((List)var3)).size();
      }

      private static final Integer getCustomCharts$lambda$4(StrikePractice var0) {
         CustomCharts.Companion var10000 = CustomCharts.Companion;
         Intrinsics.checkNotNullExpressionValue(var0, "plugin");
         return var10000.totalFights(var0);
      }

      private static final Map getCustomCharts$lambda$8(StrikePractice var0) {
         CustomCharts.Companion var10000 = CustomCharts.Companion;
         Intrinsics.checkNotNullExpressionValue(var0, "plugin");
         double var1 = (double)var10000.totalFights(var0);
         Iterable var3 = (Iterable)CustomCharts.kitIdentifiers;
         boolean var4 = false;
         Collection var6 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var3, 10)));
         boolean var7 = false;
         Iterator var8 = var3.iterator();

         while(var8.hasNext()) {
            Object var9 = var8.next();
            String var10 = (String)var9;
            boolean var11 = false;
            List var28 = var0.kits;
            Intrinsics.checkNotNullExpressionValue(var28, "plugin.kits");
            Iterable var12 = (Iterable)var28;
            boolean var13 = false;
            Collection var15 = (Collection)(new ArrayList());
            boolean var16 = false;
            Iterator var17 = var12.iterator();

            while(var17.hasNext()) {
               Object var18 = var17.next();
               BattleKit var19 = (BattleKit)var18;
               boolean var20 = false;
               String var30 = var19.getName();
               Intrinsics.checkNotNullExpressionValue(var30, "it.name");
               if (StringsKt.contains$default((CharSequence)var30, (CharSequence)var10, false, 2, (Object)null)) {
                  var15.add(var18);
               }
            }

            var12 = (Iterable)((List)var15);
            var13 = false;
            int var14 = 0;

            int var22;
            for(Iterator var27 = var12.iterator(); var27.hasNext(); var14 += var22) {
               Object var29 = var27.next();
               BattleKit var32 = (BattleKit)var29;
               boolean var33 = false;
               YamlConfiguration var31 = var0.Z().p();
               Intrinsics.checkNotNull(var31);
               var22 = var31.getInt(var32.getName());
            }

            double var24 = (double)var14 / var1 * (double)100;
            var6.add(TuplesKt.to(var10, (int)var24));
         }

         return MapsKt.toMap((Iterable)((List)var6));
      }

      private static final Map getCustomCharts$lambda$11(StrikePractice var0) {
         Iterable var1 = (Iterable)CustomCharts.kitIdentifiers;
         boolean var2 = false;
         Collection var4 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var1, 10)));
         boolean var5 = false;
         Iterator var6 = var1.iterator();

         while(var6.hasNext()) {
            Object var7 = var6.next();
            String var8 = (String)var7;
            boolean var9 = false;
            List var10001 = var0.kits;
            Intrinsics.checkNotNullExpressionValue(var10001, "plugin.kits");
            Iterable var10 = (Iterable)var10001;
            boolean var12 = false;
            boolean var19;
            if (var10 instanceof Collection && ((Collection)var10).isEmpty()) {
               var19 = false;
            } else {
               Iterator var13 = var10.iterator();

               while(true) {
                  if (!var13.hasNext()) {
                     var19 = false;
                     break;
                  }

                  Object var14 = var13.next();
                  BattleKit var15 = (BattleKit)var14;
                  boolean var16 = false;
                  String var10000 = var15.getName();
                  Intrinsics.checkNotNullExpressionValue(var10000, "k.name");
                  if (StringsKt.contains$default((CharSequence)var10000, (CharSequence)var8, false, 2, (Object)null)) {
                     var19 = true;
                     break;
                  }
               }
            }

            boolean var17 = var19;
            var4.add(TuplesKt.to(var8, var17 ? 1 : 0));
         }

         return MapsKt.toMap((Iterable)((List)var4));
      }

      private static final String getCustomCharts$lambda$12(StrikePractice var0) {
         return var0.getConfig().getBoolean("disable-inventory-modifications") ? "Enabled" : "Disabled";
      }

      private static final Map getCustomCharts$lambda$14(StrikePractice var0) {
         Pair[] var1 = new Pair[5];
         Plugin var10003 = Bukkit.getPluginManager().getPlugin("Citizens");
         var1[0] = TuplesKt.to("PvP Bots", var10003 != null ? var10003.isEnabled() : null);
         var1[1] = TuplesKt.to("Replays", var0.getConfig().getBoolean("record-all-fights") || var0.getConfig().getBoolean("record-elo-fights"));
         var1[2] = TuplesKt.to("Discord Webhooks", var0.getConfig().getBoolean("discord.enable-webhooks"));
         var1[3] = TuplesKt.to("Enderpearl Cooldown", var0.getConfig().getBoolean("enderpearl-cooldown.enabled"));
         var1[4] = TuplesKt.to("Scoreboard", f.isEnabled());
         Map var18 = MapsKt.mapOf(var1);
         boolean var2 = false;
         Map var4 = (Map)(new LinkedHashMap(MapsKt.mapCapacity(var18.size())));
         boolean var5 = false;
         Iterable var6 = (Iterable)var18.entrySet();
         boolean var7 = false;
         Iterator var8 = var6.iterator();

         while(var8.hasNext()) {
            Object var9 = var8.next();
            Entry var10 = (Entry)var9;
            boolean var12 = false;
            Object var10001 = var10.getKey();
            Entry var13 = (Entry)var9;
            Object var16 = var10001;
            boolean var14 = false;
            Integer var17 = Intrinsics.areEqual((Object)var13.getValue(), (Object)true) ? 1 : 0;
            var4.put(var16, var17);
         }

         return var4;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker var1) {
         this();
      }
   }
}
