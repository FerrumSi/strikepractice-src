package ga.strikepractice.fightinventory;

import ga.strikepractice.StrikePractice;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class c implements CommandExecutor {
   private static final Map<UUID, FightInventory> ey = new HashMap();
   private static final Map<String, UUID> ez = new HashMap();
   private final StrikePractice eA;

   public c(StrikePractice var1) {
      this.eA = var1;
   }

   public void a(FightInventory var1) {
      if (var1 != null && var1.getUUID() != null) {
         ey.put(var1.getUUID(), var1);
         if (ey.size() > 100) {
            Iterator var2 = ey.values().iterator();

            while(var2.hasNext()) {
               FightInventory var3 = (FightInventory)var2.next();
               if (var3.createdLongTimeAgo()) {
                  ez.remove(var1.getOwner(), var1.getUUID());
                  var2.remove();
               }
            }
         }
      }

      if (var1 != null && var1.getOwner() != null) {
         ez.put(var1.getOwner(), var1.getUUID());
      }

   }

   public UUID j(String var1) {
      return (UUID)ez.get(var1);
   }

   public UUID q(Player var1) {
      return this.j(var1.getName());
   }

   public FightInventory c(UUID var1) {
      return (FightInventory)ey.getOrDefault(var1, (Object)null);
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         if (var4.length >= 1) {
            try {
               UUID var6 = UUID.fromString(var4[0]);
               FightInventory var10 = this.c(var6);
               if (var10 == null) {
                  this.eA.a(var5, "invalid-inventory");
                  return true;
               }

               var5.openInventory(var10.build(var5));
               return true;
            } catch (IllegalArgumentException var9) {
               UUID var7 = this.j(var4[0]);
               if (var7 == null) {
                  this.eA.a(var5, "invalid-inventory");
                  return true;
               }

               FightInventory var8 = this.c(var7);
               if (var8 == null) {
                  this.eA.a(var5, "invalid-inventory");
               } else {
                  var5.openInventory(var8.build(var5));
               }

               return true;
            }
         }
      }

      return true;
   }
}
