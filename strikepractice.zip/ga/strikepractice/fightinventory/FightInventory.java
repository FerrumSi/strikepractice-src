package ga.strikepractice.fightinventory;

import com.google.gson.annotations.SerializedName;
import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.FightStatistics;
import ga.strikepractice.matchrecorder.RecordedMatch;
import ga.strikepractice.matchrecorder.recorder.Recordable;
import ga.strikepractice.utils.d;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.k;
import ga.strikepractice.utils.n;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.y;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;

@APIClass
public class FightInventory implements Serializable {
   private transient StrikePractice plugin;
   @SerializedName("owner")
   private String owner;
   @SerializedName("ownerUUID")
   private UUID ownerUUID;
   private transient FightStatistics statistics;
   @SerializedName("mainInv")
   private ItemStack[] mainInv;
   @SerializedName("dead")
   private boolean dead;
   @SerializedName("effects")
   private Collection<PotionEffect> effects;
   @SerializedName("food")
   private int food;
   @SerializedName("helmet")
   private ItemStack helmet;
   @SerializedName("chestplate")
   private ItemStack chestplate;
   @SerializedName("leggings")
   private ItemStack leggings;
   @SerializedName("boots")
   private ItemStack boots;
   @SerializedName("health")
   private double health;
   @SerializedName("inventoryUUID")
   private UUID inventoryUUID;
   @SerializedName("playbackUUID")
   private UUID playbackUUID;
   @SerializedName("left")
   private int left;
   @SerializedName("created")
   private long created;
   @SerializedName("leftPotions")
   private boolean leftPotions;
   private transient FightInventory nextInventory;

   public FightInventory(Player var1, StrikePractice var2) {
      if (var1 != null) {
         this.health = var1.getHealth();
         this.helmet = var1.getInventory().getHelmet();
         this.chestplate = var1.getInventory().getChestplate();
         this.leggings = var1.getInventory().getLeggings();
         this.boots = var1.getInventory().getBoots();
         this.owner = var1.getName();
         this.dead = var1.isDead();
         this.food = var1.getFoodLevel();
         this.effects = var1.getActivePotionEffects();
         this.mainInv = var1.getInventory().getContents();
         this.plugin = var2;
         this.inventoryUUID = UUID.randomUUID();
         this.ownerUUID = var1.getUniqueId();
         Fight var4 = AbstractFight.getCurrentFight(var1);
         if (var4 != null) {
            this.statistics = var4.getStatistics(var1.getUniqueId());
            this.getRecordUUID(var4);
         }

         this.save();
      }

   }

   public FightInventory(StrikePractice var1) {
      this.plugin = var1;
   }

   public FightInventory(Entity var1, String var2, PlayerInventory var3, StrikePractice var4) {
      if (var1 instanceof Damageable) {
         this.health = ((Damageable)var1).getHealth();
      }

      this.helmet = var3.getHelmet();
      this.chestplate = var3.getChestplate();
      this.leggings = var3.getLeggings();
      this.boots = var3.getBoots();
      this.owner = var2;
      this.dead = var1.isDead();
      this.food = 20;
      if (var1 instanceof LivingEntity) {
         this.effects = ((LivingEntity)var1).getActivePotionEffects();
      }

      this.mainInv = var3.getContents();
      this.plugin = var4;
      this.inventoryUUID = UUID.randomUUID();
      this.ownerUUID = var1.getUniqueId();
      Fight var5 = AbstractFight.getCurrentFight(var1.getUniqueId());
      if (var5 != null) {
         this.statistics = var5.getStatistics(var1.getUniqueId());
      }

      this.getRecordUUID(var5);
      this.save();
   }

   /** @deprecated */
   @Deprecated
   public static FightInventory fromLegacyString(String var0) {
      FightInventory var1 = new FightInventory(StrikePractice.getInstance());
      String[] var2 = var0.split(":");
      var1.setOwner(var2[0]);
      var1.setUUID(UUID.fromString(var2[1]));
      var1.setOwnerUUID(UUID.fromString(var2[2]));
      var1.setHealth(Double.parseDouble(var2[3]));
      var1.setDead(Boolean.parseBoolean(var2[4]));
      var1.setFood(Integer.parseInt(var2[5]));
      var1.setHelmet(r.S(var2[6]));
      var1.setChestplate(r.S(var2[7]));
      var1.setLeggings(r.S(var2[8]));
      var1.setBoots(r.S(var2[9]));
      ArrayList var3 = new ArrayList();
      String[] var4 = var2[10].split("; ");
      int var5 = var4.length;

      int var6;
      String var7;
      for(var6 = 0; var6 < var5; ++var6) {
         var7 = var4[var6];
         var3.add(r.S(var7));
      }

      var1.setMainInv((ItemStack[])var3.toArray(new ItemStack[36]));
      var1.setEffects(new ArrayList());
      if (var2.length > 12) {
         var4 = var2[11].split("; ");
         var5 = var4.length;

         for(var6 = 0; var6 < var5; ++var6) {
            var7 = var4[var6];
            var1.getEffects().add(k.Q(var7));
         }
      }

      return var1;
   }

   public static void inventoryMessage(Player var0, Collection<String> var1, Collection<String> var2) {
      try {
         StrikePractice var3 = StrikePractice.getInstance();
         var3.a(var0, "inventory-message");
         HashMap var4 = new HashMap(var2.size());
         String var5 = f.K(var3.getConfig().getString("loser-inventories"));
         int var6 = 0;
         String var7 = f.K(var3.getConfig().getString("inventory-separator"));
         String var8 = f.K(var3.getConfig().getString("fight-inventory-player"));
         if (!var5.isEmpty()) {
            boolean var9 = false;
            Iterator var10 = var2.iterator();

            while(true) {
               if (!var10.hasNext()) {
                  if (var6 > 0) {
                     d.b(var0, var4, var5, var7);
                  }

                  var4.clear();
                  break;
               }

               String var11 = (String)var10.next();
               ++var6;
               FightInventory var12 = var3.am().c(var3.am().j(var11));
               var4.put(var8.replace("<player>", var12.isDead() ? ChatColor.RED + var11 : ChatColor.GREEN + var11), "/clickablefightinventory " + var12.getUUID());
               if (var6 == 3 && !var9 || var9 && var6 == 5) {
                  var6 = 0;
                  if (!var9) {
                     var9 = true;
                     d.b(var0, var4, var5, var7);
                  } else {
                     d.b(var0, var4, "", var7);
                  }

                  var4.clear();
               }
            }
         }

         String var15 = f.K(var3.getConfig().getString("winner-inventories"));
         if (!var15.isEmpty()) {
            boolean var16 = false;
            var6 = 0;
            Iterator var17 = var1.iterator();

            while(true) {
               do {
                  if (!var17.hasNext()) {
                     if (var6 > 0) {
                        d.b(var0, var4, var15, var7);
                     }

                     return;
                  }

                  String var18 = (String)var17.next();
                  ++var6;
                  FightInventory var13 = var3.am().c(var3.am().j(var18));
                  var4.put(var8.replace("<player>", var13.isDead() ? ChatColor.RED + var18 : ChatColor.GREEN + var18), "/clickablefightinventory " + var13.getUUID());
               } while((var6 != 3 || var16) && (!var16 || var6 != 5));

               var6 = 0;
               if (!var16) {
                  var16 = true;
                  d.b(var0, var4, var15, var7);
               } else {
                  d.b(var0, var4, "", var7);
               }

               var4.clear();
            }
         }
      } catch (Exception var14) {
      }

   }

   public static void inventoryMessage(Player var0, Collection<FightInventory> var1) {
      try {
         StrikePractice var2 = StrikePractice.getInstance();
         HashMap var3 = new HashMap();
         String var4 = StrikePractice.getInstance().a(var0, "inventory-message", false, (Map)null)[0];
         int var5 = 0;
         boolean var6 = false;
         HashMap var7 = new HashMap();
         Iterator var8 = var1.iterator();

         while(var8.hasNext()) {
            FightInventory var9 = (FightInventory)var8.next();
            if (var9 != null && var9.getOwner() != null) {
               var7.put(var9.getOwner(), var9);
            }
         }

         String var14 = f.K(var2.getConfig().getString("inventory-separator"));
         String var15 = f.K(var2.getConfig().getString("fight-inventory-player"));
         Iterator var10 = var7.keySet().iterator();

         while(true) {
            do {
               if (!var10.hasNext()) {
                  if (var5 > 0) {
                     d.b(var0, var3, var6 ? "" : var4, var14);
                  }

                  return;
               }

               String var11 = (String)var10.next();
               ++var5;
               FightInventory var12 = var2.am().c(var2.am().j(var11));
               var3.put(var15.replace("<player>", var12.isDead() ? ChatColor.RED + var11 : ChatColor.GREEN + var11), "/clickablefightinventory " + var12.getUUID());
            } while((var5 != 3 || var6) && (!var6 || var5 != 4));

            var5 = 0;
            if (!var6) {
               var6 = true;
               d.b(var0, var3, var4, var14);
            } else {
               d.b(var0, var3, "", var14);
            }

            var3.clear();
         }
      } catch (Exception var13) {
         Bukkit.getLogger().info("Failed to send post-match inventory message to " + var0.getName());
         var13.printStackTrace();
      }
   }

   public static void message(Collection<String> var0, Collection<String> var1) {
      try {
         StrikePractice var2 = StrikePractice.getInstance();
         Iterator var3 = var0.iterator();

         String var4;
         while(var3.hasNext()) {
            var4 = (String)var3.next();
            Player var5 = y.W(var4);
            if (var5 != null) {
               var2.a(var5, "inventory-message");
            }
         }

         String var9 = f.K(var2.getConfig().getString("inventory-message-your"));
         var4 = f.K(var2.getConfig().getString("fight-inventory-player"));
         String var8 = f.K(var2.getConfig().getString("inventory-separator"));
         sendToParty(var0, var0, var2, var4, var8, var9);
         String var6 = f.K(var2.getConfig().getString("inventory-message-opponent"));
         sendToParty(var0, var1, var2, var4, var8, var6);
      } catch (Exception var7) {
      }

   }

   private static void sendToParty(Collection<String> var0, Collection<String> var1, StrikePractice var2, String var3, String var4, String var5) {
      boolean var6 = false;
      int var7 = 0;
      c var8 = var2.am();
      ArrayList var9 = new ArrayList(var1.size());
      HashMap var10 = new HashMap(var1.size());
      Iterator var11 = var1.iterator();

      String var12;
      while(var11.hasNext()) {
         var12 = (String)var11.next();
         ++var7;
         FightInventory var13 = var8.c(var8.j(var12));
         var9.add(var13);
         var10.put(var3.replace("<player>", var13.isDead() ? ChatColor.RED + var12 : ChatColor.GREEN + var12), "/clickablefightinventory " + var13.getUUID());
         if (var7 == 3 && !var6 || var6 && var7 == 5) {
            var7 = 0;
            Iterator var14 = var0.iterator();

            while(var14.hasNext()) {
               String var15 = (String)var14.next();
               Player var16 = y.W(var15);
               if (var16 != null) {
                  if (!var6) {
                     d.b(var16, var10, var5, var4);
                  } else {
                     d.b(var16, var10, "", var4);
                  }
               }
            }

            var6 = true;
            var10.clear();
         }
      }

      for(int var17 = 0; var17 < var9.size(); ++var17) {
         FightInventory var18 = (FightInventory)var9.get(var17);
         if (var18.getNextInventory() == null) {
            int var19 = var17 == var9.size() - 1 ? 0 : var17 + 1;
            var18.setNextInventory((FightInventory)var9.get(var19));
         }
      }

      if (var7 > 0) {
         var11 = var0.iterator();

         while(var11.hasNext()) {
            var12 = (String)var11.next();
            Player var20 = y.W(var12);
            if (var20 != null) {
               if (!var6) {
                  d.b(var20, var10, var5, var4);
               } else {
                  d.b(var20, var10, "", var4);
               }
            }
         }
      }

   }

   public static void duelMessage(Player var0, Player var1, FightInventory var2, FightInventory var3) {
      String var4 = var0.getName();
      String var5 = var1.getName();
      duelMessage(var0, var1, var4, var5, var2, var3);
   }

   public static void duelMessage(Player var0, Player var1, String var2, String var3, FightInventory var4, FightInventory var5) {
      List var6 = StrikePractice.getInstance().getConfig().getStringList("fight-inventory-message");
      ArrayList var7 = new ArrayList();
      String var8 = "/clickedchatwithoutaction";

      LinkedHashMap var11;
      for(Iterator var9 = var6.iterator(); var9.hasNext(); var7.add(var11)) {
         String var10 = (String)var9.next();
         var11 = new LinkedHashMap();
         String var12 = var4.getPotionsLeft() == 0 ? (int)Math.ceil(var4.getHealth()) + "❤" : var4.getPotionsLeft() + "";
         String var13 = var5.getPotionsLeft() == 0 ? (int)Math.ceil(var5.getHealth()) + "❤" : var5.getPotionsLeft() + "";
         var10 = f.K(var10).replace("<winner_pots>", var12).replace("<loser_pots>", var13);
         String var16;
         if (!var10.contains("<loser>") && var10.contains("<winner>")) {
            var16 = "/clickablefightinventory " + var4.getUUID();
            var11.put(var10.replace("<winner>", var2), var16);
         } else if (!var10.contains("<winner>") && var10.contains("<loser>")) {
            var16 = "/clickablefightinventory " + var5.getUUID();
            var11.put(var10.replace("<loser>", var3), var16);
         } else if (!var10.contains("<winner>") && !var10.contains("<loser>")) {
            var11.put(var10, var8);
         } else {
            String[] var14;
            String var15;
            if (var10.indexOf("<win") < var10.indexOf("<los")) {
               var14 = var10.split("<win");
               if (var14[0].contains("<loser>")) {
                  var15 = "/clickablefightinventory " + var5.getUUID();
                  var11.put(var14[0].replace("<loser>", var3), var15);
                  if (var14.length > 1 && var14[1].contains("ner>")) {
                     var14[1] = var14[1].replace("ner>", "");
                     var15 = "/clickablefightinventory " + var4.getUUID();
                     var11.put(var2, var15);
                  }
               } else if (var14.length > 1 && var14[1].contains("ner>")) {
                  var14[1] = var14[1].replace("ner>", "");
                  var15 = "/clickablefightinventory " + var4.getUUID();
                  var11.put(var14[0] + var2, var15);
               } else {
                  var11.put(var14[0], var8);
               }

               if (var14.length > 1) {
                  if (var14[1].contains("<loser>")) {
                     var15 = "/clickablefightinventory " + var5.getUUID();
                     var11.put(var14[1].replace("<loser>", var3), var15);
                  } else if (var14.length > 2 && var14[2].contains("ner>")) {
                     var14[2] = var14[2].replace("ner>", "");
                     var15 = "/clickablefightinventory " + var4.getUUID();
                     var11.put(var14[1] + var2, var15);
                  } else {
                     var11.put(var14[1], var8);
                  }

                  if (var14.length > 2) {
                     var11.put(var14[2], var8);
                  }
               }
            } else {
               var14 = var10.split("<lo");
               if (var14[0].contains("<winner>")) {
                  var15 = "/clickablefightinventory " + var4.getUUID();
                  var11.put(var14[0].replace("<winner>", var2), var15);
                  if (var14[1].contains("ser>")) {
                     var14[1] = var14[1].replace("ser>", "");
                     var15 = "/clickablefightinventory " + var5.getUUID();
                     var11.put(var3, var15);
                  }
               } else if (var14[1].contains("ser>")) {
                  var14[1] = var14[1].replace("ser>", "");
                  var15 = "/clickablefightinventory " + var5.getUUID();
                  var11.put(var14[0] + var3, var15);
               } else {
                  var11.put(var14[0], var8);
               }

               if (var14[1].contains("<winner>")) {
                  var15 = "/clickablefightinventory " + var4.getUUID();
                  var11.put(var14[1].replace("<winner>", var2), var15);
               } else if (var14.length > 2 && var14[2].contains("ser>")) {
                  var14[2] = var14[2].replace("ser>", "");
                  var15 = "/clickablefightinventory " + var5.getUUID();
                  var11.put(var14[1] + var3, var15);
               } else {
                  var11.put(var14[1], var8);
               }

               if (var14.length > 2) {
                  var11.put(var14[2], var8);
               }
            }
         }
      }

      if (var0 != null) {
         d.a(var0, (List)var7);
      }

      if (var1 != null && !var3.equalsIgnoreCase(var2)) {
         d.a(var1, (List)var7);
      }

   }

   private void getRecordUUID(Fight var1) {
      if (var1 instanceof Recordable) {
         ga.strikepractice.matchrecorder.recorder.fightrecorder.a var2 = ((Recordable)var1).getRecorder();
         if (var2 != null && var2.getRecordedMatch() != null) {
            this.playbackUUID = var2.getRecordedMatch().getUUID();
         }
      }

   }

   public void save() {
      this.created = System.currentTimeMillis();
      ItemStack[] var1 = this.mainInv;
      int var2 = var1.length;

      int var3;
      ItemStack var4;
      for(var3 = 0; var3 < var2; ++var3) {
         var4 = var1[var3];
         if (var4 != null && var4.getType().toString().contains("POTION")) {
            short var5 = var4.getDurability();
            if (var5 == 8197 || var5 == 8229 || var5 == 16389 || var5 == 16421 || var5 == 2586 || var4.getType().getId() == 438) {
               this.left += var4.getAmount() > 0 ? var4.getAmount() : 1;
            }
         }
      }

      if (this.left == 0) {
         var1 = this.mainInv;
         var2 = var1.length;

         for(var3 = 0; var3 < var2; ++var3) {
            var4 = var1[var3];
            if (var4 != null && var4.getType() == Material.MUSHROOM_SOUP) {
               this.left += var4.getAmount() > 0 ? var4.getAmount() : 1;
            }
         }
      } else {
         this.leftPotions = true;
      }

      this.plugin.am().a(this);
   }

   public Inventory build(Player var1) {
      int var2 = this.getSlots();
      Inventory var3 = Bukkit.createInventory(new ga.strikepractice.fightinventory.a(this), var2, f.K(this.plugin.getConfig().getString("fight-inventory.inventory").replace("<player>", this.owner)));
      int var4 = this.plugin.getConfig().getInt("fight-inventory.item-start-slot") - 1;
      int var5 = 0;

      for(int var6 = var4; var6 < 36 + var4 && var6 < var2; ++var6) {
         var3.setItem(var6, this.getMainInv()[var5]);
         ++var5;
      }

      var3.setItem(this.getSlot("helmet"), this.getHelmet());
      var3.setItem(this.getSlot("chestplate"), this.getChestplate());
      var3.setItem(this.getSlot("leggings"), this.getLeggings());
      var3.setItem(this.getSlot("boots"), this.getBoots());
      if (this.playbackUUID != null && this.plugin.I && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pW)) {
         Iterator var16 = StrikePractice.getInstance().ab().cU().values().iterator();

         label82:
         while(true) {
            while(true) {
               if (!var16.hasNext()) {
                  break label82;
               }

               List var7 = (List)var16.next();
               Iterator var8 = var7.iterator();

               while(var8.hasNext()) {
                  RecordedMatch var9 = (RecordedMatch)var8.next();
                  if (var9 != null && this.playbackUUID == var9.getUUID()) {
                     var3.setItem(this.getSlot("playback"), ga.strikepractice.matchrecorder.replay.d.a(var9));
                     break;
                  }
               }
            }
         }
      }

      ItemStack var17;
      ItemMeta var19;
      ItemStack var20;
      ItemMeta var21;
      if (this.isDead()) {
         var17 = new ItemStack(Material.SKULL_ITEM);
         var19 = var17.getItemMeta();
         var19.setDisplayName(f.K(this.plugin.getConfig().getString("fight-inventory.dead")));
         var17.setItemMeta(var19);
         var3.setItem(this.getSlot("health"), var17);
      } else {
         double var18 = Math.ceil(this.getHealth());
         var20 = new ItemStack(Material.MELON, (int)var18);
         var21 = var20.getItemMeta();
         var21.setDisplayName(f.K(this.plugin.getConfig().getString("fight-inventory.health")).replace("<health>", var18 + ""));
         var20.setItemMeta(var21);
         var3.setItem(this.getSlot("health"), var20);
      }

      var17 = new ItemStack(Material.COOKED_BEEF, this.getFood());
      var19 = var17.getItemMeta();
      var19.setDisplayName(f.K(this.plugin.getConfig().getString("fight-inventory.food")).replace("<food>", this.getFood() + ""));
      var17.setItemMeta(var19);
      var3.setItem(this.getSlot("food"), var17);
      var20 = new ItemStack(Material.POTION);
      var21 = var17.getItemMeta();
      var21.setDisplayName(f.K(this.plugin.getConfig().getString("fight-inventory.effect-displayname", "&7Potion Effects")));
      String var10 = f.K(this.plugin.getConfig().getString("fight-inventory.pots"));
      var21.setLore(Arrays.asList(var10));
      ArrayList var11 = new ArrayList();
      Iterator var12 = var21.getLore().iterator();

      while(var12.hasNext()) {
         String var13 = (String)var12.next();
         var11.add(var13);
      }

      String var22 = f.K(this.plugin.getConfig().getString("fight-inventory.effect"));
      Iterator var23 = this.getEffects().iterator();

      while(var23.hasNext()) {
         PotionEffect var14 = (PotionEffect)var23.next();
         var11.add(n.a(var22, var14));
      }

      var21.setLore(var11);
      var20.setItemMeta(var21);
      var3.setItem(this.getSlot("pots"), var20);
      if (this.getNextInventory() != null) {
         Material var24 = Material.getMaterial(this.plugin.getConfig().getString("fight-inventory.next-inventory-item"));
         if (var24 != null) {
            ItemStack var26 = new ItemStack(var24);
            ItemMeta var15 = var26.getItemMeta();
            var15.setDisplayName(f.K(this.plugin.getConfig().getString("fight-inventory.next-inventory-name")).replace("<player>", this.getNextInventory().getOwner()));
            var26.setItemMeta(var15);
            var3.setItem(this.getSlot("next-inventory"), var26);
         }
      }

      ItemStack var25;
      ItemMeta var27;
      if (!this.leftPotions && this.left != 0) {
         var25 = new ItemStack(Material.MUSHROOM_SOUP);
         var27 = this.applyStats(var25.getItemMeta());
         var25.setAmount(this.left == 0 ? 1 : this.left);
         var27.setDisplayName(f.K(this.plugin.getConfig().getString("fight-inventory.soups-left")).replace("<soups>", this.left + ""));
         var25.setItemMeta(var27);
         var3.setItem(this.getSlot("pots-left"), var25);
      } else {
         var25 = new ItemStack(Material.POTION);
         var27 = this.applyStats(var25.getItemMeta());
         var25.setDurability((short)16421);
         var25.setAmount(this.left == 0 ? 1 : this.left);
         var27.setDisplayName(f.K(this.plugin.getConfig().getString("fight-inventory.pots-left")).replace("<potions>", this.left + ""));
         var25.setItemMeta(var27);
         var3.setItem(this.getSlot("pots-left"), var25);
      }

      return var3;
   }

   private ItemMeta applyStats(ItemMeta var1) {
      if (this.statistics == null) {
         return var1;
      } else {
         ArrayList var2 = new ArrayList();
         this.plugin.getConfig().getStringList("fight-inventory.match-stats-lore").forEach((var2x) -> {
            var2.add(f.K(var2x).replace("<hits>", Integer.toString(this.statistics.getHits())).replace("<combo>", Integer.toString(this.statistics.getLongestCombo())).replace("<potions_thrown>", Integer.toString(this.statistics.getPotionsThrown())).replace("<potions_missed>", Integer.toString(this.statistics.getPotionsMissed())).replace("<potion_accuracy>", this.statistics.getAccuracy() + "%"));
         });
         var1.setLore(var2);
         return var1;
      }
   }

   public int getSlots() {
      return 9 * this.plugin.getConfig().getInt("fight-inventory.rows");
   }

   /** @deprecated */
   @Deprecated
   public String toLegacyString() {
      StringBuilder var1 = new StringBuilder();
      var1.append(this.owner);
      var1.append(":").append(this.ownerUUID.toString());
      var1.append(":").append(this.inventoryUUID.toString());
      var1.append(":").append(this.health);
      var1.append(":").append(this.dead);
      var1.append(":").append(this.food);
      var1.append(":").append(r.g(this.helmet));
      var1.append(":").append(r.g(this.chestplate));
      var1.append(":").append(r.g(this.leggings));
      var1.append(":").append(r.g(this.boots));
      String var2 = "";
      var1.append(":");
      ItemStack[] var3 = this.mainInv;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         ItemStack var6 = var3[var5];
         var1.append(var2);
         var1.append(r.g(var6));
         var2 = ", ";
      }

      if (!this.effects.isEmpty()) {
         var2 = "";
         var1.append(":");

         for(Iterator var7 = this.effects.iterator(); var7.hasNext(); var2 = ", ") {
            PotionEffect var8 = (PotionEffect)var7.next();
            var1.append(var2);
            var1.append(k.a(var8));
         }
      }

      return var1.toString();
   }

   public FightStatistics getStatistics() {
      return this.statistics;
   }

   public void setStatistics(FightStatistics var1) {
      this.statistics = var1;
   }

   public int getPotionsLeft() {
      return this.left;
   }

   public UUID getUUID() {
      return this.inventoryUUID;
   }

   public void setUUID(UUID var1) {
      this.inventoryUUID = var1;
   }

   private int getSlot(String var1) {
      int var2 = this.plugin.getConfig().getInt("fight-inventory." + var1 + "-slot");
      int var3 = this.getSlots();
      return var2 >= var3 ? var3 - 1 : var2;
   }

   public double getHealth() {
      return this.health;
   }

   public void setHealth(double var1) {
      this.health = var1;
   }

   public Collection<PotionEffect> getEffects() {
      return this.effects;
   }

   public void setEffects(Collection<PotionEffect> var1) {
      this.effects = var1;
   }

   public String getOwner() {
      return this.owner;
   }

   public void setOwner(String var1) {
      this.owner = var1;
   }

   public ItemStack[] getMainInv() {
      return this.mainInv;
   }

   public void setMainInv(ItemStack[] var1) {
      this.mainInv = var1;
   }

   public boolean isDead() {
      return this.dead;
   }

   public void setDead(boolean var1) {
      this.dead = var1;
   }

   public int getFood() {
      return this.food;
   }

   public void setFood(int var1) {
      this.food = var1;
   }

   public ItemStack getHelmet() {
      return this.helmet;
   }

   public void setHelmet(ItemStack var1) {
      this.helmet = var1;
   }

   public ItemStack getChestplate() {
      return this.chestplate;
   }

   public void setChestplate(ItemStack var1) {
      this.chestplate = var1;
   }

   public boolean createdLongTimeAgo() {
      return System.currentTimeMillis() - this.created > TimeUnit.MINUTES.toMillis(10L);
   }

   public ItemStack getLeggings() {
      return this.leggings;
   }

   public void setLeggings(ItemStack var1) {
      this.leggings = var1;
   }

   public ItemStack getBoots() {
      return this.boots;
   }

   public void setBoots(ItemStack var1) {
      this.boots = var1;
   }

   public UUID getOwnerUUID() {
      return this.ownerUUID;
   }

   public void setOwnerUUID(UUID var1) {
      this.ownerUUID = var1;
   }

   public FightInventory getNextInventory() {
      return this.nextInventory;
   }

   public void setNextInventory(FightInventory var1) {
      this.nextInventory = var1;
   }
}
