package ga.strikepractice.fightinventory;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

class a implements InventoryHolder {
   private final FightInventory ew;

   public a(FightInventory var1) {
      this.ew = var1;
   }

   public FightInventory bc() {
      return this.ew;
   }

   public Inventory getInventory() {
      return null;
   }
}
