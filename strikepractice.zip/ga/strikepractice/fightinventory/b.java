package ga.strikepractice.fightinventory;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.matchrecorder.RecordedMatch;
import ga.strikepractice.matchrecorder.replay.ReplayFight;
import ga.strikepractice.matchrecorder.replay.d;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.y;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class b implements Listener {
   private final StrikePractice ex;

   public b(StrikePractice var1) {
      this.ex = var1;
   }

   @EventHandler
   public void a(InventoryClickEvent var1) {
      ItemStack var2 = var1.getCurrentItem();
      if (var1.getWhoClicked() instanceof Player && var2 != null && var1.getInventory() != null && var1.getInventory().getHolder() != null) {
         if (var1.getInventory().getHolder() instanceof ga.strikepractice.fightinventory.a) {
            var1.setCancelled(true);
            if (var2.hasItemMeta() && var2.getItemMeta().hasDisplayName()) {
               Player var3 = (Player)var1.getWhoClicked();
               var3.closeInventory();
               if (var1.getSlot() == this.ex.getConfig().getInt("fight-inventory.next-inventory-slot")) {
                  FightInventory var4 = ((ga.strikepractice.fightinventory.a)var1.getInventory().getHolder()).bc();
                  if (var4 != null && var4.getNextInventory() != null) {
                     var3.openInventory(var4.getNextInventory().build(var3));
                  } else {
                     this.ex.a(var3, "invalid-inventory");
                  }
               } else if (var2.getType() == Material.PAPER) {
                  if (!AbstractFight.isInFight(var3) && !StrikePractice.getAPI().isInEvent(var3)) {
                     Iterator var13 = this.ex.ab().cU().values().iterator();

                     while(var13.hasNext()) {
                        List var5 = (List)var13.next();
                        Iterator var6 = var5.iterator();

                        while(var6.hasNext()) {
                           RecordedMatch var7 = (RecordedMatch)var6.next();
                           if (d.a(var7).equals(var2)) {
                              ReplayFight var8 = var7.startPlayback(0);
                              if (var8 != null) {
                                 Party var9 = Party.getParty(var3);
                                 if (var9 != null) {
                                    if (!var9.isInFight()) {
                                       Iterator var10 = var9.getMembersNames().iterator();

                                       while(var10.hasNext()) {
                                          String var11 = (String)var10.next();
                                          Player var12 = y.W(var11);
                                          if (var12 != null) {
                                             var8.addSpectator(var12);
                                          }
                                       }
                                    } else {
                                       var3.closeInventory();
                                    }
                                 } else {
                                    var8.addSpectator(var3);
                                 }
                              } else {
                                 this.ex.a(var3, "playback-can-not-start");
                              }

                              return;
                           }
                        }
                     }
                  } else {
                     var3.closeInventory();
                  }
               }
            }
         }

      }
   }
}
