package ga.strikepractice.events;

import ga.strikepractice.party.Party;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PartyInviteEvent extends Event implements Cancellable {
   private static final HandlerList eg = new HandlerList();
   private final Player eh;
   private final Player ei;
   private final Party ej;
   private boolean ek;

   public PartyInviteEvent(Player var1, Player var2, Party var3) {
      this.eh = var1;
      this.ei = var2;
      this.ej = var3;
   }

   public Player getSender() {
      return this.eh;
   }

   public Player getRecipient() {
      return this.ei;
   }

   public Party getParty() {
      return this.ej;
   }

   public HandlerList getHandlers() {
      return eg;
   }

   public static HandlerList getHandlerList() {
      return eg;
   }

   public boolean isCancelled() {
      return this.ek;
   }

   public void setCancelled(boolean var1) {
      this.ek = var1;
   }
}
