package ga.strikepractice.events;

import ga.strikepractice.party.Party;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PartyLeaveEvent extends Event {
   private static final HandlerList ep = new HandlerList();
   private final Player eq;
   private final Party er;

   public PartyLeaveEvent(Player var1, Party var2) {
      this.eq = var1;
      this.er = var2;
   }

   public Player getPlayer() {
      return this.eq;
   }

   public Party getParty() {
      return this.er;
   }

   public HandlerList getHandlers() {
      return ep;
   }

   public static HandlerList getHandlerList() {
      return ep;
   }
}
