package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.duel.Duel;
import org.bukkit.entity.Player;

@APIClass
public class DuelEndEvent extends FightEndEvent {
   private final Player winner;
   private final Player loser;

   public DuelEndEvent(Duel var1, Player var2, Player var3) {
      super(var1);
      this.winner = var2;
      this.loser = var3;
   }

   public Player getLoser() {
      return this.loser;
   }

   public Player getWinner() {
      return this.winner;
   }

   public Duel getFight() {
      return (Duel)super.getFight();
   }
}
