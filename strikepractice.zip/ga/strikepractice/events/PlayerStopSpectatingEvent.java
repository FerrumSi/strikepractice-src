package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.Fight;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class PlayerStopSpectatingEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private boolean cancelled;
   private final Player player;
   private final Fight fight;

   public PlayerStopSpectatingEvent(Player var1, Fight var2) {
      this.player = var1;
      this.fight = var2;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public Player getPlayer() {
      return this.player;
   }

   public Fight getFight() {
      return this.fight;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
