package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.party.Party;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class PartyDisbandEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Party party;

   public PartyDisbandEvent(Party var1) {
      this.party = var1;
   }

   public Party getParty() {
      return this.party;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
