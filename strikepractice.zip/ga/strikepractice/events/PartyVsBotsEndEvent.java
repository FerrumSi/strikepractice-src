package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.party.partyfights.PartyVsBots;
import ga.strikepractice.party.Party;

@APIClass
public class PartyVsBotsEndEvent extends FightEndEvent {
   private final Party party;
   private final PartyVsBotsEndEvent.Winners winners;

   public PartyVsBotsEndEvent(PartyVsBots var1, Party var2, PartyVsBotsEndEvent.Winners var3) {
      super(var1);
      this.winners = var3;
      this.party = var2;
   }

   public Party getParty() {
      return this.party;
   }

   public PartyVsBotsEndEvent.Winners getWinners() {
      return this.winners;
   }

   public PartyVsBots getFight() {
      return (PartyVsBots)super.getFight();
   }

   public static enum Winners {
      es,
      et,
      eu;

      // $FF: synthetic method
      private static PartyVsBotsEndEvent.Winners[] $values() {
         return new PartyVsBotsEndEvent.Winners[]{es, et, eu};
      }
   }
}
