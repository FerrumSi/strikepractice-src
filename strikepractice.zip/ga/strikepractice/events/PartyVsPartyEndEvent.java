package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.party.Party;

@APIClass
public class PartyVsPartyEndEvent extends FightEndEvent {
   private final Party winner;
   private final Party loser;

   public PartyVsPartyEndEvent(PartyVsParty var1, Party var2, Party var3) {
      super(var1);
      this.winner = var2;
      this.loser = var3;
   }

   public Party getLoser() {
      return this.loser;
   }

   public Party getWinner() {
      return this.winner;
   }

   public PartyVsParty getFight() {
      return (PartyVsParty)super.getFight();
   }
}
