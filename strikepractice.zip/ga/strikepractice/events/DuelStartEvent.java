package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.duel.Duel;
import org.bukkit.entity.Player;

@APIClass
public class DuelStartEvent extends FightStartEvent {
   private final Player player1;
   private final Player player2;
   private BattleKit kit;

   public DuelStartEvent(Duel var1, Player var2, Player var3, BattleKit var4) {
      super(var1);
      this.player1 = var2;
      this.player2 = var3;
      this.kit = var4;
   }

   public Player getPlayer1() {
      return this.player1;
   }

   public Player getPlayer2() {
      return this.player2;
   }

   public BattleKit getKit() {
      return this.kit;
   }

   public void setKit(BattleKit var1) {
      this.kit = var1;
   }

   public Duel getFight() {
      return (Duel)super.getFight();
   }
}
