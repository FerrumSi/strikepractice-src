package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import org.bukkit.command.CommandSender;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class PlayerHostEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private final String event;
   private final CommandSender host;
   private boolean cancelled;

   public PlayerHostEvent(String var1, CommandSender var2) {
      this.event = var1.toLowerCase();
      this.host = var2;
   }

   public String getPvPEventName() {
      return this.event;
   }

   public CommandSender getHost() {
      return this.host;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
