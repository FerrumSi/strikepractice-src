package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.botduel.BotDuel;
import ga.strikepractice.npc.CitizensNPC;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.entity.Player;

@APIClass
public class BotDuelStartEvent extends FightStartEvent {
   private final Player player;
   private final CitizensNPC bot;

   public BotDuelStartEvent(BotDuel var1, Player var2, CitizensNPC var3) {
      super(var1);
      this.player = var2;
      this.bot = var3;
   }

   public NPC getBot() {
      return this.bot.getNPC();
   }

   public Player getPlayer() {
      return this.player;
   }

   public BotDuel getFight() {
      return (BotDuel)super.getFight();
   }
}
