package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.Fight;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class FightStartEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private final Fight fight;
   private boolean cancelled;

   public FightStartEvent(Fight var1) {
      this.fight = var1;
   }

   public Fight getFight() {
      return this.fight;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
