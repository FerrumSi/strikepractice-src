package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.party.partyfights.PartyVsBots;
import ga.strikepractice.party.Party;

@APIClass
public class PartyVsBotsStartEvent extends FightStartEvent {
   private final Party party;

   public PartyVsBotsStartEvent(PartyVsBots var1, Party var2) {
      super(var1);
      this.party = var2;
   }

   public Party getParty() {
      return this.party;
   }

   public PartyVsBots getFight() {
      return (PartyVsBots)super.getFight();
   }
}
