package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.party.partyfights.PartySplit;
import ga.strikepractice.party.Party;

@APIClass
public class PartySplitStartEvent extends FightStartEvent {
   private final Party party;

   public PartySplitStartEvent(PartySplit var1, Party var2) {
      super(var1);
      this.party = var2;
   }

   public Party getParty() {
      return this.party;
   }

   public PartySplit getFight() {
      return (PartySplit)super.getFight();
   }
}
