package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.duel.BestOf;
import ga.strikepractice.fights.duel.BestOfFight;
import java.util.List;
import org.bukkit.entity.Player;

@APIClass
public class RoundStartEvent extends FightStartEvent {
   public RoundStartEvent(BestOfFight var1) {
      super(var1);
   }

   /** @deprecated */
   @Deprecated
   public Player getPlayer1() {
      return (Player)this.getFight().getPlayersInFight().get(0);
   }

   /** @deprecated */
   @Deprecated
   public Player getPlayer2() {
      List var1 = this.getFight().getPlayersInFight();
      return var1.size() > 1 ? (Player)var1.get(1) : null;
   }

   public List<Player> getPlayers() {
      return this.getFight().getPlayersInFight();
   }

   /** @deprecated */
   @Deprecated
   public BattleKit getKit() {
      return this.getFight().getKit();
   }

   /** @deprecated */
   @Deprecated
   public void setKit(BattleKit var1) {
   }

   public BestOf getBestOf() {
      return this.getFight().getBestOf();
   }

   public BestOfFight getFight() {
      return (BestOfFight)super.getFight();
   }
}
