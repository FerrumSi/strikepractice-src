package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.hostedevents.PvPEvent;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class PvPEventStartEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private boolean cancelled;
   private PvPEvent event;

   public PvPEventStartEvent(PvPEvent var1) {
      this.event = var1;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public String getPvPEventName() {
      return this.event != null ? this.event.getClass().getSimpleName() : null;
   }

   public void setEvent(PvPEvent var1) {
      this.event = var1;
   }

   public PvPEvent getEvent() {
      return this.event;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
