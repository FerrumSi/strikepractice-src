package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class LanguageSelectEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private final Player player;
   private String language;
   private boolean cancelled;

   public LanguageSelectEvent(Player var1, String var2) {
      this.player = var1;
      this.language = var2;
   }

   public String getLanguage() {
      return this.language;
   }

   public Player getPlayer() {
      return this.player;
   }

   public void setLanguage(String var1) {
      this.language = var1;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
