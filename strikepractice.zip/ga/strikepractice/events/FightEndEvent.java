package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.Fight;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class FightEndEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Fight fight;

   public FightEndEvent(Fight var1) {
      this.fight = var1;
   }

   public Fight getFight() {
      return this.fight;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
