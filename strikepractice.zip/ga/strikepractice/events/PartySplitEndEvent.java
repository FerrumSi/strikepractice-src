package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.party.partyfights.PartySplit;
import ga.strikepractice.party.Party;
import java.util.HashSet;

@APIClass
public class PartySplitEndEvent extends FightEndEvent {
   private final Party party;
   private final HashSet<String> losers;
   private final HashSet<String> winners;

   public PartySplitEndEvent(PartySplit var1, Party var2, HashSet<String> var3, HashSet<String> var4) {
      super(var1);
      this.party = var2;
      this.losers = var4;
      this.winners = var3;
   }

   public Party getParty() {
      return this.party;
   }

   public HashSet<String> getWinners() {
      return this.winners;
   }

   public HashSet<String> getLosers() {
      return this.losers;
   }

   public PartySplit getFight() {
      return (PartySplit)super.getFight();
   }
}
