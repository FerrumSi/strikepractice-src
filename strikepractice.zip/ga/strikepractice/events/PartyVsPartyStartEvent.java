package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.party.Party;

@APIClass
public class PartyVsPartyStartEvent extends FightStartEvent {
   private final Party challangerParty;
   private final Party enemyParty;

   public PartyVsPartyStartEvent(PartyVsParty var1, Party var2, Party var3) {
      super(var1);
      this.challangerParty = var2;
      this.enemyParty = var3;
   }

   public Party getChallangerParty() {
      return this.challangerParty;
   }

   public Party getEnemyParty() {
      return this.enemyParty;
   }

   public PartyVsParty getFight() {
      return (PartyVsParty)super.getFight();
   }
}
