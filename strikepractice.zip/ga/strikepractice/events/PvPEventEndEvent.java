package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.hostedevents.PvPEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class PvPEventEndEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private PvPEvent event;
   private final Player winner;

   public PvPEventEndEvent(PvPEvent var1, Player var2) {
      this.event = var1;
      this.winner = var2;
   }

   public String getPvPEventName() {
      return this.event != null ? this.event.getType().getDisplayName() : null;
   }

   public void setEvent(PvPEvent var1) {
      this.event = var1;
   }

   public PvPEvent getEvent() {
      return this.event;
   }

   public Player getWinner() {
      return this.winner;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
