package ga.strikepractice.events;

import ga.strikepractice.party.Party;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PartyJoinEvent extends Event implements Cancellable {
   private static final HandlerList el = new HandlerList();
   private final Player em;
   private final Party en;
   private final boolean eo;
   private boolean ek;

   public PartyJoinEvent(Player var1, Party var2, boolean var3) {
      this.em = var1;
      this.en = var2;
      this.eo = var3;
   }

   public Player getPlayer() {
      return this.em;
   }

   public Party getParty() {
      return this.en;
   }

   public boolean isForced() {
      return this.eo;
   }

   public HandlerList getHandlers() {
      return el;
   }

   public static HandlerList getHandlerList() {
      return el;
   }

   public boolean isCancelled() {
      return this.ek;
   }

   public void setCancelled(boolean var1) {
      this.ek = var1;
   }
}
