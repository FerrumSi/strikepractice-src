package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.party.partyfights.PartyFFA;
import ga.strikepractice.party.Party;

@APIClass
public class PartyFFAStartEvent extends FightStartEvent {
   private final Party party;

   public PartyFFAStartEvent(PartyFFA var1, Party var2) {
      super(var1);
      this.party = var2;
   }

   public Party getParty() {
      return this.party;
   }

   public PartyFFA getFight() {
      return (PartyFFA)super.getFight();
   }
}
