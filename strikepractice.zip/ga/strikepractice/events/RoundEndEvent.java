package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.duel.BestOfFight;
import java.util.Collection;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class RoundEndEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final BestOfFight fight;
   private final boolean endingNow;
   private final Collection<Player> winners;
   private final Collection<Player> losers;

   public RoundEndEvent(BestOfFight var1, boolean var2, Collection<Player> var3, Collection<Player> var4) {
      this.fight = var1;
      this.endingNow = var2;
      this.winners = var3;
      this.losers = var4;
   }

   public boolean isEndingNow() {
      return this.endingNow;
   }

   public BestOfFight getFight() {
      return this.fight;
   }

   public Collection<Player> getLosers() {
      return this.losers;
   }

   public Collection<Player> getWinners() {
      return this.winners;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
