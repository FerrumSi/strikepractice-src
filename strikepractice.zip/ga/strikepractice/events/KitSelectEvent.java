package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.battlekit.BattleKit;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@APIClass
public class KitSelectEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private final Player player;
   private BattleKit kit;
   private BattleKit editedKit;
   private boolean cancelled;

   public KitSelectEvent(Player var1, BattleKit var2) {
      this(var1, var2, var2);
   }

   public KitSelectEvent(Player var1, BattleKit var2, BattleKit var3) {
      this.player = var1;
      this.kit = var2;
      this.editedKit = var3;
   }

   public boolean hasEditedKit() {
      return this.kit != this.editedKit && this.editedKit != null;
   }

   public BattleKit getEditedKit() {
      return this.editedKit;
   }

   public void setEditedKit(BattleKit var1) {
      this.editedKit = var1;
   }

   public BattleKit getKit() {
      return this.kit;
   }

   public Player getPlayer() {
      return this.player;
   }

   public void setKit(BattleKit var1) {
      this.kit = var1;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
