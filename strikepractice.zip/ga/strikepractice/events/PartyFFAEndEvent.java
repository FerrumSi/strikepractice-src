package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.party.partyfights.PartyFFA;
import ga.strikepractice.party.Party;
import org.bukkit.entity.Player;

@APIClass
public class PartyFFAEndEvent extends FightEndEvent {
   private final Player winner;
   private final Party party;

   public PartyFFAEndEvent(PartyFFA var1, Party var2, Player var3) {
      super(var1);
      this.party = var2;
      this.winner = var3;
   }

   public Party getParty() {
      return this.party;
   }

   public Player getWinner() {
      return this.winner;
   }

   public PartyFFA getFight() {
      return (PartyFFA)super.getFight();
   }
}
