package ga.strikepractice.events;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.botduel.BotDuel;
import ga.strikepractice.npc.CitizensNPC;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.entity.Player;

@APIClass
public class BotDuelEndEvent extends FightEndEvent {
   private final Player player;
   private final CitizensNPC bot;
   private final String winner;
   private final BotDuelEndEvent.WinnerType winnerType;

   public BotDuelEndEvent(BotDuel var1, Player var2, CitizensNPC var3, String var4, BotDuelEndEvent.WinnerType var5) {
      super(var1);
      this.winnerType = var5;
      this.player = var2;
      this.bot = var3;
      this.winner = var4;
   }

   public NPC getBot() {
      return this.bot.getNPC();
   }

   public Player getPlayer() {
      return this.player;
   }

   public String getWinner() {
      return this.winner;
   }

   public String getLoser() {
      return this.winnerType == BotDuelEndEvent.WinnerType.BOT ? this.player.getName() : this.getBot().getName();
   }

   public BotDuelEndEvent.WinnerType getWinnerType() {
      return this.winnerType;
   }

   public BotDuel getFight() {
      return (BotDuel)super.getFight();
   }

   @APIClass
   public static enum WinnerType {
      BOT,
      PLAYER;

      // $FF: synthetic method
      private static BotDuelEndEvent.WinnerType[] $values() {
         return new BotDuelEndEvent.WinnerType[]{BOT, PLAYER};
      }
   }
}
