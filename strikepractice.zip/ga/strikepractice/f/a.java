package ga.strikepractice.f;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.StrikePracticeAPI;
import ga.strikepractice.fights.elo.EloCalculator;

public class a {
   private void ba() {
      StrikePracticeAPI var1 = StrikePractice.getAPI();
      var1.setEloCalculator((var0) -> {
         int var1 = var0.getWinnerOldElo() - var0.getLoserOldElo();
         if (var1 > 10) {
            var0.setLoserNewElo(var0.getLoserOldElo() - 20);
            var0.setWinnerNewElo(var0.getWinnerOldElo() + 20);
         }

         if (var1 > 20) {
            var0.setLoserNewElo(var0.getLoserOldElo() - 50);
            var0.setWinnerNewElo(var0.getWinnerOldElo() + 50);
         } else {
            var0.setLoserNewElo(var0.getLoserOldElo() - 100);
            var0.setWinnerNewElo(var0.getWinnerOldElo() + 100);
         }

      });
   }

   private void bb() {
      StrikePracticeAPI var1 = StrikePractice.getAPI();
      EloCalculator var2 = var1.getEloCalculator();
      var1.setEloCalculator((var1x) -> {
         var2.calculateElo(var1x);
         var1x.setWinnerNewElo(var1x.getWinnerNewElo() * 2);
         var1x.setLoserNewElo(var1x.getLoserNewElo() * 2);
      });
   }
}
