package ga.strikepractice;

import com.google.common.base.Charsets;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.d;
import ga.strikepractice.kotlin.Lazy;
import ga.strikepractice.kotlin.LazyKt;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.jvm.functions.Function0;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.utils.B;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020-J\u0006\u0010.\u001a\u00020+J\u0006\u0010/\u001a\u00020+J\u0006\u00100\u001a\u00020+J\b\u00101\u001a\u00020\nH\u0002J\u0006\u00102\u001a\u00020+J\u0006\u00103\u001a\u00020+J\u0006\u00104\u001a\u00020+J\u0006\u00105\u001a\u00020+J\u0006\u00106\u001a\u00020+J\u0006\u00107\u001a\u00020+J\u0006\u00108\u001a\u00020+J\u000e\u00109\u001a\u00020+2\u0006\u0010:\u001a\u00020;J\u0006\u0010<\u001a\u00020+J\u0006\u0010=\u001a\u00020+J\u0006\u0010>\u001a\u00020+J\u0006\u0010?\u001a\u00020+J\u0016\u0010@\u001a\u00020+2\u0006\u0010:\u001a\u00020;2\u0006\u0010,\u001a\u00020-J\u0006\u0010A\u001a\u00020+R\"\u0010\u0007\u001a\u0004\u0018\u00010\u00062\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\"\u0010\u000b\u001a\u0004\u0018\u00010\n2\b\u0010\u0005\u001a\u0004\u0018\u00010\n@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\"\u0010\u000f\u001a\u0004\u0018\u00010\u000e2\b\u0010\u0005\u001a\u0004\u0018\u00010\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\"\u0010\u0012\u001a\u0004\u0018\u00010\n2\b\u0010\u0005\u001a\u0004\u0018\u00010\n@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\rR\"\u0010\u0014\u001a\u0004\u0018\u00010\u000e2\b\u0010\u0005\u001a\u0004\u0018\u00010\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0011R\"\u0010\u0017\u001a\u0004\u0018\u00010\u00162\b\u0010\u0005\u001a\u0004\u0018\u00010\u0016@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\"\u0010\u001a\u001a\u0004\u0018\u00010\n2\b\u0010\u0005\u001a\u0004\u0018\u00010\n@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\rR\"\u0010\u001c\u001a\u0004\u0018\u00010\u000e2\b\u0010\u0005\u001a\u0004\u0018\u00010\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0011R\"\u0010\u001e\u001a\u0004\u0018\u00010\n2\b\u0010\u0005\u001a\u0004\u0018\u00010\n@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\rR\"\u0010 \u001a\u0004\u0018\u00010\u000e2\b\u0010\u0005\u001a\u0004\u0018\u00010\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0011R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\"\u001a\u00020\n8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b$\u0010%\u001a\u0004\b#\u0010\rR\"\u0010&\u001a\u0004\u0018\u00010\n2\b\u0010\u0005\u001a\u0004\u0018\u00010\n@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\rR\"\u0010(\u001a\u0004\u0018\u00010\u000e2\b\u0010\u0005\u001a\u0004\u0018\u00010\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b)\u0010\u0011¨\u0006B"},
   d2 = {"Lga/strikepractice/FileManager;", "", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "<set-?>", "Lga/strikepractice/arena/ArenaFile;", "arenaFile", "getArenaFile", "()Lga/strikepractice/arena/ArenaFile;", "Lorg/bukkit/configuration/file/YamlConfiguration;", "dataConfig", "getDataConfig", "()Lorg/bukkit/configuration/file/YamlConfiguration;", "Ljava/io/File;", "dataFile", "getDataFile", "()Ljava/io/File;", "fightsConfig", "getFightsConfig", "fightsFile", "getFightsFile", "Lga/strikepractice/battlekit/KitFile;", "kitFile", "getKitFile", "()Lga/strikepractice/battlekit/KitFile;", "langItems", "getLangItems", "languageItemsFile", "getLanguageItemsFile", "messagesConfig", "getMessagesConfig", "messagesFile", "getMessagesFile", "scoreboardConfig", "getScoreboardConfig", "scoreboardConfig$delegate", "Lga/strikepractice/kotlin/Lazy;", "spawnItemsConfig", "getSpawnItemsConfig", "spawnItemsFile", "getSpawnItemsFile", "addFight", "", "kit", "Lga/strikepractice/battlekit/BattleKit;", "createDataFile", "createFightFile", "createMessagesFile", "initScoreboardConfig", "loadArenas", "loadKits", "loadLanguageItems", "loadSpawnItems", "makeArenaFileIfDoesNotExist", "makeKitsFileIfDoesNotExist", "reloadMessages", "removeRollbackKit", "arena", "Lga/strikepractice/arena/Arena;", "saveArenas", "saveDataFile", "saveKits", "saveLanguageItems", "saveRollbackKit", "saveSpawnItems", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nFileManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FileManager.kt\nga/strikepractice/FileManager\n+ 2 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,309:1\n81#2,4:310\n81#2,4:314\n81#2,4:318\n81#2,4:322\n81#2,4:326\n81#2,4:330\n81#2,4:336\n81#2,4:340\n81#2,4:344\n81#2,4:348\n81#2,4:354\n81#2,4:358\n81#2,4:362\n81#2,4:366\n81#2,4:370\n1855#3,2:334\n1855#3,2:352\n*S KotlinDebug\n*F\n+ 1 FileManager.kt\nga/strikepractice/FileManager\n*L\n53#1:310,4\n71#1:314,4\n80#1:318,4\n89#1:322,4\n131#1:326,4\n147#1:330,4\n162#1:336,4\n172#1:340,4\n193#1:344,4\n198#1:348,4\n223#1:354,4\n255#1:358,4\n268#1:362,4\n273#1:366,4\n283#1:370,4\n154#1:334,2\n205#1:352,2\n*E\n"})
public final class a {
   @NotNull
   private final StrikePractice plugin;
   @Nullable
   private d a;
   @Nullable
   private ga.strikepractice.arena.b b;
   @Nullable
   private File d;
   @Nullable
   private YamlConfiguration e;
   @Nullable
   private File f;
   @Nullable
   private YamlConfiguration g;
   @Nullable
   private File h;
   @Nullable
   private YamlConfiguration i;
   @Nullable
   private File j;
   @Nullable
   private YamlConfiguration k;
   @Nullable
   private File l;
   @Nullable
   private YamlConfiguration m;
   @NotNull
   private final Lazy n;

   public a(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.plugin = var1;
      this.n = LazyKt.lazy((Function0)(new Function0<YamlConfiguration>() {
         @NotNull
         public final YamlConfiguration N() {
            return a.this.M();
         }

         // $FF: synthetic method
         public Object invoke() {
            return this.N();
         }
      }));
   }

   @Nullable
   public final d a() {
      return this.a;
   }

   @Nullable
   public final ga.strikepractice.arena.b d() {
      return this.b;
   }

   @Nullable
   public final File e() {
      return this.d;
   }

   @Nullable
   public final YamlConfiguration g() {
      return this.e;
   }

   @Nullable
   public final File h() {
      return this.f;
   }

   @Nullable
   public final YamlConfiguration j() {
      return this.g;
   }

   @Nullable
   public final File o() {
      return this.h;
   }

   @Nullable
   public final YamlConfiguration p() {
      return this.i;
   }

   @Nullable
   public final File q() {
      return this.j;
   }

   @Nullable
   public final YamlConfiguration r() {
      return this.k;
   }

   @Nullable
   public final File t() {
      return this.l;
   }

   @Nullable
   public final YamlConfiguration u() {
      return this.m;
   }

   @NotNull
   public final YamlConfiguration w() {
      Lazy var1 = this.n;
      return (YamlConfiguration)var1.getValue();
   }

   public final void x() {
      this.y();
   }

   public final void y() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Creating messages.yml";
         var4.info(var5.append(var6).toString());
      }

      this.d = new File(this.plugin.getDataFolder(), "messages.yml");
      File var10 = this.d;
      Intrinsics.checkNotNull(var10);
      if (!var10.exists()) {
         this.plugin.saveResource("messages.yml", false);
      }

      this.e = YamlConfiguration.loadConfiguration(this.d);
      InputStream var8 = this.plugin.getResource("messages.yml");
      if (var8 != null) {
         try {
            YamlConfiguration var9 = YamlConfiguration.loadConfiguration((Reader)(new InputStreamReader(var8, Charsets.UTF_8)));
            YamlConfiguration var11 = this.e;
            if (var11 != null) {
               var11.setDefaults((Configuration)var9);
            }
         } catch (Exception var7) {
         }
      }

   }

   public final void z() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Creating dataFile";
         var4.info(var5.append(var6).toString());
      }

      this.l = new File(this.plugin.getDataFolder(), "data.dat");
      File var7 = this.l;
      Intrinsics.checkNotNull(var7);
      if (!var7.exists()) {
         this.plugin.saveResource("data.dat", false);
      }

      this.m = YamlConfiguration.loadConfiguration(this.l);
   }

   public final void A() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Creating fights.yml";
         var4.info(var5.append(var6).toString());
      }

      this.h = new File(this.plugin.getDataFolder(), "fights.yml");
      File var7 = this.h;
      Intrinsics.checkNotNull(var7);
      if (!var7.exists()) {
         this.plugin.saveResource("fights.yml", false);
      }

      this.i = YamlConfiguration.loadConfiguration(this.h);
   }

   public final void B() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Saving kits";
         var4.info(var5.append(var6).toString());
      }

      if (this.plugin.kits.size() > 0 || StrikePractice.D) {
         d var7 = this.a;
         Intrinsics.checkNotNull(var7);
         var7.au().set("kits", this.plugin.kits);
         var7 = this.a;
         Intrinsics.checkNotNull(var7);
         var7.save();
      }

   }

   public final void a(@NotNull Arena var1, @NotNull BattleKit var2) {
      Intrinsics.checkNotNullParameter(var1, "arena");
      Intrinsics.checkNotNullParameter(var2, "kit");
      String var10000 = var1.getName();
      Intrinsics.checkNotNullExpressionValue(var10000, "arena.name");
      if (!StringsKt.contains$default((CharSequence)var10000, (CharSequence)":", false, 2, (Object)null)) {
         var10000 = var1.getName();
         Intrinsics.checkNotNullExpressionValue(var10000, "arena.name");
         if (!StringsKt.contains$default((CharSequence)var10000, (CharSequence)"spleef", false, 2, (Object)null)) {
            Set var3 = ((ga.strikepractice.battlekit.b)var2).aG();
            if (var3.isEmpty()) {
               return;
            }

            String var4 = var1.getName() + ':' + StringsKt.replace$default(StringsKt.replace$default(var3.toString(), "[", "", false, 4, (Object)null), "]", "", false, 4, (Object)null);
            ga.strikepractice.arena.b var6 = this.b;
            Intrinsics.checkNotNull(var6);
            List var5 = var6.au().getStringList("rollback-kits");
            var5.add(var4);
            if (var5.isEmpty()) {
               var6 = this.b;
               Intrinsics.checkNotNull(var6);
               var6.au().set("rollback-kits", (Object)null);
            } else {
               var6 = this.b;
               Intrinsics.checkNotNull(var6);
               var6.au().set("rollback-kits", var5);
            }

            var6 = this.b;
            Intrinsics.checkNotNull(var6);
            var6.save();
            return;
         }
      }

   }

   public final void a(@NotNull Arena var1) {
      Intrinsics.checkNotNullParameter(var1, "arena");
      String var10000 = var1.getName();
      Intrinsics.checkNotNullExpressionValue(var10000, "arena.name");
      if (!StringsKt.contains$default((CharSequence)var10000, (CharSequence)":", false, 2, (Object)null)) {
         var10000 = var1.getName();
         Intrinsics.checkNotNullExpressionValue(var10000, "arena.name");
         if (!StringsKt.contains$default((CharSequence)var10000, (CharSequence)"spleef", false, 2, (Object)null)) {
            final String var2 = var1.getName() + ':';
            ga.strikepractice.arena.b var10002 = this.b;
            Intrinsics.checkNotNull(var10002);
            List var3 = (List)(new ArrayList((Collection)var10002.au().getStringList("rollback-kits")));
            var3.removeIf(ga.strikepractice.a::a);
            ga.strikepractice.arena.b var4;
            if (var3.isEmpty()) {
               var4 = this.b;
               Intrinsics.checkNotNull(var4);
               var4.au().set("rollback-kits", (Object)null);
            } else {
               var4 = this.b;
               Intrinsics.checkNotNull(var4);
               var4.au().set("rollback-kits", var3);
            }

            var4 = this.b;
            Intrinsics.checkNotNull(var4);
            var4.save();
            return;
         }
      }

   }

   public final void C() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Loading arenas";
         var4.info(var5.append(var6).toString());
      }

      this.K();
      this.plugin.M.clear();
      ga.strikepractice.arena.b var10 = this.b;
      Intrinsics.checkNotNull(var10);
      if (var10.au().getList("arenas") != null) {
         var10 = this.b;
         Intrinsics.checkNotNull(var10);
         Iterator var7 = var10.au().getList("arenas").iterator();

         while(var7.hasNext()) {
            Object var8 = var7.next();
            if (var8 != null && var8 instanceof Arena) {
               c var9 = (c)var8;
               String var11 = var9.getName();
               Intrinsics.checkNotNullExpressionValue(var11, "a.name");
               if (!StringsKt.contains$default((CharSequence)var11, (CharSequence)":", false, 2, (Object)null)) {
                  this.plugin.M.add(var9);
               }
            }
         }
      }

   }

   public final void D() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var10 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var9 = var10000;
         boolean var3 = false;
         String var11 = "Loading spawnitems.yml";
         var9.info(var10.append(var11).toString());
      }

      this.plugin.N.clear();
      this.j = new File(this.plugin.getDataFolder(), "spawnitems.yml");
      File var13 = this.j;
      Intrinsics.checkNotNull(var13);
      if (!var13.exists()) {
         this.plugin.saveResource("spawnitems.yml", false);
      }

      this.k = YamlConfiguration.loadConfiguration(this.j);
      YamlConfiguration var14 = this.k;
      if (var14 != null) {
         List var15 = var14.getList("spawn-items");
         if (var15 != null) {
            Iterable var12 = (Iterable)var15;
            boolean var4 = false;
            Iterator var5 = var12.iterator();

            while(var5.hasNext()) {
               Object var6 = var5.next();
               boolean var8 = false;
               if (var6 instanceof ga.strikepractice.p.b && !this.plugin.N.contains(var6)) {
                  this.plugin.N.add((ga.strikepractice.p.b)var6);
               }
            }
         }
      }

   }

   public final void E() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Saving spawnitems.yml";
         var4.info(var5.append(var6).toString());
      }

      YamlConfiguration var8 = this.k;
      Intrinsics.checkNotNull(var8);
      var8.set("spawn-items", this.plugin.N);

      try {
         var8 = this.k;
         Intrinsics.checkNotNull(var8);
         var8.save(this.j);
      } catch (IOException var7) {
         var7.printStackTrace();
      }

   }

   public final void F() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Saving arenas";
         var4.info(var5.append(var6).toString());
      }

      if (this.plugin.M.size() > 0 || StrikePractice.D) {
         List var7 = (List)(new ArrayList());
         Iterator var8 = this.plugin.M.iterator();

         while(var8.hasNext()) {
            Arena var9 = (Arena)var8.next();
            if (var9.getCenter() == null && var9.getLoc1() != null && var9.getLoc2() != null) {
               var9.setCenter(new Location(var9.getLoc1().getWorld(), (double)(var9.getLoc1().getBlockX() + var9.getLoc2().getBlockX()) / 2.0D, (double)(var9.getLoc1().getBlockY() + var9.getLoc2().getBlockY() + 5) / 2.0D, (double)(var9.getLoc1().getBlockZ() + var9.getLoc2().getBlockZ()) / 2.0D));
            }

            if (var9.getLoc1() != null && var9.getLoc2() != null && var9.getCenter().getWorld() != null) {
               String var10 = var9.getName();
               Intrinsics.checkNotNullExpressionValue(var10, "a.name");
               if (!StringsKt.contains$default((CharSequence)var10, (CharSequence)":", false, 2, (Object)null)) {
                  Intrinsics.checkNotNullExpressionValue(var9, "a");
                  var7.add(var9);
               }
            }
         }

         ga.strikepractice.arena.b var11 = this.b;
         Intrinsics.checkNotNull(var11);
         var11.au().set("arenas", var7);
         var11 = this.b;
         Intrinsics.checkNotNull(var11);
         var11.save();
      }

   }

   public final void G() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Make KitFile";
         var4.info(var5.append(var6).toString());
      }

      this.a = new d(this.plugin);
   }

   public final void H() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var14 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var13 = var10000;
         boolean var3 = false;
         String var15 = "Loading languageitems.yml";
         var13.info(var14.append(var15).toString());
      }

      this.f = new File(this.plugin.getDataFolder(), "languageitems.yml");
      File var17 = this.f;
      Intrinsics.checkNotNull(var17);
      if (!var17.exists()) {
         this.plugin.saveResource("languageitems.yml", false);
      }

      this.g = YamlConfiguration.loadConfiguration(this.f);
      this.plugin.K.clear();
      YamlConfiguration var18 = this.g;
      if (var18 != null) {
         List var19 = var18.getList("language-items");
         if (var19 != null) {
            Iterable var16 = (Iterable)var19;
            boolean var4 = false;
            Iterator var5 = var16.iterator();

            while(var5.hasNext()) {
               Object var6 = var5.next();
               boolean var8 = false;
               if (var6 instanceof ga.strikepractice.h.b) {
                  Object var9 = var6;
                  boolean var10 = false;
                  Iterator var11 = this.plugin.K.iterator();

                  while(var11.hasNext()) {
                     ga.strikepractice.h.b var12 = (ga.strikepractice.h.b)var11.next();
                     if (var12.cC() != null && ((ga.strikepractice.h.b)var9).cC() != null && Intrinsics.areEqual((Object)var12.cC(), (Object)((ga.strikepractice.h.b)var9).cC()) && var12.getLanguage() != null && ((ga.strikepractice.h.b)var9).getLanguage() != null && Intrinsics.areEqual((Object)((ga.strikepractice.h.b)var9).getLanguage(), (Object)var12.getLanguage()) && var12.bl() == ((ga.strikepractice.h.b)var9).bl()) {
                        var10 = true;
                        break;
                     }
                  }

                  if (!var10) {
                     this.plugin.K.add(var9);
                  }
               }
            }
         }
      }

   }

   public final void I() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Saving languageitems.yml";
         var4.info(var5.append(var6).toString());
      }

      YamlConfiguration var8 = this.g;
      Intrinsics.checkNotNull(var8);
      Set var10002 = this.plugin.K;
      Intrinsics.checkNotNullExpressionValue(var10002, "plugin.languageItems");
      var8.set("language-items", CollectionsKt.toList((Iterable)var10002));

      try {
         var8 = this.g;
         Intrinsics.checkNotNull(var8);
         var8.save(this.f);
      } catch (IOException var7) {
         var7.printStackTrace();
      }

   }

   public final void a(@NotNull BattleKit var1) {
      Intrinsics.checkNotNullParameter(var1, "kit");

      try {
         CompletableFuture.runAsync(ga.strikepractice.a::a);
      } catch (Exception var3) {
         Bukkit.getLogger().info("Failed to add fight to fights.yml. This is harmless but please report it.");
      }

   }

   public final void J() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Loading kits.yml";
         var4.info(var5.append(var6).toString());
      }

      this.G();
      this.plugin.kits.clear();
      d var9 = this.a;
      Intrinsics.checkNotNull(var9);
      if (var9.au().getList("kits") != null) {
         var9 = this.a;
         Intrinsics.checkNotNull(var9);
         Iterator var7 = var9.au().getList("kits").iterator();

         while(var7.hasNext()) {
            Object var8 = var7.next();
            if (var8 instanceof BattleKit) {
               this.plugin.kits.add((ga.strikepractice.battlekit.b)var8);
            }
         }
      }

   }

   public final void K() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Make ArenaFile";
         var4.info(var5.append(var6).toString());
      }

      this.b = new ga.strikepractice.arena.b(this.plugin);
   }

   public final void L() {
      B.a var1 = B.vj;
      boolean var2 = false;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var5 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var4 = var10000;
         boolean var3 = false;
         String var6 = "Saving data file";
         var4.info(var5.append(var6).toString());
      }

      try {
         YamlConfiguration var8 = this.m;
         Intrinsics.checkNotNull(var8);
         var8.save(this.l);
      } catch (IOException var7) {
         var7.printStackTrace();
      }

   }

   private final YamlConfiguration M() {
      B.a var1 = B.vj;
      boolean var2 = false;
      boolean var3;
      if (var1.fV()) {
         Logger var10000 = Bukkit.getLogger();
         StringBuilder var6 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var5 = var10000;
         var3 = false;
         String var7 = "Init scoreboard.yml";
         var5.info(var6.append(var7).toString());
      }

      ConfigurationSection var8 = this.plugin.getConfig().getConfigurationSection("scoreboard");
      File var9 = new File(this.plugin.getDataFolder(), "scoreboard.yml");
      var3 = var9.createNewFile();
      if (var3) {
         this.plugin.saveResource("scoreboard.yml", true);
      }

      YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var9);
      if (var8 != null) {
         if (var4.getConfigurationSection("scoreboard") != null && !var3) {
            Bukkit.getLogger().warning("scoreboard section exists in scoreboard.yml but also still exists in config.yml. Assuming scoreboard.yml is correct and not copying.Copy the entire 'scoreboard:' (including that 'scoreboard:') section from the config.yml manually to scoreboard.yml if you want to use the one found in config.yml");
         } else {
            Bukkit.getLogger().info("Copying old scoreboard config from config.yml to scoreboard.yml");
            var4.set("scoreboard", var8);
            var4.save(var9);
            Bukkit.getLogger().info("Scoreboard config copied! Deleting old section");
            this.plugin.getConfig().set("scoreboard", (Object)null);
            this.plugin.saveConfig();
         }
      }

      Intrinsics.checkNotNullExpressionValue(var4, "newConfig");
      return var4;
   }

   private static final boolean a(Function1 var0, Object var1) {
      Intrinsics.checkNotNullParameter(var0, "$tmp0");
      return (Boolean)var0.invoke(var1);
   }

   private static final void a(BattleKit var0, ga.strikepractice.a var1) {
      Intrinsics.checkNotNullParameter(var0, "$kit");
      Intrinsics.checkNotNullParameter(var1, "this$0");
      if (StrikePractice.getInstance().kits.contains(var0)) {
         YamlConfiguration var10000 = var1.i;
         Intrinsics.checkNotNull(var10000);
         if (var10000.get(var0.getName()) == null) {
            var10000 = var1.i;
            Intrinsics.checkNotNull(var10000);
            var10000.set(var0.getName(), 1);
         } else {
            var10000 = var1.i;
            Intrinsics.checkNotNull(var10000);
            int var2 = var10000.getInt(var0.getName());
            var10000 = var1.i;
            Intrinsics.checkNotNull(var10000);
            var10000.set(var0.getName(), var2 + 1);
         }

         try {
            var10000 = var1.i;
            Intrinsics.checkNotNull(var10000);
            var10000.save(var1.h);
         } catch (IOException var3) {
            Bukkit.getLogger().warning("Failed to save fight statistics (fights.yml). This is harmless.");
         }
      }

   }
}
