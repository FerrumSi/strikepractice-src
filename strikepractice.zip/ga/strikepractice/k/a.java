package ga.strikepractice.k;

public enum a {
   py("staff"),
   pz("admin"),
   pA("cooldownbypass"),
   pB("brackets.host"),
   pC("hostevent.brackets"),
   pD("sumo.host"),
   pE("hostevent.sumo"),
   pF("juggernaut.host"),
   pG("hostevent.juggernaut"),
   pH("lms.host"),
   pI("hostevent.lms"),
   pJ("koth.host"),
   pK("hostevent.koth"),
   pL("publicparty"),
   pM("partylimit"),
   pN("customkit"),
   pO("customkit.armor"),
   pP("customkit.combo"),
   pQ("customkit.horse"),
   pR("customkit.build"),
   pS("customkit.bow"),
   pT("update"),
   pU("partyplayback"),
   pV("partybots"),
   pW("playback"),
   pX("hostevent.anykit"),
   pY("premiumqueue"),
   pZ("openparty"),
   qa("mapselector"),
   qb("queuebypass");

   private final String qc;

   private a(String var3) {
      this.qc = var3;
   }

   public String dY() {
      return this.qc;
   }

   public String toString() {
      return "strikepractice." + this.qc;
   }

   // $FF: synthetic method
   private static ga.strikepractice.k.a[] dZ() {
      return new ga.strikepractice.k.a[]{py, pz, pA, pB, pC, pD, pE, pF, pG, pH, pI, pJ, pK, pL, pM, pN, pO, pP, pQ, pR, pS, pT, pU, pV, pW, pX, pY, pZ, qa, qb};
   }
}
