package ga.strikepractice.k;

import org.bukkit.command.CommandSender;

public class b {
   public static boolean a(CommandSender var0, ga.strikepractice.k.a var1) {
      return var0.isOp() || var0.hasPermission(ga.strikepractice.k.a.pz.toString()) || var0.hasPermission(var1.toString()) || var0.hasPermission("strikepractice.*") || var1.toString().startsWith("strikepractice.hostevent.") && var0.hasPermission("strikepractice.hostevent.*");
   }
}
