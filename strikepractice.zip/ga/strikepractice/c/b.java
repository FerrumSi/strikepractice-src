package ga.strikepractice.c;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.u;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class b extends BukkitRunnable {
   public static final String dO = "StrikePracticeDelayedTeleport";
   private final UUID player;
   private final Location dP;
   private final Location dQ;
   private int counter;
   private final StrikePractice dR;
   private final ga.strikepractice.c.a dS;

   public b(StrikePractice var1, int var2, Player var3, Location var4, ga.strikepractice.c.a var5) {
      this.player = var3.getUniqueId();
      this.dP = var3.getLocation();
      this.dQ = var4;
      this.dR = var1;
      this.counter = var2;
      this.dS = var5;
      if (var2 <= 0) {
         if (this.dS != null) {
            this.dS.aQ();
         }

         N.a(var3, this.dQ);
      } else {
         var1.a(var3, "teleporting", u.a("<seconds>", var2));
         this.runTaskTimer(var1, 20L, 20L);
      }

   }

   public void run() {
      Player var1 = Bukkit.getPlayer(this.player);
      if (var1 != null && var1.getLocation().getWorld() == this.dP.getWorld() && var1.getLocation().distance(this.dP) < 1.0D) {
         --this.counter;
         if (this.counter <= 0) {
            if (this.dS != null) {
               this.dS.aQ();
            }

            N.a(var1, this.dQ);
            this.cancel();
         }

      } else {
         this.aR();
      }
   }

   public synchronized void cancel() {
      super.cancel();
   }

   void aR() {
      this.cancel();
      Player var1 = Bukkit.getPlayer(this.player);
      if (var1 != null) {
         this.dR.a(var1, "teleport-cancelled");
         var1.removeMetadata("StrikePracticeDelayedTeleport", this.dR);
      }

   }
}
