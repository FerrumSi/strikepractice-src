package ga.strikepractice.c;

public abstract class a {
   public abstract void aQ();
}
