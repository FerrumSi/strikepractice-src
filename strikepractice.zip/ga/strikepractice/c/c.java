package ga.strikepractice.c;

import ga.strikepractice.StrikePractice;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;

public class c implements Listener {
   private final StrikePractice dT;

   public c(StrikePractice var1) {
      this.dT = var1;
   }

   @EventHandler(
      ignoreCancelled = true,
      priority = EventPriority.MONITOR
   )
   public void a(EntityDamageEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         if (var2.hasMetadata("StrikePracticeDelayedTeleport")) {
            MetadataValue var3 = this.dT.a((Metadatable)var2, (String)"StrikePracticeDelayedTeleport");
            if (var3 != null && var3.value() != null && var3.value() instanceof b) {
               b var4 = (b)var3.value();
               var4.aR();
            }
         }
      }

   }
}
