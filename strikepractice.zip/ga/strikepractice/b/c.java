package ga.strikepractice.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.requests.FightRequest;
import ga.strikepractice.playerkits.PlayerKits;
import ga.strikepractice.playersettings.PlayerSettings;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.A;
import ga.strikepractice.utils.C;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

public class c implements Listener {
   public static final String cP = "StrikePracticeLoadingPlayerData";
   private final StrikePractice cQ;

   public c(StrikePractice var1) {
      this.cQ = var1;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void a(PlayerJoinEvent var1) {
      long var2 = System.currentTimeMillis();
      final Player var4 = var1.getPlayer();
      var4.setMetadata("StrikePracticeLoadingPlayerData", new FixedMetadataValue(this.cQ, true));
      var4.setWalkSpeed(0.2F);
      if (this.cQ.getConfig().getBoolean("join-lobby-teleport")) {
         (new BukkitRunnable() {
            public void run() {
               c.this.cQ.clear(var4, true, true);
            }
         }).runTaskLater(this.cQ, 2L);
      }

      C.c(() -> {
         UUID var5 = var1.getPlayer().getUniqueId();
         if (A.vc != null && ga.strikepractice.k.b.a(var4, ga.strikepractice.k.a.pT)) {
            var4.sendMessage(A.vc);
         }

         try {
            this.cQ.aq().j(var4);
         } catch (Exception var10) {
            var10.printStackTrace();
            C.d(() -> {
               var4.kickPlayer("StrikePractice >> Database error. Contact admins or check console.");
            });
            return;
         }

         try {
            PlayerKits var6 = this.cQ.Y().g(var5);
            new PlayerSettings(var5);
            new DefaultPlayerStats(var5, false);
            if (StrikePractice.u) {
               return;
            }

            this.cQ.Y().a(var4, var6);
            var4.removeMetadata("StrikePracticeLoadingPlayerData", this.cQ);
            long var7 = System.currentTimeMillis();
            Bukkit.getLogger().info("Loaded " + var4.getName() + "'s data in " + (var7 - var2) + " ms.");
         } catch (Exception var9) {
            var9.printStackTrace();
            C.d(() -> {
               var4.kickPlayer("StrikePractice >> Error while loading your data. Contact admins or check console.");
            });
         }

      });
   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      if (!StrikePractice.u) {
         Player var2 = var1.getPlayer();
         UUID var3 = var2.getUniqueId();
         PlayerKits var4 = this.cQ.Y().e(var2, false);
         var2.removeMetadata("StrikePracticeRollbackRateAlerts", this.cQ);
         var2.removeMetadata(ga.strikepractice.playerkits.b.qM, this.cQ);
         FightRequest.clearAll(var2);
         var2.removeMetadata("StrikePracticeRankedQueue", this.cQ);
         var2.removeMetadata("StrikePractice2v2RankedQueue", this.cQ);
         if (var2.hasMetadata("StrikePracticeLoadingPlayerData")) {
            DefaultPlayerStats var5 = (DefaultPlayerStats)DefaultPlayerStats.getStats().remove(var3);
            if (var5 != null && var5.to) {
               Bukkit.getLogger().warning(var2.getName() + " left while LOADING_DATA was present but stats were loaded. If they have lost their stats please report it to Toppe");
            }
         } else {
            C.c(() -> {
               DefaultPlayerStats var2 = DefaultPlayerStats.getStats(var3, false);
               if (var2 != null) {
                  var2.save();
               }

               DefaultPlayerStats.getStats().remove(var3);
               if (var4 != null) {
                  var4.savePlayerKitsToFile();
               }

               PlayerSettings.getPlayerSettings(var3).save();
               PlayerSettings.getSettings().remove(var3);
            });
         }

      }
   }
}
