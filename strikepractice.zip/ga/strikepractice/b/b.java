package ga.strikepractice.b;

import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.stats.PlayerStats;
import java.util.LinkedHashMap;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface b {
   LinkedHashMap<String, Double> b(String var1, int var2);

   LinkedHashMap<String, Double> c(BattleKit var1, int var2);

   LinkedHashMap<String, Double> d(BattleKit var1, int var2);

   int a(UUID var1, String var2);

   void b(PlayerStats var1);

   void a(UUID var1, String var2, int var3);

   void a(PlayerStats var1);

   void k(Player var1);

   default int a(@NotNull UUID var1, @Nullable BattleKit var2) {
      Bukkit.getLogger().warning("The current database in use does not support #countWins (or the placeholders)");
      return 0;
   }

   default int b(@NotNull UUID var1, @Nullable BattleKit var2) {
      Bukkit.getLogger().warning("The current database in use does not support #countLosses (or the placeholders)");
      return 0;
   }

   default int c(@NotNull UUID var1, @Nullable BattleKit var2) {
      Bukkit.getLogger().warning("The current database in use does not support #countWinStreak (or the placeholders)");
      return 0;
   }

   default void initialize() {
   }
}
