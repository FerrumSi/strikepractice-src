package ga.strikepractice.b.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.jdk7.AutoCloseableKt;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.Ref;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.Regex;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.stats.PlayerStats;
import ga.strikepractice.stats.Stats;
import ga.strikepractice.utils.B;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0010\u0006\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\"\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u001a\u0010\u0011\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016J\u001a\u0010\u0012\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016J\u001a\u0010\u0013\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016J\u0010\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\fH\u0002J\u0010\u0010\u0015\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\fH\u0002J\u0018\u0010\u0016\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u0006H\u0016J.\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u001a0\u00192\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u001b\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J$\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u001a0\u00192\u0006\u0010\u0017\u001a\u00020\u00062\u0006\u0010\u001b\u001a\u00020\nH\u0016J&\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u001a0\u00192\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u001b\u001a\u00020\nH\u0016J&\u0010\u001d\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u001a0\u00192\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u001b\u001a\u00020\nH\u0016J\b\u0010\u001e\u001a\u00020\u001fH\u0016J \u0010 \u001a\u00020\u001f2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u00062\u0006\u0010!\u001a\u00020\nH\u0016J\u0010\u0010\"\u001a\u00020\u001f2\u0006\u0010\u0017\u001a\u00020#H\u0016J\u0010\u0010$\u001a\u00020\u001f2\u0006\u0010%\u001a\u00020&H\u0016J\u0010\u0010'\u001a\u00020\u001f2\u0006\u0010\u0017\u001a\u00020#H\u0016R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006("},
   d2 = {"Lga/strikepractice/data/sql/SQLDatabaseQuerier;", "Lga/strikepractice/data/DatabaseQuerier;", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "eloColumns", "", "eloColumnsStartingValues", "updateQueryColumns", "countFights", "", "uuid", "Ljava/util/UUID;", "kit", "Lga/strikepractice/battlekit/BattleKit;", "winner", "", "countLosses", "countWinStreak", "countWins", "createIfNotExists", "exists", "getStatsSync", "stats", "getTopStats", "Ljava/util/LinkedHashMap;", "", "limit", "getTopStatsLosses", "getTopStatsWins", "initialize", "", "setStatsSync", "amount", "statsFromDatabase", "Lga/strikepractice/stats/PlayerStats;", "updatePlayerOnJoin", "player", "Lorg/bukkit/entity/Player;", "updateToDatabase", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nSQLDatabaseQuerier.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SQLDatabaseQuerier.kt\nga/strikepractice/data/sql/SQLDatabaseQuerier\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n*L\n1#1,374:1\n1#2:375\n81#3,4:376\n81#3,4:380\n81#3,4:384\n81#3,4:388\n*S KotlinDebug\n*F\n+ 1 SQLDatabaseQuerier.kt\nga/strikepractice/data/sql/SQLDatabaseQuerier\n*L\n252#1:376,4\n280#1:380,4\n291#1:384,4\n325#1:388,4\n*E\n"})
public final class b implements ga.strikepractice.b.b {
   @NotNull
   private final StrikePractice dh;
   @Nullable
   private String di;
   @Nullable
   private String dj;
   @Nullable
   private String dk;

   public b(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.dh = var1;
   }

   public void initialize() {
      StringBuilder var1 = new StringBuilder();
      StringBuilder var2 = new StringBuilder();
      Iterator var3 = StrikePractice.getInstance().kits.iterator();

      while(var3.hasNext()) {
         BattleKit var4 = (BattleKit)var3.next();
         if (var4.isElo()) {
            var1.append(Stats.eloColumn(var4)).append(", ");
            var2.append("'").append(ga.strikepractice.b.a.cM).append("'").append(", ");
         }
      }

      var1.append("global_elo");
      this.di = var1.toString();
      var2.append("'").append(ga.strikepractice.b.a.cM).append("'");
      this.dj = var2.toString();
      StringBuilder var7 = new StringBuilder();
      var7.append("kills");
      var7.append(" = ?,");
      var7.append("deaths");
      var7.append(" = ?,");
      var7.append("lms");
      var7.append(" = ?,");
      var7.append("brackets");
      var7.append(" = ?,");
      var7.append("party_vs_party_wins");
      var7.append(" = ?,");
      var7.append("global_elo");
      var7.append(" = ?,");
      var7.append("sumo_wins");
      var7.append(" = ?,");
      var7.append("juggernaut");
      var7.append(" = ?,");
      Iterator var8 = this.dh.kits.iterator();

      while(var8.hasNext()) {
         BattleKit var5 = (BattleKit)var8.next();
         if (var5.isElo()) {
            String var6 = Stats.eloColumn(var5);
            var7.append(var6);
            var7.append(" = ?,");
         }
      }

      var7.deleteCharAt(var7.length() - 1);
      this.dk = var7.toString();
   }

   @NotNull
   public LinkedHashMap<String, Double> b(@NotNull final String var1, final int var2) {
      Intrinsics.checkNotNullParameter(var1, "stats");
      boolean var4;
      String var6;
      if (var1.length() > 30 || StringsKt.contains$default((CharSequence)var1, (CharSequence)" ", false, 2, (Object)null)) {
         var4 = false;
         var6 = "invalid 'stats':" + var1;
         throw new IllegalArgumentException(var6.toString());
      } else if (!Stats.allStatsColumns().contains(var1)) {
         var4 = false;
         var6 = "invalid 'stats':" + var1;
         throw new IllegalArgumentException(var6.toString());
      } else {
         CharSequence var3 = (CharSequence)var1;
         if (!(new Regex("[a-zA-Z0-9_-]+")).matches(var3)) {
            var4 = false;
            var6 = "invalid 'stats':" + var1;
            throw new IllegalArgumentException(var6.toString());
         } else {
            final LinkedHashMap var5 = new LinkedHashMap();
            ga.strikepractice.b.b.a var10000 = this.dh.O;
            Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
            c.a(var10000, (Function1)(new Function1<Connection, Unit>() {
               public final void f(@NotNull Connection var1x) {
                  Intrinsics.checkNotNullParameter(var1x, "conn");
                  AutoCloseable var2x = (AutoCloseable)var1x.createStatement();
                  String var3 = var1;
                  int var4 = var2;
                  LinkedHashMap var5x = var5;
                  Throwable var6 = null;

                  try {
                     Statement var7 = (Statement)var2x;
                     boolean var8 = false;
                     String var9 = "SELECT username, " + var3 + " from stats order by " + var3 + " desc limit " + var4;
                     AutoCloseable var10 = (AutoCloseable)var7.executeQuery(var9);
                     Throwable var11 = null;

                     try {
                        ResultSet var12 = (ResultSet)var10;
                        boolean var13 = false;

                        while(var12.next()) {
                           String var14 = var12.getString("username");
                           if (!var5x.containsKey(var14)) {
                              Map var10000 = (Map)var5x;
                              Intrinsics.checkNotNullExpressionValue(var14, "player");
                              var10000.put(var14, var12.getDouble(var3));
                           }
                        }

                        Unit var28 = Unit.INSTANCE;
                     } catch (Throwable var23) {
                        var11 = var23;
                        throw var23;
                     } finally {
                        AutoCloseableKt.closeFinally(var10, var11);
                     }

                     Unit var27 = Unit.INSTANCE;
                  } catch (Throwable var25) {
                     var6 = var25;
                     throw var25;
                  } finally {
                     AutoCloseableKt.closeFinally(var2x, var6);
                  }

               }

               // $FF: synthetic method
               public Object invoke(Object var1x) {
                  this.f((Connection)var1x);
                  return Unit.INSTANCE;
               }
            }));
            return var5;
         }
      }
   }

   @NotNull
   public LinkedHashMap<String, Double> c(@Nullable BattleKit var1, int var2) {
      return this.a(var1, var2, true);
   }

   @NotNull
   public LinkedHashMap<String, Double> d(@Nullable BattleKit var1, int var2) {
      return this.a(var1, var2, false);
   }

   private final LinkedHashMap<String, Double> a(final BattleKit var1, final int var2, final boolean var3) {
      final LinkedHashMap var4 = new LinkedHashMap();
      ga.strikepractice.b.b.a var10000 = this.dh.O;
      Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
      c.a(var10000, (Function1)(new Function1<Connection, Unit>() {
         public final void g(@NotNull Connection var1x) {
            Intrinsics.checkNotNullParameter(var1x, "conn");
            AutoCloseable var2x = (AutoCloseable)var1x.prepareStatement(StringsKt.trimIndent("\n                    SELECT username, COUNT(*) as count\n                    FROM fight_players fp\n                             JOIN fights f ON f.started = fp.fight\n                    WHERE is_winner = ? " + (var1 != null ? "AND kit=?" : "") + "\n                    GROUP BY uuid\n                    ORDER BY count DESC\n                    LIMIT " + var2 + "\n                        "));
            boolean var3x = var3;
            BattleKit var4x = var1;
            LinkedHashMap var5 = var4;
            Throwable var6 = null;

            try {
               PreparedStatement var7 = (PreparedStatement)var2x;
               boolean var8 = false;
               var7.setBoolean(1, var3x);
               if (var4x != null) {
                  boolean var10 = false;
                  var7.setString(2, var4x.getName());
               }

               AutoCloseable var11 = (AutoCloseable)var7.executeQuery();
               Throwable var9 = null;

               try {
                  ResultSet var27 = (ResultSet)var11;
                  boolean var12 = false;

                  while(var27.next()) {
                     String var13 = var27.getString("username");
                     if (!var5.containsKey(var13)) {
                        Map var10000 = (Map)var5;
                        Intrinsics.checkNotNullExpressionValue(var13, "player");
                        var10000.put(var13, var27.getDouble("count"));
                     }
                  }

                  Unit var28 = Unit.INSTANCE;
               } catch (Throwable var22) {
                  var9 = var22;
                  throw var22;
               } finally {
                  AutoCloseableKt.closeFinally(var11, var9);
               }

               Unit var26 = Unit.INSTANCE;
            } catch (Throwable var24) {
               var6 = var24;
               throw var24;
            } finally {
               AutoCloseableKt.closeFinally(var2x, var6);
            }

         }

         // $FF: synthetic method
         public Object invoke(Object var1x) {
            this.g((Connection)var1x);
            return Unit.INSTANCE;
         }
      }));
      return var4;
   }

   public int a(@NotNull final UUID var1, @NotNull final String var2) {
      Intrinsics.checkNotNullParameter(var1, "uuid");
      Intrinsics.checkNotNullParameter(var2, "stats");
      if (this.a(var1)) {
         ga.strikepractice.b.b.a var10000 = this.dh.O;
         Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
         return ((Number)c.a(var10000, (Function1)(new Function1<Connection, Integer>() {
            @NotNull
            public final Integer e(@NotNull Connection var1x) {
               Intrinsics.checkNotNullParameter(var1x, "conn");
               AutoCloseable var2x = (AutoCloseable)var1x.prepareStatement("SELECT * FROM stats WHERE uuid= ?");
               UUID var3 = var1;
               String var4 = var2;
               Throwable var5 = null;

               Integer var24;
               try {
                  PreparedStatement var6 = (PreparedStatement)var2x;
                  boolean var7 = false;
                  var6.setString(1, var3.toString());
                  AutoCloseable var8 = (AutoCloseable)var6.executeQuery();
                  Throwable var9 = null;

                  int var25;
                  try {
                     ResultSet var10 = (ResultSet)var8;
                     boolean var11 = false;
                     var25 = var10.next() ? var10.getInt(var4) : (StringsKt.startsWith$default(var4, "elo_", false, 2, (Object)null) ? ga.strikepractice.b.a.cM : 0);
                  } catch (Throwable var20) {
                     var9 = var20;
                     throw var20;
                  } finally {
                     AutoCloseableKt.closeFinally(var8, var9);
                  }

                  var24 = var25;
               } catch (Throwable var22) {
                  var5 = var22;
                  throw var22;
               } finally {
                  AutoCloseableKt.closeFinally(var2x, var5);
               }

               return var24;
            }

            // $FF: synthetic method
            public Object invoke(Object var1x) {
               return this.e((Connection)var1x);
            }
         }))).intValue();
      } else {
         return StringsKt.startsWith$default(var2, "elo_", false, 2, (Object)null) ? ga.strikepractice.b.a.cM : 0;
      }
   }

   public void b(@NotNull final PlayerStats var1) {
      Intrinsics.checkNotNullParameter(var1, "stats");
      ga.strikepractice.b.b.a var10000 = this.dh.O;
      Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
      c.a(var10000, (Function1)(new Function1<Connection, Unit>() {
         public final void i(@NotNull Connection var1x) {
            Intrinsics.checkNotNullParameter(var1x, "conn");
            AutoCloseable var2 = (AutoCloseable)var1x.prepareStatement("SELECT * FROM stats WHERE uuid = ?");
            PlayerStats var3 = var1;
            b var4 = b.this;
            Throwable var5 = null;

            try {
               PreparedStatement var6 = (PreparedStatement)var2;
               boolean var7 = false;
               var6.setString(1, var3.getUUID().toString());
               AutoCloseable var8 = (AutoCloseable)var6.executeQuery();
               Throwable var9 = null;

               try {
                  ResultSet var10 = (ResultSet)var8;
                  boolean var11 = false;
                  if (var10.next()) {
                     var3.setBracketsWins(var10.getInt("brackets"));
                     var3.setDeaths(var10.getInt("deaths"));
                     var3.setKills(var10.getInt("kills"));
                     var3.setLmsWins(var10.getInt("lms"));
                     var3.setPartyVsPartyWins(var10.getInt("party_vs_party_wins"));
                     HashMap var12 = new HashMap(var4.dh.kits.size());
                     Iterator var13 = var4.dh.kits.iterator();

                     while(true) {
                        if (!var13.hasNext()) {
                           var3.setPlayerElos((Map)var12);
                           break;
                        }

                        BattleKit var14 = (BattleKit)var13.next();
                        if (var14.isElo()) {
                           String var15 = Stats.eloColumn(var14);
                           int var16 = var10.getInt(var15);
                           if (var16 == 0) {
                              var16 = ga.strikepractice.b.a.cM;
                           }

                           Integer var17 = var16;
                           Map var10000 = (Map)var12;
                           Intrinsics.checkNotNullExpressionValue(var15, "s");
                           var10000.put(var15, var17);
                        }
                     }
                  }

                  Unit var31 = Unit.INSTANCE;
               } catch (Throwable var26) {
                  var9 = var26;
                  throw var26;
               } finally {
                  AutoCloseableKt.closeFinally(var8, var9);
               }

               Unit var30 = Unit.INSTANCE;
            } catch (Throwable var28) {
               var5 = var28;
               throw var28;
            } finally {
               AutoCloseableKt.closeFinally(var2, var5);
            }

         }

         // $FF: synthetic method
         public Object invoke(Object var1x) {
            this.i((Connection)var1x);
            return Unit.INSTANCE;
         }
      }));
   }

   public void a(@NotNull final UUID var1, @NotNull final String var2, final int var3) {
      Intrinsics.checkNotNullParameter(var1, "uuid");
      Intrinsics.checkNotNullParameter(var2, "stats");
      this.b(var1);
      ga.strikepractice.b.b.a var10000 = this.dh.O;
      Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
      c.a(var10000, (Function1)(new Function1<Connection, Integer>() {
         @NotNull
         public final Integer h(@NotNull Connection var1x) {
            Intrinsics.checkNotNullParameter(var1x, "conn");
            AutoCloseable var2x = (AutoCloseable)var1x.prepareStatement("UPDATE stats SET " + var2 + " = ? WHERE uuid = ?");
            int var3x = var3;
            UUID var4 = var1;
            Throwable var5 = null;

            Integer var12;
            try {
               PreparedStatement var6 = (PreparedStatement)var2x;
               boolean var7 = false;
               var6.setInt(1, var3x);
               var6.setString(2, var4.toString());
               var12 = var6.executeUpdate();
            } catch (Throwable var10) {
               var5 = var10;
               throw var10;
            } finally {
               AutoCloseableKt.closeFinally(var2x, var5);
            }

            return var12;
         }

         // $FF: synthetic method
         public Object invoke(Object var1x) {
            return this.h((Connection)var1x);
         }
      }));
   }

   public void a(@NotNull final PlayerStats var1) {
      Intrinsics.checkNotNullParameter(var1, "stats");
      final UUID var2 = var1.getUUID();
      ga.strikepractice.b.b.a var10000 = this.dh.O;
      Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
      c.a(var10000, (Function1)(new Function1<Connection, Integer>() {
         @NotNull
         public final Integer k(@NotNull Connection var1x) {
            Intrinsics.checkNotNullParameter(var1x, "conn");
            AutoCloseable var2x = (AutoCloseable)var1x.prepareStatement("UPDATE stats SET " + b.this.dk + " WHERE uuid = ?");
            PlayerStats var3 = var1;
            b var4 = b.this;
            UUID var5 = var2;
            Throwable var6 = null;

            Integer var16;
            try {
               PreparedStatement var7 = (PreparedStatement)var2x;
               boolean var8 = false;
               byte var9 = 1;
               int var17 = var9 + 1;
               var7.setInt(var9, var3.getKills());
               var7.setInt(var17++, var3.getDeaths());
               var7.setInt(var17++, var3.getLMSWins());
               var7.setInt(var17++, var3.getBracketsWins());
               var7.setInt(var17++, var3.getPartyVsPartyWins());
               var7.setInt(var17++, var3.getGlobalElo());
               var7.setInt(var17++, var3.getSumoWins());
               var7.setInt(var17++, var3.getJuggernautWins());
               Iterator var10 = var4.dh.kits.iterator();

               while(var10.hasNext()) {
                  BattleKit var11 = (BattleKit)var10.next();
                  if (var11.isElo()) {
                     var7.setInt(var17++, var3.getElo(var11));
                  }
               }

               var7.setString(var17, var5.toString());
               var16 = var7.executeUpdate();
            } catch (Throwable var14) {
               var6 = var14;
               throw var14;
            } finally {
               AutoCloseableKt.closeFinally(var2x, var6);
            }

            return var16;
         }

         // $FF: synthetic method
         public Object invoke(Object var1x) {
            return this.k((Connection)var1x);
         }
      }));
   }

   public void k(@NotNull final Player var1) {
      Intrinsics.checkNotNullParameter(var1, "player");
      final UUID var2 = var1.getUniqueId();
      Intrinsics.checkNotNullExpressionValue(var2, "uuid");
      this.b(var2);
      ga.strikepractice.b.b.a var10000 = this.dh.O;
      Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
      c.a(var10000, (Function1)(new Function1<Connection, Integer>() {
         @NotNull
         public final Integer j(@NotNull Connection var1x) {
            Intrinsics.checkNotNullParameter(var1x, "conn");
            AutoCloseable var2x = (AutoCloseable)var1x.prepareStatement("UPDATE stats SET username = ? WHERE uuid = ?");
            Player var3 = var1;
            UUID var4 = var2;
            Throwable var5 = null;

            Integer var12;
            try {
               PreparedStatement var6 = (PreparedStatement)var2x;
               boolean var7 = false;
               var6.setString(1, var3.getName());
               var6.setString(2, var4.toString());
               var12 = var6.executeUpdate();
            } catch (Throwable var10) {
               var5 = var10;
               throw var10;
            } finally {
               AutoCloseableKt.closeFinally(var2x, var5);
            }

            return var12;
         }

         // $FF: synthetic method
         public Object invoke(Object var1x) {
            return this.j((Connection)var1x);
         }
      }));
   }

   public int b(@NotNull UUID var1, @Nullable BattleKit var2) {
      Intrinsics.checkNotNullParameter(var1, "uuid");
      return this.a(var1, var2, false);
   }

   public int a(@NotNull UUID var1, @Nullable BattleKit var2) {
      Intrinsics.checkNotNullParameter(var1, "uuid");
      return this.a(var1, var2, true);
   }

   public int c(@NotNull final UUID var1, @Nullable final BattleKit var2) {
      Intrinsics.checkNotNullParameter(var1, "uuid");
      final Ref.IntRef var3 = new Ref.IntRef();
      long var4 = System.currentTimeMillis();
      boolean var14 = false;

      B.a var6;
      boolean var7;
      boolean var8;
      Logger var10;
      StringBuilder var11;
      String var12;
      Logger var10000;
      try {
         var14 = true;
         var6 = B.vj;
         var7 = false;
         if (var6.fV()) {
            var10000 = Bukkit.getLogger();
            var11 = (new StringBuilder()).append("[SP DEBUG] ");
            var10 = var10000;
            var8 = false;
            var12 = "Starting countWinStreak for " + var1 + " with kit=" + (var2 != null ? var2.getName() : null);
            var10.info(var11.append(var12).toString());
         }

         ga.strikepractice.b.b.a var17 = this.dh.O;
         Intrinsics.checkNotNullExpressionValue(var17, "plugin.mySQL");
         c.a(var17, (Function1)(new Function1<Connection, Unit>() {
            public final void b(@NotNull Connection var1x) {
               Intrinsics.checkNotNullParameter(var1x, "conn");
               AutoCloseable var2x = (AutoCloseable)var1x.prepareStatement(StringsKt.trimIndent("\n                SELECT is_winner FROM fight_players fp\n                JOIN fights f ON f.started = fp.fight\n                WHERE uuid = ? \n                " + (var2 != null ? "AND kit = ?" : "") + "\n                ORDER BY f.started DESC LIMIT 200\n            "));
               UUID var3x = var1;
               BattleKit var4 = var2;
               Ref.IntRef var5 = var3;
               Throwable var6 = null;

               try {
                  PreparedStatement var7 = (PreparedStatement)var2x;
                  boolean var8 = false;
                  var7.setString(1, var3x.toString());
                  if (var4 != null) {
                     boolean var10 = false;
                     var7.setString(2, var4.getName());
                  }

                  AutoCloseable var11 = (AutoCloseable)var7.executeQuery();
                  Throwable var9 = null;

                  try {
                     ResultSet var27 = (ResultSet)var11;

                     int var13;
                     for(boolean var12 = false; var27.next() && var27.getBoolean("is_winner"); var13 = var5.element++) {
                     }

                     Unit var28 = Unit.INSTANCE;
                  } catch (Throwable var22) {
                     var9 = var22;
                     throw var22;
                  } finally {
                     AutoCloseableKt.closeFinally(var11, var9);
                  }

                  Unit var26 = Unit.INSTANCE;
               } catch (Throwable var24) {
                  var6 = var24;
                  throw var24;
               } finally {
                  AutoCloseableKt.closeFinally(var2x, var6);
               }

            }

            // $FF: synthetic method
            public Object invoke(Object var1x) {
               this.b((Connection)var1x);
               return Unit.INSTANCE;
            }
         }));
         var14 = false;
      } finally {
         if (var14) {
            B.a var16 = B.vj;
            var8 = false;
            if (var16.fV()) {
               var10000 = Bukkit.getLogger();
               var11 = (new StringBuilder()).append("[SP DEBUG] ");
               var10 = var10000;
               boolean var9 = false;
               var12 = "countWinStreak took " + (System.currentTimeMillis() - var4) + "ms";
               var10.info(var11.append(var12).toString());
            }

            if (System.currentTimeMillis() - var4 > 2000L) {
               Bukkit.getLogger().warning("[StrikePractice] Counting win streak took " + (System.currentTimeMillis() - var4) + " ms. Your database may be slow.");
            }

         }
      }

      var6 = B.vj;
      var7 = false;
      if (var6.fV()) {
         var10000 = Bukkit.getLogger();
         var11 = (new StringBuilder()).append("[SP DEBUG] ");
         var10 = var10000;
         var8 = false;
         var12 = "countWinStreak took " + (System.currentTimeMillis() - var4) + "ms";
         var10.info(var11.append(var12).toString());
      }

      if (System.currentTimeMillis() - var4 > 2000L) {
         Bukkit.getLogger().warning("[StrikePractice] Counting win streak took " + (System.currentTimeMillis() - var4) + " ms. Your database may be slow.");
      }

      return var3.element;
   }

   private final int a(final UUID var1, final BattleKit var2, final boolean var3) {
      long var4 = System.currentTimeMillis();

      boolean var8;
      Logger var10;
      StringBuilder var11;
      String var12;
      int var15;
      Logger var10000;
      try {
         B.a var6 = B.vj;
         boolean var7 = false;
         if (var6.fV()) {
            var10000 = Bukkit.getLogger();
            var11 = (new StringBuilder()).append("[SP DEBUG] ");
            var10 = var10000;
            var8 = false;
            var12 = "counting fights for " + var1 + " kit=" + (var2 != null ? var2.getName() : null) + " wins=" + var3;
            var10.info(var11.append(var12).toString());
         }

         ga.strikepractice.b.b.a var17 = this.dh.O;
         Intrinsics.checkNotNullExpressionValue(var17, "plugin.mySQL");
         var15 = ((Number)c.a(var17, (Function1)(new Function1<Connection, Integer>() {
            @NotNull
            public final Integer a(@NotNull Connection var1x) {
               Intrinsics.checkNotNullParameter(var1x, "conn");
               AutoCloseable var2x;
               int var10000;
               if (var2 != null) {
                  var2x = (AutoCloseable)var1x.prepareStatement("SELECT COUNT(*) FROM fight_players fp JOIN fights f ON f.started=fp.fight WHERE kit=? AND is_winner=? AND uuid=? ");
                  BattleKit var3x = var2;
                  boolean var4 = var3;
                  UUID var5 = var1;
                  Throwable var6 = null;

                  int var58;
                  try {
                     PreparedStatement var7 = (PreparedStatement)var2x;
                     boolean var8 = false;
                     var7.setString(1, var3x.getName());
                     var7.setBoolean(2, var4);
                     var7.setString(3, var5.toString());
                     AutoCloseable var9 = (AutoCloseable)var7.executeQuery();
                     Throwable var10 = null;

                     int var64;
                     try {
                        ResultSet var11 = (ResultSet)var9;
                        boolean var12 = false;
                        var64 = var11.next() ? var11.getInt(1) : 0;
                     } catch (Throwable var45) {
                        var10 = var45;
                        throw var45;
                     } finally {
                        AutoCloseableKt.closeFinally(var9, var10);
                     }

                     var58 = var64;
                  } catch (Throwable var47) {
                     var6 = var47;
                     throw var47;
                  } finally {
                     AutoCloseableKt.closeFinally(var2x, var6);
                  }

                  var10000 = var58;
               } else {
                  var2x = (AutoCloseable)var1x.prepareStatement("SELECT COUNT(*) FROM fight_players WHERE is_winner=? AND uuid=?");
                  boolean var53 = var3;
                  UUID var54 = var1;
                  Throwable var55 = null;

                  int var57;
                  try {
                     PreparedStatement var56 = (PreparedStatement)var2x;
                     boolean var59 = false;
                     var56.setBoolean(1, var53);
                     var56.setString(2, var54.toString());
                     AutoCloseable var60 = (AutoCloseable)var56.executeQuery();
                     Throwable var61 = null;

                     int var63;
                     try {
                        ResultSet var62 = (ResultSet)var60;
                        boolean var65 = false;
                        var63 = var62.next() ? var62.getInt(1) : 0;
                     } catch (Throwable var49) {
                        var61 = var49;
                        throw var49;
                     } finally {
                        AutoCloseableKt.closeFinally(var60, var61);
                     }

                     var57 = var63;
                  } catch (Throwable var51) {
                     var55 = var51;
                     throw var51;
                  } finally {
                     AutoCloseableKt.closeFinally(var2x, var55);
                  }

                  var10000 = var57;
               }

               return var10000;
            }

            // $FF: synthetic method
            public Object invoke(Object var1x) {
               return this.a((Connection)var1x);
            }
         }))).intValue();
      } finally {
         B.a var16 = B.vj;
         var8 = false;
         if (var16.fV()) {
            var10000 = Bukkit.getLogger();
            var11 = (new StringBuilder()).append("[SP DEBUG] ");
            var10 = var10000;
            boolean var9 = false;
            var12 = "counting fights took " + (System.currentTimeMillis() - var4) + "ms";
            var10.info(var11.append(var12).toString());
         }

         if (System.currentTimeMillis() - var4 > 2000L) {
            Bukkit.getLogger().warning("[StrikePractice] Counting some stats based on fights took " + (System.currentTimeMillis() - var4) + " ms. Your database may be slow.");
         }

      }

      return var15;
   }

   private final boolean a(final UUID var1) {
      boolean var2;
      try {
         ga.strikepractice.b.b.a var10000 = this.dh.O;
         Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
         var2 = (Boolean)c.a(var10000, (Function1)(new Function1<Connection, Boolean>() {
            @NotNull
            public final Boolean d(@NotNull Connection var1x) {
               Intrinsics.checkNotNullParameter(var1x, "conn");
               AutoCloseable var2 = (AutoCloseable)var1x.prepareStatement("SELECT * FROM stats WHERE uuid=?");
               UUID var3 = var1;
               Throwable var4 = null;

               Boolean var23;
               try {
                  PreparedStatement var5 = (PreparedStatement)var2;
                  boolean var6 = false;
                  var5.setString(1, var3.toString());
                  AutoCloseable var7 = (AutoCloseable)var5.executeQuery();
                  Throwable var8 = null;

                  boolean var24;
                  try {
                     ResultSet var9 = (ResultSet)var7;
                     boolean var10 = false;
                     var24 = var9.next();
                  } catch (Throwable var19) {
                     var8 = var19;
                     throw var19;
                  } finally {
                     AutoCloseableKt.closeFinally(var7, var8);
                  }

                  var23 = var24;
               } catch (Throwable var21) {
                  var4 = var21;
                  throw var21;
               } finally {
                  AutoCloseableKt.closeFinally(var2, var4);
               }

               return var23;
            }

            // $FF: synthetic method
            public Object invoke(Object var1x) {
               return this.d((Connection)var1x);
            }
         }));
      } catch (SQLException var4) {
         var4.printStackTrace();
         var2 = false;
      }

      return var2;
   }

   private final boolean b(final UUID var1) {
      if (!this.a(var1)) {
         final String var2 = Bukkit.getPlayer(var1) != null ? Bukkit.getPlayer(var1).getName() : Bukkit.getOfflinePlayer(var1).getName();
         ga.strikepractice.b.b.a var10000 = this.dh.O;
         Intrinsics.checkNotNullExpressionValue(var10000, "plugin.mySQL");
         c.a(var10000, (Function1)(new Function1<Connection, Integer>() {
            @NotNull
            public final Integer c(@NotNull Connection var1x) {
               Intrinsics.checkNotNullParameter(var1x, "conn");
               AutoCloseable var2x = (AutoCloseable)var1x.prepareStatement(StringsKt.trimIndent("\n                INSERT INTO stats \n                (uuid, username, kills, deaths, lms, brackets, \n                party_vs_party_wins, " + b.this.di + ")\n                VALUES (?, ?, '0', '0', '0', '0', '0', " + b.this.dj + ")\n                "));
               UUID var3 = var1;
               String var4 = var2;
               Throwable var5 = null;

               Integer var12;
               try {
                  PreparedStatement var6 = (PreparedStatement)var2x;
                  boolean var7 = false;
                  var6.setString(1, var3.toString());
                  String var10002 = var4;
                  if (var4 == null) {
                     var10002 = "unknown";
                  }

                  var6.setString(2, var10002);
                  var12 = var6.executeUpdate();
               } catch (Throwable var10) {
                  var5 = var10;
                  throw var10;
               } finally {
                  AutoCloseableKt.closeFinally(var2x, var5);
               }

               return var12;
            }

            // $FF: synthetic method
            public Object invoke(Object var1x) {
               return this.c((Connection)var1x);
            }
         }));
         return true;
      } else {
         return false;
      }
   }
}
