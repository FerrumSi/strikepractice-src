package ga.strikepractice.b.b.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jdk7.AutoCloseableKt;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.sql.Connection;
import java.sql.PreparedStatement;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0016\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b¨\u0006\t"},
   d2 = {"Lga/strikepractice/data/sql/migration/FightPlayersMigration_v3_3_1;", "", "()V", "perform", "", "plugin", "Lga/strikepractice/StrikePractice;", "conn", "Ljava/sql/Connection;", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nFightPlayersMigration_v3_3_1.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FightPlayersMigration_v3_3_1.kt\nga/strikepractice/data/sql/migration/FightPlayersMigration_v3_3_1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,32:1\n1#2:33\n*E\n"})
public final class a {
   public final void a(@NotNull StrikePractice var1, @NotNull Connection var2) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      Intrinsics.checkNotNullParameter(var2, "conn");
      String var3 = "database-migration.fight-players-v3_3_1";
      YamlConfiguration var10000 = var1.Z().u();
      Intrinsics.checkNotNull(var10000);
      if (!var10000.getBoolean(var3)) {
         Bukkit.getLogger().warning("Migrating SQL database (" + var3 + ").");
         var10000 = var1.Z().u();
         Intrinsics.checkNotNull(var10000);
         var10000.set(var3, true);
         var1.Z().L();
      }

      String[] var5 = new String[]{"ALTER IGNORE TABLE fight_players ADD UNIQUE INDEX uniq_players (uuid, fight);"};
      String[] var4 = var5;
      int var18 = 0;

      for(int var6 = var5.length; var18 < var6; ++var18) {
         String var7 = var4[var18];

         try {
            AutoCloseable var8 = (AutoCloseable)var2.prepareStatement(var7);
            Throwable var9 = null;

            try {
               PreparedStatement var10 = (PreparedStatement)var8;
               boolean var11 = false;
               boolean var19 = var10.execute();
            } catch (Throwable var15) {
               var9 = var15;
               throw var15;
            } finally {
               AutoCloseableKt.closeFinally(var8, var9);
            }
         } catch (Exception var17) {
         }
      }

   }
}
