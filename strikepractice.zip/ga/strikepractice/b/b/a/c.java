package ga.strikepractice.b.b.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.TuplesKt;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.collections.MapsKt;
import ga.strikepractice.kotlin.jdk7.AutoCloseableKt;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b¨\u0006\t"},
   d2 = {"Lga/strikepractice/data/sql/migration/FightsReplaceMigration_v3_3_2;", "", "()V", "perform", "", "plugin", "Lga/strikepractice/StrikePractice;", "conn", "Ljava/sql/Connection;", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nFightsReplaceMigration_v3_3_2.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FightsReplaceMigration_v3_3_2.kt\nga/strikepractice/data/sql/migration/FightsReplaceMigration_v3_3_2\n+ 2 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,82:1\n76#2:83\n96#2,5:84\n1864#3,2:89\n1866#3:92\n1#4:91\n*S KotlinDebug\n*F\n+ 1 FightsReplaceMigration_v3_3_2.kt\nga/strikepractice/data/sql/migration/FightsReplaceMigration_v3_3_2\n*L\n58#1:83\n58#1:84,5\n66#1:89,2\n66#1:92\n*E\n"})
public final class c {
   public final void b(@NotNull StrikePractice var1, @Nullable Connection var2) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      if (var1.getConfig().getBoolean("legacy-fight-format")) {
         Bukkit.getLogger().warning("legacy-fight-format is enabled. Not migrating the fights database table. Some new placeholders may not work.");
      } else {
         String var3 = "database-migration.fights-obfuscation-replace-v3_3_2";
         if (var1.getDescription().getVersion().compareTo("3.4.0") < 0) {
            Bukkit.getLogger().info("Migration " + var3 + " not yet scheduled for this version, will happen in newer version.");
         } else {
            YamlConfiguration var10000 = var1.Z().u();
            Intrinsics.checkNotNull(var10000);
            if (!var10000.getBoolean(var3)) {
               Bukkit.getLogger().info("Starting SQL migration " + var3 + ". This may take a while...");
               long var4 = System.currentTimeMillis();
               Pair[] var7 = new Pair[]{TuplesKt.to("hk", "DUEL"), TuplesKt.to("hl", "DUEL_QUEUE"), TuplesKt.to("hm", "DUEL_QUEUE_RANKED"), TuplesKt.to("hn", "DUEL_QUEUE_PREMIUM"), TuplesKt.to("hg", "uuid"), TuplesKt.to("aH", "arena"), TuplesKt.to("cK", "kit"), TuplesKt.to("dw", "ended"), TuplesKt.to("q", "started"), TuplesKt.to("dp", "fightInventory"), TuplesKt.to("hI", "oldElo"), TuplesKt.to("hJ", "newELo"), TuplesKt.to("dg", "mainInv"), TuplesKt.to("dh", "potions"), TuplesKt.to("di", "food"), TuplesKt.to("bI", "helmet"), TuplesKt.to("bJ", "chestplate"), TuplesKt.to("bK", "leggings"), TuplesKt.to("bL", "boots"), TuplesKt.to("dj", "health"), TuplesKt.to("bG", "inv"), TuplesKt.to("bF", "bestOf"), TuplesKt.to("ba", "icon")};
               Map var6 = MapsKt.mapOf(var7);
               boolean var9 = false;
               Collection var11 = (Collection)(new ArrayList());
               boolean var12 = false;
               Iterator var13 = var6.entrySet().iterator();

               boolean var16;
               while(var13.hasNext()) {
                  Entry var14 = (Entry)var13.next();
                  var16 = false;
                  String[] var17 = new String[]{"UPDATE fights SET fight_data=REPLACE(fight_data, '\"" + (String)var14.getKey() + "\"', '\"" + (String)var14.getValue() + "\"')", "UPDATE fights SET mode=REPLACE(mode, '" + (String)var14.getKey() + "', '" + (String)var14.getValue() + "')", "UPDATE fight_players SET player_data=REPLACE(player_data, '\"" + (String)var14.getKey() + "\"', '\"" + (String)var14.getValue() + "\"')"};
                  Iterable var15 = (Iterable)CollectionsKt.listOf(var17);
                  CollectionsKt.addAll(var11, var15);
               }

               List var27 = (List)var11;
               Iterable var8 = (Iterable)var27;
               var9 = false;
               int var10 = 0;
               Iterator var28 = var8.iterator();

               while(var28.hasNext()) {
                  Object var29 = var28.next();
                  int var30 = var10++;
                  if (var30 < 0) {
                     CollectionsKt.throwIndexOverflow();
                  }

                  String var31 = (String)var29;
                  var16 = false;
                  Bukkit.getLogger().info("Migration progress " + (var30 + 1) + '/' + var27.size());

                  try {
                     Intrinsics.checkNotNull(var2);
                     AutoCloseable var33 = (AutoCloseable)var2.prepareStatement(var31);
                     Throwable var18 = null;

                     try {
                        PreparedStatement var19 = (PreparedStatement)var33;
                        boolean var20 = false;
                        boolean var34 = var19.execute();
                     } catch (Throwable var24) {
                        var18 = var24;
                        throw var24;
                     } finally {
                        AutoCloseableKt.closeFinally(var33, var18);
                     }
                  } catch (Exception var26) {
                     Bukkit.getLogger().warning("Failed to run migration query (" + var30 + "): " + var31);
                     var26.printStackTrace();
                  }
               }

               var10000 = var1.Z().u();
               Intrinsics.checkNotNull(var10000);
               var10000.set(var3, true);
               var1.Z().L();
               var1.saveConfig();
               Bukkit.getLogger().info("\nMigration finished in " + (System.currentTimeMillis() - var4) + " milliseconds.\n");
            }

         }
      }
   }
}
