package ga.strikepractice.b.b.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.sql.Connection;
import java.sql.PreparedStatement;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b¨\u0006\t"},
   d2 = {"Lga/strikepractice/data/sql/migration/ReplayDataMigration_v3_6_4;", "", "()V", "perform", "", "plugin", "Lga/strikepractice/StrikePractice;", "conn", "Ljava/sql/Connection;", "strikepractice-core"}
)
public final class d {
   public final void c(@NotNull StrikePractice var1, @Nullable Connection var2) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      String var3 = "database-migration.replay-data-column-length-v3_6_4";
      YamlConfiguration var10000 = var1.Z().u();
      Intrinsics.checkNotNull(var10000);
      if (!var10000.getBoolean(var3)) {
         Bukkit.getLogger().info("Starting SQL migration " + var3 + "...");
         String var4 = "ALTER TABLE replays MODIFY replay_data MEDIUMTEXT NOT NULL";
         if (var2 != null) {
            PreparedStatement var5 = var2.prepareStatement(var4);
            if (var5 != null) {
               var5.executeUpdate();
            }
         }

         Bukkit.getLogger().info("Finished SQL migration " + var3 + '.');
      }

   }
}
