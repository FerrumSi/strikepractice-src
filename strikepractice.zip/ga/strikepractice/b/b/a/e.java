package ga.strikepractice.b.b.a;

import ga.strikepractice.StrikePractice;
import java.sql.Connection;
import java.sql.PreparedStatement;
import org.bukkit.Bukkit;

public class e {
   public void a(StrikePractice var1, Connection var2) {
      String var3 = "database-migration.stats-v3_8_1";
      if (this.l(var2)) {
         Bukkit.getLogger().warning("Migrating SQL database (" + var3 + ").");
         Bukkit.getLogger().warning("Be sure you have the latest web-addon or otherwise it may break.");
         String[] var4 = new String[]{"ALTER TABLE stats ADD sumo_wins int NOT NULL DEFAULT 0 AFTER brackets", "ALTER TABLE stats ADD juggernaut int NOT NULL DEFAULT 0 AFTER sumo_wins", "ALTER TABLE stats DROP PRIMARY KEY", "ALTER TABLE stats ADD ID INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (ID)", "CREATE UNIQUE INDEX uuid_index ON stats (uuid)", "ALTER TABLE fight_players ADD `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY;"};
         String[] var5 = var4;
         int var6 = var4.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            String var8 = var5[var7];

            try {
               PreparedStatement var9 = var2.prepareStatement(var8);

               try {
                  var9.execute();
               } catch (Throwable var13) {
                  if (var9 != null) {
                     try {
                        var9.close();
                     } catch (Throwable var12) {
                        var13.addSuppressed(var12);
                     }
                  }

                  throw var13;
               }

               if (var9 != null) {
                  var9.close();
               }
            } catch (Exception var14) {
               var14.printStackTrace();
            }
         }

         Bukkit.getLogger().warning("Finished migrating SQL database (" + var3 + ").");
      }

   }

   private boolean l(Connection var1) {
      String var2 = "SHOW COLUMNS FROM stats LIKE 'sumo_wins'";

      try {
         PreparedStatement var3 = var1.prepareStatement("SHOW COLUMNS FROM stats LIKE 'sumo_wins'");

         boolean var4;
         try {
            var4 = !var3.executeQuery().next();
         } catch (Throwable var7) {
            if (var3 != null) {
               try {
                  var3.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (var3 != null) {
            var3.close();
         }

         return var4;
      } catch (Exception var8) {
         Bukkit.getLogger().warning("Failed to check if migration is needed.");
         var8.printStackTrace();
         return false;
      }
   }
}
