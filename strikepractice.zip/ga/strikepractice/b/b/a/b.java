package ga.strikepractice.b.b.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.C;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;

public final class b {
   public void a(StrikePractice var1, Connection var2) {
      if (var1.getConfig().getBoolean("legacy-fight-format")) {
         Bukkit.getLogger().warning("legacy-fight-format is enabled. Not migrating the fights database table. Some new placeholders may not work.");

         try {
            if (var2 != null && !var2.isClosed() && (var1.getConfig().getBoolean("save-elo-fights") || var1.getConfig().getBoolean("save-all-fights"))) {
               ResultSet var16 = var2.getMetaData().getTables((String)null, (String)null, "fights", new String[]{"TABLE"});
               if (!var16.next()) {
                  String var17 = "SQL database tables don't seem to exist (or are old/broken). You may need to set 'legacy-fight-format: false' to create them correctly.";
                  Bukkit.getLogger().warning("--------------");
                  Bukkit.getLogger().warning("");
                  Bukkit.getLogger().warning(var17);
                  Bukkit.getLogger().warning("");
                  Bukkit.getLogger().warning("--------------");
                  ga.strikepractice.r.c.eQ().put(var17, ga.strikepractice.r.c.b.tW);
               }
            }
         } catch (Exception var13) {
            Bukkit.getLogger().warning("You can (probably) ignore this error:");
            var13.printStackTrace();
         }

      } else {
         String var3 = "database-migration.fights-v3_3_0";
         if (!var1.Z().u().getBoolean(var3)) {
            boolean var4 = false;

            try {
               var4 = var2.getMetaData().getColumns((String)null, (String)null, "fights", "hits").next();
            } catch (Exception var10) {
               var10.printStackTrace();
            }

            if (!var4) {
               Bukkit.getLogger().info("New fights table detected. No need to migrate...");
               var1.getConfig().set("legacy-fight-format", false);
               var1.saveConfig();
               Bukkit.getLogger().info("Automatically disabled legacy-fight-format");
            } else {
               Bukkit.getLogger().warning("Migrating SQL database (" + var3 + "). This may take a while...");
               Bukkit.getLogger().warning("Be sure you have the latest web-addon or otherwise it will break.");
               Bukkit.getLogger().info("Copying 'fights' table to 'fights_old' as a backup.");

               PreparedStatement var5;
               try {
                  var5 = var2.prepareStatement("CREATE TABLE fights_old AS SELECT * FROM fights");

                  try {
                     var5.execute();
                  } catch (Throwable var11) {
                     if (var5 != null) {
                        try {
                           var5.close();
                        } catch (Throwable var8) {
                           var11.addSuppressed(var8);
                        }
                     }

                     throw var11;
                  }

                  if (var5 != null) {
                     var5.close();
                  }
               } catch (Exception var15) {
                  Bukkit.getLogger().warning("Backup failed. Aborting. ");
                  var15.printStackTrace();
                  Bukkit.getPluginManager().disablePlugin(var1);
                  return;
               }

               Bukkit.getLogger().warning("Dropping current fights table");

               try {
                  var5 = var2.prepareStatement("DROP TABLE fights");

                  try {
                     var5.execute();
                  } catch (Throwable var12) {
                     if (var5 != null) {
                        try {
                           var5.close();
                        } catch (Throwable var9) {
                           var12.addSuppressed(var9);
                        }
                     }

                     throw var12;
                  }

                  if (var5 != null) {
                     var5.close();
                  }
               } catch (Exception var14) {
                  var14.printStackTrace();
                  Bukkit.getLogger().warning("Something went wrong");
                  return;
               }

               Bukkit.getLogger().warning("Table dropped! Creating a new one");
               var1.O.aM();
               C.c(() -> {
                  Bukkit.getLogger().info("Converting old fights asynchronously. OK to join now.");
                  List var1 = this.aO();
                  Bukkit.getLogger().info("Found " + var1.size() + " matches in fights_old. Converting...");
                  int var2 = 0;
                  Iterator var3 = var1.iterator();

                  while(var3.hasNext()) {
                     String[] var4 = (String[])var3.next();

                     try {
                        ga.strikepractice.fights.savedfights.b var5 = ga.strikepractice.fights.savedfights.b.a(var4, UUID.fromString(var4[16]));
                        var5.bP().saveToDatabase();
                        ++var2;
                        if (var2 % 50 == 0) {
                           Bukkit.getLogger().info("Converting fights progress: " + var2 + "/" + var1.size());
                        }
                     } catch (Exception var6) {
                        Bukkit.getLogger().warning("Failed to migrate fight: " + var4[16]);
                        var6.printStackTrace();
                     }
                  }

                  Bukkit.getLogger().info("Migration completed! Hopefully successfully! (May still be saving, please wait a few minutes)");
               });
               var1.Z().u().set(var3, true);
               var1.Z().L();
               var1.saveConfig();
               Bukkit.getLogger().info("Automatically disabled legacy-fight-format.");
            }
         }

      }
   }

   private List<String[]> aO() {
      ArrayList var1 = new ArrayList();

      try {
         Connection var2 = StrikePractice.getInstance().O.aN();

         try {
            PreparedStatement var3 = var2.prepareStatement("SELECT * FROM fights_old");

            try {
               ResultSet var4 = var3.executeQuery();

               while(var4.next()) {
                  String[] var5 = new String[]{var4.getString("winners"), var4.getString("losers"), var4.getString("kit_info"), var4.getString("arena"), var4.getString("started"), var4.getString("ended"), var4.getString("winners_old_elos"), var4.getString("losers_old_elos"), var4.getString("winners_new_elos"), var4.getString("losers_new_elos"), var4.getString("inventories"), var4.getString("hits"), var4.getString("longest_combo"), var4.getString("potions_thrown"), var4.getString("potions_missed"), var4.getString("potion_accuracy"), var4.getString("playback")};
                  var1.add(var5);
               }

               var4.close();
            } catch (Throwable var8) {
               if (var3 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (var3 != null) {
               var3.close();
            }
         } catch (Throwable var9) {
            if (var2 != null) {
               try {
                  var2.close();
               } catch (Throwable var6) {
                  var9.addSuppressed(var6);
               }
            }

            throw var9;
         }

         if (var2 != null) {
            var2.close();
         }
      } catch (Exception var10) {
         var10.printStackTrace();
      }

      return var1;
   }
}
