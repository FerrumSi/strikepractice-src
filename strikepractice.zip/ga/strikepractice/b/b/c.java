package ga.strikepractice.b.b;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jdk7.AutoCloseableKt;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.sql.Connection;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0016\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a)\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\u00020\u00022\u0012\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u0002H\u00010\u0004¢\u0006\u0002\u0010\u0006¨\u0006\u0007"},
   d2 = {"useConnection", "T", "Lga/strikepractice/data/sql/MySQL;", "block", "Lga/strikepractice/kotlin/Function1;", "Ljava/sql/Connection;", "(Lga/strikepractice/data/sql/MySQL;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "strikepractice-core"}
)
public final class c {
   public static final <T> T a(@NotNull ga.strikepractice.b.b.a var0, @NotNull Function1<? super Connection, ? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "block");
      AutoCloseable var2 = (AutoCloseable)var0.aN();
      Throwable var3 = null;

      Object var10;
      try {
         Connection var4 = (Connection)var2;
         boolean var5 = false;
         Intrinsics.checkNotNullExpressionValue(var4, "connection");
         var10 = var1.invoke(var4);
      } catch (Throwable var8) {
         var3 = var8;
         throw var8;
      } finally {
         AutoCloseableKt.closeFinally(var2, var3);
      }

      return var10;
   }
}
