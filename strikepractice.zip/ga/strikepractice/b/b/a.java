package ga.strikepractice.b.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.b.b.a.d;
import ga.strikepractice.b.b.a.e;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.hikari.HikariConfig;
import ga.strikepractice.hikari.HikariDataSource;
import ga.strikepractice.stats.Stats;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class a {
   private final String cW;
   private final int cX;
   private final String cY;
   private final String password;
   private final String cZ;
   public boolean da;
   public static final String db = "stats";
   public static final String dc = "fights";
   public static final String dd = "fight_players";
   public ga.strikepractice.fights.savedfights.c de;
   public boolean df;
   private HikariDataSource dg;

   public a(String var1, int var2, String var3, String var4, String var5) {
      this.cW = var1;
      this.cX = var2;
      this.cY = var3;
      this.password = var4;
      this.cZ = var5;
      this.de = new ga.strikepractice.fights.savedfights.c(StrikePractice.getInstance());
      StrikePractice var6 = StrikePractice.getInstance();
      this.df = var6.getConfig().getBoolean("save-elo-fights") || var6.getConfig().getBoolean("save-all-fights");
   }

   public void aL() {
      try {
         HikariConfig var1 = new HikariConfig();
         String var2 = StrikePractice.getInstance().getConfig().getString("database.override-connection-url");
         if (var2 == null) {
            var2 = "jdbc:mysql://" + this.cW + ":" + this.cX + "/" + this.cZ;
            if (!var2.contains("?")) {
               var2 = var2 + "?";
            }

            var2 = var2 + "&autoReconnect=true";
         } else {
            Bukkit.getLogger().warning("Using database.override-connection-url and ignoring some database.* values (host, port, db)");
         }

         var1.setJdbcUrl(var2);
         var1.setUsername(this.cY);
         var1.setPassword(this.password);
         var1.setPoolName("StrikePracticePool");
         var1.setMaximumPoolSize(10);
         var1.setMinimumIdle(2);
         var1.setIdleTimeout(300000L);
         var1.setMaxLifetime(600000L);
         var1.setConnectionTimeout(10000L);
         var1.setConnectionTestQuery("SELECT 1");
         var1.addDataSourceProperty("cachePrepStmts", "true");
         var1.addDataSourceProperty("prepStmtCacheSize", "250");
         var1.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
         var1.addDataSourceProperty("useServerPrepStmts", "true");
         this.dg = new HikariDataSource(var1);
         this.da = true;
         this.aN().close();
         Bukkit.getLogger().info("------------------------------------------");
         Bukkit.getLogger().info("Connected to the StrikePractice database");
         Bukkit.getLogger().info("------------------------------------------");
      } catch (Exception var3) {
         Bukkit.getLogger().warning("There was an error while connecting to the MySQL...");
         var3.printStackTrace();
      }

   }

   public void aM() {
      StrikePractice var1 = StrikePractice.getInstance();

      try {
         Connection var2 = this.aN();

         try {
            this.d("CREATE TABLE IF NOT EXISTS stats (uuid VARCHAR(36) NOT NULL UNIQUE PRIMARY KEY,username VARCHAR(16) NOT NULL, global_elo int NOT NULL, kills int NOT NULL, deaths int NOT NULL, lms int NOT NULL, brackets int NOT NULL, party_vs_party_wins int NOT NULL,INDEX username_index (username))");
            Iterator var3 = var1.kits.iterator();

            while(var3.hasNext()) {
               BattleKit var4 = (BattleKit)var3.next();
               if (var4.isElo()) {
                  this.d(var4);
               }
            }

            (new ga.strikepractice.b.b.a.b()).a(var1, var2);
            this.d("CREATE TABLE IF NOT EXISTS fights(id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, started  BIGINT NOT NULL UNIQUE,ended BIGINT NOT NULL UNIQUE,replay_id VARCHAR(36),arena VARCHAR(36),kit VARCHAR(36),mode VARCHAR(36),fight_data TEXT,INDEX f_started_index (started),INDEX f_ended_index (ended),INDEX f_replay_id_index (replay_id),INDEX f_mode_index (mode),INDEX f_kit_index (kit))");
            this.d("CREATE TABLE IF NOT EXISTS fight_players(uuid VARCHAR(36) NOT NULL,fight VARCHAR(16) NOT NULL,username VARCHAR(16) NOT NULL,is_winner BOOLEAN, player_data TEXT,INDEX fp_uuid_index(uuid),INDEX fp_fight_id_index(fight),INDEX fp_is_winner_index(is_winner))");
            this.d("CREATE TABLE IF NOT EXISTS replays (replay_id VARCHAR(36) PRIMARY KEY,name VARCHAR(512) NOT NULL,replay_data MEDIUMTEXT NOT NULL)");
            (new ga.strikepractice.b.b.a.a()).a(var1, var2);
            (new ga.strikepractice.b.b.a.c()).b(var1, var2);
            (new d()).c(var1, var2);
            (new e()).a(var1, var2);
         } catch (Throwable var6) {
            if (var2 != null) {
               try {
                  var2.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (var2 != null) {
            var2.close();
         }
      } catch (SQLException var7) {
         var7.printStackTrace();
      }

   }

   public void d(BattleKit var1) {
      String var2 = Stats.eloColumn(var1);

      try {
         Connection var3 = this.aN();

         try {
            PreparedStatement var4 = var3.prepareStatement("ALTER TABLE stats ADD " + var2 + " int NOT NULL DEFAULT " + ga.strikepractice.b.a.cM);

            try {
               var4.execute();
            } catch (Throwable var9) {
               if (var4 != null) {
                  try {
                     var4.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (var4 != null) {
               var4.close();
            }
         } catch (Throwable var10) {
            if (var3 != null) {
               try {
                  var3.close();
               } catch (Throwable var7) {
                  var10.addSuppressed(var7);
               }
            }

            throw var10;
         }

         if (var3 != null) {
            var3.close();
         }
      } catch (Exception var11) {
      }

   }

   public void close() {
      if (this.dg != null && !this.dg.isClosed()) {
         this.dg.close();
      }

      this.da = false;
   }

   public Connection aN() {
      try {
         return this.dg.getConnection();
      } catch (SQLException var2) {
         throw new RuntimeException(var2);
      }
   }

   public void d(String var1, Object... var2) {
      try {
         Connection var3 = this.aN();

         try {
            PreparedStatement var4 = var3.prepareStatement(var1);

            try {
               for(int var5 = 0; var5 < var2.length; ++var5) {
                  Object var6 = var2[var5];
                  if (var6 instanceof Integer) {
                     var4.setInt(var5 + 1, (Integer)var6);
                  } else if (var6 instanceof Boolean) {
                     var4.setBoolean(var5 + 1, (Boolean)var6);
                  } else {
                     var4.setString(var5 + 1, var6 == null ? null : var6.toString());
                  }
               }

               var4.execute();
            } catch (Throwable var9) {
               if (var4 != null) {
                  try {
                     var4.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (var4 != null) {
               var4.close();
            }
         } catch (Throwable var10) {
            if (var3 != null) {
               try {
                  var3.close();
               } catch (Throwable var7) {
                  var10.addSuppressed(var7);
               }
            }

            throw var10;
         }

         if (var3 != null) {
            var3.close();
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
         Bukkit.getScheduler().runTask(StrikePractice.getInstance(), () -> {
            Iterator var1x = Bukkit.getOnlinePlayers().iterator();

            while(var1x.hasNext()) {
               Player var2 = (Player)var1x.next();
               if (ga.strikepractice.k.b.a(var2, ga.strikepractice.k.a.pz)) {
                  var2.sendMessage(ChatColor.RED + "Failed to update data. Be sure you restart the server after editing kits etc! (Query: " + var1 + ")");
               }
            }

         });
      }

   }

   /** @deprecated */
   @Deprecated
   public ResultSet e(String var1) {
      try {
         Connection var2 = this.aN();

         ResultSet var4;
         try {
            Statement var3 = var2.createStatement();

            try {
               var4 = var3.executeQuery(var1);
            } catch (Throwable var8) {
               if (var3 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (var3 != null) {
               var3.close();
            }
         } catch (Throwable var9) {
            if (var2 != null) {
               try {
                  var2.close();
               } catch (Throwable var6) {
                  var9.addSuppressed(var6);
               }
            }

            throw var9;
         }

         if (var2 != null) {
            var2.close();
         }

         return var4;
      } catch (SQLException var10) {
         var10.printStackTrace();
         Bukkit.getScheduler().runTask(StrikePractice.getInstance(), () -> {
            Iterator var1x = Bukkit.getOnlinePlayers().iterator();

            while(var1x.hasNext()) {
               Player var2 = (Player)var1x.next();
               if (ga.strikepractice.k.b.a(var2, ga.strikepractice.k.a.pz)) {
                  var2.sendMessage(ChatColor.RED + "Failed to collect data (Query: " + var1 + ")");
               }
            }

         });
         return null;
      }
   }
}
