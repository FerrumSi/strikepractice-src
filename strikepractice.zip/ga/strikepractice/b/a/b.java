package ga.strikepractice.b.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.B;
import java.io.File;
import java.io.IOException;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class b {
   private final StrikePractice cU;
   private YamlConfiguration aO;
   private File aN;
   private final UUID cV;

   /** @deprecated */
   @Deprecated
   public b(StrikePractice var1, String var2) {
      this(var1, UUID.fromString(var2), true);
   }

   public b(StrikePractice var1, UUID var2) {
      this(var1, var2, true);
   }

   public b(StrikePractice var1, UUID var2, boolean var3) {
      this.cU = var1;
      this.cV = var2;
      this.e(var3);
   }

   /** @deprecated */
   @Deprecated
   public b(StrikePractice var1, String var2, boolean var3) {
      this(var1, UUID.fromString(var2), var3);
   }

   public void e(boolean var1) {
      boolean var2 = false;
      File var3 = new File(this.cU.getDataFolder(), "playerdata");
      var3.mkdirs();
      this.aN = new File(this.cU.getDataFolder(), "playerdata" + File.separator + this.cV + ".yml");
      if (!this.aN.exists() && var1) {
         if (Bukkit.getPlayer(this.cV) == null) {
            B.debug("StrikePractice >> PlayerDataFile.load() - Player seems to be a bot (not online). UUID: " + this.cV);
            return;
         }

         Bukkit.getLogger().info("StrikePractice >> Creating a new playerdata file. UUID: " + this.cV);

         try {
            this.aN.createNewFile();
            var2 = true;
         } catch (IOException var6) {
            var6.printStackTrace();
         }
      }

      if (this.aN.exists()) {
         this.aO = YamlConfiguration.loadConfiguration(this.aN);
         Player var4 = Bukkit.getPlayer(this.cV);
         if (var4 != null && !var4.getName().equals(this.aO.get("username"))) {
            this.aO.set("username", var4.getName());
            if (!var2) {
               this.save();
            }
         }

         if (var2) {
            this.aO.set("scoreboard-disabled", this.cU.getConfig().getBoolean("player-settings.default-values.scoreboard-disabled"));
            this.aO.set("duel-requests-disabled", this.cU.getConfig().getBoolean("player-settings.default-values.duel-requests-disabled"));
            boolean var5 = this.cU.getConfig().getBoolean("player-settings.default-values.admin-scoreboard");
            if (var5) {
               this.aO.set("admin-scoreboard", var5);
            }

            this.aO.set("hide-other-players", this.cU.getConfig().getBoolean("player-settings.default-values.hide-players"));
            this.save();
         }
      }

   }

   public File av() {
      return this.aN;
   }

   public YamlConfiguration au() {
      return this.aO;
   }

   public void save() {
      try {
         this.au().save(this.av());
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }
}
