package ga.strikepractice.b.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.stats.PlayerStats;
import ga.strikepractice.stats.Stats;
import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class a implements ga.strikepractice.b.b {
   private final StrikePractice cT;

   public a(StrikePractice var1) {
      this.cT = var1;
   }

   public LinkedHashMap<String, Double> b(String var1, int var2) {
      LinkedHashMap var3 = new LinkedHashMap();
      if (!this.cT.getConfig().getBoolean("top-placeholders-require-mysql")) {
         HashMap var4 = new HashMap();
         File var5 = new File(this.cT.getDataFolder(), "playerdata");
         if (!var5.exists()) {
            return var3;
         }

         File[] var6 = var5.listFiles();
         int var7 = var6.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            File var9 = var6[var8];

            try {
               YamlConfiguration var10 = YamlConfiguration.loadConfiguration(var9);
               if (var10 != null) {
                  Object var11 = var10.get("stats." + var1);
                  String var12 = var10.getString("username");
                  if (var11 != null && var12 != null) {
                     if (var11 instanceof Double) {
                        var4.put(var12, (Double)var11);
                     } else if (var11 instanceof Integer) {
                        int var13 = (Integer)var11;
                        var4.put(var12, (double)var13);
                     }
                  }
               }
            } catch (Exception var14) {
            }
         }

         var3 = (LinkedHashMap)var4.entrySet().stream().sorted(Entry.comparingByValue(Comparator.reverseOrder())).limit(10L).collect(Collectors.toMap(Entry::getKey, Entry::getValue, (var0, var1x) -> {
            return var0;
         }, LinkedHashMap::new));
      }

      return var3;
   }

   public LinkedHashMap<String, Double> d(BattleKit var1, int var2) {
      Bukkit.getLogger().warning("The current database in use does not support #getTopStatsLosses (or the placeholders)");
      return new LinkedHashMap();
   }

   public LinkedHashMap<String, Double> c(BattleKit var1, int var2) {
      Bukkit.getLogger().warning("The current database in use does not support #getTopStatsWins (or the placeholders)");
      return new LinkedHashMap();
   }

   public int a(UUID var1, String var2) {
      File var3 = new File(this.cT.getDataFolder(), "playerdata" + File.separator + var1.toString() + ".yml");
      if (var3.exists()) {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         if (var4 != null && var4.get("stats." + var2) != null) {
            return var4.getInt("stats." + var2);
         }
      }

      return var2.startsWith("elo_") ? ga.strikepractice.b.a.cM : 0;
   }

   public void b(PlayerStats var1) {
      File var2 = new File(this.cT.getDataFolder(), "playerdata" + File.separator + var1.getUUID().toString() + ".yml");
      if (var2.exists()) {
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         var1.setBracketsWins(var3.getInt("stats.brackets"));
         var1.setDeaths(var3.getInt("stats.deaths"));
         var1.setKills(var3.getInt("stats.kills"));
         var1.setLmsWins(var3.getInt("stats.lms"));
         var1.setPartyVsPartyWins(var3.getInt("stats.party_vs_party_wins"));
         HashMap var4 = new HashMap();
         Iterator var5 = this.cT.kits.iterator();

         while(var5.hasNext()) {
            BattleKit var6 = (BattleKit)var5.next();
            if (var6.isElo()) {
               String var7 = Stats.eloColumn(var6);
               if (var3.get("stats." + var7) != null) {
                  var4.put(var7, var3.getInt("stats." + var7));
               } else {
                  var4.put(var7, ga.strikepractice.b.a.cM);
               }
            }
         }

         var1.setPlayerElos(var4);
      }

   }

   public void a(UUID var1, String var2, int var3) {
      File var4 = new File(this.cT.getDataFolder(), "playerdata" + File.separator + var1.toString() + ".yml");
      if (var4.exists()) {
         YamlConfiguration var5 = YamlConfiguration.loadConfiguration(var4);
         var5.set("stats." + var2, var3);

         try {
            var5.save(var4);
         } catch (IOException var7) {
            var7.printStackTrace();
         }
      } else {
         b var8 = new b(this.cT, var1);
         YamlConfiguration var6 = var8.au();
         var6.set("stats." + var2, var3);
         var8.save();
      }

   }

   public void a(PlayerStats var1) {
      UUID var2 = var1.getUUID();
      File var3 = new File(this.cT.getDataFolder(), "playerdata" + File.separator + var2.toString() + ".yml");
      YamlConfiguration var4;
      if (!var3.exists()) {
         b var5 = new b(this.cT, var2);
         var4 = var5.au();
      } else {
         var4 = YamlConfiguration.loadConfiguration(var3);
      }

      var4.set("stats.brackets", var1.getBracketsWins());
      var4.set("stats.kills", var1.getKills());
      var4.set("stats.deaths", var1.getDeaths());
      var4.set("stats.lms", var1.getLMSWins());
      var4.set("stats.party_vs_party_wins", var1.getPartyVsPartyWins());
      var4.set("stats.global_elo", var1.getGlobalElo());
      var4.set("stats.sumo_wins", var1.getSumoWins());
      var4.set("stats.juggernaut", var1.getJuggernautWins());
      Iterator var9 = this.cT.kits.iterator();

      while(var9.hasNext()) {
         BattleKit var6 = (BattleKit)var9.next();
         if (var6.isElo()) {
            String var7 = Stats.eloColumn(var6);
            var4.set("stats." + var7, var1.getElo(var6));
         }
      }

      try {
         var4.save(var3);
      } catch (IOException var8) {
         var8.printStackTrace();
      }

   }

   public void k(Player var1) {
   }
}
