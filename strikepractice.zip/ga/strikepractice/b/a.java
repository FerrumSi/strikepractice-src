package ga.strikepractice.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.stats.PlayerStats;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class a {
   public static int cM;
   private final StrikePractice cN;
   private final b cO;

   public a(StrikePractice var1) {
      this.cN = var1;
      cM = var1.getConfig().getInt("starting-elo");
      this.cO = (b)(var1.H ? new ga.strikepractice.b.b.b(var1) : new ga.strikepractice.b.a.a(var1));
      this.cO.initialize();
   }

   public b aJ() {
      return this.cO;
   }

   public void aK() {
      Bukkit.broadcast(ChatColor.RED + "Restart the server to avoid problems with the database!", ga.strikepractice.k.a.pz.dY());
   }

   public void a(PlayerStats var1) {
      this.cO.a(var1);
   }

   public void a(UUID var1, String var2, int var3) {
      this.cO.a(var1, var2, var3);
   }

   public void b(PlayerStats var1) {
      this.cO.b(var1);
   }

   public int a(UUID var1, String var2) {
      return this.cO.a(var1, var2);
   }

   public LinkedHashMap<String, Double> a(String var1, int var2) {
      return this.cO.b(var1, var2);
   }

   public LinkedHashMap<String, Double> a(BattleKit var1, int var2) {
      return this.cO.c(var1, var2);
   }

   public LinkedHashMap<String, Double> b(BattleKit var1, int var2) {
      return this.cO.d(var1, var2);
   }

   public LinkedHashMap<String, Double> c(int var1) {
      return this.a((BattleKit)null, var1);
   }

   public LinkedHashMap<String, Double> d(int var1) {
      return this.b((BattleKit)null, var1);
   }

   public void j(Player var1) {
      this.cO.k(var1);
   }

   public void a(String var1, Object... var2) {
      C.c(() -> {
         this.b(var1, var2);
      });
   }

   public void b(String var1, Object... var2) {
      try {
         B.debug("query " + var1 + ", args: " + Arrays.toString(var2));
         this.cN.O.d(var1, var2);
         B.debug("query finish");
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }
}
