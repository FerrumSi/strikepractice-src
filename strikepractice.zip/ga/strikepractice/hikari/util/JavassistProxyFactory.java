package ga.strikepractice.hikari.util;

import ga.strikepractice.hikari.pool.ProxyCallableStatement;
import ga.strikepractice.hikari.pool.ProxyConnection;
import ga.strikepractice.hikari.pool.ProxyDatabaseMetaData;
import ga.strikepractice.hikari.pool.ProxyPreparedStatement;
import ga.strikepractice.hikari.pool.ProxyResultSet;
import ga.strikepractice.hikari.pool.ProxyStatement;
import java.lang.reflect.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import javassist.ClassMap;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.CtNewMethod;
import javassist.LoaderClassPath;
import javassist.Modifier;
import javassist.NotFoundException;

public final class JavassistProxyFactory {
   private static ClassPool classPool;
   private static String genDirectory = "";

   public static void main(String... var0) {
      classPool = new ClassPool();
      classPool.importPackage("java.sql");
      classPool.appendClassPath(new LoaderClassPath(JavassistProxyFactory.class.getClassLoader()));
      if (var0.length > 0) {
         genDirectory = var0[0];
      }

      String var1 = "{ try { return delegate.method($$); } catch (SQLException e) { throw checkException(e); } }";
      generateProxyClass(Connection.class, ProxyConnection.class.getName(), var1);
      generateProxyClass(Statement.class, ProxyStatement.class.getName(), var1);
      generateProxyClass(ResultSet.class, ProxyResultSet.class.getName(), var1);
      generateProxyClass(DatabaseMetaData.class, ProxyDatabaseMetaData.class.getName(), var1);
      var1 = "{ try { return ((cast) delegate).method($$); } catch (SQLException e) { throw checkException(e); } }";
      generateProxyClass(PreparedStatement.class, ProxyPreparedStatement.class.getName(), var1);
      generateProxyClass(CallableStatement.class, ProxyCallableStatement.class.getName(), var1);
      modifyProxyFactory();
   }

   private static void modifyProxyFactory() {
      System.out.println("Generating method bodies for com.zaxxer.hikari.proxy.ProxyFactory");
      String var0 = ProxyConnection.class.getPackage().getName();
      CtClass var1 = classPool.getCtClass("ga.strikepractice.hikari.pool.ProxyFactory");
      CtMethod[] var2 = var1.getMethods();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         CtMethod var5 = var2[var4];
         String var6 = var5.getName();
         byte var7 = -1;
         switch(var6.hashCode()) {
         case -1995233385:
            if (var6.equals("getProxyStatement")) {
               var7 = 1;
            }
            break;
         case -1729648339:
            if (var6.equals("getProxyResultSet")) {
               var7 = 4;
            }
            break;
         case -443793985:
            if (var6.equals("getProxyCallableStatement")) {
               var7 = 3;
            }
            break;
         case 1457258178:
            if (var6.equals("getProxyDatabaseMetaData")) {
               var7 = 5;
            }
            break;
         case 2011710902:
            if (var6.equals("getProxyConnection")) {
               var7 = 0;
            }
            break;
         case 2145615834:
            if (var6.equals("getProxyPreparedStatement")) {
               var7 = 2;
            }
         }

         switch(var7) {
         case 0:
            var5.setBody("{return new " + var0 + ".HikariProxyConnection($$);}");
            break;
         case 1:
            var5.setBody("{return new " + var0 + ".HikariProxyStatement($$);}");
            break;
         case 2:
            var5.setBody("{return new " + var0 + ".HikariProxyPreparedStatement($$);}");
            break;
         case 3:
            var5.setBody("{return new " + var0 + ".HikariProxyCallableStatement($$);}");
            break;
         case 4:
            var5.setBody("{return new " + var0 + ".HikariProxyResultSet($$);}");
            break;
         case 5:
            var5.setBody("{return new " + var0 + ".HikariProxyDatabaseMetaData($$);}");
         }
      }

      var1.writeFile(genDirectory + "target/classes");
   }

   private static <T> void generateProxyClass(Class<T> var0, String var1, String var2) {
      String var3 = var1.replaceAll("(.+)\\.(\\w+)", "$1.Hikari$2");
      CtClass var4 = classPool.getCtClass(var1);
      CtClass var5 = classPool.makeClass(var3, var4);
      var5.setModifiers(Modifier.setPublic(16));
      System.out.println("Generating " + var3);
      HashSet var6 = new HashSet();
      CtMethod[] var7 = var4.getMethods();
      int var8 = var7.length;

      for(int var9 = 0; var9 < var8; ++var9) {
         CtMethod var10 = var7[var9];
         if ((var10.getModifiers() & 16) == 16) {
            var6.add(var10.getName() + var10.getSignature());
         }
      }

      HashSet var19 = new HashSet();
      Iterator var20 = getAllInterfaces(var0).iterator();

      while(var20.hasNext()) {
         Class var21 = (Class)var20.next();
         CtClass var22 = classPool.getCtClass(var21.getName());
         var5.addInterface(var22);
         CtMethod[] var11 = var22.getDeclaredMethods();
         int var12 = var11.length;

         for(int var13 = 0; var13 < var12; ++var13) {
            CtMethod var14 = var11[var13];
            String var15 = var14.getName() + var14.getSignature();
            if (!var6.contains(var15) && !var19.contains(var15)) {
               var19.add(var15);
               CtMethod var16 = CtNewMethod.copy(var14, var5, (ClassMap)null);
               String var17 = var2;
               CtMethod var18 = var4.getMethod(var14.getName(), var14.getSignature());
               if ((var18.getModifiers() & 1024) != 1024 && !isDefaultMethod(var21, var14)) {
                  var17 = var2.replace("((cast) ", "");
                  var17 = var17.replace("delegate", "super");
                  var17 = var17.replace("super)", "super");
               }

               var17 = var17.replace("cast", var0.getName());
               if (isThrowsSqlException(var14)) {
                  var17 = var17.replace("method", var16.getName());
               } else {
                  var17 = "{ return ((cast) delegate).method($$); }".replace("method", var16.getName()).replace("cast", var0.getName());
               }

               if (var16.getReturnType() == CtClass.voidType) {
                  var17 = var17.replace("return", "");
               }

               var16.setBody(var17);
               var5.addMethod(var16);
            }
         }
      }

      var5.getClassFile().setMajorVersion(52);
      var5.writeFile(genDirectory + "target/classes");
   }

   private static boolean isThrowsSqlException(CtMethod var0) {
      try {
         CtClass[] var1 = var0.getExceptionTypes();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            CtClass var4 = var1[var3];
            if (var4.getSimpleName().equals("SQLException")) {
               return true;
            }
         }
      } catch (NotFoundException var5) {
      }

      return false;
   }

   private static boolean isDefaultMethod(Class<?> var0, CtMethod var1) {
      ArrayList var2 = new ArrayList();
      CtClass[] var3 = var1.getParameterTypes();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         CtClass var6 = var3[var5];
         var2.add(toJavaClass(var6));
      }

      return var0.getDeclaredMethod(var1.getName(), (Class[])var2.toArray(new Class[0])).toString().contains("default ");
   }

   private static Set<Class<?>> getAllInterfaces(Class<?> var0) {
      LinkedHashSet var1 = new LinkedHashSet();
      Class[] var2 = var0.getInterfaces();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Class var5 = var2[var4];
         if (var5.getInterfaces().length > 0) {
            var1.addAll(getAllInterfaces(var5));
         }

         var1.add(var5);
      }

      if (var0.getSuperclass() != null) {
         var1.addAll(getAllInterfaces(var0.getSuperclass()));
      }

      if (var0.isInterface()) {
         var1.add(var0);
      }

      return var1;
   }

   private static Class<?> toJavaClass(CtClass var0) {
      return var0.getName().endsWith("[]") ? Array.newInstance(toJavaClass(var0.getName().replace("[]", "")), 0).getClass() : toJavaClass(var0.getName());
   }

   private static Class<?> toJavaClass(String var0) {
      byte var2 = -1;
      switch(var0.hashCode()) {
      case -1325958191:
         if (var0.equals("double")) {
            var2 = 5;
         }
         break;
      case 104431:
         if (var0.equals("int")) {
            var2 = 0;
         }
         break;
      case 3039496:
         if (var0.equals("byte")) {
            var2 = 3;
         }
         break;
      case 3052374:
         if (var0.equals("char")) {
            var2 = 7;
         }
         break;
      case 3327612:
         if (var0.equals("long")) {
            var2 = 1;
         }
         break;
      case 3625364:
         if (var0.equals("void")) {
            var2 = 8;
         }
         break;
      case 64711720:
         if (var0.equals("boolean")) {
            var2 = 6;
         }
         break;
      case 97526364:
         if (var0.equals("float")) {
            var2 = 4;
         }
         break;
      case 109413500:
         if (var0.equals("short")) {
            var2 = 2;
         }
      }

      switch(var2) {
      case 0:
         return Integer.TYPE;
      case 1:
         return Long.TYPE;
      case 2:
         return Short.TYPE;
      case 3:
         return Byte.TYPE;
      case 4:
         return Float.TYPE;
      case 5:
         return Double.TYPE;
      case 6:
         return Boolean.TYPE;
      case 7:
         return Character.TYPE;
      case 8:
         return Void.TYPE;
      default:
         return Class.forName(var0);
      }
   }
}
