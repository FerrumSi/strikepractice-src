package ga.strikepractice.hikari.hibernate;

import ga.strikepractice.hikari.HikariConfig;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

public class HikariConfigurationUtil {
   public static final String CONFIG_PREFIX = "hibernate.hikari.";
   public static final String CONFIG_PREFIX_DATASOURCE = "hibernate.hikari.dataSource.";

   public static HikariConfig loadConfiguration(Map var0) {
      Properties var1 = new Properties();
      copyProperty("hibernate.connection.isolation", var0, "transactionIsolation", var1);
      copyProperty("hibernate.connection.autocommit", var0, "autoCommit", var1);
      copyProperty("hibernate.connection.driver_class", var0, "driverClassName", var1);
      copyProperty("hibernate.connection.url", var0, "jdbcUrl", var1);
      copyProperty("hibernate.connection.username", var0, "username", var1);
      copyProperty("hibernate.connection.password", var0, "password", var1);
      Iterator var2 = var0.keySet().iterator();

      while(var2.hasNext()) {
         Object var3 = var2.next();
         String var4 = (String)var3;
         if (var4.startsWith("hibernate.hikari.")) {
            var1.setProperty(var4.substring("hibernate.hikari.".length()), (String)var0.get(var4));
         }
      }

      return new HikariConfig(var1);
   }

   private static void copyProperty(String var0, Map var1, String var2, Properties var3) {
      if (var1.containsKey(var0)) {
         var3.setProperty(var2, (String)var1.get(var0));
      }

   }
}
