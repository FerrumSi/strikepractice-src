package ga.strikepractice.hikari.pool;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.sql.Wrapper;

public final class HikariProxyStatement extends ProxyStatement implements AutoCloseable, Statement, Wrapper {
   public boolean isWrapperFor(Class var1) {
      try {
         return super.delegate.isWrapperFor(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public ResultSet executeQuery(String var1) {
      try {
         return super.executeQuery(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public int executeUpdate(String var1) {
      try {
         return super.executeUpdate(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public int getMaxFieldSize() {
      try {
         return super.delegate.getMaxFieldSize();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void setMaxFieldSize(int var1) {
      try {
         super.delegate.setMaxFieldSize(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public int getMaxRows() {
      try {
         return super.delegate.getMaxRows();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void setMaxRows(int var1) {
      try {
         super.delegate.setMaxRows(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public void setEscapeProcessing(boolean var1) {
      try {
         super.delegate.setEscapeProcessing(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public int getQueryTimeout() {
      try {
         return super.delegate.getQueryTimeout();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void setQueryTimeout(int var1) {
      try {
         super.delegate.setQueryTimeout(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public void cancel() {
      try {
         super.delegate.cancel();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public SQLWarning getWarnings() {
      try {
         return super.delegate.getWarnings();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void clearWarnings() {
      try {
         super.delegate.clearWarnings();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void setCursorName(String var1) {
      try {
         super.delegate.setCursorName(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public boolean execute(String var1) {
      try {
         return super.execute(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public ResultSet getResultSet() {
      try {
         return super.getResultSet();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public int getUpdateCount() {
      try {
         return super.delegate.getUpdateCount();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public boolean getMoreResults() {
      try {
         return super.delegate.getMoreResults();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void setFetchDirection(int var1) {
      try {
         super.delegate.setFetchDirection(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public int getFetchDirection() {
      try {
         return super.delegate.getFetchDirection();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void setFetchSize(int var1) {
      try {
         super.delegate.setFetchSize(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public int getFetchSize() {
      try {
         return super.delegate.getFetchSize();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public int getResultSetConcurrency() {
      try {
         return super.delegate.getResultSetConcurrency();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public int getResultSetType() {
      try {
         return super.delegate.getResultSetType();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void addBatch(String var1) {
      try {
         super.delegate.addBatch(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public void clearBatch() {
      try {
         super.delegate.clearBatch();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public int[] executeBatch() {
      try {
         return super.executeBatch();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public Connection getConnection() {
      try {
         return super.getConnection();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public boolean getMoreResults(int var1) {
      try {
         return super.delegate.getMoreResults(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public ResultSet getGeneratedKeys() {
      try {
         return super.getGeneratedKeys();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public int executeUpdate(String var1, int var2) {
      try {
         return super.executeUpdate(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public int executeUpdate(String var1, int[] var2) {
      try {
         return super.executeUpdate(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public int executeUpdate(String var1, String[] var2) {
      try {
         return super.executeUpdate(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public boolean execute(String var1, int var2) {
      try {
         return super.execute(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public boolean execute(String var1, int[] var2) {
      try {
         return super.execute(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public boolean execute(String var1, String[] var2) {
      try {
         return super.execute(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public int getResultSetHoldability() {
      try {
         return super.delegate.getResultSetHoldability();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public boolean isClosed() {
      try {
         return super.delegate.isClosed();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void setPoolable(boolean var1) {
      try {
         super.delegate.setPoolable(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public boolean isPoolable() {
      try {
         return super.delegate.isPoolable();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void closeOnCompletion() {
      try {
         super.delegate.closeOnCompletion();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public boolean isCloseOnCompletion() {
      try {
         return super.delegate.isCloseOnCompletion();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public long getLargeUpdateCount() {
      try {
         return super.delegate.getLargeUpdateCount();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public void setLargeMaxRows(long var1) {
      try {
         super.delegate.setLargeMaxRows(var1);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public long getLargeMaxRows() {
      try {
         return super.delegate.getLargeMaxRows();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public long[] executeLargeBatch() {
      try {
         return super.delegate.executeLargeBatch();
      } catch (SQLException var2) {
         throw this.checkException(var2);
      }
   }

   public long executeLargeUpdate(String var1) {
      try {
         return super.delegate.executeLargeUpdate(var1);
      } catch (SQLException var3) {
         throw this.checkException(var3);
      }
   }

   public long executeLargeUpdate(String var1, int var2) {
      try {
         return super.delegate.executeLargeUpdate(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public long executeLargeUpdate(String var1, int[] var2) {
      try {
         return super.delegate.executeLargeUpdate(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   public long executeLargeUpdate(String var1, String[] var2) {
      try {
         return super.delegate.executeLargeUpdate(var1, var2);
      } catch (SQLException var4) {
         throw this.checkException(var4);
      }
   }

   HikariProxyStatement(ProxyConnection var1, Statement var2) {
      super(var1, var2);
   }
}
