package ga.strikepractice.hikari.metrics;

/** @deprecated */
@Deprecated
public class MetricsTracker implements IMetricsTracker {
}
