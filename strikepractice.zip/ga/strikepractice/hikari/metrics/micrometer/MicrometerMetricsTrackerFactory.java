package ga.strikepractice.hikari.metrics.micrometer;

import ga.strikepractice.hikari.metrics.IMetricsTracker;
import ga.strikepractice.hikari.metrics.MetricsTrackerFactory;
import ga.strikepractice.hikari.metrics.PoolStats;
import io.micrometer.core.instrument.MeterRegistry;

public class MicrometerMetricsTrackerFactory implements MetricsTrackerFactory {
   private final MeterRegistry registry;

   public MicrometerMetricsTrackerFactory(MeterRegistry var1) {
      this.registry = var1;
   }

   public IMetricsTracker create(String var1, PoolStats var2) {
      return new MicrometerMetricsTracker(var1, var2, this.registry);
   }
}
