package ga.strikepractice.j.a;

public class a {
   public static final String pa = "STRIKEPRACTICE_PACKET_HANDLER";
}
