package ga.strikepractice.j.a.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.B;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import java.util.Iterator;
import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.PluginManager;

public class b {
   private static boolean pc;
   private static b pd;
   private final StrikePractice pe;

   public b(StrikePractice var1) {
      this.pe = var1;
   }

   public static void n(StrikePractice var0) {
      pd = new b(var0);
      PluginManager var10000 = Bukkit.getPluginManager();
      b var10003 = pd;
      Objects.requireNonNull(var10003);
      var10000.registerEvents(var10003.new a(), var0);
   }

   public void ao(Player var1) {
      try {
         Channel var2 = this.c(var1);
         ChannelHandler var3 = var2.pipeline().get("STRIKEPRACTICE_PACKET_HANDLER");
         if (var3 == null) {
            var2.pipeline().addBefore("packet_handler", "STRIKEPRACTICE_PACKET_HANDLER", new ga.strikepractice.j.a.a.a(var1));
         }
      } catch (Exception var4) {
         if (!pc && Bukkit.getPluginManager().getPlugin("ViaVersion") != null) {
            B.debug("Some StrikePractice features might not work due to ViaVersion!");
            pc = true;
         }
      }

   }

   public void d(Player var1, boolean var2) {
      if (!var2) {
         Channel var3 = this.c(var1);
         if (var3 != null) {
            ChannelHandler var4 = var3.pipeline().get("STRIKEPRACTICE_PACKET_HANDLER");
            if (var4 != null) {
               var3.eventLoop().execute(() -> {
                  var3.pipeline().remove("STRIKEPRACTICE_PACKET_HANDLER");
               });
            }
         }

      }
   }

   public Channel c(Object var1) {
      return (Channel)this.pe.ao().dH().aj((Player)var1);
   }

   public void T() {
      Iterator var1 = Bukkit.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player var2 = (Player)var1.next();
         this.ao(var2);
      }

   }

   public void S() {
      try {
         Iterator var1 = Bukkit.getOnlinePlayers().iterator();

         while(var1.hasNext()) {
            Player var2 = (Player)var1.next();
            this.d(var2, false);
         }
      } catch (Exception var3) {
         Bukkit.getLogger().warning("StrikePractice >> Failed to unregister players. Probably safe to ignore.");
         var3.printStackTrace();
      }

   }

   public static b dW() {
      return pd;
   }

   class a implements Listener {
      @EventHandler
      public void c(PlayerJoinEvent var1) {
         b.dW().ao(var1.getPlayer());
      }
   }
}
