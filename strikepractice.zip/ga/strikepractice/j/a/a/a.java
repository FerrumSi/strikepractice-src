package ga.strikepractice.j.a.a;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import java.util.Iterator;
import org.bukkit.entity.Player;

public class a extends ChannelDuplexHandler {
   private final Player pb;

   public a(Player var1) {
      this.pb = var1;
   }

   public void write(ChannelHandlerContext var1, Object var2, ChannelPromise var3) {
      ga.strikepractice.j.a var4 = new ga.strikepractice.j.a(this.pb, var2);

      try {
         Iterator var5 = ga.strikepractice.j.b.b.pg.iterator();

         while(var5.hasNext()) {
            ga.strikepractice.j.b.a var6 = (ga.strikepractice.j.b.a)var5.next();
            var6.a(var4);
         }
      } catch (Exception var7) {
         var7.printStackTrace();
      }

      if (var2 != null && !var4.isCancelled()) {
         super.write(var1, var2, var3);
      }

   }

   public void channelRead(ChannelHandlerContext var1, Object var2) {
      ga.strikepractice.j.a var3 = new ga.strikepractice.j.a(this.pb, var2);

      try {
         Iterator var4 = ga.strikepractice.j.b.b.pg.iterator();

         while(var4.hasNext()) {
            ga.strikepractice.j.b.a var5 = (ga.strikepractice.j.b.a)var4.next();
            var5.b(var3);
         }
      } catch (Exception var6) {
         var6.printStackTrace();
      }

      if (var2 != null && !var3.isCancelled()) {
         super.channelRead(var1, var2);
      }

   }
}
