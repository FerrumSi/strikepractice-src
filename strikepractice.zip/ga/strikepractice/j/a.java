package ga.strikepractice.j;

import org.bukkit.entity.Player;

public class a {
   private final Player oN;
   private boolean cancelled;
   private Object oO;

   public a(Player var1, Object var2) {
      this.oN = var1;
      this.oO = var2;
   }

   public Object dR() {
      return this.oO;
   }

   public void b(Object var1) {
      this.oO = var1;
   }

   public Player getPlayer() {
      return this.oN;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }

   public b dS() {
      b var1 = null;
      b[] var2 = b.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         b var5 = var2[var4];
         if (var5.getName().equals(this.dR().getClass().getSimpleName())) {
            var1 = var5;
         }
      }

      return var1;
   }
}
