package ga.strikepractice.j.b;

import java.util.ArrayList;
import java.util.List;

public class b {
   public static List<ga.strikepractice.j.b.a> pg = new ArrayList();

   public static void a(ga.strikepractice.j.b.a var0) {
      pg.add(var0);
   }

   public static void b(ga.strikepractice.j.b.a var0) {
      pg.remove(var0);
   }
}
