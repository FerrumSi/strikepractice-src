package ga.strikepractice.j.b;

import ga.strikepractice.StrikePractice;
import org.bukkit.entity.Player;

public class c extends ga.strikepractice.j.b.a {
   private final StrikePractice ph;

   public c(StrikePractice var1) {
      this.ph = var1;
   }

   public void a(ga.strikepractice.j.a var1) {
   }

   public void b(ga.strikepractice.j.a var1) {
      Player var2 = var1.getPlayer();
      ga.strikepractice.j.b var3 = var1.dS();
      if (var3 != null && var3.equals(ga.strikepractice.j.b.oP)) {
         ga.strikepractice.utils.b.b var4 = this.ph.ao().dH().a(var1.dR());
         if (var4 != null && ga.strikepractice.utils.b.a.a(var2, var4)) {
            var1.setCancelled(true);
         }
      }

   }
}
