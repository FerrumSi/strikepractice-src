package ga.strikepractice.j.b;

public abstract class a {
   public a() {
      b.a(this);
   }

   public abstract void a(ga.strikepractice.j.a var1);

   public abstract void b(ga.strikepractice.j.a var1);

   public void dX() {
      b.b(this);
   }
}
