package ga.strikepractice.j;

public enum b {
   oP("PacketPlayInUpdateSign"),
   oQ("PacketPlayInClientCommand"),
   oR("PacketPlayInCloseWindow"),
   oS("PacketPlayInFlying"),
   oT("PacketPlayInLook"),
   oU("PacketPlayInPosition"),
   oV("PacketPlayInPositionLook"),
   oW("PacketPlayInUseEntity"),
   oX("PacketPlayOutBlockPlace");

   private final String oY;

   private b(String var3) {
      this.oY = var3;
   }

   public String getName() {
      return this.oY;
   }

   public boolean dT() {
      return this.getName().startsWith("PacketPlayOut");
   }

   public boolean dU() {
      return this.getName().startsWith("PacketPlayIn");
   }

   // $FF: synthetic method
   private static b[] dV() {
      return new b[]{oP, oQ, oR, oS, oT, oU, oV, oW, oX};
   }
}
