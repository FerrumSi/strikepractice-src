package ga.strikepractice.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.utils.B;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import net.badlion.timers.api.Timer;
import net.badlion.timers.api.TimerApi;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.messaging.Messenger;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\u0018\u00002\u00020\u0001:\u0002\u0013\u0014B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0006\u001a\u00020\u0007J\u0010\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u0005H\u0002J(\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0015"},
   d2 = {"Lga/strikepractice/clients/ClientManager;", "", "()V", "clients", "", "Lga/strikepractice/clients/ClientManager$Client;", "enable", "", "registerClientSupport", "client", "sendCooldown", "p", "Lorg/bukkit/entity/Player;", "name", "", "material", "Lorg/bukkit/Material;", "time", "", "Client", "NullListener", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nClientManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ClientManager.kt\nga/strikepractice/clients/ClientManager\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,119:1\n1855#2,2:120\n*S KotlinDebug\n*F\n+ 1 ClientManager.kt\nga/strikepractice/clients/ClientManager\n*L\n84#1:120,2\n*E\n"})
public final class a {
   @NotNull
   private final List<ga.strikepractice.a.a.a> cJ = (List)(new ArrayList());

   public final void aH() {
      this.a((ga.strikepractice.a.a.a)(new ga.strikepractice.a.a.a() {
         public boolean isEnabled() {
            if (!this.aI()) {
               return false;
            } else if (Bukkit.getPluginManager().getPlugin("BadlionClientTimerAPI") == null) {
               Bukkit.getLogger().warning("Download BadlionClientTimerAPI to support cooldowns for BAC. https://github.com/BadlionNetwork/BadlionClientTimerAPI/releases");
               return false;
            } else {
               return true;
            }
         }

         public void a(@NotNull Player var1, @Nullable String var2, @NotNull Material var3, long var4) {
            Intrinsics.checkNotNullParameter(var1, "p");
            Intrinsics.checkNotNullParameter(var3, "material");
            TimerApi var6 = TimerApi.getInstance();
            Timer var7 = var6.createTimeTimer(new ItemStack(var3), false, var4, TimeUnit.MILLISECONDS);
            var7.addReceiver(var1);
         }

         @NotNull
         public String getName() {
            return "badlion";
         }

         public void b(@NotNull StrikePractice var1) {
            ga.strikepractice.a.a.a.a.a(this, var1);
         }

         public boolean aI() {
            return ga.strikepractice.a.a.a.a.c(this);
         }
      }));
      this.a((ga.strikepractice.a.a.a)(new ga.strikepractice.a.a.a() {
         @NotNull
         private final String cL = "Lunar-Client";

         public void b(@NotNull StrikePractice var1) {
            Intrinsics.checkNotNullParameter(var1, "plugin");
            Messenger var2 = var1.getServer().getMessenger();
            boolean var3 = false;
            var2.registerOutgoingPluginChannel((Plugin)var1, this.cL);
            var2.registerIncomingPluginChannel((Plugin)var1, this.cL, (PluginMessageListener)ga.strikepractice.a.a.b.cK);
         }

         public void a(@NotNull Player var1, @Nullable String var2, @NotNull Material var3, long var4) {
            Intrinsics.checkNotNullParameter(var1, "p");
            Intrinsics.checkNotNullParameter(var3, "material");
            ByteArrayOutputStream var7 = new ByteArrayOutputStream();
            boolean var9 = false;
            var7.write(3);
            var7.write(ga.strikepractice.a.b.d(var2));
            var7.write(ga.strikepractice.a.b.a(var4));
            var7.write(ga.strikepractice.a.b.b(var3.getId()));
            var7.close();
            var1.sendPluginMessage((Plugin)StrikePractice.getInstance(), this.cL, var7.toByteArray());
         }

         @NotNull
         public String getName() {
            return "lunar";
         }

         public boolean isEnabled() {
            return ga.strikepractice.a.a.a.a.b(this);
         }

         public boolean aI() {
            return ga.strikepractice.a.a.a.a.c(this);
         }
      }));
   }

   private final void a(ga.strikepractice.a.a.a var1) {
      if (var1.isEnabled()) {
         try {
            StrikePractice var10001 = StrikePractice.getInstance();
            Intrinsics.checkNotNullExpressionValue(var10001, "getInstance()");
            var1.b(var10001);
            this.cJ.add(var1);
            Bukkit.getLogger().info("Registered client cooldowns for " + var1.getName() + "-client");
         } catch (Exception var3) {
            Bukkit.getLogger().warning("Failed to enable module for " + var1.getName() + " client cooldowns. ");
            if (B.vj.fV()) {
               var3.printStackTrace();
            }
         }
      }

   }

   public final void a(@NotNull Player var1, @Nullable String var2, @NotNull Material var3, long var4) {
      Intrinsics.checkNotNullParameter(var1, "p");
      Intrinsics.checkNotNullParameter(var3, "material");
      Iterable var6 = (Iterable)this.cJ;
      boolean var7 = false;
      Iterator var8 = var6.iterator();

      while(var8.hasNext()) {
         Object var9 = var8.next();
         ga.strikepractice.a.a.a var10 = (ga.strikepractice.a.a.a)var9;
         boolean var11 = false;

         try {
            var10.a(var1, var2, var3, var4);
         } catch (Exception var13) {
            Bukkit.getLogger().warning("Failed to send cooldown with " + var10.getName() + " implementation. Disable it in the config if this continues.");
            var13.printStackTrace();
         }
      }

   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\bb\u0018\u00002\u00020\u0001J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J*\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u00102\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H&R\u0014\u0010\u0002\u001a\u00020\u00038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0002\u0010\u0004R\u0014\u0010\u0005\u001a\u00020\u00038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0005\u0010\u0004R\u0012\u0010\u0006\u001a\u00020\u0007X¦\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\t¨\u0006\u0015"},
      d2 = {"Lga/strikepractice/clients/ClientManager$Client;", "", "isConfigEnable", "", "()Z", "isEnabled", "name", "", "getName", "()Ljava/lang/String;", "onEnable", "", "plugin", "Lga/strikepractice/StrikePractice;", "sendCooldown", "p", "Lorg/bukkit/entity/Player;", "material", "Lorg/bukkit/Material;", "time", "", "strikepractice-core"}
   )
   private interface a {
      void b(@NotNull StrikePractice var1);

      void a(@NotNull Player var1, @Nullable String var2, @NotNull Material var3, long var4);

      @NotNull
      String getName();

      boolean isEnabled();

      boolean aI();

      @Metadata(
         mv = {1, 8, 0},
         k = 3,
         xi = 48
      )
      public static final class a {
         public static void a(@NotNull ga.strikepractice.a.a.a var0, @NotNull StrikePractice var1) {
            Intrinsics.checkNotNullParameter(var1, "plugin");
         }

         public static boolean b(@NotNull ga.strikepractice.a.a.a var0) {
            return var0.aI();
         }

         public static boolean c(@NotNull ga.strikepractice.a.a.a var0) {
            return StrikePractice.getInstance().getConfig().getBoolean("client-cooldowns." + var0.getName());
         }
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016¨\u0006\u000b"},
      d2 = {"Lga/strikepractice/clients/ClientManager$NullListener;", "Lorg/bukkit/plugin/messaging/PluginMessageListener;", "()V", "onPluginMessageReceived", "", "s", "", "player", "Lorg/bukkit/entity/Player;", "bytes", "", "strikepractice-core"}
   )
   private static final class b implements PluginMessageListener {
      @NotNull
      public static final ga.strikepractice.a.a.b cK = new ga.strikepractice.a.a.b();

      public void onPluginMessageReceived(@NotNull String var1, @NotNull Player var2, @NotNull byte[] var3) {
         Intrinsics.checkNotNullParameter(var1, "s");
         Intrinsics.checkNotNullParameter(var2, "player");
         Intrinsics.checkNotNullParameter(var3, "bytes");
      }
   }
}
