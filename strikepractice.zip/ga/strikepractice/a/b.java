package ga.strikepractice.a;

import com.google.common.base.Charsets;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;

public final class b {
   public static byte[] d(String var0) {
      ByteArrayOutputStream var1 = new ByteArrayOutputStream();
      byte[] var2 = var0.getBytes(Charsets.UTF_8);
      var1.write(a(var2.length));
      var1.write(var2);
      var1.close();
      return var1.toByteArray();
   }

   public static byte[] a(int var0) {
      ByteArrayOutputStream var1;
      for(var1 = new ByteArrayOutputStream(); (var0 & -128) != 0; var0 >>>= 7) {
         var1.write(var0 & 127 | 128);
      }

      var1.write(var0);
      var1.close();
      return var1.toByteArray();
   }

   public static byte[] b(int var0) {
      ByteArrayOutputStream var1 = new ByteArrayOutputStream();
      DataOutputStream var2 = new DataOutputStream(var1);
      var2.writeInt(var0);
      var2.close();
      var1.close();
      return var1.toByteArray();
   }

   public static byte[] a(long var0) {
      ByteArrayOutputStream var2 = new ByteArrayOutputStream();
      DataOutputStream var3 = new DataOutputStream(var2);
      var3.writeLong(var0);
      var3.close();
      var2.close();
      return var2.toByteArray();
   }
}
