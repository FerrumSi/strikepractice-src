package ga.strikepractice.g;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.util.Vector;

public class a implements Listener {
   private final StrikePractice ko;

   public a(StrikePractice var1) {
      this.ko = var1;
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void a(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player && var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         if ((double)var2.getNoDamageTicks() > (double)var2.getMaximumNoDamageTicks() / 2.0D) {
            return;
         }

         BattleKit var3 = BattleKit.getCurrentKit(var2);
         if (this.ko.ak().cN() && (var3 == null || !var3.isCombo())) {
            return;
         }

         c var4 = this.ko.ak().k(var3);
         double var5 = var2.getLocation().getY() % 1.0D == 0.0D ? var4.cQ() : var4.cO();
         double var7 = var2.getLocation().getY() % 1.0D == 0.0D ? var4.cR() : var4.cP();
         Player var9 = (Player)var1.getDamager();
         double var10 = var9.isSprinting() ? 0.8D : 0.5D;
         double var12 = var9.getItemInHand() == null ? 0.0D : (double)var9.getItemInHand().getEnchantmentLevel(Enchantment.KNOCKBACK) * 0.2D;
         double var14 = var2.isOnGround() ? 1.0D : 0.5D;
         Vector var16 = var2.getLocation().toVector().subtract(var9.getLocation().toVector()).normalize();
         var16.setX((var16.getX() * var10 + var12) * var5);
         var16.setY(0.35D * var14 * var7);
         var16.setZ((var16.getZ() * var10 + var12) * var5);
         this.ko.ao().dH().a(var2, var16.getX(), var16.getY(), var16.getZ());
      }

   }

   @EventHandler
   public void a(PlayerVelocityEvent var1) {
      Player var2 = var1.getPlayer();
      EntityDamageEvent var3 = var2.getLastDamageCause();
      if (var3 != null && var3 instanceof EntityDamageByEntityEvent) {
         EntityDamageByEntityEvent var4 = (EntityDamageByEntityEvent)var3;
         if (var4.getDamager() instanceof Player) {
            if (this.ko.ak().cN()) {
               BattleKit var5 = BattleKit.getCurrentKit(var2);
               if (var5 != null && var5.isCombo()) {
                  var1.setCancelled(true);
               }
            } else {
               var1.setCancelled(true);
            }
         }

      }
   }
}
