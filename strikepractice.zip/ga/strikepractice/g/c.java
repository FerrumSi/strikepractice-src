package ga.strikepractice.g;

import ga.strikepractice.StrikePractice;

public class c {
   private final StrikePractice ku;
   private final String kv;
   private double kw;
   private double kx;
   private double ky;
   private double kz;
   private final double kA;
   private final double kB;
   private final double kC;
   private final double kD;

   public c(StrikePractice var1, String var2) {
      this.kv = var2;
      this.ku = var1;
      this.kw = var1.getConfig().getDouble("knockback." + var2 + ".air-horizontal");
      this.kx = var1.getConfig().getDouble("knockback." + var2 + ".air-vertical");
      this.ky = var1.getConfig().getDouble("knockback." + var2 + ".horizontal");
      this.kz = var1.getConfig().getDouble("knockback." + var2 + ".vertical");
      this.kA = var1.getConfig().getDouble("knockback." + var2 + ".air-horizontal-max");
      this.kB = var1.getConfig().getDouble("knockback." + var2 + ".air-vertical-max");
      this.kC = var1.getConfig().getDouble("knockback." + var2 + ".horizontal-max");
      this.kD = var1.getConfig().getDouble("knockback." + var2 + ".vertical-max");
   }

   public String getIdentifier() {
      return this.kv;
   }

   public double cO() {
      return this.kA == 0.0D ? this.kw : this.a(this.kw, this.kA);
   }

   public double cP() {
      return this.kB == 0.0D ? this.kx : this.a(this.kx, this.kB);
   }

   public double cQ() {
      return this.kC == 0.0D ? this.ky : this.a(this.ky, this.kC);
   }

   public double cR() {
      return this.kD == 0.0D ? this.kz : this.a(this.kz, this.kD);
   }

   public void b(double var1) {
      this.kw = var1;
   }

   public void c(double var1) {
      this.kx = var1;
   }

   public void d(double var1) {
      this.ky = var1;
   }

   public void e(double var1) {
      this.kz = var1;
   }

   public void save() {
      this.ku.getConfig().set("knockback." + this.kv + ".air-horizontal", this.kw);
      this.ku.getConfig().set("knockback." + this.kv + ".air-vertical", this.kx);
      this.ku.getConfig().set("knockback." + this.kv + ".horizontal", this.ky);
      this.ku.getConfig().set("knockback." + this.kv + ".vertical", this.kz);
      this.ku.saveConfig();
   }

   private double a(double var1, double var3) {
      return var1 + StrikePractice.t.nextDouble() * (var3 - var1);
   }
}
