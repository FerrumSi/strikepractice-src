package ga.strikepractice.g;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import java.util.HashSet;
import java.util.Iterator;
import org.bukkit.Bukkit;

public class b {
   private final HashSet<c> kp = new HashSet();
   private final StrikePractice kq;
   private final c kr;
   private final c ks;
   private boolean kt;

   public b(StrikePractice var1) {
      this.kq = var1;
      Bukkit.getLogger().info("StrikePractice >> Loading knockback:");
      this.kp.add(this.kr = new c(var1, "default"));
      this.kp.add(this.ks = new c(var1, "combo"));
      this.kt = var1.getConfig().getBoolean("knockback.only-combo");
      Bukkit.getLogger().info("only-combo: " + this.kt);
      Bukkit.getLogger().info("Loaded default profiles: default, combo");
      Iterator var2 = var1.kits.iterator();

      while(var2.hasNext()) {
         BattleKit var3 = (BattleKit)var2.next();
         if (var1.getConfig().get("knockback." + var3.getName() + ".horizontal") != null && !var3.getName().equals("default") && !var3.getName().equals("combo")) {
            this.kp.add(new c(var1, var3.getName()));
            Bukkit.getLogger().info("Loaded kit knockback profile: " + var3.getName());
         }
      }

      Bukkit.getLogger().info("StrikePractice >> Knockback loaded");
   }

   public c k(BattleKit var1) {
      if (var1 != null) {
         Iterator var2 = this.kp.iterator();

         c var3;
         do {
            if (!var2.hasNext()) {
               return var1.isCombo() ? this.ks : this.kr;
            }

            var3 = (c)var2.next();
         } while(!var3.getIdentifier().equals(var1.getName()));

         return var3;
      } else {
         return this.kr;
      }
   }

   public c y(String var1) {
      if (var1 != null) {
         Iterator var2 = this.kp.iterator();

         c var3;
         do {
            if (!var2.hasNext()) {
               return var1.equals("combo") ? this.ks : this.kr;
            }

            var3 = (c)var2.next();
         } while(!var3.getIdentifier().equals(var1));

         return var3;
      } else {
         return this.kr;
      }
   }

   public void g(boolean var1) {
      this.kt = var1;
   }

   public boolean cN() {
      return this.kt;
   }

   public void save() {
      Iterator var1 = this.kp.iterator();

      while(var1.hasNext()) {
         c var2 = (c)var1.next();
         var2.save();
      }

      this.kq.getConfig().set("knockback.only-combo", this.kt);
      this.kq.saveConfig();
   }
}
