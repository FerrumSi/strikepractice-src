package ga.strikepractice;

import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.EloChange;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.fights.other.FFAFight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.i.l;
import ga.strikepractice.l.c;
import ga.strikepractice.npc.CitizensNPC;
import ga.strikepractice.party.Party;
import ga.strikepractice.playersettings.PlayerSettings;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.stats.Stats;
import ga.strikepractice.stats.e;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.n;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.s;
import ga.strikepractice.utils.t;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

public class b implements CommandExecutor, Listener {
   private final StrikePractice ar;

   public b(StrikePractice var1) {
      this.ar = var1;
   }

   public boolean onCommand(final CommandSender var1, Command var2, String var3, final String[] var4) {
      Player var5;
      Fight var6;
      if (var4.length == 2 && var1 instanceof Player && var4[0].equalsIgnoreCase("ffabot")) {
         var5 = (Player)var1;
         var6 = AbstractFight.getCurrentFight(var5);
         if (var6 instanceof FFAFight) {
            var1.sendMessage("Spawning...");
            CitizensNPC var7 = new CitizensNPC("Botti", "Botti", var6.getArena().getLoc2());
            var7.startCombatTask(Collections.singletonList(var5.getUniqueId()), var6, CitizensNPC.Difficulty.HARD, StrikePractice.getAPI().getKit(var4[1]));
         } else {
            var1.sendMessage("You're not in a ffa fight");
         }
      }

      double var24;
      String var26;
      String var29;
      if (var4.length == 1) {
         if (!var4[0].equalsIgnoreCase("reload") && !var4[0].equalsIgnoreCase("rl")) {
            if (var4[0].equalsIgnoreCase("arenasworld")) {
               if (var1 instanceof Player) {
                  var1.sendMessage(ChatColor.GOLD + "Teleporting to the arenas world...");
                  ((Player)var1).teleport(new Location(Bukkit.getWorld(StrikePractice.A), 0.0D, 10.0D, 0.0D));
               }
            } else if (!var4[0].equalsIgnoreCase("debug") && !var4[0].equalsIgnoreCase("trace")) {
               if (var4[0].equalsIgnoreCase("setlobby") && var1 instanceof Player) {
                  this.ar.getConfig().set("lobby", (new D(((Player)var1).getLocation())).toString());
                  this.ar.saveConfig();
                  this.ar.L.fP();
                  var1.sendMessage(ChatColor.GOLD + "You have set the new lobby!");
                  var29 = this.ar.getConfig().getString("player-spawn-hider.spawn-corner1");
                  var26 = this.ar.getConfig().getString("player-spawn-hider.spawn-corner2");
                  if (var29 == null) {
                     this.ar.getConfig().set("player-spawn-hider.spawn-corner1", (new D(this.ar.L.fN().clone().add(100.0D, 100.0D, 100.0D))).toString());
                     this.ar.saveConfig();
                  }

                  if (var26 == null) {
                     this.ar.getConfig().set("player-spawn-hider.spawn-corner2", (new D(this.ar.L.fN().clone().add(-100.0D, -100.0D, -100.0D))).toString());
                     this.ar.saveConfig();
                  }
               } else if (var4[0].equalsIgnoreCase("block") && var1 instanceof Player) {
                  var5 = (Player)var1;
                  var5.getLocation().add(0.0D, -1.0D, 0.0D).getBlock().setType(Material.GLASS);
                  var5.teleport(var5.getLocation().getBlock().getLocation().add(0.5D, 1.0D, 0.5D));
               } else if (var4[0].equalsIgnoreCase("setediting") && var1 instanceof Player) {
                  this.ar.getConfig().set("editing-place", (new D(((Player)var1).getLocation())).toString());
                  this.ar.saveConfig();
                  var1.sendMessage(ChatColor.GOLD + "You have set the new editing place!");
               } else if (var4[0].equalsIgnoreCase("savekits")) {
                  this.ar.Z().B();
                  var1.sendMessage(ChatColor.GOLD + "Kits have been saved!");
               } else if (var4[0].equalsIgnoreCase("placeholders")) {
                  (new c()).a(var1);
               } else if (var4[0].equalsIgnoreCase("savearenas")) {
                  this.ar.Z().F();
                  var1.sendMessage(ChatColor.GOLD + "Arenas have been saved!");
               } else if (var4[0].equalsIgnoreCase("savelanguageitems")) {
                  this.ar.Z().I();
                  var1.sendMessage(ChatColor.GOLD + "Languageitems have been saved!");
               } else if (var4[0].equalsIgnoreCase("savespawnitems")) {
                  this.ar.Z().E();
                  var1.sendMessage(ChatColor.GOLD + "Spawnitems have been saved!");
               } else {
                  final Location var63;
                  if (var4[0].equalsIgnoreCase("flatfiletomysql")) {
                     if (!this.ar.H || !this.ar.O.da) {
                        var1.sendMessage(ChatColor.RED + "MySQL must be enabled and working to use that command!");
                        return true;
                     }

                     var63 = var1 instanceof Player ? ((Entity)var1).getLocation() : null;
                     if (var1 instanceof Player) {
                        var1.sendMessage(ChatColor.RED + "Move to cancel! Starting convertion in 5 seconds!");
                     } else {
                        var1.sendMessage(ChatColor.RED + "Starting convertion in 5 seconds. Stop the server immediately to cancel!");
                     }

                     (new BukkitRunnable() {
                        public void run() {
                           if (var1 != null) {
                              if (var63 == null || var63.distance(((Player)var1).getLocation()) < 1.0D) {
                                 var1.sendMessage(b.this.ar.X() + ChatColor.RED + "Convertion starting... You may disconnect from the server now.");
                                 (new BukkitRunnable() {
                                    public void run() {
                                       int var1x = 0;
                                       long var2 = System.currentTimeMillis();
                                       long var4 = System.currentTimeMillis();
                                       File var6 = new File(b.this.ar.getDataFolder(), "playerdata");
                                       var6.mkdirs();
                                       List var7 = Stats.allStatsColumns();
                                       File[] var8 = var6.listFiles();
                                       if (var1 != null) {
                                          var1.sendMessage(b.this.ar.X() + ChatColor.YELLOW + "Converting total of " + ChatColor.GOLD + var8.length + ChatColor.YELLOW + " files. This might take a while.");
                                       }

                                       ga.strikepractice.b.a.a var9 = new ga.strikepractice.b.a.a(b.this.ar);
                                       var9.initialize();
                                       File[] var10 = var8;
                                       int var11 = var8.length;

                                       for(int var12 = 0; var12 < var11; ++var12) {
                                          File var13 = var10[var12];

                                          try {
                                             if (var13.getName().endsWith(".yml")) {
                                                UUID var14 = UUID.fromString(var13.getName().replace(".yml", ""));
                                                Iterator var15 = var7.iterator();

                                                while(var15.hasNext()) {
                                                   String var16 = (String)var15.next();
                                                   int var17 = var9.a(var14, var16);
                                                   b.this.ar.aq().a(var14, var16, var17);
                                                }

                                                ++var1x;
                                                if (var1x % 10 == 0 && var4 + 10000L < System.currentTimeMillis()) {
                                                   var4 = System.currentTimeMillis();
                                                   if (var1 != null) {
                                                      double var24 = (double)(var1x / var8.length * 100);
                                                      long var25 = (long)(var8.length / var1x) * (System.currentTimeMillis() - var2);
                                                      long var19 = var25 / 1000L % 60L;
                                                      long var21 = (var25 - var19) / 1000L / 60L;
                                                      var1.sendMessage(b.this.ar.X() + ChatColor.YELLOW + "Converting files " + ChatColor.GOLD + var1x + "/" + var8.length + ChatColor.YELLOW + ". " + ChatColor.GOLD + var24 + "%" + ChatColor.YELLOW + "ready. Estimated time remaining: " + ChatColor.GOLD + var21 + " minutes and " + var19 + " seconds" + ChatColor.YELLOW + ".");
                                                   }
                                                }
                                             }
                                          } catch (Exception var23) {
                                          }
                                       }

                                       var1.sendMessage(b.this.ar.X() + ChatColor.RED + "File convertion successfully finished!");
                                    }
                                 }).runTaskAsynchronously(b.this.ar);
                              }

                              if (var1 != null && var63 != null && var63.distance(((Player)var1).getLocation()) > 1.0D) {
                                 var1.sendMessage(b.this.ar.X() + ChatColor.RED + "Convertion cancelled because you moved!");
                              }

                           }
                        }
                     }).runTaskLater(this.ar, 100L);
                  } else if (var4[0].equalsIgnoreCase("mysqltoflatfile")) {
                     if (!this.ar.H || !this.ar.O.da) {
                        var1.sendMessage(ChatColor.RED + "MySQL must be enabled and working to use that command!");
                        return true;
                     }

                     var63 = var1 instanceof Player ? ((Entity)var1).getLocation() : null;
                     if (var1 instanceof Player) {
                        var1.sendMessage(ChatColor.RED + "Move to cancel! Starting convertion in 5 seconds!");
                     } else {
                        var1.sendMessage(ChatColor.RED + "Starting convertion in 5 seconds. Stop the server immediately to cancel!");
                     }

                     (new BukkitRunnable() {
                        public void run() {
                           if (var1 != null) {
                              if (var63 == null || var63.distance(((Player)var1).getLocation()) < 1.0D) {
                                 var1.sendMessage(b.this.ar.X() + ChatColor.RED + "Convertion starting... You may disconnect from the server now.");
                                 (new BukkitRunnable() {
                                    public void run() {
                                       int var1x = 0;
                                       long var2 = System.currentTimeMillis();
                                       long var4 = System.currentTimeMillis();
                                       File var6 = new File(b.this.ar.getDataFolder(), "playerdata");
                                       var6.mkdirs();
                                       List var7 = Stats.allStatsColumns();
                                       File[] var8 = var6.listFiles();
                                       if (var1 != null) {
                                          var1.sendMessage(b.this.ar.X() + ChatColor.YELLOW + "Converting total of " + ChatColor.GOLD + var8.length + ChatColor.YELLOW + " files. This might take a while.");
                                       }

                                       ga.strikepractice.b.a.a var9 = new ga.strikepractice.b.a.a(b.this.ar);
                                       var9.initialize();
                                       File[] var10 = var8;
                                       int var11 = var8.length;

                                       for(int var12 = 0; var12 < var11; ++var12) {
                                          File var13 = var10[var12];

                                          try {
                                             if (var13.getName().endsWith(".yml")) {
                                                UUID var14 = UUID.fromString(var13.getName().replace(".yml", ""));
                                                Iterator var15 = var7.iterator();

                                                while(var15.hasNext()) {
                                                   String var16 = (String)var15.next();
                                                   int var17 = b.this.ar.aq().a(var14, var16);
                                                   var9.a(var14, var16, var17);
                                                }

                                                ++var1x;
                                                if (var1x % 10 == 0 && var4 + 10000L < System.currentTimeMillis()) {
                                                   var4 = System.currentTimeMillis();
                                                   if (var1 != null) {
                                                      double var24 = (double)(var1x / var8.length * 100);
                                                      long var25 = (long)(var8.length / var1x) * (System.currentTimeMillis() - var2);
                                                      long var19 = var25 / 1000L % 60L;
                                                      long var21 = (var25 - var19) / 1000L / 60L;
                                                      var1.sendMessage(b.this.ar.X() + ChatColor.YELLOW + "Converting files " + ChatColor.GOLD + var1x + "/" + var8.length + ChatColor.YELLOW + ". " + ChatColor.GOLD + var24 + "%" + ChatColor.YELLOW + "ready. Estimated time remaining: " + ChatColor.GOLD + var21 + " minutes and " + var19 + " seconds" + ChatColor.YELLOW + ".");
                                                   }
                                                }
                                             }
                                          } catch (Exception var23) {
                                          }
                                       }

                                       var1.sendMessage(b.this.ar.X() + ChatColor.RED + "File convertion successfully finished!");
                                       var1.sendMessage(ChatColor.RED + "Disabling MySQL now!");
                                       b.this.ar.O.close();
                                       b.this.ar.O = null;
                                       b.this.ar.H = false;
                                       b.this.ar.getConfig().set("database.mysql", false);
                                       b.this.ar.saveConfig();
                                       var1.sendMessage(ChatColor.RED + "MySQL disabled!");
                                    }
                                 }).runTaskAsynchronously(b.this.ar);
                              }

                              if (var1 != null && var63 != null && !(var63.distance(((Player)var1).getLocation()) < 1.0D)) {
                                 var1.sendMessage(b.this.ar.X() + ChatColor.RED + "Convertion cancelled because you moved!");
                              }

                           }
                        }
                     }).runTaskLater(this.ar, 100L);
                  } else {
                     Iterator var62;
                     if (var4[0].equalsIgnoreCase("savedata")) {
                        var1.sendMessage(ChatColor.RED + "Saving player data...");
                        var62 = Bukkit.getOnlinePlayers().iterator();

                        while(var62.hasNext()) {
                           Player var40 = (Player)var62.next();

                           try {
                              PlayerSettings.getPlayerSettings(var40).save();
                              DefaultPlayerStats var55 = DefaultPlayerStats.getStats(var40.getUniqueId(), false);
                              if (var55 != null) {
                                 var55.save(false);
                              }

                              this.ar.Y().getPlayerKits(var40).savePlayerKitsToFile();
                           } catch (Exception var14) {
                              var1.sendMessage(ChatColor.RED + "Error occurred while saving " + var40.getName() + "'s data, check console for the error.");
                              var14.printStackTrace();
                           }
                        }

                        e.eI();
                        var1.sendMessage(ChatColor.GREEN + "Saving completed!");
                     } else if (var4[0].equalsIgnoreCase("totalfights")) {
                        var62 = this.ar.kits.iterator();

                        while(var62.hasNext()) {
                           BattleKit var43 = (BattleKit)var62.next();
                           var1.sendMessage(ChatColor.BLUE + var43.getFancyName() + ChatColor.BLUE + " (" + var43.getName() + ChatColor.RESET + "" + ChatColor.BLUE + "): " + ChatColor.GREEN + this.ar.Z().p().getInt(var43.getName()));
                        }
                     } else if (var4[0].equalsIgnoreCase("findarena") && var1 instanceof Player) {
                        var24 = 500.0D;
                        Arena var57 = null;
                        Arena var44 = null;
                        Location var45 = ((Entity)var1).getLocation();
                        Iterator var52 = this.ar.M.iterator();

                        while(true) {
                           while(var52.hasNext()) {
                              Arena var58 = (Arena)var52.next();
                              if (var58.getCenter() != null && var58.getLoc1() != null && var58.getLoc2() != null) {
                                 if (var58.getCorner1() != null && var58.getCorner2() != null && t.a(var45, var58.getCorner1(), var58.getCorner2())) {
                                    var1.sendMessage(ChatColor.GOLD + "Inside arena corners of " + var58.getName());
                                 }

                                 if (var58.getCenter() != null && var58.getCenter().getWorld().getName().equals(var45.getWorld().getName())) {
                                    double var59 = var58.getCenter().distance(var45);
                                    if (var59 < var24) {
                                       var24 = var59;
                                       var44 = var57;
                                       var57 = var58;
                                    }
                                 }
                              } else {
                                 var1.sendMessage(var58.getName() + " is missing pos1, pos2 or the center");
                              }
                           }

                           if (var57 == null) {
                              var1.sendMessage(ChatColor.RED + "Couldn't find any arena...");
                           } else {
                              var1.sendMessage(ChatColor.GREEN + "Closest arena: " + var57.getName() + ", distance to center: " + n.h(var24));
                           }

                           if (var44 != null) {
                              double var56 = var44.getCenter().distance(((Player)var1).getLocation());
                              if (var56 < 300.0D) {
                                 boolean var60 = var56 < 50.0D;
                                 var1.sendMessage((var60 ? ChatColor.RED : ChatColor.GRAY) + "Second closest arena: " + var44.getName() + ", distance to center: " + n.h(var56));
                              }
                           }
                           break;
                        }
                     } else if (var4[0].equalsIgnoreCase("spawncorner1")) {
                        this.ar.getConfig().set("player-spawn-hider.spawn-corner1", (new D(((Player)var1).getLocation())).toString());
                        this.ar.saveConfig();
                        var1.sendMessage(ChatColor.BLUE + "Spawncorner1 set!");
                     } else if (var4[0].equalsIgnoreCase("spawncorner2")) {
                        this.ar.getConfig().set("player-spawn-hider.spawn-corner2", (new D(((Player)var1).getLocation())).toString());
                        this.ar.saveConfig();
                        var1.sendMessage(ChatColor.BLUE + "Spawncorner2 set!");
                     } else if (var4[0].equalsIgnoreCase("goldenhead")) {
                        if (var1 instanceof Player) {
                           var1.sendMessage(ChatColor.GREEN + "Giving a golden head!");
                           ((Player)var1).getInventory().addItem(new ItemStack[]{l.dz()});
                        }
                     } else if ((var4[0].equalsIgnoreCase("position") || var4[0].equalsIgnoreCase("pos") || var4[0].equalsIgnoreCase("loc")) && var1 instanceof Player) {
                        var1.sendMessage(ChatColor.GOLD + "Current position: " + ChatColor.YELLOW + (new D(((Player)var1).getLocation())).gb());
                     } else if (!var4[0].equalsIgnoreCase("update") && !var4[0].equalsIgnoreCase("checkupdate")) {
                        if (var4[0].equalsIgnoreCase("changelog")) {
                           var1.sendMessage(ChatColor.RED + "Changelog is no longer built-in.");
                           var1.sendMessage(ChatColor.GRAY + "https://www.spigotmc.org/resources/46906/updates");
                        }
                     } else {
                        var1.sendMessage(ChatColor.GOLD + "Checking for updates.");
                        ga.strikepractice.r.e.d((var1x) -> {
                           if (var1x) {
                              var1.sendMessage(ChatColor.RED + "Found a new update:");
                           } else {
                              var1.sendMessage(ChatColor.GREEN + "Didn't find any updates!");
                           }

                        });
                     }
                  }
               }
            } else if (!B.fQ()) {
               var1.sendMessage(ChatColor.GREEN + "Debug mode enabled (you will see more messages in the console).");
               B.l(true);
               if (var4[0].equalsIgnoreCase("trace")) {
                  var1.sendMessage(ChatColor.RED + "Trace mode enabled (you will see A LOT of messages in the console).");
                  B.m(true);
               }
            } else {
               var1.sendMessage(ChatColor.RED + "Debug/trace mode disabled.");
               B.l(false);
               B.m(false);
            }

            return true;
         } else {
            var1.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "WARNING! Reloading is not recommended. You might need to relog or/and restart to make all features work again.");
            long var61 = System.currentTimeMillis();
            Bukkit.getPluginManager().disablePlugin(this.ar);
            Bukkit.getPluginManager().enablePlugin(this.ar);
            long var50 = System.currentTimeMillis();
            var1.sendMessage(ChatColor.GOLD + "StrikePractice was reloaded in " + (var50 - var61) + " ms.");
            return true;
         }
      } else {
         int var34;
         int var36;
         if (var4.length >= 2 && var4[0].equalsIgnoreCase("flat") && var1 instanceof Player) {
            var5 = (Player)var1;
            var34 = Integer.parseInt(var4[1]);
            Location var48 = var5.getLocation();
            var36 = -var34 / 2;
            Material var42 = var4.length > 2 && Material.getMaterial(var4[2].toUpperCase()) != null ? Material.getMaterial(var4[2].toUpperCase()) : Material.GLASS;

            for(int var46 = 0; var46 < var34; ++var46) {
               for(int var54 = 0; var54 < var34; ++var54) {
                  var48.clone().add((double)(var36 + var46), 0.0D, (double)(var36 + var54)).getBlock().setType(var42);
               }
            }

            var1.sendMessage(ChatColor.GREEN + "Done!");
            return true;
         } else if (var4.length == 3 && var4[0].equalsIgnoreCase("setconfig")) {
            Object var53 = var4[2];

            try {
               var53 = Boolean.parseBoolean(var4[2]);
            } catch (Exception var16) {
            }

            try {
               var53 = Double.parseDouble(var4[2]);
            } catch (Exception var15) {
            }

            this.ar.getConfig().set(var4[1], var53);
            this.ar.saveConfig();
            var1.sendMessage(ChatColor.YELLOW + "Config updated:");
            var1.sendMessage(var4[1] + ": " + var4[2]);
            return true;
         } else if (var4.length > 1 && (var4[0].equalsIgnoreCase("placeholder") || var4[0].equalsIgnoreCase("ph"))) {
            StringBuilder var51 = new StringBuilder();

            for(var34 = 1; var34 < var4.length; ++var34) {
               var51.append(var4[var34]);
            }

            var1.sendMessage(this.ar.ah().a(var1 instanceof Player ? (Player)var1 : null, var51.toString(), "", true));
            return true;
         } else if (var4.length > 1 && var4[0].equalsIgnoreCase("resetelo")) {
            BattleKit var49 = BattleKit.getKit(var4[1]);
            if (var49 != null && var49.isElo()) {
               var1.sendMessage(ChatColor.RED + "Resetting stats... This might take a while");
               C.c(() -> {
                  String var2 = Stats.eloColumn(var49);
                  Iterator var3 = Bukkit.getOnlinePlayers().iterator();

                  while(var3.hasNext()) {
                     Player var4 = (Player)var3.next();
                     DefaultPlayerStats var5 = DefaultPlayerStats.getStats(var4.getUniqueId());
                     if (var5 != null) {
                        HashMap var6 = var5.getElos();
                        if (var6.containsKey(var2)) {
                           var6.put(var2, ga.strikepractice.b.a.cM);
                           var5.save(true);
                        }
                     }
                  }

                  OfflinePlayer[] var9 = Bukkit.getOfflinePlayers();
                  int var10 = var9.length;

                  for(int var11 = 0; var11 < var10; ++var11) {
                     OfflinePlayer var12 = var9[var11];
                     DefaultPlayerStats var7 = DefaultPlayerStats.getStats(var12.getUniqueId(), false, false);
                     if (var7 != null) {
                        HashMap var8 = var7.getElos();
                        if (var8.containsKey(var2)) {
                           var8.put(var2, ga.strikepractice.b.a.cM);
                           var7.save(true);
                        }
                     }
                  }

                  if (var1 != null) {
                     var1.sendMessage(ChatColor.GREEN + var49.getName() + "'s elos have been reset.");
                  }

                  if (Bukkit.getConsoleSender() != var1) {
                     Bukkit.getLogger().info(var49.getName() + "'s elos have been reset by " + var1.getName());
                  }

               });
            } else {
               var1.sendMessage(ChatColor.RED + "The kit was not found or is not a ranked kit!");
            }

            return true;
         } else if (var4.length > 1 && var4[0].equalsIgnoreCase("resetstats")) {
            var29 = var4.length > 2 ? var4[2] : "all";
            Bukkit.getLogger().info("Logging information while resetting stats:");
            var1.sendMessage(ChatColor.RED + "Loading player profile...");
            if (var1 != Bukkit.getConsoleSender()) {
               Bukkit.getLogger().info(ChatColor.RED + "Loading player profile...");
            }

            C.c(() -> {
               OfflinePlayer var3 = Bukkit.getOfflinePlayer(var4[1]);
               if (var3.hasPlayedBefore()) {
                  var1.sendMessage(ChatColor.RED + "Resetting stats...");
                  if (var1 != Bukkit.getConsoleSender()) {
                     Bukkit.getLogger().info(ChatColor.RED + "Resetting stats...");
                  }

                  DefaultPlayerStats var4x = DefaultPlayerStats.getStats(var3.getUniqueId(), true, false);
                  Iterator var5 = var4x.getElos().entrySet().iterator();

                  while(true) {
                     Entry var6;
                     do {
                        if (!var5.hasNext()) {
                           if (var29.equalsIgnoreCase("any") || var29.equalsIgnoreCase("all") || var29.equalsIgnoreCase("kills")) {
                              var1.sendMessage(ChatColor.RED + "Kills= old: " + var4x.getKills() + ", new: " + 0);
                              if (var1 != Bukkit.getConsoleSender()) {
                                 Bukkit.getLogger().info(ChatColor.RED + "Kills= old: " + var4x.getKills() + ", new: " + 0);
                              }

                              var4x.setKills(0);
                           }

                           if (var29.equalsIgnoreCase("any") || var29.equalsIgnoreCase("all") || var29.equalsIgnoreCase("deaths")) {
                              var1.sendMessage(ChatColor.RED + "Deaths= old: " + var4x.getDeaths() + ", new: " + 0);
                              if (var1 != Bukkit.getConsoleSender()) {
                                 Bukkit.getLogger().info(ChatColor.RED + "Deaths= old: " + var4x.getDeaths() + ", new: " + 0);
                              }

                              var4x.setDeaths(0);
                           }

                           if (var29.equalsIgnoreCase("any") || var29.equalsIgnoreCase("all") || var29.toLowerCase().contains("party")) {
                              var1.sendMessage(ChatColor.RED + "Party Wins= old: " + var4x.getPartyVsPartyWins() + ", new: " + 0);
                              if (var1 != Bukkit.getConsoleSender()) {
                                 Bukkit.getLogger().info(ChatColor.RED + "Party Wins= old: " + var4x.getPartyVsPartyWins() + ", new: " + 0);
                              }

                              var4x.setPartyVsPartyWins(0);
                           }

                           if (var29.equalsIgnoreCase("any") || var29.equalsIgnoreCase("all") || var29.equalsIgnoreCase("brackets")) {
                              var1.sendMessage(ChatColor.RED + "Brackets Wins= old: " + var4x.getBracketsWins() + ", new: " + 0);
                              if (var1 != Bukkit.getConsoleSender()) {
                                 Bukkit.getLogger().info(ChatColor.RED + "Brackets Wins= old: " + var4x.getBracketsWins() + ", new: " + 0);
                              }

                              var4x.setBracketsWins(0);
                           }

                           if (var29.equalsIgnoreCase("any") || var29.equalsIgnoreCase("all") || var29.equalsIgnoreCase("lms")) {
                              var1.sendMessage(ChatColor.RED + "LMS Wins= old: " + var4x.getLMSWins() + ", new: " + 0);
                              if (var1 != Bukkit.getConsoleSender()) {
                                 Bukkit.getLogger().info(ChatColor.RED + "LMS Wins= old: " + var4x.getLMSWins() + ", new: " + 0);
                              }

                              var4x.setLmsWins(0);
                           }

                           var1.sendMessage(ChatColor.RED + "Saving stats...");
                           if (var1 != Bukkit.getConsoleSender()) {
                              Bukkit.getLogger().info(ChatColor.RED + "Saving stats...");
                           }

                           var4x.save();
                           var1.sendMessage(ChatColor.RED + var3.getName() + "(UUID" + var3.getUniqueId() + ") '" + var29 + "' stats have been reset!");
                           Bukkit.getLogger().info(var1.getName() + " has reset " + var3.getName() + "(UUID" + var3.getUniqueId() + ")'s stats: " + var29);
                           return;
                        }

                        var6 = (Entry)var5.next();
                     } while(!var29.equalsIgnoreCase("any") && !var29.equalsIgnoreCase("all") && !var29.equalsIgnoreCase("elo") && !var29.equalsIgnoreCase((String)var6.getKey()));

                     var1.sendMessage(ChatColor.RED + (String)var6.getKey() + "= old: " + var6.getValue() + ", new: " + ga.strikepractice.b.a.cM);
                     if (var1 != Bukkit.getConsoleSender()) {
                        Bukkit.getLogger().info(ChatColor.RED + (String)var6.getKey() + "= old: " + var6.getValue() + ", new: " + ga.strikepractice.b.a.cM);
                     }

                     var4x.getElos().put((String)var6.getKey(), ga.strikepractice.b.a.cM);
                  }
               } else {
                  var1.sendMessage(ChatColor.RED + "That player has not played on this server!");
               }
            });
            return true;
         } else {
            World var23;
            if (var4.length > 1 && var1 instanceof Player) {
               if (var4[0].equalsIgnoreCase("rename") || var4[0].equalsIgnoreCase("renamehand")) {
                  var5 = (Player)var1;
                  ItemStack var32 = var5.getItemInHand();
                  if (!r.h(var32)) {
                     var1.sendMessage(ChatColor.RED + "Hold something in your hand.");
                     return true;
                  }

                  ItemStack var47 = var5.getItemInHand();
                  ItemMeta var39 = var47.getItemMeta();
                  var39.setDisplayName(f.K(var4[1].replace("_", " ")));
                  var47.setItemMeta(var39);
                  var5.getInventory().setItemInHand(var47);
                  var5.updateInventory();
                  var1.sendMessage(ChatColor.GOLD + "The item in your hand has been renamed!");
                  return true;
               }

               ga.strikepractice.g.c var37;
               if (var4[0].toLowerCase().contains("airhorizontal")) {
                  if (this.ar.ak() == null) {
                     var1.sendMessage(ChatColor.RED + "Knockback is not enabled in the config!");
                     return true;
                  }

                  try {
                     var24 = Double.parseDouble(var4[1]);
                  } catch (IllegalArgumentException var17) {
                     var1.sendMessage(ChatColor.RED + "That's not a number!");
                     return true;
                  }

                  var37 = this.ar.ak().y(var4[0].replace("airhorizontal", ""));
                  var37.b(var24);
                  var37.save();
                  var1.sendMessage(ChatColor.GREEN + "KB set: " + var24);
                  return true;
               }

               if (var4[0].toLowerCase().contains("airvertical")) {
                  if (this.ar.ak() == null) {
                     var1.sendMessage(ChatColor.RED + "Knockback is not enabled in the config!");
                     return true;
                  }

                  try {
                     var24 = Double.parseDouble(var4[1]);
                  } catch (IllegalArgumentException var18) {
                     var1.sendMessage(ChatColor.RED + "That's not a number!");
                     return true;
                  }

                  var37 = this.ar.ak().y(var4[0].replace("airvertical", ""));
                  var37.c(var24);
                  var37.save();
                  var1.sendMessage(ChatColor.GREEN + "KB set: " + var24);
                  return true;
               }

               if (var4[0].toLowerCase().contains("horizontal")) {
                  if (this.ar.ak() == null) {
                     var1.sendMessage(ChatColor.RED + "Knockback is not enabled in the config!");
                     return true;
                  }

                  try {
                     var24 = Double.parseDouble(var4[1]);
                  } catch (IllegalArgumentException var19) {
                     var1.sendMessage(ChatColor.RED + "That's not a number!");
                     return true;
                  }

                  var37 = this.ar.ak().y(var4[0].replace("horizontal", ""));
                  var37.d(var24);
                  var37.save();
                  var1.sendMessage(ChatColor.GREEN + "KB set: " + var24);
                  return true;
               }

               if (var4[0].toLowerCase().contains("vertical")) {
                  if (this.ar.ak() == null) {
                     var1.sendMessage(ChatColor.RED + "Knockback is not enabled in the config!");
                     return true;
                  }

                  try {
                     var24 = Double.parseDouble(var4[1]);
                  } catch (IllegalArgumentException var20) {
                     var1.sendMessage(ChatColor.RED + "That's not a number!");
                     return true;
                  }

                  var37 = this.ar.ak().y(var4[0].replace("vertical", ""));
                  var37.e(var24);
                  var37.save();
                  var1.sendMessage(ChatColor.GREEN + "KB set: " + var24);
                  return true;
               }

               if (var4[0].equalsIgnoreCase("onlycombo")) {
                  if (this.ar.ak() == null) {
                     var1.sendMessage(ChatColor.RED + "Knockback is not enabled in the config!");
                     return true;
                  }

                  this.ar.ak().g(!this.ar.ak().cN());
                  this.ar.ak().save();
                  var1.sendMessage(ChatColor.GREEN + "Only-combo: " + this.ar.ak().cN());
                  return true;
               }

               if (var4[0].equalsIgnoreCase("addmeta")) {
                  var29 = var4[1];
                  ((Player)var1).setMetadata(var29, new FixedMetadataValue(this.ar, true));
                  var1.sendMessage(ChatColor.GREEN + "Meta added: " + var29);
                  return true;
               }

               if (var4[0].equalsIgnoreCase("removemeta")) {
                  var29 = var4[1];
                  ((Player)var1).removeMetadata(var29, this.ar);
                  var1.sendMessage(ChatColor.GREEN + "Meta removed: " + var29);
                  return true;
               }

               if (var4[0].equalsIgnoreCase("config")) {
                  var29 = var4[1];
                  var1.sendMessage(var29 + ": " + this.ar.getConfig().get(var29));
                  return true;
               }

               if (var4[0].equalsIgnoreCase("tempworld")) {
                  var29 = var4[1];
                  var1.sendMessage(ChatColor.RED + "Creating a temporary world: " + var29);
                  World var31 = (new WorldCreator(var29)).createWorld();
                  var1.sendMessage(ChatColor.RED + "The world will be deleted when the plugin is disabled!");
                  ((Player)var1).teleport(var31.getSpawnLocation().add(0.0D, 5.0D, 0.0D));
                  return true;
               }

               if (var4[0].equalsIgnoreCase("cancel")) {
                  var5 = Bukkit.getPlayer(var4[1]);
                  if (var5 == null) {
                     var1.sendMessage(ChatColor.RED + "The player is not online!");
                     return true;
                  }

                  var6 = AbstractFight.getCurrentFight(var5);
                  if (var6 == null) {
                     var1.sendMessage(ChatColor.RED + "The player is not in a match.");
                     return true;
                  }

                  String var35 = "";

                  for(var36 = 2; var36 < var4.length; ++var36) {
                     var35 = var35 + " " + var4[var36];
                  }

                  var1.sendMessage(ChatColor.RED + "Cancelling " + var5.getName() + "'s fight.");
                  var6.forceEnd(var35.length() == 0 ? ChatColor.RED + "The fight was forced to end!" : f.K(var35));
                  Iterator var38 = Bukkit.getOnlinePlayers().iterator();

                  while(var38.hasNext()) {
                     Player var41 = (Player)var38.next();
                     if (ga.strikepractice.k.b.a(var41, ga.strikepractice.k.a.py)) {
                        var41.sendMessage(ChatColor.RED + var1.getName() + " cancelled " + var5.getName() + "'s fight" + (var35.length() > 0 ? ": " + var35 : "."));
                     }
                  }

                  return true;
               }

               if (var4[0].equalsIgnoreCase("world")) {
                  var23 = null;
                  Iterator var27 = Bukkit.getWorlds().iterator();

                  while(var27.hasNext()) {
                     World var33 = (World)var27.next();
                     if (var33.getName().equalsIgnoreCase(var4[1])) {
                        var23 = var33;
                     }
                  }

                  if (var23 == null) {
                     var1.sendMessage(ChatColor.RED + "Invalid world!");
                  } else {
                     ((Player)var1).teleport(var23.getSpawnLocation().add(0.0D, 5.0D, 0.0D));
                  }

                  return true;
               }

               if (var4[0].equalsIgnoreCase("speed")) {
                  try {
                     var24 = (double)Integer.parseInt(var4[1]);
                     ((Player)var1).setWalkSpeed((float)(var24 / 10.0D));
                     ((Player)var1).setFlySpeed((float)(var24 / 10.0D));
                  } catch (IllegalArgumentException var21) {
                     var1.sendMessage(ChatColor.YELLOW + "/strikepractice speed <1-10>");
                  }

                  return true;
               }

               if (var4[0].equalsIgnoreCase("info")) {
                  this.c((Player)var1, var4[1]);
                  return true;
               }
            }

            if (var4.length == 3) {
               if (var4[0].equalsIgnoreCase("stackarenas")) {
                  var23 = Bukkit.getWorld(var4[1]);
                  if (var23 == null) {
                     var1.sendMessage(ChatColor.RED + "That world doesn't exist.");
                  } else if (var23.getPlayers().size() > 0) {
                     var1.sendMessage(ChatColor.RED + "Could not unload! The world still has players.");
                  } else {
                     var26 = var4[2];
                     var1.sendMessage(ChatColor.BLUE + "Creating the world " + var26 + " and stacking arenas in the world " + var26);
                     this.ar.ai().a(var23, var26);
                  }

                  return true;
               }

               if (var4[0].equalsIgnoreCase("rollbackelo") || var4[0].equalsIgnoreCase("revive") || var4[0].equalsIgnoreCase("reviveelo")) {
                  var5 = Bukkit.getPlayer(var4[1]);
                  if (var5 == null) {
                     C.c(new Runnable() {
                        public void run() {
                           OfflinePlayer var1x = Bukkit.getOfflinePlayer(var4[1]);
                           Bukkit.getScheduler().runTask(b.this.ar, () -> {
                              if (var1 != null) {
                                 UUID var3 = null;

                                 try {
                                    var3 = UUID.fromString(var4[1]);
                                 } catch (IllegalArgumentException var12) {
                                 }

                                 if (!var1x.hasPlayedBefore() && var3 == null) {
                                    var1.sendMessage(ChatColor.RED + "That player has not played on this server!");
                                 } else {
                                    if (var3 == null) {
                                       var3 = var1x.getUniqueId();
                                    }

                                    boolean var4x = false;

                                    int var13;
                                    try {
                                       var13 = Integer.parseInt(var4[2]);
                                    } catch (IllegalArgumentException var11) {
                                       var1.sendMessage(ChatColor.RED + "/sprac rollbackelo <online player:uuid> <number of fights>");
                                       return;
                                    }

                                    if (!Duel.eloFights.containsKey(var3)) {
                                       var1.sendMessage(ChatColor.RED + "No recent ranked matchs found!");
                                       return;
                                    }

                                    List var5 = (List)Duel.eloFights.get(var3);
                                    var1.sendMessage(ChatColor.RED + "Reviving " + var3 + "'s " + var13 + " previous ranked fights...");
                                    ListIterator var6 = var5.listIterator(var5.size());
                                    DefaultPlayerStats var7 = DefaultPlayerStats.getStats(var3, true, false);

                                    while(var6.hasPrevious() && var7 != null) {
                                       --var13;
                                       EloChange var8 = (EloChange)var6.previous();
                                       int var9 = var7.getElo(var8.getKit());
                                       int var10 = var9 - var8.getEloChange();
                                       var7.getElos().put(Stats.eloColumn(var8.getKit()), var10);
                                       var1.sendMessage(ChatColor.GRAY + "Kit: " + var8.getKit().getName() + ", old elo: " + var9 + ", new elo: " + var10 + ", change: " + var8.getEloChange());
                                       if (var13 == 0) {
                                          break;
                                       }
                                    }

                                    var1.sendMessage(ChatColor.GREEN + "Done. Saving stats...");
                                    var7.save(true);
                                    var1.sendMessage(ChatColor.GREEN + "Completed!");
                                 }
                              }

                           });
                        }
                     });
                  } else {
                     UUID var25 = var5.getUniqueId();
                     boolean var28 = false;

                     int var30;
                     try {
                        var30 = Integer.parseInt(var4[2]);
                     } catch (IllegalArgumentException var22) {
                        var1.sendMessage(ChatColor.RED + "/sprac rollbackelo <online player:uuid> <number of fights>");
                        return true;
                     }

                     if (!Duel.eloFights.containsKey(var25)) {
                        var1.sendMessage(ChatColor.RED + "No recent ranked matchs found!");
                        return true;
                     }

                     List var8 = (List)Duel.eloFights.get(var25);
                     var1.sendMessage(ChatColor.RED + "Reviving " + var25 + "'s " + var30 + " previous ranked fights...");
                     ListIterator var9 = var8.listIterator(var8.size());
                     DefaultPlayerStats var10 = DefaultPlayerStats.getStats(var25, true, false);

                     while(var9.hasPrevious() && var10 != null) {
                        EloChange var11 = (EloChange)var9.previous();
                        int var12 = var10.getElo(var11.getKit());
                        int var13 = var12 + var11.getEloChange();
                        var10.getElos().put(Stats.eloColumn(var11.getKit()), var13);
                        var1.sendMessage(ChatColor.GRAY + "Kit: " + var11.getKit().getName() + ", old elo: " + var12 + ", new elo: " + var13);
                     }

                     var1.sendMessage(ChatColor.GREEN + "Done, saving stats...");
                     var10.save(true);
                     var1.sendMessage(ChatColor.GREEN + "Saving completed!");
                  }

                  return true;
               }
            }

            var1.sendMessage(ChatColor.GOLD + "StrikePractice - Toppe's PvP Practice Plugin. Version: " + this.ar.getDescription().getVersion());
            var1.sendMessage(ChatColor.YELLOW + "/sprac setlobby");
            var1.sendMessage(ChatColor.YELLOW + "/sprac setediting");
            var1.sendMessage(ChatColor.YELLOW + "/sprac reload");
            var1.sendMessage(ChatColor.YELLOW + "/sprac info <player>");
            var1.sendMessage(ChatColor.YELLOW + "/sprac arenasworld");
            var1.sendMessage(ChatColor.YELLOW + "/sprac renamehand <name>");
            var1.sendMessage(ChatColor.YELLOW + "/sprac savedata|savearenas|savekits|savelanguageitems|savespawnitems");
            var1.sendMessage(ChatColor.YELLOW + "/sprac position");
            var1.sendMessage(ChatColor.YELLOW + "/sprac totalfights");
            var1.sendMessage(ChatColor.YELLOW + "/sprac spawncorner1|spawncorner2");
            var1.sendMessage(ChatColor.YELLOW + "/sprac cancel <player>");
            var1.sendMessage(ChatColor.YELLOW + "/sprac resetelo <kit> (resets everyone's elo)");
            var1.sendMessage(ChatColor.YELLOW + "/sprac resetstats <player> [elo, kitName, deaths, kills, lms, brackets, partywins, all]");
            var1.sendMessage(ChatColor.YELLOW + "/sprac reviveelo <player:uuid> <number of fights>");
            var1.sendMessage(ChatColor.YELLOW + "/sprac goldenhead");
            var1.sendMessage(ChatColor.RED + "NEW: /sprac placeholders - browse placeholders");
            var1.sendMessage(ChatColor.YELLOW + "/sprac placeholder <text> - test a placeholder");
            if (this.ar.ak() == null) {
               var1.sendMessage(ChatColor.GRAY + "(knockback disabled)");
            } else {
               var1.sendMessage(ChatColor.GOLD + "Knockback:");
               var1.sendMessage(ChatColor.YELLOW + "/sprac onlycombo - only combo mode ");
               var1.sendMessage(ChatColor.YELLOW + "/sprac horizontal/vertical <value>");
               var1.sendMessage(ChatColor.YELLOW + "/sprac airhorizontal/vertical <value>");
               var1.sendMessage(ChatColor.YELLOW + "/sprac combohorizontal/vertical <value>");
               var1.sendMessage(ChatColor.YELLOW + "/sprac comboairhorizontal/vertical <value>");
            }

            return true;
         }
      }
   }

   public void c(Player var1, String var2) {
      Player var3 = Bukkit.getPlayer(var2);
      if (var3 != null) {
         this.a((Player)var1, (OfflinePlayer)var3);
      } else {
         C.c(() -> {
            OfflinePlayer var3 = Bukkit.getOfflinePlayer(var2);
            Bukkit.getScheduler().runTask(this.ar, () -> {
               if (var1 != null) {
                  if (var3.hasPlayedBefore()) {
                     this.a(var1, var3);
                  } else {
                     var1.sendMessage(ChatColor.RED + "That player has not played on this server!");
                  }
               }

            });
         });
      }
   }

   private void a(Player var1, OfflinePlayer var2) {
      String var3 = var2.getName();
      UUID var4 = var2.getUniqueId();
      Inventory var5 = Bukkit.createInventory(new b.a(var4), 27, ChatColor.RED + "SP Info: " + var3);
      ga.strikepractice.b.a.b var6 = new ga.strikepractice.b.a.b(this.ar, var4, false);
      YamlConfiguration var7 = var6.au();
      var5.setItem(4, s.a(Material.SKULL_ITEM, ChatColor.BLUE + "Name: " + var3, (byte)3, (String[])(ChatColor.GRAY + "UUID: " + var4.toString())));
      var5.setItem(1, s.a(Material.BOOK_AND_QUILL, var7 == null ? ChatColor.RED + "Data file exists: false" : ChatColor.YELLOW + "Data file exists: true"));
      SimpleDateFormat var8 = new SimpleDateFormat("yyyy/MM/dd HH:mm");
      var5.setItem(7, s.a(Material.COMPASS, ChatColor.BLUE + "Played", (byte)0, (List)Arrays.asList(ChatColor.GRAY + "First played: " + var8.format(var2.getFirstPlayed()), ChatColor.GRAY + "Last played: " + var8.format(var2.getLastPlayed()))));
      if (var7 != null) {
         BattleKit var9 = this.ar.Y().a(var4, var6).getCustomKit();
         var5.setItem(10, s.a(var9.getIcon().getType(), var9.getName(), (byte)0, (List)Arrays.asList(ChatColor.RED + "Click to preview the player's custom kit.", ChatColor.RED + "Middle click to delete the player's custom kit.")));
         if (!var2.isOnline()) {
            var5.setItem(16, s.a(Material.PAPER, ChatColor.BLUE + "Language: " + (var7.get("language") == null ? ga.strikepractice.h.e.T((Player)null) : var7.getString("language"))));
         }
      }

      if (var2.isOnline()) {
         Player var13 = (Player)var2;
         var5.setItem(16, s.a(Material.PAPER, ChatColor.BLUE + "Language: " + PlayerSettings.getPlayerSettings(var13.getUniqueId()).getLanguage()));
         if (AbstractFight.isInFight(var13)) {
            var5.setItem(19, s.a(Material.DIAMOND_SWORD, ChatColor.BLUE + "In Fight: true", (byte)0, (String[])(ChatColor.RED + "Click to teleport to the fight arena (Arena: " + (AbstractFight.getCurrentFight(var13).getArena() == null ? "unknown arena" : AbstractFight.getCurrentFight(var13).getArena().getName()) + ")")));
         } else {
            var5.setItem(19, s.a(Material.DIAMOND_SWORD, ChatColor.BLUE + "In Fight: false"));
         }

         var5.setItem(22, s.a(Material.FEATHER, ChatColor.BLUE + "Gamemode and flying", (byte)0, (List)Arrays.asList(ChatColor.GRAY + "Gamemode: " + var13.getGameMode(), ChatColor.GRAY + "Flying: " + var13.isFlying(), ChatColor.GRAY + "Allow Flight: " + var13.getAllowFlight())));
         Fight var10 = AbstractFight.getCurrentFight(var13);
         String var11 = "n/a";
         if (var10 instanceof Duel) {
            Duel var12 = (Duel)var10;
            if (var12.getP1().equals(var13.getName())) {
               var11 = var12.getP2();
            } else if (var12.getP2().equals(var13.getName())) {
               var11 = var12.getP1();
            }
         }

         var5.setItem(13, s.a(Material.ENCHANTED_BOOK, ChatColor.BLUE + "StrikePractice Info:", (byte)0, (List)Arrays.asList(ChatColor.GRAY + "Spectator: " + this.ar.ac().isSpectator(var13), ChatColor.GRAY + "Max no damage ticks: " + var13.getMaximumNoDamageTicks() + " - No damage ticks: " + var13.getNoDamageTicks() + " - Kit: " + (BattleKit.getCurrentKit(var13) == null ? "n/a" : BattleKit.getCurrentKit(var13).getName()), ChatColor.GRAY + "In event: " + PvPEvent.getEventString(var13), ChatColor.GRAY + "1v1 Opponent: " + var11)));
         Party var14 = Party.getParty(var13);
         if (var14 != null) {
            var5.setItem(25, s.a(Material.EYE_OF_ENDER, ChatColor.BLUE + "In Party: true", (byte)0, (List)Arrays.asList(ChatColor.YELLOW + "Owner: " + var14.getOwner(), ChatColor.GRAY + "Members: " + var14.getMembersNames().size(), ChatColor.GRAY + "In Fight: " + var14.isInFight(), ChatColor.RED + "Click to disband")));
         } else {
            var5.setItem(25, s.a(Material.EYE_OF_ENDER, ChatColor.BLUE + "In Party: false"));
         }
      }

      var1.openInventory(var5);
   }

   @EventHandler
   public void a(InventoryClickEvent var1) {
      if (var1.getCurrentItem() != null && var1.getWhoClicked() instanceof Player && var1.getInventory() != null && var1.getClickedInventory() != null && ga.strikepractice.k.b.a(var1.getWhoClicked(), ga.strikepractice.k.a.pz)) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCurrentItem();
         Player var5;
         UUID var10;
         if (var1.getClickedInventory().getHolder() != null && var1.getClickedInventory().getHolder() instanceof b.a && var1.getView().getTitle() != null && var1.getView().getTitle().startsWith(ChatColor.RED + "SP Info: ")) {
            var1.setCancelled(true);
            var10 = ((b.a)var1.getClickedInventory().getHolder()).getUUID();
            if (var3 == null || var3.getItemMeta() == null || var3.getItemMeta().getLore() == null) {
               return;
            }

            String var12;
            Inventory var15;
            if (var1.getSlot() == 25 && !var3.getItemMeta().getLore().isEmpty()) {
               var12 = Bukkit.getServer().getOfflinePlayer(var10).getName();
               var15 = Bukkit.createInventory((InventoryHolder)null, 27, "Disband party: " + var12);
               var15.setItem(11, s.a(Material.WOOL, ChatColor.DARK_RED + "Disband " + var12 + " 's party.", (byte)14, (String[])()));
               var15.setItem(15, s.a(Material.WOOL, ChatColor.DARK_RED + "Cancel", (byte)5, (String[])()));
               var2.closeInventory();
               var2.openInventory(var15);
            } else if (var1.getSlot() == 19) {
               var5 = Bukkit.getPlayer(var10);
               if (var5 == null) {
                  var2.closeInventory();
                  var2.sendMessage(ChatColor.RED + "The player is no longer online!");
               }

               Fight var14 = AbstractFight.getCurrentFight(var5);
               if ((var14 == null || var14.getArena() != null) && var14.getArena().getCenter() != null && Bukkit.getWorld(var14.getArena().getCenter().getWorld().getName()) != null) {
                  var2.closeInventory();
                  var2.sendMessage(ChatColor.GRAY + "Teleporting...");
                  N.e(var2, var14.getArena().getCenter());
               } else {
                  var2.sendMessage(ChatColor.RED + "Invalid arena!");
               }
            } else if (var1.getSlot() == 10) {
               if (var1.getClick().equals(ClickType.MIDDLE)) {
                  var12 = Bukkit.getServer().getOfflinePlayer(var10).getName();
                  var15 = Bukkit.createInventory((InventoryHolder)null, 27, "Delete kit: " + var12);
                  var15.setItem(11, s.a(Material.WOOL, ChatColor.DARK_RED + "Delete " + var12 + " 's custom kit.", (byte)14, (String[])()));
                  var15.setItem(15, s.a(Material.WOOL, ChatColor.DARK_RED + "Cancel", (byte)5, (String[])()));
                  var2.closeInventory();
                  var2.openInventory(var15);
               } else {
                  var5 = Bukkit.getPlayer(var10);
                  if (var5 != null) {
                     ga.strikepractice.m.a.a(var2, this.ar.Y().getPlayerKits(var5).getCustomKit(), this.ar);
                  } else {
                     ga.strikepractice.b.a.b var17 = new ga.strikepractice.b.a.b(this.ar, var10, false);
                     YamlConfiguration var18 = var17.au();
                     if (var18 != null) {
                        BattleKit var19 = this.ar.Y().a(var10, var17).getCustomKit();
                        ga.strikepractice.m.a.a(var2, var19, this.ar);
                     }
                  }
               }
            }
         } else if (var1.getView().getTitle().startsWith("Disband party: ")) {
            if (var3.getDurability() == 5) {
               var2.closeInventory();
            } else if (var3.getDurability() == 14) {
               String var4 = var1.getView().getTitle().replace("Disband party: ", "");
               var5 = Bukkit.getPlayer(var4);
               if (var5 == null) {
                  var2.sendMessage(ChatColor.RED + "Player not found!");
               } else {
                  Party var6 = Party.getParty(var5);
                  if (var6 == null) {
                     var2.sendMessage(ChatColor.RED + "That player doesn't have a party anymore.");
                  } else {
                     Iterator var7 = var6.getMembersNames().iterator();

                     while(var7.hasNext()) {
                        String var8 = (String)var7.next();
                        Player var9 = Bukkit.getPlayer(var8);
                        this.ar.a(var9, "party-was-deleted");
                     }

                     var6.disbandParty();
                     var2.sendMessage(ChatColor.BLUE + "The party was disbanded!");
                  }
               }

               var2.closeInventory();
            }
         } else if (var1.getView().getTitle().startsWith("Delete kit: ")) {
            var10 = Bukkit.getOfflinePlayer(var1.getView().getTitle().replace("Delete kit: ", "")).getUniqueId();
            if (var3.getDurability() == 5) {
               var2.closeInventory();
            } else if (var3.getDurability() == 14) {
               ga.strikepractice.b.a.b var11 = new ga.strikepractice.b.a.b(this.ar, var10, false);
               YamlConfiguration var13 = var11.au();
               if (var13 != null) {
                  Player var16 = Bukkit.getPlayer(var10);
                  if (var16 != null) {
                     this.ar.Y().f(var16, this.ar.Y().ej());
                  }

                  var13.set("kit", this.ar.Y().ej());
                  Bukkit.getLogger().info(var2.getName() + " has reset the custom kit of the uuid " + var10);
                  var2.sendMessage(ChatColor.RED + "You have reset the player's custom kit!");
                  var2.closeInventory();
               }
            }
         }
      }

   }

   static class a implements InventoryHolder {
      private final UUID uuid;

      public a(UUID var1) {
         this.uuid = var1;
      }

      public UUID getUUID() {
         return this.uuid;
      }

      public Inventory getInventory() {
         return null;
      }
   }
}
