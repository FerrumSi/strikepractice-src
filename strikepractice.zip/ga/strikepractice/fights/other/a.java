package ga.strikepractice.fights.other;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.c.b;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.playerkits.b.d;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.G;
import ga.strikepractice.utils.u;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class a implements CommandExecutor, Listener {
   private final StrikePractice fS;
   private boolean fT;
   private final Map<Arena, FFAFight> fU = new ConcurrentHashMap();
   private long fV;
   private final long fW;
   public final boolean fX;

   public a(StrikePractice var1) {
      this.fS = var1;
      this.fX = var1.getConfig().getInt("autostack-arenas-on-enable") > 0 && var1.getConfig().getBoolean("use-copied-arena-for-ffa");
      this.fW = var1.getConfig().getLong("ffa-reset-delay") * 20L * 60L;
      (new ga.strikepractice.fights.other.a.a()).runTaskTimer(var1, this.fW, this.fW);
      this.fV = System.currentTimeMillis() + 30000L;
      Iterator var2 = var1.M.iterator();

      while(true) {
         while(true) {
            Arena var3;
            do {
               if (!var2.hasNext()) {
                  return;
               }

               var3 = (Arena)var2.next();
            } while(!this.d(var3));

            if (!var3.getKits().isEmpty()) {
               FFAFight var4 = new FFAFight(var1);
               var4.setArena(var3);
               var4.setKit(BattleKit.getKit((String)var3.getKits().get(0)));
               if (var4.getKit() != null) {
                  var4.start();
                  var3.setCurrentFight(var4);
                  var3.setCustomMaxChangesPerTick(Math.max(c.aV * 5, 100));
                  this.fU.put(var3, var4);
                  continue;
               }
            }

            var1.getLogger().warning("Could not start FFA fight because the kit is not valid. Arena: " + var3.getName());
         }
      }
   }

   public boolean d(Arena var1) {
      Location var2 = var1.getCenter();
      if (var2 == null) {
         B.debug("FFA arena " + var1.getName() + " has no center set -> will not be used for FFA.");
         return false;
      } else {
         if (this.fX) {
            B.debug("Using stacked arenas for FFA, arena must be in /sprac arenasworld");
            Iterator var3 = this.fU.keySet().iterator();

            while(var3.hasNext()) {
               Arena var4 = (Arena)var3.next();
               if (var4.getOriginalName().equals(var1.getOriginalName())) {
                  B.debug("FFA arena " + var1.getName() + " is the base arena (not copied) -> will not be used for FFA.");
                  return false;
               }
            }
         }

         return var1.isFFA() && this.fX == var1.getName().contains(":");
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void e(EntityDamageEvent var1) {
      if (var1.getCause() != null && var1.getCause() == DamageCause.FALL && this.fT) {
         Fight var2 = AbstractFight.getCurrentFight(var1.getEntity().getUniqueId());
         if (var2 instanceof FFAFight && var2.getArena().isBuild()) {
            var1.setCancelled(true);
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true,
      priority = EventPriority.LOW
   )
   public void a(PlayerCommandPreprocessEvent var1) {
      final Player var2 = var1.getPlayer();
      Fight var3 = AbstractFight.getCurrentFight(var2);
      if (var3 instanceof FFAFight && var1.getMessage().equalsIgnoreCase("/spawn")) {
         new b(this.fS, this.fS.getConfig().getInt("wait-before-leaving-ffa-arena"), var2, this.fS.L.fN(), new ga.strikepractice.c.a() {
            public void aQ() {
               AbstractFight.setCurrentFight(var2, (Fight)null);
               a.this.fS.clear(var2, true, true);
            }
         });
         var1.setCancelled(true);
      } else {
         Iterator var4 = this.fU.entrySet().iterator();

         Entry var5;
         String var6;
         String var7;
         do {
            if (!var4.hasNext()) {
               return;
            }

            var5 = (Entry)var4.next();
            var6 = var1.getMessage().toLowerCase();
            var7 = "/" + ((Arena)var5.getKey()).getOriginalName().toLowerCase();
         } while(!var6.startsWith(var7));

         if (!PvPEvent.isInEvent(var2) && !AbstractFight.isInFight(var2) && Party.getParty(var2) == null && !d.aE(var2)) {
            Arena var8 = (Arena)var5.getKey();
            String[] var9 = var6.split("\\s+");
            if (var9.length >= 2) {
               BattleKit var10 = BattleKit.getKit(var9[1]);
               if (var10 != null && var8.getKits().contains(var10.getName())) {
                  ((FFAFight)var5.getValue()).joinPlayer(var2, var10);
               } else {
                  this.fS.a(var2, "invalid-kit");
               }
            } else if (var8.getKits().size() > 1) {
               this.a(var2, var8.getKits(), (FFAFight)var5.getValue());
            } else {
               ((FFAFight)var5.getValue()).joinPlayer(var2, ((FFAFight)var5.getValue()).getKit());
            }
         } else {
            this.fS.a(var2, "can-not-do-command");
         }

         var1.setCancelled(true);
      }
   }

   public long bj() {
      long var1 = System.currentTimeMillis() - this.fV;
      return this.fW * 50L - var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!(var1 instanceof Player)) {
         return true;
      } else {
         Player var5 = (Player)var1;
         Iterator var6 = this.fU.entrySet().iterator();

         Entry var7;
         do {
            if (!var6.hasNext()) {
               return true;
            }

            var7 = (Entry)var6.next();
         } while(var4.length != 0 && !var4[0].equalsIgnoreCase(((Arena)var7.getKey()).getOriginalName()));

         if (!PvPEvent.isInEvent(var5) && !AbstractFight.isInFight(var5) && Party.getParty(var5) == null && !d.aE(var5)) {
            Arena var8 = (Arena)var7.getKey();
            if (var4.length >= 2) {
               BattleKit var9 = BattleKit.getKit(var4[1]);
               if (var9 != null && var8.getKits().contains(var9.getName())) {
                  ((FFAFight)var7.getValue()).joinPlayer(var5, var9);
               } else {
                  this.fS.a(var5, "invalid-kit");
               }
            } else if (var8.getKits().size() > 1) {
               this.a(var5, var8.getKits(), (FFAFight)var7.getValue());
            } else {
               ((FFAFight)var7.getValue()).joinPlayer(var5, ((FFAFight)var7.getValue()).getKit());
            }
         } else {
            this.fS.a(var5, "can-not-do-command");
         }

         return true;
      }
   }

   public void onDisable() {
      Iterator var1 = this.fU.entrySet().iterator();

      while(var1.hasNext()) {
         Entry var2 = (Entry)var1.next();
         Arena var3 = (Arena)var2.getKey();
         if (var3.isBuild()) {
            ((FFAFight)var2.getValue()).setEnded(true);
            var3.quickRollback();
         }
      }

   }

   private void a(Player var1, List<String> var2, FFAFight var3) {
      G.a(var1, BattleKitType.ANY, (var2x) -> {
         var3.joinPlayer(var1, var2x);
      }, (var1x) -> {
         return var2.contains(var1x.getName());
      });
   }

   public Map<Arena, FFAFight> bk() {
      return this.fU;
   }

   private class a extends BukkitRunnable {
      private BukkitTask ga;

      private a() {
      }

      public void run() {
         this.ga = (new BukkitRunnable() {
            int counter = 30;

            public void run() {
               Iterator var1;
               if (this.counter > 0 && (this.counter % 10 == 0 || this.counter <= 5)) {
                  var1 = Bukkit.getOnlinePlayers().iterator();

                  while(var1.hasNext()) {
                     Player var9 = (Player)var1.next();
                     Fight var10 = AbstractFight.getCurrentFight(var9);
                     if (var10 instanceof FFAFight && var10.getArena().isBuild()) {
                        a.this.fS.a(var9, "ffa-arena-reset", u.a("<time>", this.counter + ""));
                     }
                  }
               } else if (this.counter == 0) {
                  a.this.fT = true;
                  var1 = a.this.fU.entrySet().iterator();

                  label48:
                  while(true) {
                     Entry var2;
                     Arena var3;
                     do {
                        if (!var1.hasNext()) {
                           break label48;
                        }

                        var2 = (Entry)var1.next();
                        var3 = (Arena)var2.getKey();
                     } while(!var3.isBuild());

                     FFAFight var4 = (FFAFight)var2.getValue();
                     HashMap var5 = new HashMap();
                     Iterator var6 = var4.getPlayers().iterator();

                     while(var6.hasNext()) {
                        UUID var7 = (UUID)var6.next();
                        Player var8 = Bukkit.getPlayer(var7);
                        if (var8 != null && var8.isOnline()) {
                           var5.put(var7, var8.getLocation().clone());
                        }
                     }

                     var3.rollbackArena(var4);
                     a.this.fV = System.currentTimeMillis();
                     Bukkit.getScheduler().runTaskLater(a.this.fS, () -> {
                        Iterator var3x = var4.getPlayers().iterator();

                        while(true) {
                           Player var5x;
                           Location var6;
                           Location var7;
                           do {
                              do {
                                 UUID var4x;
                                 do {
                                    do {
                                       if (!var3x.hasNext()) {
                                          return;
                                       }

                                       var4x = (UUID)var3x.next();
                                       var5x = Bukkit.getPlayer(var4x);
                                    } while(var5x == null);
                                 } while(!var5x.isOnline());

                                 var6 = (Location)var5.get(var4x);
                                 var7 = var5x.getLocation();
                              } while(var6 == null);
                           } while(!(var6.distanceSquared(var7) < 0.2D) && var5x.getLocation().getBlock().getType() == Material.AIR);

                           Location var8 = var7.clone().add(0.0D, 2.0D, 0.0D);
                           if (var8.getBlock().getType() != Material.AIR) {
                              var8 = var3.getCenter().clone().add(0.0D, 2.0D, 0.0D);
                           }

                           var5x.teleport(var8);
                        }
                     }, 40L);
                  }
               }

               if (this.counter < -60) {
                  a.this.fT = false;
                  a.this.ga.cancel();
               }

               --this.counter;
            }
         }).runTaskTimer(a.this.fS, 20L, 20L);
      }

      // $FF: synthetic method
      a(Object var2) {
         this();
      }
   }
}
