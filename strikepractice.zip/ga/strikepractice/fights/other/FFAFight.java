package ga.strikepractice.fights.other;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.DefaultCachedBlockChange;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.queue.d;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.i;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class FFAFight extends AbstractFight {
   private final StrikePractice fQ;
   private final Collection<UUID> fR = Collections.newSetFromMap(new ConcurrentHashMap());
   private boolean ended;

   public FFAFight(StrikePractice var1) {
      this.fQ = var1;
      this.setStartedAfterCountdown();
   }

   public void start() {
      if (this.arena != null) {
         this.arena.setUsing(true, this);
      }

   }

   public void joinPlayer(Player var1, BattleKit var2) {
      if (var1.isOnline()) {
         this.fR.add(var1.getUniqueId());
         d.b(var1, true);
         if (this.fQ.ac().isSpectator(var1)) {
            this.fQ.ac().removeSpectator(var1, false);
         }

         if (var1.isDead()) {
            var1.spigot().respawn();
            C.a(() -> {
               this.joinPlayer(var1, var2);
            }, 2L);
         } else {
            this.fQ.clear(var1, false, false);
            if (!N.e(var1, this.arena.getCenter())) {
               this.forceEnd(ChatColor.RED + "An error occurred when joining the FFA arena!");
            } else {
               var1.setHealth(var1.getMaxHealth());
               var1.setFoodLevel(20);
               var1.setFireTicks(0);
               var2.giveKit(var1);
               int var3 = this.fQ.getConfig().getInt("ffa-countdown");
               if (var3 >= 0) {
                  i.a(Collections.singletonList(var1.getName()), var3, var2.isStickSpawn());
               }

               var1.closeInventory();
               AbstractFight.setCurrentFight(var1, this);
               var2.sendFightInfo(var1);
            }
         }
      }
   }

   public boolean addBlockChange(DefaultCachedBlockChange var1) {
      this.blockChanges.putIfAbsent(var1.getLocation(), var1);
      this.handleDisappear(var1);
      return true;
   }

   public boolean allowSpectating() {
      return false;
   }

   public boolean hasEnded() {
      return this.ended;
   }

   public void setArena(Arena var1) {
      super.setArena(var1);
      this.kit = StrikePractice.getAPI().getKit((String)var1.getKits().get(0));
      Bukkit.getLogger().info(var1.getName() + " (ffa arena) main kit: " + (this.kit == null ? "null" : this.kit.getName()));
      Bukkit.getLogger().info(var1.getName() + " (ffa arena) all kit options: " + var1.getKits());
   }

   public void setEnded(boolean var1) {
      this.ended = var1;
   }

   public boolean canStart() {
      return this.arena != null && this.arena.getCenter() != null;
   }

   public void handleDeath(Player var1) {
      if (AbstractFight.getCurrentFight(var1) == this) {
         BattleKit var2 = BattleKit.getCurrentKit(var1);
         AbstractFight.setCurrentFight(var1, (Fight)null);
         this.fQ.clear(var1, true, true);
         this.fR.remove(var1.getUniqueId());
         if (this.fQ.getConfig().getBoolean("ffa-rejoin-automatically")) {
            C.a(() -> {
               this.joinPlayer(var1, var2);
            }, 4L);
         }

      }
   }

   public void forceEnd(String var1) {
      Iterator var2 = Bukkit.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         Player var3 = (Player)var2.next();
         Fight var4 = AbstractFight.getCurrentFight(var3);
         if (var4 != null && var4.equals(this)) {
            this.handleDeath(var3);
            if (var1 != null) {
               var3.sendMessage(var1);
            }
         }
      }

   }

   public List<String> getTeammates(Player var1) {
      return Collections.singletonList(var1.getName());
   }

   public List<String> getOpponents(Player var1) {
      ArrayList var2 = new ArrayList(this.fR.size() - 1);
      Iterator var3 = this.fR.iterator();

      while(var3.hasNext()) {
         UUID var4 = (UUID)var3.next();
         Player var5 = Bukkit.getPlayer(var4);
         if (var5 != null && var5 != var1) {
            var2.add(var5.getName());
         }
      }

      return var2;
   }

   public Collection<UUID> getPlayers() {
      return this.fR;
   }
}
