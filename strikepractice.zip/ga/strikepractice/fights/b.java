package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.r;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.util.Vector;

public class b implements Listener {
   private final Map<UUID, b.a> eS = new ConcurrentHashMap();
   private final StrikePractice eT;
   private final DecimalFormat eU;

   public b(StrikePractice var1) {
      this.eT = var1;
      this.eU = new DecimalFormat(var1.getConfig().getString("fireball.cooldown.format", "0"));
      var1.getServer().getScheduler().runTaskTimerAsynchronously(var1, () -> {
         this.eS.entrySet().removeIf((var2) -> {
            UUID var3 = (UUID)var2.getKey();
            if (var3 == null) {
               return true;
            } else {
               Player var4 = Bukkit.getPlayer(var3);
               if (var4 != null && var4.isOnline()) {
                  boolean var5 = ((b.a)var2.getValue()).hasExpired();
                  ListIterator var6 = var4.getInventory().iterator();

                  while(var6.hasNext()) {
                     ItemStack var7 = (ItemStack)var6.next();
                     if (var7 != null && var7.getType() == Material.FIREBALL) {
                        ItemMeta var8 = var7.getItemMeta();
                        if (var8 != null) {
                           String var9 = var1.getConfig().getString("fireball.cooldown.fireball-name");
                           if (var9 != null && !var9.isEmpty() && !"false".equalsIgnoreCase(var9)) {
                              var8.setDisplayName(var5 ? null : f.K(var9.replace("<time>", this.eU.format(((b.a)var2.getValue()).bd()))));
                              var7.setItemMeta(var8);
                           }
                        }
                     }
                  }

                  return var5;
               } else {
                  return true;
               }
            }
         });
      }, 0L, (long)var1.getConfig().getInt("fireball.cooldown.interval", 2));
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void b(EntityDamageByEntityEvent var1) {
      if (var1.getDamager().getType() == EntityType.FIREBALL) {
         Fireball var2 = (Fireball)var1.getDamager();
         B.a(() -> {
            return "Damage taken by fireball, shooter: " + var2.getShooter();
         });
         if (var2.getShooter() instanceof Player && var2.getShooter().equals(var1.getEntity())) {
            double var3 = var1.getFinalDamage() * this.eT.getConfig().getDouble("fireball.shooter-damage-multiplier");
            B.a(() -> {
               return "Fireball shooter damage: " + var3 + " (original: " + var1.getDamage() + ", original final: " + var1.getFinalDamage() + ")";
            });
            var1.setDamage(var3);
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void c(EntityDamageByEntityEvent var1) {
      if (var1.getDamager().getType() == EntityType.PRIMED_TNT) {
         TNTPrimed var2 = (TNTPrimed)var1.getDamager();
         Entity var3 = var2.getSource();
         if (var2.hasMetadata("TNTSource")) {
            var3 = (Entity)((MetadataValue)var2.getMetadata("TNTSource").get(0)).value();
         }

         if (var3 != null) {
            B.a(() -> {
               return "Damage taken by tnt, source: " + var3.getName();
            });
         }

         if (var3 instanceof Player && var3.equals(var1.getEntity())) {
            double var4 = var1.getFinalDamage() * this.eT.getConfig().getDouble("tnt.source-damage-multiplier");
            B.a(() -> {
               return "tnt source damage: " + var4 + " (original: " + var1.getDamage() + ", original final: " + var1.getFinalDamage() + ")";
            });
            var1.setDamage(var4);
         }

      }
   }

   @EventHandler
   public void c(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      Objects.requireNonNull(this.eT);
      if (!var2.hasMetadata("StrikePracticeProtected")) {
         ItemStack var3 = var1.getItem();
         if (var3 != null && var3.getType() == Material.FIREBALL && var1.getAction() != null) {
            if (var1.getAction().name().contains("RIGHT")) {
               Fight var4 = AbstractFight.getCurrentFight(var2);
               if (var4 != null && var4.hasStarted() && !var4.hasEnded()) {
                  BattleKit var5 = var4.getKit();
                  if (var5 != null && var5.isShootFireballs()) {
                     var1.setCancelled(true);
                     b.a var6 = (b.a)this.eS.get(var2.getUniqueId());
                     if (var6 != null && !var6.hasExpired()) {
                        return;
                     }

                     if (this.eT.getConfig().getBoolean("fireball.cooldown.enabled", true)) {
                        this.eS.put(var2.getUniqueId(), new b.a(this.eT.getConfig().getInt("fireball.cooldown.cooldown", 2)));
                     }

                     Fireball var7 = (Fireball)var2.launchProjectile(Fireball.class);
                     var7.setVelocity(var2.getLocation().getDirection().multiply(1));
                     var5.giveKitMeta(var7);
                     C.a(() -> {
                        if (!var7.isDead()) {
                           var7.remove();
                        }

                     }, 100L);
                     if (var2.getItemInHand() != null && var2.getItemInHand().getType() == Material.FIREBALL) {
                        if (var3.getAmount() > 1) {
                           var3.setAmount(var3.getAmount() - 1);
                        } else {
                           var2.getInventory().remove(var3);
                        }
                     } else {
                        r.a((Inventory)var2.getInventory(), (ItemStack)var1.getItem(), (int)1);
                     }
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(EntityExplodeEvent var1) {
      EntityType var2 = var1.getEntityType();
      if (var2 == EntityType.FIREBALL || var2 == EntityType.PRIMED_TNT) {
         BattleKit var3 = BattleKit.getCurrentKit(var1.getEntity());
         if (var3 != null) {
            if (var2 != EntityType.FIREBALL || var3.isFireballJumps()) {
               if (var2 != EntityType.PRIMED_TNT || var3.isTNTJumps()) {
                  B.debug(var2.name() + " explosion");
                  var1.setYield(var3.isBuild() ? 2.0F : 0.0F);
                  String var4 = var2 == EntityType.FIREBALL ? "fireball" : "tnt";
                  double var5 = this.eT.getConfig().getDouble(var4 + ".knockback.radius.x");
                  double var7 = this.eT.getConfig().getDouble(var4 + ".knockback.radius.y");
                  double var9 = this.eT.getConfig().getDouble(var4 + ".knockback.radius.z");
                  Iterator var11 = var1.getEntity().getNearbyEntities(var5, var7, var9).iterator();

                  while(var11.hasNext()) {
                     Entity var12 = (Entity)var11.next();
                     if (var12 instanceof Player) {
                        Player var13 = (Player)var12;
                        GameMode var14 = var13.getGameMode();
                        if (this.eT.ac().isSpectator(var13) || var14 == GameMode.CREATIVE || var14 == GameMode.SPECTATOR) {
                           return;
                        }
                     }

                     B.a(() -> {
                        return "Knocking player/entity: " + var12.getName() + " with a " + var2.name();
                     });
                     this.a(var12, var4, var1.getLocation());
                  }

               }
            }
         }
      }
   }

   private void a(Entity var1, String var2, Location var3) {
      double var4 = Math.max(-4.0D, Math.min(4.0D, -this.eT.getConfig().getDouble(var2 + ".knockback.multiplier", 3.0D)));
      double var6 = Math.max(-4.0D, Math.min(4.0D, this.eT.getConfig().getDouble(var2 + ".knockback.y-force", 1.5D)));
      Vector var8 = var3.toVector().subtract(var1.getLocation().toVector());
      if (var8.lengthSquared() > 0.0D) {
         var8 = var8.normalize().multiply(var4).setY(var6);
      } else {
         var8 = new Vector(0.0D, var6, 0.0D);
      }

      if (Double.isFinite(var8.getX()) && Double.isFinite(var8.getY()) && Double.isFinite(var8.getZ())) {
         var1.setVelocity(var8);
      } else {
         var1.setVelocity(new Vector(0.0D, var6, 0.0D));
      }

   }

   public static class a {
      private final long eV = System.currentTimeMillis();
      private final int eW;

      public a(int var1) {
         this.eW = var1;
      }

      public long bd() {
         long var1 = TimeUnit.SECONDS.toMillis((long)this.eW) - (System.currentTimeMillis() - this.eV);
         return var1 < 0L ? 0L : TimeUnit.MILLISECONDS.toSeconds(var1);
      }

      public boolean hasExpired() {
         return System.currentTimeMillis() - this.eV > TimeUnit.SECONDS.toMillis((long)this.eW);
      }
   }
}
