package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.duel.BestOf;
import ga.strikepractice.fights.duel.BestOfFight;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.fights.other.FFAFight;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.u;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class d implements CommandExecutor {
   private final StrikePractice fg;

   public d(StrikePractice var1) {
      this.fg = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!(var1 instanceof Player)) {
         return true;
      } else {
         Player var5 = (Player)var1;
         Fight var6 = AbstractFight.getCurrentFight(var5);
         if (var6 != null && var6.hasStarted() && !var6.hasEnded()) {
            if (var6 instanceof FFAFight) {
               AbstractFight.setCurrentFight(var5, (Fight)null);
               this.fg.clear(var5, true, true);
               return true;
            } else {
               Party var7 = Party.getParty(var5);
               if (var7 != null && var7.getOwnerPlayer() != var5) {
                  this.fg.a(var5, "must-own-party");
                  return true;
               } else {
                  if (var6 instanceof BestOfFight) {
                     BestOfFight var8 = (BestOfFight)var6;
                     var8.setBestOf((BestOf)null);
                  }

                  if (var6 instanceof BotFight) {
                     var6.getPlayersInFight().forEach((var1x) -> {
                        if (var1x != null && var1x.isOnline()) {
                           var6.handleDeath(var1x);
                        }

                     });
                     this.fg.a(var5, "surrender");
                     return true;
                  } else if (var6 instanceof Duel) {
                     var6.handleDeath(var5);
                     this.fg.L.L(var5);
                     return true;
                  } else {
                     List var12 = var6.getOpponents(var5);
                     Player var9 = var12.isEmpty() ? null : Bukkit.getPlayer((String)var12.get(0));
                     if (var9 == null) {
                        this.fg.a(var5, "not-in-fight");
                        return true;
                     } else {
                        StrikePractice.getAPI().forceWinRound(var9);
                        this.fg.a(var5, "surrender");
                        Iterator var10 = var6.getPlayersInFight().iterator();

                        Player var11;
                        while(var10.hasNext()) {
                           var11 = (Player)var10.next();
                           if (var5 != var11) {
                              this.fg.a(var11, "surrender-announce", u.a("<player>", var5.getName()));
                           }
                        }

                        var10 = var6.getSpectators().iterator();

                        while(var10.hasNext()) {
                           var11 = (Player)var10.next();
                           if (var5 != var11) {
                              this.fg.a(var11, "surrender-announce", u.a("<player>", var5.getName()));
                           }
                        }

                        return true;
                     }
                  }
               }
            }
         } else {
            this.fg.a(var5, "not-in-fight");
            return true;
         }
      }
   }
}
