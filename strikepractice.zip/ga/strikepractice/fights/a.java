package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.botduel.BotDuel;
import ga.strikepractice.fights.duel.BestOf;
import ga.strikepractice.fights.duel.BestOfFight;
import ga.strikepractice.fights.party.partyfights.PartySplit;
import ga.strikepractice.fights.party.partyfights.PartyVsBots;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.npc.CitizensNPC;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.x;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.scheduler.BukkitRunnable;

public class a implements Listener {
   public static final String eD = "StrikePracticeItemDrop";
   private static final String eE = "SP_nextRespawnLocation";
   private final StrikePractice eF;
   private final boolean eG;
   private final int eH;
   private final boolean eI;

   public a(StrikePractice var1) {
      this.eF = var1;
      this.eI = var1.getConfig().getBoolean("party.allow-rod-boosting");
      this.eG = var1.getConfig().getBoolean("fix-bot-damage");
      this.eH = var1.getConfig().getInt("build-limit");
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(EntityDamageByEntityEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2;
         Player var3;
         Party var4;
         Party var5;
         Fight var6;
         if (var1.getDamager() instanceof Player) {
            var2 = (Player)var1.getDamager();
            var3 = (Player)var1.getEntity();
            if (var2 != var3) {
               var4 = Party.getParty(var2);
               var5 = Party.getParty(var3);
               if (var4 != null && var5 != null) {
                  var6 = AbstractFight.getCurrentFight(var2);
                  if (var4 != null && var5 != null && var4.getOwner().equals(var5.getOwner()) && (var6 instanceof PartyVsParty || var6 instanceof PartyVsBots || this.a(var2, var3, var4, AbstractFight.getCurrentFight(var2)))) {
                     var1.setCancelled(true);
                  }
               }
            }
         } else if (var1.getDamager() instanceof Projectile && ((Projectile)var1.getDamager()).getShooter() instanceof Player) {
            if (var1.getDamager() instanceof FishHook && this.eI) {
               return;
            }

            var2 = (Player)((Projectile)var1.getDamager()).getShooter();
            var3 = (Player)var1.getEntity();
            if (var2 != var3) {
               var4 = Party.getParty(var2);
               var5 = Party.getParty(var3);
               if (var4 != null && var5 != null) {
                  var6 = AbstractFight.getCurrentFight(var2);
                  if (var4 != null && var5 != null && var4.getOwner().equals(var5.getOwner()) && (var6 instanceof PartyVsParty || var6 instanceof PartyVsBots || this.a(var2, var3, var4, AbstractFight.getCurrentFight(var2)))) {
                     var1.setCancelled(true);
                  }
               }
            }
         }

         if (this.eG && var1.getDamager() instanceof HumanEntity) {
            Fight var7 = AbstractFight.getCurrentFight(var1.getDamager().getUniqueId());
            if (var7 instanceof BotFight && Bukkit.getPlayer(var1.getDamager().getUniqueId()) == null) {
               var1.setDamage(var1.getDamage() + CitizensNPC.getDamage(((HumanEntity)var1.getDamager()).getInventory().getItemInHand()));
            }
         }
      }

   }

   private boolean a(Player var1, Player var2, Party var3, Fight var4) {
      if (!(var4 instanceof PartySplit)) {
         return false;
      } else {
         PartySplit var5 = (PartySplit)var4;
         return var5.alive.contains(var1.getName()) && var5.alive.contains(var2.getName()) || var5.alive2.contains(var1.getName()) && var5.alive2.contains(var2.getName());
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void a(PlayerQuitEvent var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null) {
         if (var2 instanceof BestOfFight) {
            ((BestOfFight)var2).setBestOf((BestOf)null);
         }

         var2.handleDeath(var1.getPlayer());
      }

      if (this.eF.aa().vI) {
         this.eF.aa().bk(var1.getPlayer());
      }

      var1.getPlayer().removeMetadata("SP_nextRespawnLocation", this.eF);
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(BlockBreakEvent var1) {
      Player var10000 = var1.getPlayer();
      Objects.requireNonNull(this.eF);
      if (var10000.hasMetadata("StrikePracticeProtected")) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      ignoreCancelled = true,
      priority = EventPriority.HIGH
   )
   public void a(PlayerPickupItemEvent var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null && var2.hasEnded() && !x.fH()) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(BlockPlaceEvent var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null && var2.getKit() != null && var2.getKit().isBuild()) {
         int var3 = var1.getBlock().getY() - var2.getArena().getCenter().getBlockY();
         if (var3 > this.eH) {
            var1.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void b(PlayerBucketEmptyEvent var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null && var2.getKit() != null && var2.getKit().isBuild()) {
         int var3 = var1.getBlockClicked().getY() - var2.getArena().getCenter().getBlockY();
         if (var3 > this.eH) {
            var1.setCancelled(true);
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(FoodLevelChangeEvent var1) {
      if (var1.getEntity() instanceof Player && var1.getFoodLevel() < 20) {
         BattleKit var2 = BattleKit.getCurrentKit(var1.getEntity());
         if (var2 != null && var2.isNoHunger()) {
            var1.setFoodLevel(20);
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true,
      priority = EventPriority.HIGHEST
   )
   public void b(EntityDamageEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         Fight var3 = AbstractFight.getCurrentFight(var2);
         if (var3 != null) {
            if (var3.hasEnded()) {
               var1.setCancelled(true);
            } else if (var3 instanceof BestOfFight && ((BestOfFight)var3).isBreakTime()) {
               var1.setCancelled(true);
            } else if (var2.getHealth() - var1.getFinalDamage() <= 0.0D) {
               BestOf var4 = var3 instanceof BestOfFight ? ((BestOfFight)var3).getBestOf() : null;
               if (var4 != null && var4.getRounds() > 1 && !var4.endsNow(var2.getUniqueId())) {
                  boolean var5 = x.bc(var2);
                  B.debug("Took more damage than health in bestof fight, has totem: " + var5);
                  if (!var5) {
                     if (var3 instanceof BotFight && Bukkit.getPlayer(var2.getUniqueId()) == null) {
                        ((BotFight)var3).handleBotDeath(var2);
                     } else {
                        var3.handleDeath(var2);
                     }

                     var1.setDamage(0.0D);
                  }
               }
            }
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(PlayerInteractEvent var1) {
      Player var10000 = var1.getPlayer();
      Objects.requireNonNull(this.eF);
      if (var10000.hasMetadata("StrikePracticeProtected") && var1.getPlayer().getItemInHand() != null) {
         short var2 = var1.getPlayer().getItemInHand().getDurability();
         if (var2 == 16421 || var2 == 16389 || var2 == 2586) {
            var1.setCancelled(true);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void a(ChunkLoadEvent var1) {
      if (!var1.isNewChunk()) {
         Entity[] var2 = var1.getChunk().getEntities();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Entity var5 = var2[var4];
            if (var5 instanceof Item && var5.hasMetadata("StrikePracticeItemDrop")) {
               var5.remove();
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void a(PlayerDropItemEvent var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null && var2.hasEnded()) {
         var1.setCancelled(true);
      } else {
         Player var10000 = var1.getPlayer();
         Objects.requireNonNull(this.eF);
         if (var10000.hasMetadata("StrikePracticeProtected")) {
            var1.setCancelled(true);
         } else if (var2 != null) {
            Item var3 = var1.getItemDrop();
            var3.setMetadata("StrikePracticeItemDrop", new FixedMetadataValue(this.eF, true));
            C.a(() -> {
               if (!var3.isDead()) {
                  var3.remove();
               }

            }, (long)this.eF.getConfig().getInt("remove-drops") * 20L);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void a(final EntityDeathEvent var1) {
      final Fight var2 = AbstractFight.getCurrentFight(var1.getEntity().getUniqueId());
      if (var2 != null && var1.getDrops() != null) {
         int var3 = this.eF.getConfig().getInt("remove-drops") * 20;
         ArrayList var4 = new ArrayList(var1.getDrops().size());
         if (!StrikePractice.u) {
            Iterator var5 = var1.getDrops().iterator();

            while(var5.hasNext()) {
               ItemStack var6 = (ItemStack)var5.next();
               if (r.h(var6)) {
                  Item var7 = var1.getEntity().getWorld().dropItemNaturally(var1.getEntity().getLocation(), var6);
                  var4.add(var7);
                  var7.setMetadata("StrikePracticeItemDrop", new FixedMetadataValue(this.eF, true));
               }
            }

            Bukkit.getScheduler().scheduleSyncDelayedTask(this.eF, () -> {
               Iterator var1 = var4.iterator();

               while(var1.hasNext()) {
                  Item var2 = (Item)var1.next();
                  if (var2 != null) {
                     var2.remove();
                  }
               }

               var4.clear();
            }, (long)var3);
         }

         var1.getDrops().clear();
         if (var2 instanceof BotFight && Bukkit.getPlayer(var1.getEntity().getUniqueId()) == null) {
            if (var2 instanceof BotDuel && ((BotDuel)var2).getBestOf() != null && !((BotDuel)var2).getBestOf().endsNow(var1.getEntity().getUniqueId())) {
               var1.getDrops().clear();
            }

            ((BotFight)var2).handleBotDeath(var1.getEntity());
            final LivingEntity var9 = var1.getEntity();
            (new BukkitRunnable() {
               public void run() {
                  if (var9 != null) {
                     var9.teleport(var1.getEntity().getLocation().subtract(0.0D, 10.0D, 0.0D));
                  }

               }
            }).runTaskLater(this.eF, 10L);
         } else if (var1.getEntity() instanceof Player) {
            final Player var8 = (Player)var1.getEntity();
            if (var2.getArena() == null || var2.getArena().getCenter() == null) {
               return;
            }

            final Location var10 = var8.getLocation().add(0.0D, 2.0D, 0.0D);
            var2.handleDeath(var8);
            ga.strikepractice.fights.queue.d.bs();
            if (var2.allowSpectating()) {
               if (!PvPEvent.isInEvent(var8)) {
                  this.a(var8, var8.getLocation().add(0.0D, 2.0D, 0.0D));
               }

               int var11 = this.eF.getConfig().getInt("wait-before-spectator") + 2;
               if (var11 < 2) {
                  var11 = 2;
               }

               (new BukkitRunnable() {
                  public void run() {
                     if (var8 != null) {
                        a.this.eF.ac().l(var8, var2);
                        N.e(var8, var10);
                     }

                  }
               }).runTaskLater(this.eF, (long)var11);
            } else {
               (new BukkitRunnable() {
                  public void run() {
                     if (var8 != null) {
                        a.this.eF.L.L(var8);
                     }

                  }
               }).runTaskLater(this.eF, 1L);
            }
         }
      }

   }

   private void a(Player var1, Location var2) {
      B.debug("Setting respawn location for " + var1.getName() + " to " + var2);
      var1.setMetadata("SP_nextRespawnLocation", new FixedMetadataValue(this.eF, var2));
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerRespawnEvent var1) {
      B.debug("Handling respawn location for " + var1.getPlayer().getName());
      if (var1.getPlayer().hasMetadata("SP_nextRespawnLocation") && this.eF.getConfig().getBoolean("death.respawn-in-arena")) {
         MetadataValue var2 = this.eF.a((Metadatable)var1.getPlayer(), (String)"SP_nextRespawnLocation");
         if (var2 != null) {
            if (var2.value() != null && var2.value() instanceof Location) {
               var1.setRespawnLocation((Location)var2.value());
            } else {
               Bukkit.getLogger().info("Respawn location was invalid: " + var2);
            }
         }

         var1.getPlayer().removeMetadata("SP_nextRespawnLocation", this.eF);
      }

   }
}
