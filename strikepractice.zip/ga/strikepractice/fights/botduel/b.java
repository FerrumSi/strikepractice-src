package ga.strikepractice.fights.botduel;

import ga.strikepractice.kotlin.Metadata;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\n\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\t"},
   d2 = {"Lga/strikepractice/fights/botduel/BotDuelHolder;", "Lorg/bukkit/inventory/InventoryHolder;", "rounds", "", "(I)V", "getRounds", "()I", "getInventory", "Lorg/bukkit/inventory/Inventory;", "strikepractice-core"}
)
public final class b implements InventoryHolder {
   private final int fu;

   public b(int var1) {
      this.fu = var1;
   }

   public final int getRounds() {
      return this.fu;
   }

   @Nullable
   public Inventory getInventory() {
      return null;
   }
}
