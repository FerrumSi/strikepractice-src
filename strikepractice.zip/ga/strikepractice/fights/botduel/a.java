package ga.strikepractice.fights.botduel;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.battlekit.e;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.BotFight;
import ga.strikepractice.fights.duel.BestOf;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.collections.ArraysKt;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.g;
import ga.strikepractice.utils.r;
import java.util.Set;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\u0018\u00002\u00020\u00012\u00020\u0002B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0007J3\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00110\u0013H\u0016¢\u0006\u0002\u0010\u0014R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0015"},
   d2 = {"Lga/strikepractice/fights/botduel/BotDuelCommand;", "Lorg/bukkit/command/CommandExecutor;", "Lorg/bukkit/event/Listener;", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "onClick", "", "e", "Lorg/bukkit/event/inventory/InventoryClickEvent;", "onCommand", "", "p", "Lorg/bukkit/command/CommandSender;", "cmd", "Lorg/bukkit/command/Command;", "label", "", "args", "", "(Lorg/bukkit/command/CommandSender;Lorg/bukkit/command/Command;Ljava/lang/String;[Ljava/lang/String;)Z", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nBotDuelCommand.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BotDuelCommand.kt\nga/strikepractice/fights/botduel/BotDuelCommand\n+ 2 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n*L\n1#1,117:1\n81#2,4:118\n81#2,4:122\n*S KotlinDebug\n*F\n+ 1 BotDuelCommand.kt\nga/strikepractice/fights/botduel/BotDuelCommand\n*L\n90#1:118,4\n93#1:122,4\n*E\n"})
public final class a implements CommandExecutor, Listener {
   @NotNull
   private final StrikePractice ft;

   public a(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.ft = var1;
   }

   @EventHandler
   public final void b(@NotNull InventoryClickEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (var1.getWhoClicked() instanceof Player) {
         HumanEntity var10000 = var1.getWhoClicked();
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.bukkit.entity.Player");
         Player var2 = (Player)var10000;
         InventoryHolder var3 = var1.getInventory().getHolder();
         if (var3 instanceof b) {
            String var10 = var1.getView().getTitle();
            String var10001 = this.ft.getConfig().getString("inventory-title");
            Intrinsics.checkNotNullExpressionValue(var10001, "plugin.config.getString(\"inventory-title\")");
            if (Intrinsics.areEqual((Object)var10, (Object)g.P(var10001))) {
               if (var1.getClickedInventory() == null || Intrinsics.areEqual((Object)var1.getClickedInventory(), (Object)var2.getInventory())) {
                  return;
               }

               if (r.h(var1.getCurrentItem())) {
                  var1.setCancelled(true);
                  ItemMeta var11 = var1.getCurrentItem().getItemMeta();
                  if ((var11 != null ? var11.hasDisplayName() : false) && var1.getSlot() == var1.getInventory().getSize() - 1 && this.ft.getConfig().getBoolean("kit-editor-in-kit-selector")) {
                     this.ft.Y().az(var2);
                     return;
                  }

                  BattleKit var4 = BattleKit.getKit(var2, var1.getCurrentItem(), false);
                  BattleKit var5 = this.ft.Y().getPlayerKits(var2).getCustomKit();
                  if (var5 != null) {
                     label61: {
                        var10 = var5.getName();
                        ItemStack var12 = var1.getCurrentItem();
                        if (var12 != null) {
                           ItemMeta var13 = var12.getItemMeta();
                           if (var13 != null) {
                              var10001 = var13.getDisplayName();
                              break label61;
                           }
                        }

                        var10001 = null;
                     }

                     if (Intrinsics.areEqual((Object)var10, (Object)var10001)) {
                        var4 = var5;
                     }
                  }

                  if (var4 == null) {
                     var2.sendMessage(ChatColor.RED.toString() + "Error: invalid kit.. please try another kit and contact admins!");
                     return;
                  }

                  if ((var1.getClick() == ClickType.SHIFT_LEFT || var1.getClick() == ClickType.SHIFT_RIGHT) && this.ft.getConfig().getBoolean("preview.shift-click-preview")) {
                     ga.strikepractice.m.a.a(var2, var4, this.ft);
                     return;
                  }

                  int var6 = ((b)var3).getRounds();
                  BattleKitType[] var8 = new BattleKitType[]{BattleKitType.BOT_FIGHT, BattleKitType.ANY};
                  BattleKit var7 = e.a(var4, false, var8);
                  BotDuel var9 = new BotDuel(this.ft, var2.getName(), var7);
                  if (var6 > 0) {
                     var9.setBestOf(new BestOf(var6));
                  }

                  new ga.strikepractice.fights.a.b(var2, var7, ga.strikepractice.fights.botduel.a::a);
               }
            }
         }

      }
   }

   public boolean onCommand(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      Integer var5;
      BattleKit var6;
      label109: {
         Intrinsics.checkNotNullParameter(var1, "p");
         Intrinsics.checkNotNullParameter(var2, "cmd");
         Intrinsics.checkNotNullParameter(var3, "label");
         Intrinsics.checkNotNullParameter(var4, "args");
         if (var1 instanceof Player) {
            if (PvPEvent.isInEvent((Player)var1) || AbstractFight.getCurrentFight((Player)var1) != null) {
               this.ft.a((Player)var1, "you-can-not-duel-now");
               return true;
            }

            if (Party.getParty((Player)var1) != null) {
               this.ft.a((Player)var1, "can-not-do-while-in-party");
               return true;
            }

            if (!this.ft.I) {
               var1.sendMessage(ChatColor.RED.toString() + "Bot fights are disabled because Citizens plugin is not installed!");
               return true;
            }

            String var10000 = (String)ArraysKt.getOrNull(var4, 0);
            var5 = var10000 != null ? StringsKt.toIntOrNull(var10000) : null;
            var6 = null;
            B.a var7 = B.vj;
            boolean var8 = false;
            boolean var9;
            Logger var10;
            StringBuilder var11;
            String var12;
            Logger var16;
            if (var7.fV()) {
               var16 = Bukkit.getLogger();
               var11 = (new StringBuilder()).append("[SP DEBUG] ");
               var10 = var16;
               var9 = false;
               var12 = "Custom rounds in /botduel command: " + var5;
               var10.info(var11.append(var12).toString());
            }

            if (var4.length > 1) {
               var6 = StrikePractice.getAPI().getKit(var4[1]);
               var7 = B.vj;
               var8 = false;
               if (var7.fV()) {
                  var16 = Bukkit.getLogger();
                  var11 = (new StringBuilder()).append("[SP DEBUG] ");
                  var10 = var16;
                  var9 = false;
                  var12 = "Kit in /botduel command: " + (var6 != null ? var6.getName() : null);
                  var10.info(var11.append(var12).toString());
               }

               Set var17;
               boolean var18;
               label85: {
                  if (var6 != null) {
                     var17 = var6.getKitTypes();
                     if (var17 != null) {
                        var18 = var17.contains(BattleKitType.BOT_FIGHT);
                        break label85;
                     }
                  }

                  var18 = false;
               }

               if (var18) {
                  break label109;
               }

               label79: {
                  if (var6 != null) {
                     var17 = var6.getKitTypes();
                     if (var17 != null) {
                        var18 = var17.contains(BattleKitType.ANY);
                        break label79;
                     }
                  }

                  var18 = false;
               }

               if (var18) {
                  break label109;
               }
            }

            this.ft.L.a((Player)var1, (InventoryHolder)(new b(var5 != null ? var5 : -1)), BattleKitType.BOT_FIGHT);
         }

         return true;
      }

      BattleKitType[] var14 = new BattleKitType[]{BattleKitType.BOT_FIGHT, BattleKitType.ANY};
      BattleKit var13 = e.a(var6, false, var14);
      BotDuel var15 = new BotDuel(this.ft, ((Player)var1).getName(), var13);
      if (var5 != null && var5 > 0) {
         var15.setBestOf(new BestOf(var5));
      }

      new ga.strikepractice.fights.a.b((Player)var1, var13, ga.strikepractice.fights.botduel.a::a);
      return true;
   }

   private static final void a(BotDuel var0, Player var1, Arena var2) {
      Intrinsics.checkNotNullParameter(var0, "$botDuel");
      Intrinsics.checkNotNullParameter(var1, "$p");
      var0.setArena(var2);
      ga.strikepractice.npc.e.a(var1, (BotFight)var0);
   }

   private static final void a(BotDuel var0, CommandSender var1, Arena var2) {
      Intrinsics.checkNotNullParameter(var0, "$botDuel");
      Intrinsics.checkNotNullParameter(var1, "$p");
      var0.setArena(var2);
      ga.strikepractice.npc.e.a((Player)var1, (BotFight)var0);
   }
}
