package ga.strikepractice.fights.botduel;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.events.BotDuelEndEvent;
import ga.strikepractice.events.BotDuelStartEvent;
import ga.strikepractice.events.RoundEndEvent;
import ga.strikepractice.events.RoundStartEvent;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.BotFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.duel.BestOf;
import ga.strikepractice.fights.duel.BestOfFight;
import ga.strikepractice.fights.queue.d;
import ga.strikepractice.matchrecorder.recorder.Recordable;
import ga.strikepractice.npc.CitizensNPC;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.u;
import ga.strikepractice.utils.y;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.metadata.Metadatable;
import org.bukkit.scheduler.BukkitRunnable;

@APIClass
public class BotDuel extends AbstractFight implements BotFight, BestOfFight, Recordable {
   private final StrikePractice plugin;
   private final String p1;
   private String botName;
   private CitizensNPC p2;
   private boolean ended;
   private CitizensNPC.Difficulty difficulty;
   private BestOf bestOf;
   private UUID fakeBotUUIDForBestOf;
   private boolean breaktime;
   private ga.strikepractice.matchrecorder.recorder.fightrecorder.a recorder;

   public BotDuel(StrikePractice var1, String var2, BattleKit var3) {
      this.plugin = var1;
      this.p1 = var2;
      super.kit = var3;
      if (var3 != null) {
         this.bestOf = new BestOf(var3.getBestOf());
         this.fakeBotUUIDForBestOf = UUID.randomUUID();
      }

   }

   public boolean canStart() {
      if (super.arena == null) {
         if (this.kit.isBuild()) {
            this.arena = c.b(Bukkit.getPlayer(this.p1), this.kit);
         } else {
            this.arena = c.d(Bukkit.getPlayer(this.p1), this.kit);
         }
      }

      return this.p1 != null && this.arena != null && !this.arena.needsRollback() && !this.arena.isUsing() && this.arena.getLoc1() != null && this.arena.getLoc2() != null && this.arena.getLoc1().getWorld() != null && this.arena.getLoc1().getWorld().getName().equals(this.arena.getLoc2().getWorld().getName());
   }

   public void start() {
      super.start();
      Player var1 = y.W(this.p1);
      this.setStartedAfterCountdown();
      d.b(var1, true);
      if (this.plugin.ac().isSpectator(var1)) {
         this.plugin.ac().removeSpectator(var1, false);
      }

      if (var1.isDead()) {
         var1.spigot().respawn();
      }

      this.plugin.clear(var1, false, false);
      this.arena.setUsing(true, this);
      this.doStuff(var1);
      BotDuelStartEvent var2 = new BotDuelStartEvent(this, var1, this.p2);
      Bukkit.getPluginManager().callEvent(var2);
      if (!var2.isCancelled()) {
         this.plugin.Z().a(this.kit);
         this.plugin.a(var1, "fight-start-message.duel", u.a("<opponent>", this.getP2().getNPC().getName()));
         this.kit.sendFightInfo(var1);
         if (this.recorder == null && this.plugin.getConfig().getBoolean("record-all-fights")) {
            this.recorder = new ga.strikepractice.matchrecorder.recorder.fightrecorder.a(this, Arrays.asList(var1.getUniqueId()), Arrays.asList(this.getP2()));
            (new BukkitRunnable() {
               public void run() {
                  if (!BotDuel.this.hasEnded()) {
                     BotDuel.this.recorder.startRecording();
                  }

               }
            }).runTaskLater(this.plugin, 100L);
         }

      }
   }

   private void doStuff(Player var1) {
      if (!N.e(var1, this.arena.getLoc1())) {
         this.forceEndDelayed(ChatColor.RED + "An error occurred in your fight and the fight was forced to end!");
      } else {
         Bukkit.getPluginManager().callEvent(new RoundStartEvent(this));
         var1.setHealth(var1.getMaxHealth());
         var1.setFoodLevel(20);
         var1.setFireTicks(0);
         this.kit.giveKit(var1);
         this.botName = f.K(this.plugin.getConfig().getString("bot-name").replace("<player>", var1.getName()));
         this.p2 = new CitizensNPC(this.botName, var1.getName(), this.arena.getLoc2());
         this.p2.combatTask = null;
         this.p2.startCombatTask(Collections.singletonList(var1.getUniqueId()), this, this.difficulty);
         this.startCountdown();
         AbstractFight.setCurrentFight(var1, this);
         var1.updateInventory();
         if (this.bestOf != null && this.bestOf.getRounds() > 1) {
            this.bestOf.message(var1, this.fakeBotUUIDForBestOf, this.getP2().getNPC().getName());
         }

         if (this.kit.isBedwars()) {
            this.bed1Broken = this.bed2Broken = false;
         }

      }
   }

   private void startCountdown() {
      i.a(Collections.singletonList(this.p1), this.kit == null || this.kit.isStickSpawn());
   }

   public void handleDeath(final Player var1) {
      try {
         if (this.ended || this.breaktime) {
            return;
         }

         if (this.bestOf != null && this.bestOf.getRounds() > 1) {
            boolean var2 = this.bestOf.endsNow(var1.getUniqueId());
            Bukkit.getPluginManager().callEvent(new RoundEndEvent(this, var2, Collections.singletonList(this.getP2().getBukkitEntity()), Collections.singletonList(var1)));
         }

         if (this.bestOf != null && !this.bestOf.handleWin(this.fakeBotUUIDForBestOf)) {
            this.breaktime = true;
            this.p2.destroy();
            this.arena.rollbackArena(this);
            (new BukkitRunnable() {
               public void run() {
                  if (var1 != null) {
                     BotDuel.this.doStuff(Bukkit.getPlayer(BotDuel.this.p1));
                     BotDuel.this.breaktime = false;
                  }

               }
            }).runTaskLater(this.plugin, !this.kit.isNoBestOfRollback() && this.kit.isBuild() ? 5L : 1L);
            return;
         }

         this.ended = true;
         super.ended = System.currentTimeMillis();
         Bukkit.getPluginManager().callEvent(new BotDuelEndEvent(this, var1, this.getP2(), this.getP2().getNPC().getName(), BotDuelEndEvent.WinnerType.BOT));
         FightInventory var8 = new FightInventory(var1, this.plugin);
         FightInventory var3 = null;

         try {
            var3 = new FightInventory(this.getP2().getBukkitEntity(), this.getP2().getNPC().getName(), this.getP2().getBukkitEntity().getInventory(), this.plugin);
         } catch (Exception var6) {
            if (B.fQ()) {
               var6.printStackTrace();
            }
         }

         try {
            this.getP2().destroy();
         } catch (Exception var5) {
            Bukkit.getLogger().warning("Failed to destroy bot");
            var5.printStackTrace();
         }

         if (var3 != null) {
            var8.setNextInventory(var3);
            var3.setNextInventory(var8);
         }

         this.plugin.clear(var1, true, true);
         this.arena.setUsing(false, (Fight)null);
         this.plugin.a(var1, "did-not-win", u.a("<loser>", var1.getName(), "<winner>", this.getP2().getNPC().getName(), "<health>", var3 == null ? "--" : Double.toString((double)Math.round(var3.getHealth()))));
         if (this.plugin.getConfig().getBoolean("clickable-messages") && var3 != null) {
            C.c(() -> {
               FightInventory.duelMessage((Player)null, var1, this.botName, var1.getName(), var3, var8);
               this.sendSpectatorMessages(Collections.singleton(this.botName), Collections.singleton(var1.getName()));
               AbstractFight.setCurrentFight(var1, (Fight)null);
            });
         }

         this.endRecording(var8, var3, var1.getUniqueId(), this.getP2().getNPC().getUniqueId(), var1);
         this.p2 = null;
      } catch (Exception var7) {
         var7.printStackTrace();
      }

   }

   public void handleBotDeath(Metadatable var1) {
      if (!this.ended && !this.breaktime) {
         final Player var2 = y.W(this.getP1());
         if (this.bestOf != null && this.bestOf.getRounds() > 0) {
            boolean var3 = this.bestOf.endsNow(this.fakeBotUUIDForBestOf);
            Bukkit.getPluginManager().callEvent(new RoundEndEvent(this, var3, Collections.singletonList(var2), Collections.singletonList(this.getP2().getBukkitEntity())));
         }

         if (this.bestOf != null && !this.bestOf.handleWin(var2.getUniqueId())) {
            this.breaktime = true;
            this.arena.rollbackArena(this);
            (new BukkitRunnable() {
               public void run() {
                  if (var2 != null) {
                     BotDuel.this.p2.destroy();
                     BotDuel.this.doStuff(var2);
                     BotDuel.this.breaktime = false;
                  }

               }
            }).runTaskLater(this.plugin, !this.kit.isNoBestOfRollback() && this.kit.isBuild() ? 5L : 1L);
         } else {
            this.ended = true;
            super.ended = System.currentTimeMillis();
            Bukkit.getPluginManager().callEvent(new BotDuelEndEvent(this, var2, this.getP2(), var2.getName(), BotDuelEndEvent.WinnerType.PLAYER));
            FightInventory var7 = null;

            try {
               Player var4 = (Player)var1;
               var7 = new FightInventory(var4, var4.getName(), var4.getInventory(), this.plugin);
            } catch (Exception var6) {
               if (B.fQ()) {
                  var6.printStackTrace();
               }
            }

            FightInventory var8 = new FightInventory(var2, this.plugin);
            if (var7 != null && var8 != null) {
               var7.setNextInventory(var8);
               var8.setNextInventory(var7);
            }

            Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, () -> {
               this.arena.setUsing(false, (Fight)null);
               if (var2 != null) {
                  AbstractFight.setCurrentFight(var2, (Fight)null);
                  this.plugin.clear(var2, true, true);
               }

            }, (long)(20 * this.plugin.getConfig().getInt("wait-before-teleport")));
            this.plugin.a(var2, "you-won", u.a("<loser>", this.getP2().getNPC().getName(), "<winner>", var2.getName()));
            if (this.plugin.getConfig().getBoolean("clickable-messages") && var7 != null) {
               C.c(() -> {
                  FightInventory.duelMessage(var2, (Player)null, var2.getName(), this.botName, var8, var7);
                  this.sendSpectatorMessages(Collections.singleton(var2.getName()), Collections.singleton(this.botName));
               });
            }

            this.endRecording(var7, var8, this.getP2().getNPC().getUniqueId(), var2.getUniqueId(), var2);
            this.getP2().destroy();
            this.p2 = null;
         }
      }
   }

   private void endRecording(final FightInventory var1, final FightInventory var2, UUID var3, UUID var4, final Player var5) {
      B.debug("Recording ending soon: " + this.recorder);
      if (this.recorder != null && this.recorder.getRecordedMatch() != null && this.recorder.dm()) {
         (new BukkitRunnable() {
            public void run() {
               B.debug("Ending recording");
               ArrayList var1x = new ArrayList();
               var1x.add(var1);
               var1x.add(var2);
               UUID var2x = BotDuel.this.recorder.stopRecording(var1x).getUUID();
               if (var2x != null && BotDuel.this.plugin.getConfig().getBoolean("kill-cam")) {
                  ga.strikepractice.utils.d.b(var5, BotDuel.this.plugin.a(var5, "kill-cam", true, (Map)null)[0], "/replay " + var2x + " killcam 20");
               }

            }
         }).runTaskLater(this.plugin, 40L);
      }

   }

   public void forceEnd(String var1) {
      Player var2 = y.W(this.p1);
      Bukkit.getPluginManager().callEvent(new BotDuelEndEvent(this, var2, this.getP2(), (String)null, (BotDuelEndEvent.WinnerType)null));
      this.arena.setUsing(false, (Fight)null);

      try {
         this.getP2().destroy(true);
      } catch (Exception var4) {
         Bukkit.getLogger().warning("Failed to destroy bot (forceEnd)");
         var4.printStackTrace();
      }

      if (var2 != null) {
         if (var1 != null) {
            var2.sendMessage(var1);
         }

         AbstractFight.setCurrentFight(var2, (Fight)null);
         this.plugin.a(var2, true, true, true);
      }

      this.p2 = null;
      this.ended = true;
      super.ended = System.currentTimeMillis();
   }

   public boolean allowSpectating() {
      return false;
   }

   public boolean hasEnded() {
      return this.ended;
   }

   public void setArena(Arena var1) {
      this.arena = var1;
   }

   public void setBestOf(BestOf var1) {
      this.bestOf = var1;
   }

   public BestOf getBestOf() {
      return this.bestOf;
   }

   public boolean isBreakTime() {
      return this.breaktime;
   }

   public String getP1() {
      return this.p1;
   }

   public String getBotName() {
      return this.botName;
   }

   public CitizensNPC getP2() {
      return this.p2;
   }

   public CitizensNPC.Difficulty getDifficulty() {
      return this.difficulty;
   }

   public void setDifficulty(CitizensNPC.Difficulty var1) {
      this.difficulty = var1;
   }

   public ga.strikepractice.matchrecorder.recorder.fightrecorder.a getRecorder() {
      return this.recorder;
   }

   public List<String> getTeammates(Player var1) {
      return Collections.singletonList(var1.getName());
   }

   public List<String> getOpponents(Player var1) {
      return Collections.singletonList(this.botName);
   }

   public boolean playersAreTeammates(Player var1, Player var2) {
      return false;
   }

   public Collection<CitizensNPC> getBots() {
      return Collections.singletonList(this.getP2());
   }
}
