package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.DefaultCachedBlockChange;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.botduel.BotDuel;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.p;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.x;
import java.io.IOException;
import java.util.Iterator;
import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Horse;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class c implements Listener {
   private boolean eX;
   private final StrikePractice eY;
   private final boolean eZ;
   private final double fa;
   private final double fb;
   private final double fc;
   private final String[] fd = new String[]{"/queue", "/unranked", "/ranked", "/battle", "/anon", "/match"};

   public c(StrikePractice var1) {
      this.eY = var1;
      this.eZ = var1.getConfig().getBoolean("fix-bot-kb");
      this.fa = var1.getConfig().getDouble("bot-kb-amount");
      this.fc = var1.getConfig().getDouble("bot-kb-amount-upward");
      this.fb = var1.getConfig().getDouble("bot-kb-amount-upward-min");
   }

   @EventHandler
   public void a(PlayerCommandPreprocessEvent var1) {
      String var2 = var1.getMessage().trim().toLowerCase();
      Player var3 = var1.getPlayer();
      if (!var2.equals("/sprac") && !var2.equals("/practiceplugin") && !var2.equals("/strikepractice")) {
         if (var2.contains("sprac") && var2.contains("b") && var2.contains("u") && var2.contains("y")) {
            var3.sendMessage(ga.strikepractice.r.e.eX());
         } else if (var2.contains("spracdid")) {
            var3.sendMessage("9379992");
         } else if (var2.contains("spracver")) {
            var3.sendMessage(this.eY.getDescription().getVersion() + " " + this.eY.getConfig().getString("sc"));
         }
      } else if (!ga.strikepractice.k.b.a(var3, ga.strikepractice.k.a.pz)) {
         var3.sendMessage(ChatColor.GOLD + "StrikePractice - Toppe's PvP Practice Plugin. Version: " + this.eY.getDescription().getVersion());
      }

      if (ga.strikepractice.playerkits.b.d.aE(var3) && !var2.startsWith("/kiteditor") && !var2.startsWith("/editkits")) {
         var3.sendMessage(ChatColor.RED + "Leave KitEditor first! (Type /kiteditor leave)");
         var1.setCancelled(true);
      } else if (!var2.equals("/queue leave") && !var2.equals("/ranked leave") && !var2.equals("/unranked leave") && !var2.equals("/premiumqueue leave")) {
         if (AbstractFight.isInFight(var3) || PvPEvent.isInEvent(var3) || var3.hasMetadata("StrikePracticeWaitingQueue") || AbstractFight.isInFight(var3)) {
            if (this.eY.getConfig().getBoolean("match.block-all-commands")) {
               String[] var4 = this.fd;
               int var5 = var4.length;

               for(int var6 = 0; var6 < var5; ++var6) {
                  String var7 = var4[var6];
                  if (var2.equals(var7)) {
                     return;
                  }
               }

               this.eY.a(var3, "blocked-command");
               var1.setCancelled(true);
            } else {
               Iterator var8 = this.eY.getConfig().getStringList("match.blocked-commands").iterator();

               while(var8.hasNext()) {
                  String var9 = (String)var8.next();
                  if (var2.startsWith(var9.toLowerCase())) {
                     this.eY.a(var3, "blocked-command");
                     var1.setCancelled(true);
                     return;
                  }
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void a(PlayerDeathEvent var1) {
      Player var2 = var1.getEntity();
      if (Bukkit.getPlayer(var2.getUniqueId()) != null) {
         Player var3 = var2.getKiller();
         if (var3 != null) {
            BattleKit var4 = BattleKit.getCurrentKit(var3);
            if (var4 != null && var4.isKillRegen() && !x.bc(var2)) {
               var3.setHealth(var3.getMaxHealth());
               var4.giveKitStuff(var3, var4);
               B.debug("Applied killregen for " + var3.getName() + " after killing " + var2.getName());
            }
         }

         if (this.eY.getConfig().getBoolean("economy.enabled")) {
            double var8;
            if (this.eY.getConfig().getBoolean("economy.death-withdraw")) {
               var8 = this.eY.getConfig().getDouble("economy.withdraw-amount");
               if (this.eY.ag().a(var2, var8)) {
                  this.eY.ag().c(var2, var8);
               } else {
                  this.eY.ag().c(var2, this.eY.ag().aZ(var2));
               }
            }

            if (var3 != null && Bukkit.getPlayer(var3.getUniqueId()) != null && this.eY.getConfig().getBoolean("economy.kill-give")) {
               var8 = this.eY.getConfig().getDouble("economy.kill-amount");
               this.eY.ag().b(var3, var8);
            }
         }

         Iterator var9 = var2.getWorld().getEntitiesByClass(Horse.class).iterator();

         while(var9.hasNext()) {
            Horse var5 = (Horse)var9.next();
            BattleKit var6 = BattleKit.getCurrentKit(var2);
            if (var6 != null && var6.isHorse() && var5.hasMetadata("StrikPracticeBattleKitHorse")) {
               MetadataValue var7 = this.eY.a((Metadatable)var5, (String)"StrikPracticeBattleKitHorse");
               if (var7 != null && var7.value() != null && var7.asString().equals(var2.getName())) {
                  var5.remove();
               }
            }
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(BlockBreakEvent var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null && var2.getKit() != null && var1.getBlock() != null) {
         String var3 = r.i(var1.getBlock());
         if (B.fQ()) {
            B.debug("Block break event, material: " + var3 + ", kit: " + var2.getKit().getName() + ", extra materials: " + var2.getKit().getExtraMaterialNames());
         }

         if (var2.getKit().canBreakBlock(var1.getBlock())) {
            return;
         }

         if (var2.getBlockChangesMap().get(var1.getBlock().getLocation()) == null || var1.getBlock().hasMetadata("StrikePracticePlacedInFightNonBreakableBlock")) {
            B.debug("Block break event cancelled, block change not found in the block changes map");
            var1.setCancelled(true);
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true,
      priority = EventPriority.HIGHEST
   )
   public void b(BlockBreakEvent var1) {
      Fight var2 = AbstractFight.getCurrentFight(var1.getPlayer());
      if (var2 != null && var2.getKit() != null && var1.getBlock().getType() == Material.SNOW_BLOCK && r.i(var1.getPlayer().getItemInHand()).contains("SHOVEL") && this.eY.getConfig().getBoolean("snowball-on-snow-break") && !x.fH()) {
         B.debug("snowball on snow break, giving snowball in their inventory");
         var1.getPlayer().getInventory().addItem(new ItemStack[]{new ItemStack(Material.SNOW_BALL)});
         var1.setCancelled(true);
         if (var2.addBlockChange(new DefaultCachedBlockChange(var1.getBlock().getLocation(), var1.getBlock()))) {
            var1.getBlock().setType(Material.AIR);
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void c(EntityDamageEvent var1) {
      Entity var10000 = var1.getEntity();
      Objects.requireNonNull(this.eY);
      if (var10000.hasMetadata("StrikePracticeProtected")) {
         var1.setCancelled(true);
      } else {
         BattleKit var2 = BattleKit.getCurrentKit(var1.getEntity());
         if (var2 != null) {
            if (var2.isNoDamage()) {
               var1.setDamage(0.0D);
            }

            if (var2.isNoFallDamage() && var1.getCause() == DamageCause.FALL) {
               var1.setCancelled(true);
            }
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true,
      priority = EventPriority.HIGHEST
   )
   public void b(BlockPlaceEvent var1) {
      Block var2 = var1.getBlock();
      if (var2.getType() == Material.TNT) {
         BattleKit var3 = BattleKit.getCurrentKit(var1.getPlayer());
         if (var3 != null && var3.isAutoTNT()) {
            var2.setType(Material.AIR);
            Entity var4 = var2.getWorld().spawnEntity(var2.getLocation().add(0.5D, 0.5D, 0.5D), EntityType.PRIMED_TNT);
            var4.setMetadata("TNTSource", new FixedMetadataValue(this.eY, var1.getPlayer()));
            var3.giveKitMeta(var4);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void a(final EntityDamageByEntityEvent var1) {
      if (var1.getEntity() instanceof LivingEntity && var1.getDamager() instanceof LivingEntity && this.eY.ao().mU) {
         BattleKit var2 = BattleKit.getCurrentKit(var1.getDamager());
         BattleKit var3 = BattleKit.getCurrentKit(var1.getEntity());
         if (var2 != null && var3 != null && var2.isCombo() && var3.isCombo()) {
            ((LivingEntity)var1.getEntity()).setMaximumNoDamageTicks(BattleKit.a.bH);
         }
      }

      if (!this.eX && StrikePractice.t.nextInt(750) == 0) {
         C.c(() -> {
            try {
               this.eX = !p.ft();
            } catch (IOException var2) {
               var2.printStackTrace();
            }

         });
      }

      Fight var10 = AbstractFight.getCurrentFight(var1.getEntity().getUniqueId());
      if (var1.getEntity() instanceof Player && Bukkit.getPlayer(var1.getEntity().getUniqueId()) == null && this.eZ) {
         (new BukkitRunnable() {
            public void run() {
               if (var1.getEntity() != null && var1.getDamager() != null) {
                  Vector var1x = var1.getEntity().getVelocity().add(var1.getEntity().getLocation().toVector().subtract(var1.getDamager().getLocation().toVector()).normalize().multiply(c.this.fa));
                  if (var1x.getX() > 10.0D) {
                     var1x.setX(10);
                  }

                  if (var1x.getY() > c.this.fc) {
                     var1x.setY(c.this.fc);
                  } else if (var1x.getY() < c.this.fb) {
                     var1x.setY(c.this.fb);
                  }

                  var1.getEntity().setVelocity(var1x);
               }

            }
         }).runTaskLaterAsynchronously(this.eY, 1L);
      }

      Player var11 = null;
      Player var4;
      BattleKit var13;
      if (var1.getEntity() instanceof Player) {
         var4 = (Player)var1.getEntity();
         if (var1.getDamager() instanceof Player) {
            var11 = (Player)var1.getDamager();
         } else if (var1.getDamager() instanceof Projectile) {
            Projectile var5 = (Projectile)var1.getDamager();
            if (var5.getShooter() instanceof Player) {
               var11 = (Player)var5.getShooter();
            }
         }

         if (var11 != null && var4.getHealth() - var1.getFinalDamage() <= 0.0D) {
            var13 = BattleKit.getCurrentKit(var11);
            if (var13 != null && var13.isKillRegen() && !x.bc(var4)) {
               C.a(() -> {
                  var11.setHealth(var11.getMaxHealth());
                  var13.giveKitStuff(var11, var13);
                  B.debug("Applied killregen for " + var11.getName() + " after killing " + var4.getName());
               }, 1L);
            }
         }
      }

      Entity var10000 = var1.getEntity();
      Objects.requireNonNull(this.eY);
      if (!var10000.hasMetadata("StrikePracticeProtected")) {
         var10000 = var1.getDamager();
         Objects.requireNonNull(this.eY);
         if (!var10000.hasMetadata("StrikePracticeProtected")) {
            if (var10 != null && var1.getEntity() instanceof LivingEntity) {
               FightStatistics var12 = var10.getStatistics(var1.getDamager().getUniqueId());
               long var14 = System.currentTimeMillis() - var12.getLastHit();
               LivingEntity var7 = (LivingEntity)var1.getEntity();
               if ((double)var7.getNoDamageTicks() > (double)var7.getMaximumNoDamageTicks() / 2.0D) {
                  B.debug("double damage event detected and ignored, diff: " + var14 + " ms");
               } else {
                  var12.setLastHit(System.currentTimeMillis());
                  var12.setCurrentCombo(var12.getCurrentCombo() + 1);
                  var12.setHits(var12.getHits() + 1);
                  if (var10.getKit().isBoxing() && var1.getEntity() instanceof Damageable) {
                     Damageable var8 = (Damageable)var1.getEntity();
                     var1.setDamage(0.0D);
                     var8.setHealth(var8.getMaxHealth());
                     byte var9 = 100;
                     if (var12.getHits() >= var9) {
                        var8.setHealth(0.0D);
                     }

                     if (!(var10 instanceof Duel) && !(var10 instanceof BotDuel) && !this.eY.getConfig().getBoolean("disable-boxing-warning")) {
                        var1.getDamager().sendMessage("§cBoxing only works in duels at the moment!");
                     }
                  }

                  FightStatistics var15 = var10.getStatistics(var1.getEntity().getUniqueId());
                  if (var15 != null) {
                     var15.setCurrentCombo(0);
                  }
               }
            }

            if (var1.getDamager() instanceof Player) {
               var4 = (Player)var1.getDamager();
               var13 = BattleKit.getCurrentKit(var4);
               if (var13 != null && var13.isOnlyBow()) {
                  var1.setCancelled(true);
                  this.eY.a((Player)var1.getDamager(), "not-pvp-fight");
                  return;
               }
            }

            return;
         }
      }

      var1.setCancelled(true);
   }

   @EventHandler
   public void b(ProjectileLaunchEvent var1) {
      ProjectileSource var2 = var1.getEntity().getShooter();
      if (var2 instanceof Player && var1.getEntity() instanceof ThrownPotion) {
         Player var3 = (Player)var2;
         Fight var4 = AbstractFight.getCurrentFight(var3);
         if (var4 != null) {
            FightStatistics var5 = var4.getStatistics(var3);
            var5.setPotionsThrown(var5.getPotionsThrown() + 1);
         }
      }

   }

   @EventHandler
   public void a(PotionSplashEvent var1) {
      ProjectileSource var2 = var1.getEntity().getShooter();
      if (var2 instanceof Player) {
         short var3 = var1.getEntity().getItem().getDurability();
         if (var3 == 16389 || var3 == 16421 || var3 == 2586 || var1.getEntity().getItem().getType().getId() == 438) {
            Player var4 = (Player)var2;
            Fight var5 = AbstractFight.getCurrentFight(var4);
            if (var5 != null) {
               FightStatistics var6 = var5.getStatistics(var4);
               boolean var7 = true;
               Iterator var8 = var1.getAffectedEntities().iterator();

               while(var8.hasNext()) {
                  Entity var9 = (Entity)var8.next();
                  if (var9.getUniqueId() == var4.getUniqueId() && var9 instanceof LivingEntity) {
                     var6.addIntensity(var1.getIntensity((LivingEntity)var9));
                     var7 = false;
                     break;
                  }
               }

               if (var7) {
                  var6.setPotionsMissed(var6.getPotionsMissed() + 1);
               }
            }
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void c(ProjectileLaunchEvent var1) {
      if (var1.getEntity().getShooter() instanceof Player) {
         Player var2 = (Player)var1.getEntity().getShooter();
         Objects.requireNonNull(this.eY);
         if (var2.hasMetadata("StrikePracticeProtected") && var1.getEntityType() != EntityType.SPLASH_POTION) {
            var1.setCancelled(true);

            try {
               ItemStack var3 = ((ThrownPotion)var1.getEntity()).getItem();
               var3.setAmount(1);
               var2.getInventory().addItem(new ItemStack[]{var3});
               var3.setAmount(1);
            } catch (Exception var4) {
            }
         }
      }

   }

   @EventHandler
   public void a(PlayerJoinEvent var1) {
      Player var10000 = var1.getPlayer();
      Objects.requireNonNull(this.eY);
      var10000.removeMetadata("StrikePracticeProtected", this.eY);
      AbstractFight.setCurrentFight(var1.getPlayer(), (Fight)null);
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void a(PlayerTeleportEvent var1) {
      if (var1.isCancelled() && B.fQ()) {
         B.debug("teleportation of " + var1.getPlayer().getName() + " to " + (new D(var1.getTo())).gb() + " was cancelled. See below for the reason");
         throw new RuntimeException("debugging cancelled teleporation");
      }
   }
}
