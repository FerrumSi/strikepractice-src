package ga.strikepractice.fights;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.battlekit.BattleKit;

@APIClass
public class EloChange {
   private final BattleKit kit;
   private final int eloChange;

   public EloChange(BattleKit var1, int var2) {
      this.kit = var1;
      this.eloChange = var2;
   }

   public int getEloChange() {
      return this.eloChange;
   }

   public BattleKit getKit() {
      return this.kit;
   }
}
