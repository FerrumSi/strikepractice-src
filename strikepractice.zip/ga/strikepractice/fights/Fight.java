package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.DefaultCachedBlockChange;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.utils.C;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@APIClass
public interface Fight {
   void start();

   boolean allowSpectating();

   Arena getArena();

   void setArena(Arena var1);

   void setKit(BattleKit var1);

   FightStatistics getStatistics(UUID var1);

   FightStatistics getStatistics(Player var1);

   /** @deprecated */
   @Deprecated
   HashMap<UUID, FightStatistics> getStatistics();

   default Map<UUID, FightStatistics> getFightStatistics() {
      return this.getStatistics();
   }

   @Nullable
   default FightStatistics getFightStatistics(@NotNull Player var1) {
      return (FightStatistics)this.getFightStatistics().get(var1.getUniqueId());
   }

   boolean hasEnded();

   default boolean hasStarted() {
      return System.currentTimeMillis() > this.getStarted();
   }

   boolean canStart();

   void handleDeath(Player var1);

   void forceEnd(String var1);

   default void forceEndDelayed(String var1) {
      C.a(() -> {
         this.forceEnd(var1);
      }, 5L);
   }

   BattleKit getKit();

   long getStarted();

   long getEnded();

   void setStartedAfterCountdown();

   long getDuration();

   /** @deprecated */
   @Deprecated
   Set<DefaultCachedBlockChange> getBlockChanges();

   Map<Location, DefaultCachedBlockChange> getBlockChangesMap();

   MatchDurationLimit getDurationLimit();

   boolean addBlockChange(DefaultCachedBlockChange var1);

   default void clearBlockChanges() {
      this.getBlockChanges().clear();
   }

   /** @deprecated */
   @Deprecated
   default ga.strikepractice.fights.savedfights.b saveFight(List<UUID> var1, List<UUID> var2, List<FightInventory> var3, List<FightInventory> var4, UUID var5) {
      return null;
   }

   default List<Player> getPlayersInFight() {
      StrikePractice var1 = StrikePractice.getInstance();
      ArrayList var2 = new ArrayList(2);
      Iterator var3 = Bukkit.getOnlinePlayers().iterator();

      while(var3.hasNext()) {
         Player var4 = (Player)var3.next();
         if (AbstractFight.getCurrentFight(var4) == this) {
            var2.add(var4);
         }
      }

      return var2;
   }

   default List<String> getPlayerNames() {
      return (List)this.getPlayersInFight().stream().map(OfflinePlayer::getName).collect(Collectors.toList());
   }

   List<String> getTeammates(Player var1);

   List<String> getOpponents(Player var1);

   default boolean playersAreTeammates(Player var1, Player var2) {
      return this.getTeammates(var1).contains(var2.getName());
   }

   default boolean playersAreOpponents(Player var1, Player var2) {
      return this.getOpponents(var1).contains(var2.getName());
   }

   default List<Player> getSpectators() {
      return (List)StrikePractice.getInstance().ac().d(this).stream().map(Bukkit::getPlayer).filter(Objects::nonNull).collect(Collectors.toList());
   }
}
