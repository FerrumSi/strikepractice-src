package ga.strikepractice.fights.elo;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.utils.B;

@APIClass
public interface EloCalculator {
   void calculateElo(EloChanges var1);

   static EloCalculator getEloCalculator() {
      return EloCalculator.Companion.fP;
   }

   static void setEloCalculator(EloCalculator var0) {
      EloCalculator.Companion.fP = var0;
   }

   static EloCalculator withModifier(EloCalculator var0, double var1) {
      return (var3) -> {
         var0.calculateElo(var3);
         B.debug(String.format("Calculating elo with modifier %f\nOld elo: %d/%d\nNew elo: %d/%d", var1, var3.getWinnerOldElo(), var3.getLoserOldElo(), var3.getWinnerNewElo(), var3.getLoserNewElo()));
         var3.setWinnerNewElo(var3.getWinnerOldElo() + (int)((double)var3.getWinnerChange() * var1));
         var3.setLoserNewElo(var3.getLoserOldElo() + (int)((double)var3.getLoserChange() * var1));
         B.debug(String.format("New elo: %d/%d", var3.getWinnerNewElo(), var3.getLoserNewElo()));
      };
   }

   public static class Companion {
      public static EloCalculator fP = new EloCalculator.DefaultEloCalculator();
   }

   @APIClass
   public static class DefaultEloCalculator implements EloCalculator {
      public void calculateElo(EloChanges var1) {
         int var2 = var1.getWinnerOldElo();
         int var3 = var1.getLoserOldElo();
         int var4 = var2;
         int var5 = var3;
         int var6;
         if (var2 > var3) {
            var6 = var2 - var3;
            if (var6 >= 101 && var6 <= 200) {
               var4 = var2 + 4;
               var5 = var3 - 4;
            }

            if (var6 > 200) {
               var4 = var2 + 3;
               var5 = var3 - 3;
            }

            if (var6 >= 51 && var6 <= 100) {
               var4 = var2 + 6;
               var5 = var3 - 6;
            }

            if (var6 <= 50) {
               var4 = var2 + 7;
               var5 = var3 - 7;
            }
         }

         if (var2 == var3) {
            var4 = var2 + 8;
            var5 = var3 - 8;
         }

         if (var3 > var2) {
            var6 = var3 - var2;
            if (var6 >= 101 && var6 <= 150) {
               var5 = var3 - 15;
               var4 = var2 + 15;
            }

            if (var6 >= 151 && var6 <= 200) {
               var5 = var3 - 17;
               var4 = var2 + 17;
            }

            if (var6 > 200) {
               var5 = var3 - 21;
               var4 = var2 + 21;
            }

            if (var6 >= 51 && var6 <= 100) {
               var5 = var3 - 13;
               var4 = var2 + 13;
            }

            if (var6 <= 50) {
               var5 = var3 - 10;
               var4 = var2 + 10;
            }
         }

         var5 = Math.max(var5, 0);
         var4 = Math.max(var4, 0);
         var1.setWinnerNewElo(var4);
         var1.setLoserNewElo(var5);
      }
   }
}
