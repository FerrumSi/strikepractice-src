package ga.strikepractice.fights.elo;

import ga.strikepractice.api.APIClass;

@APIClass
public class EloChanges {
   private final int winnerOldElo;
   private final int loserOldElo;
   private int winnerNewElo;
   private int loserNewElo;

   public EloChanges(int var1, int var2, int var3, int var4) {
      this.winnerOldElo = var1;
      this.loserOldElo = var2;
      this.winnerNewElo = var3;
      this.loserNewElo = var4;
   }

   public int getWinnerChange() {
      return this.winnerNewElo - this.winnerOldElo;
   }

   public int getLoserChange() {
      return this.loserNewElo - this.loserOldElo;
   }

   public int getLoserNewElo() {
      return this.loserNewElo;
   }

   public int getLoserOldElo() {
      return this.loserOldElo;
   }

   public int getWinnerNewElo() {
      return this.winnerNewElo;
   }

   public int getWinnerOldElo() {
      return this.winnerOldElo;
   }

   public void setLoserNewElo(int var1) {
      this.loserNewElo = var1;
   }

   public void setWinnerNewElo(int var1) {
      this.winnerNewElo = var1;
   }
}
