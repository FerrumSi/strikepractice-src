package ga.strikepractice.fights.duel;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.StrikePracticeAPI;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.botduel.BotDuel;
import ga.strikepractice.fights.party.partyfights.PartyFFA;
import ga.strikepractice.fights.party.partyfights.PartySplit;
import ga.strikepractice.fights.party.partyfights.PartyVsBots;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.collections.ArraysKt;
import ga.strikepractice.kotlin.collections.SetsKt;
import ga.strikepractice.kotlin.jvm.JvmOverloads;
import ga.strikepractice.kotlin.jvm.JvmStatic;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.I;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.Q;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.x;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.material.Wool;
import org.bukkit.metadata.Metadatable;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0010\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\bH\u0007J\u0010\u0010\t\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\nH\u0007J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\fH\u0007J\u0010\u0010\r\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u000eH\u0007J\u0010\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0010H\u0007J\u0010\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0012H\u0007J\u0010\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u0015H\u0002¨\u0006\u0017"},
   d2 = {"Lga/strikepractice/fights/duel/BedWars;", "Lorg/bukkit/event/Listener;", "()V", "itemSpawn", "", "e", "Lorg/bukkit/event/entity/ItemSpawnEvent;", "onBlockBreak", "Lorg/bukkit/event/block/BlockBreakEvent;", "onDamage", "Lorg/bukkit/event/entity/EntityDamageEvent;", "onExplosion", "Lorg/bukkit/event/entity/EntityExplodeEvent;", "onPortal", "Lorg/bukkit/event/player/PlayerPortalEvent;", "onShoot", "Lorg/bukkit/event/entity/EntityShootBowEvent;", "onSleep", "Lorg/bukkit/event/player/PlayerBedEnterEvent;", "reloadArrow", "p", "Lorg/bukkit/entity/Player;", "Companion", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nBedWars.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BedWars.kt\nga/strikepractice/fights/duel/BedWars\n+ 2 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,429:1\n81#2,4:430\n81#2,4:438\n88#2,4:442\n81#2,4:446\n81#2,4:450\n81#2,4:454\n81#2,4:458\n81#2,4:462\n81#2,4:466\n81#2,4:474\n81#2,4:478\n81#2,4:482\n81#2,4:486\n81#2,4:490\n81#2,4:494\n81#2,4:498\n12744#3,2:434\n12744#3,2:436\n1855#4:470\n1855#4,2:471\n1856#4:473\n*S KotlinDebug\n*F\n+ 1 BedWars.kt\nga/strikepractice/fights/duel/BedWars\n*L\n43#1:430,4\n49#1:438,4\n71#1:442,4\n73#1:446,4\n85#1:450,4\n90#1:454,4\n97#1:458,4\n101#1:462,4\n103#1:466,4\n133#1:474,4\n142#1:478,4\n147#1:482,4\n149#1:486,4\n151#1:490,4\n171#1:494,4\n184#1:498,4\n47#1:434,2\n48#1:436,2\n112#1:470\n113#1:471,2\n112#1:473\n*E\n"})
public final class a implements Listener {
   @NotNull
   public static final ga.strikepractice.fights.duel.a.a fv = new ga.strikepractice.fights.duel.a.a((DefaultConstructorMarker)null);
   @NotNull
   private static final Material[] fw;

   private final void r(Player var1) {
      StrikePractice var2 = StrikePractice.getInstance();
      B.a var3 = B.vj;
      boolean var4 = false;
      boolean var5;
      Logger var13;
      StringBuilder var14;
      String var15;
      Logger var10000;
      if (var3.fV()) {
         var10000 = Bukkit.getLogger();
         var14 = (new StringBuilder()).append("[SP DEBUG] ");
         var13 = var10000;
         var5 = false;
         var15 = "Checking if " + var1.getName() + " needs arrows in /battlekit bedwars";
         var13.info(var14.append(var15).toString());
      }

      if (var2.getConfig().getBoolean("bedwars-reload-arrows")) {
         BattleKit var16 = BattleKit.getCurrentKit((Metadatable)var1);
         if ((var16 != null ? var16.isBedwars() : false) || (var16 != null ? var16.isBridges() : false)) {
            ItemStack[] var26 = var1.getInventory().getContents();
            Intrinsics.checkNotNullExpressionValue(var26, "p.inventory.contents");
            Object[] var17 = (Object[])var26;
            boolean var6 = false;
            int var7 = 0;

            int var8;
            boolean var27;
            label83: {
               for(var8 = var17.length; var7 < var8; ++var7) {
                  Object var9 = var17[var7];
                  ItemStack var10 = (ItemStack)var9;
                  boolean var11 = false;
                  if ((var10 != null ? var10.getType() : null) == Material.BOW) {
                     var27 = true;
                     break label83;
                  }
               }

               var27 = false;
            }

            var4 = var27;
            var26 = var1.getInventory().getContents();
            Intrinsics.checkNotNullExpressionValue(var26, "p.inventory.contents");
            Object[] var18 = (Object[])var26;
            boolean var21 = false;
            var8 = 0;

            label72: {
               for(int var23 = var18.length; var8 < var23; ++var8) {
                  Object var24 = var18[var8];
                  ItemStack var25 = (ItemStack)var24;
                  boolean var12 = false;
                  if ((var25 != null ? var25.getType() : null) == Material.ARROW) {
                     var27 = true;
                     break label72;
                  }
               }

               var27 = false;
            }

            var5 = var27;
            B.a var19 = B.vj;
            var21 = false;
            if (var19.fV()) {
               var10000 = Bukkit.getLogger();
               var14 = (new StringBuilder()).append("[SP DEBUG] ");
               var13 = var10000;
               boolean var22 = false;
               var15 = var1.getName() + " hasBow=" + var4 + ", hasArrow=" + var5 + ' ';
               var13.info(var14.append(var15).toString());
            }

            if (var4 && !var5) {
               PlayerInventory var28 = var1.getInventory();
               ItemStack[] var20 = new ItemStack[]{new ItemStack(Material.ARROW)};
               var28.addItem(var20);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public final void a(@NotNull EntityShootBowEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (var1.getProjectile() instanceof Projectile) {
         Entity var10000 = var1.getProjectile();
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.bukkit.entity.Projectile");
         ProjectileSource var2 = ((Projectile)var10000).getShooter();
         if (var2 instanceof Player) {
            C.a(ga.strikepractice.fights.duel.a::a, 100L);
         }
      }

   }

   @EventHandler
   public final void c(@NotNull BlockBreakEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      B.a var2 = B.vj;
      boolean var3 = false;
      boolean var4;
      Logger var10000;
      Logger var23;
      StringBuilder var24;
      String var25;
      if (var2.fX()) {
         var10000 = Bukkit.getLogger();
         var24 = (new StringBuilder()).append("[SP TRACE] ");
         var23 = var10000;
         var4 = false;
         var25 = var1.getPlayer().getName() + " broke " + var1.getBlock().getType().name() + '/' + r.i(var1.getBlock());
         var23.info(var24.append(var25).toString());
      }

      if (!StringsKt.contains$default((CharSequence)r.i(var1.getBlock()), (CharSequence)"BED", false, 2, (Object)null)) {
         Block var35 = var1.getBlock();
         if ((var35 != null ? var35.getType() : null) != Material.DRAGON_EGG) {
            return;
         }
      }

      var2 = B.vj;
      var3 = false;
      if (var2.fV()) {
         var10000 = Bukkit.getLogger();
         var24 = (new StringBuilder()).append("[SP DEBUG] ");
         var23 = var10000;
         var4 = false;
         var25 = var1.getPlayer().getName() + " broke bed/dragon egg";
         var23.info(var24.append(var25).toString());
      }

      Player var26 = var1.getPlayer();
      if (!StrikePractice.getInstance().ac().isSpectator(var26)) {
         AbstractFight var27;
         BattleKit var36;
         boolean var37;
         label121: {
            var27 = (AbstractFight)AbstractFight.getCurrentFight(var26);
            if (var27 != null) {
               var36 = var27.getKit();
               if (var36 != null) {
                  var37 = var36.isBedwars();
                  break label121;
               }
            }

            var37 = false;
         }

         if (!var37) {
            label114: {
               if (var27 != null) {
                  var36 = var27.getKit();
                  if (var36 != null) {
                     var37 = var36.isBridges();
                     break label114;
                  }
               }

               var37 = false;
            }

            if (!var37) {
               return;
            }
         }

         if (var27.hasStarted()) {
            ga.strikepractice.fights.duel.a.a var39;
            if (var27.getKit().isBridges()) {
               var1.setCancelled(true);
               var39 = fv;
               Location var10001 = var1.getBlock().getLocation();
               Intrinsics.checkNotNullExpressionValue(var10001, "e.block.location");
               Intrinsics.checkNotNullExpressionValue(var26, "p");
               var39.a(var10001, var26);
            } else {
               B.a var28 = B.vj;
               boolean var5 = false;
               if (var28.fV()) {
                  var10000 = Bukkit.getLogger();
                  var24 = (new StringBuilder()).append("[SP DEBUG] ");
                  var23 = var10000;
                  boolean var6 = false;
                  var25 = var1.getPlayer().getName() + " broke bed in *real* bedwars";
                  var23.info(var24.append(var25).toString());
               }

               var39 = fv;
               Intrinsics.checkNotNullExpressionValue(var26, "p");
               int var29 = var39.i(var26, (Fight)var27);
               Pair var30 = fv.g(var26, (Fight)var27);
               Location var31 = (Location)var30.component1();
               Location var7 = (Location)var30.component2();
               Location var8 = var1.getBlock().getLocation();
               B.a var9;
               boolean var10;
               boolean var11;
               if (var8.distanceSquared(var31) < var8.distanceSquared(var7)) {
                  var9 = B.vj;
                  var10 = false;
                  if (var9.fV()) {
                     var10000 = Bukkit.getLogger();
                     var24 = (new StringBuilder()).append("[SP DEBUG] ");
                     var23 = var10000;
                     var11 = false;
                     var25 = var1.getPlayer().getName() + " broke their own bed in bedwars";
                     var23.info(var24.append(var25).toString());
                  }

                  var1.setCancelled(true);
                  return;
               }

               if (var29 == 1) {
                  if (var27.isBed2Broken()) {
                     return;
                  }

                  var27.setBed2Broken(true);
                  var9 = B.vj;
                  var10 = false;
                  if (var9.fV()) {
                     var10000 = Bukkit.getLogger();
                     var24 = (new StringBuilder()).append("[SP DEBUG] ");
                     var23 = var10000;
                     var11 = false;
                     var25 = var1.getPlayer().getName() + " broke bed2";
                     var23.info(var24.append(var25).toString());
                  }
               } else {
                  if (var27.isBed1Broken()) {
                     return;
                  }

                  var27.setBed1Broken(true);
                  var9 = B.vj;
                  var10 = false;
                  if (var9.fV()) {
                     var10000 = Bukkit.getLogger();
                     var24 = (new StringBuilder()).append("[SP DEBUG] ");
                     var23 = var10000;
                     var11 = false;
                     var25 = var1.getPlayer().getName() + " broke bed1";
                     var23.info(var24.append(var25).toString());
                  }
               }

               var9 = B.vj;
               var10 = false;
               if (var9.fV()) {
                  var10000 = Bukkit.getLogger();
                  var24 = (new StringBuilder()).append("[SP DEBUG] ");
                  var23 = var10000;
                  var11 = false;
                  var25 = var1.getPlayer().getName() + " broke bed for first time in this fight";
                  var23.info(var24.append(var25).toString());
               }

               String var32 = StrikePractice.getInstance().getConfig().getString("bedwars-bed-break-sound");
               if (var32 != null) {
                  I.a(var8, var32, 2.0F, 1.0F);
               }

               List var33 = StrikePractice.getInstance().getConfig().getStringList("bedwars-bed-break-commands");
               if (var33 != null && !((Collection)var33).isEmpty()) {
                  List var40 = var27.getOpponents(var26);
                  Intrinsics.checkNotNullExpressionValue(var40, "fight.getOpponents(p)");
                  Iterable var34 = (Iterable)var40;
                  boolean var12 = false;
                  Iterator var13 = var34.iterator();

                  while(var13.hasNext()) {
                     Object var14 = var13.next();
                     String var15 = (String)var14;
                     boolean var16 = false;
                     Iterable var17 = (Iterable)var33;
                     boolean var18 = false;
                     Iterator var19 = var17.iterator();

                     while(var19.hasNext()) {
                        Object var20 = var19.next();
                        String var21 = (String)var20;
                        boolean var22 = false;
                        CommandSender var41 = (CommandSender)Bukkit.getConsoleSender();
                        Intrinsics.checkNotNullExpressionValue(var21, "command");
                        Intrinsics.checkNotNullExpressionValue(var15, "opponent");
                        String var38 = StringsKt.replace$default(var21, "<target>", var15, false, 4, (Object)null);
                        String var10003 = var26.getName();
                        Intrinsics.checkNotNullExpressionValue(var10003, "p.name");
                        Bukkit.dispatchCommand(var41, StringsKt.replace$default(var38, "<player>", var10003, false, 4, (Object)null));
                     }
                  }
               }
            }
         }

      }
   }

   @EventHandler
   public final void a(@NotNull ItemSpawnEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (!x.uZ.fK()) {
         if (r.j(var1.getEntity().getItemStack())) {
            B.a var2 = B.vj;
            boolean var3 = false;
            if (var2.fV()) {
               Logger var10000 = Bukkit.getLogger();
               StringBuilder var6 = (new StringBuilder()).append("[SP DEBUG] ");
               Logger var5 = var10000;
               boolean var4 = false;
               String var7 = "Cancelled bed item spawn";
               var5.info(var6.append(var7).toString());
            }

            var1.setCancelled(true);
         }

      }
   }

   @EventHandler
   public final void a(@NotNull PlayerPortalEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      Player var2 = var1.getPlayer();
      Fight var3 = AbstractFight.getCurrentFight(var2);
      B.a var4 = B.vj;
      boolean var5 = false;
      boolean var6;
      Logger var7;
      StringBuilder var8;
      String var9;
      Logger var10000;
      if (var4.fV()) {
         var10000 = Bukkit.getLogger();
         var8 = (new StringBuilder()).append("[SP DEBUG] ");
         var7 = var10000;
         var6 = false;
         var9 = var2.getName() + " entered portal";
         var7.info(var8.append(var9).toString());
      }

      if (var3 != null || StrikePractice.getInstance().ac().isSpectator(var2)) {
         var1.setCancelled(true);
      }

      boolean var11;
      label40: {
         if (var3 != null) {
            BattleKit var10 = var3.getKit();
            if (var10 != null) {
               var11 = var10.isBridges();
               break label40;
            }
         }

         var11 = false;
      }

      if (var11) {
         var4 = B.vj;
         var5 = false;
         if (var4.fV()) {
            var10000 = Bukkit.getLogger();
            var8 = (new StringBuilder()).append("[SP DEBUG] ");
            var7 = var10000;
            var6 = false;
            var9 = var2.getName() + " entered portal in the bridge";
            var7.info(var8.append(var9).toString());
         }

         ga.strikepractice.fights.duel.a.a var12 = fv;
         Location var10001 = var2.getLocation();
         Intrinsics.checkNotNullExpressionValue(var10001, "p.location");
         Intrinsics.checkNotNullExpressionValue(var2, "p");
         if (!var12.a(var10001, var2)) {
            var4 = B.vj;
            var5 = false;
            if (var4.fV()) {
               var10000 = Bukkit.getLogger();
               var8 = (new StringBuilder()).append("[SP DEBUG] ");
               var7 = var10000;
               var6 = false;
               var9 = var2.getName() + " bedwars portal win failed to handle. See above";
               var7.info(var8.append(var9).toString());
            }
         } else {
            var4 = B.vj;
            var5 = false;
            if (var4.fV()) {
               var10000 = Bukkit.getLogger();
               var8 = (new StringBuilder()).append("[SP DEBUG] ");
               var7 = var10000;
               var6 = false;
               var9 = var2.getName() + " handle win handled";
               var7.info(var8.append(var9).toString());
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public final void b(@NotNull EntityExplodeEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      var1.blockList().removeIf(ga.strikepractice.fights.duel.a::c);
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public final void d(@NotNull EntityDamageEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (var1.getEntity() instanceof Damageable) {
         Entity var10000 = var1.getEntity();
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.bukkit.entity.Damageable");
         double var2 = ((Damageable)var10000).getHealth();
         if (var1.getFinalDamage() >= var2 && var1.getEntity() instanceof Player) {
            var10000 = var1.getEntity();
            Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.bukkit.entity.Player");
            Player var4 = (Player)var10000;
            Fight var5 = StrikePractice.getAPI().getFight(var4);
            if (var5 != null && !var5.hasEnded() && var5.getKit() != null && (var5.getKit().isBedwars() || var5.getKit().isBridges())) {
               B.a var6 = B.vj;
               boolean var7 = false;
               if (var6.fV()) {
                  Logger var12 = Bukkit.getLogger();
                  StringBuilder var10 = (new StringBuilder()).append("[SP DEBUG] ");
                  Logger var9 = var12;
                  boolean var8 = false;
                  String var11 = var4.getName() + " would have died finalDamage=" + var1.getFinalDamage() + " health=" + var2 + " but kit has bedwars enabled";
                  var9.info(var10.append(var11).toString());
               }

               if (!ga.strikepractice.fights.duel.a.a.a(fv, var4, (Fight)null, 2, (Object)null)) {
                  var1.setCancelled(true);
               }
            }
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public final void a(@NotNull PlayerBedEnterEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      BattleKit var2 = StrikePractice.getAPI().getKit(var1.getPlayer());
      if ((var2 != null ? var2.isBedwars() : false) || (var2 != null ? var2.isBridges() : false)) {
         var1.setCancelled(true);
         B.a var3 = B.vj;
         boolean var4 = false;
         if (var3.fV()) {
            Logger var10000 = Bukkit.getLogger();
            StringBuilder var7 = (new StringBuilder()).append("[SP DEBUG] ");
            Logger var6 = var10000;
            boolean var5 = false;
            String var8 = "StrikePractice cancelled sleeping in bed with the kit.";
            var6.info(var7.append(var8).toString());
         }
      }

   }

   private static final void a(ProjectileSource var0, ga.strikepractice.fights.duel.a var1) {
      Intrinsics.checkNotNullParameter(var1, "this$0");
      if (((Player)var0).isOnline()) {
         Intrinsics.checkNotNullExpressionValue(var0, "shooter");
         var1.r((Player)var0);
      }

   }

   private static final boolean c(Function1 var0, Object var1) {
      Intrinsics.checkNotNullParameter(var0, "$tmp0");
      return (Boolean)var0.invoke(var1);
   }

   @JvmStatic
   @NotNull
   public static final ChatColor s(@NotNull Player var0) {
      return fv.x(var0);
   }

   @JvmStatic
   @NotNull
   public static final ChatColor t(@NotNull Player var0) {
      return fv.y(var0);
   }

   @JvmStatic
   public static final void u(@NotNull Player var0) {
      fv.z(var0);
   }

   @JvmStatic
   @JvmOverloads
   public static final boolean a(@NotNull Player var0, @Nullable Fight var1) {
      return fv.e(var0, var1);
   }

   @JvmStatic
   @JvmOverloads
   public static final void b(@NotNull Player var0, @Nullable Fight var1) {
      fv.f(var0, var1);
   }

   @JvmStatic
   @NotNull
   public static final Location c(@NotNull Player var0, @NotNull Fight var1) {
      return fv.h(var0, var1);
   }

   @JvmStatic
   public static final int d(@NotNull Player var0, @Nullable Fight var1) {
      return fv.i(var0, var1);
   }

   @JvmStatic
   @JvmOverloads
   public static final boolean v(@NotNull Player var0) {
      return fv.A(var0);
   }

   @JvmStatic
   @JvmOverloads
   public static final void w(@NotNull Player var0) {
      fv.B(var0);
   }

   static {
      Material[] var0 = new Material[]{Material.WOOL, Material.STAINED_CLAY};
      fw = var0;
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0007J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\t\u001a\u00020\nH\u0007J\u0018\u0010\r\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\u0010H\u0007J\u001a\u0010\u0011\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\n2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0007J$\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000e0\u00142\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u0010\u0010\u0015\u001a\u00020\f2\u0006\u0010\t\u001a\u00020\nH\u0007J\u001c\u0010\u0016\u001a\u00020\u00172\u0006\u0010\t\u001a\u00020\n2\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0007J\u0018\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0019\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\nH\u0002J\u001c\u0010\u001a\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0007R\u0016\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0006¨\u0006\u001b"},
      d2 = {"Lga/strikepractice/fights/duel/BedWars$Companion;", "", "()V", "COLORABLE_MATERIALS", "", "Lorg/bukkit/Material;", "[Lorg/bukkit/Material;", "applyTeamColors", "", "p", "Lorg/bukkit/entity/Player;", "getOpponentColor", "Lorg/bukkit/ChatColor;", "getOwnSpawn", "Lorg/bukkit/Location;", "fight", "Lga/strikepractice/fights/Fight;", "getSpawnPoint", "", "getSpawnPoints", "Lga/strikepractice/kotlin/Pair;", "getTeamColor", "handleDeath", "", "handleWin", "loc", "respawn", "strikepractice-core"}
   )
   @SourceDebugExtension({"SMAP\nBedWars.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BedWars.kt\nga/strikepractice/fights/duel/BedWars$Companion\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n*L\n1#1,429:1\n13579#2,2:430\n3792#2:432\n4307#2,2:433\n1855#3:435\n1856#3:440\n81#4,4:436\n81#4,4:441\n81#4,4:445\n81#4,4:449\n81#4,4:453\n81#4,4:457\n81#4,4:461\n*S KotlinDebug\n*F\n+ 1 BedWars.kt\nga/strikepractice/fights/duel/BedWars$Companion\n*L\n212#1:430,2\n230#1:432\n230#1:433,2\n231#1:435\n231#1:440\n232#1:436,4\n246#1:441,4\n270#1:445,4\n285#1:449,4\n287#1:453,4\n378#1:457,4\n336#1:461,4\n*E\n"})
   public static final class a {
      private a() {
      }

      @JvmStatic
      @NotNull
      public final ChatColor x(@NotNull Player var1) {
         Intrinsics.checkNotNullParameter(var1, "p");
         boolean var2 = this.i(var1, AbstractFight.getCurrentFight(var1)) == 1;
         return var2 ? ChatColor.BLUE : ChatColor.RED;
      }

      @JvmStatic
      @NotNull
      public final ChatColor y(@NotNull Player var1) {
         Intrinsics.checkNotNullParameter(var1, "p");
         boolean var2 = this.i(var1, AbstractFight.getCurrentFight(var1)) == 1;
         return !var2 ? ChatColor.BLUE : ChatColor.RED;
      }

      @JvmStatic
      public final void z(@NotNull Player var1) {
         Intrinsics.checkNotNullParameter(var1, "p");
         boolean var2 = this.i(var1, AbstractFight.getCurrentFight(var1)) == 1;
         Color var3 = var2 ? Color.BLUE : Color.RED;
         int var4 = var2 ? 11 : 14;
         StrikePractice var5 = StrikePractice.getInstance();
         PlayerInventory var6 = var1.getInventory();
         boolean var8 = false;
         ItemStack[] var10000 = var6.getArmorContents();
         Intrinsics.checkNotNullExpressionValue(var10000, "armorContents");
         Object[] var9 = (Object[])var10000;
         boolean var10 = false;
         int var11 = 0;

         Object var13;
         ItemStack var14;
         boolean var15;
         boolean var20;
         for(int var12 = var9.length; var11 < var12; ++var11) {
            var13 = var9[var11];
            var14 = (ItemStack)var13;
            var15 = false;
            if ((var14 != null ? var14.getItemMeta() : null) instanceof LeatherArmorMeta) {
               ItemMeta var40 = var14.getItemMeta();
               Intrinsics.checkNotNull(var40, "null cannot be cast to non-null type org.bukkit.inventory.meta.LeatherArmorMeta");
               LeatherArmorMeta var16 = (LeatherArmorMeta)var40;
               var20 = false;
               var16.setColor(var3);
               var14.setItemMeta((ItemMeta)var16);
            }
         }

         boolean var26 = Q.vY && !var5.getConfig().getBoolean("disable-colored-items-hack");
         var10000 = var6.getContents();
         Intrinsics.checkNotNullExpressionValue(var10000, "contents");
         Object[] var27 = (Object[])var10000;
         boolean var30 = false;
         Object[] var31 = var27;
         Collection var35 = (Collection)(new ArrayList());
         boolean var37 = false;
         int var38 = 0;

         for(int var39 = var27.length; var38 < var39; ++var38) {
            Object var17 = var31[var38];
            ItemStack var18 = (ItemStack)var17;
            boolean var19 = false;
            if (ArraysKt.contains(ga.strikepractice.fights.duel.a.fw, var18 != null ? var18.getType() : null)) {
               var35.add(var17);
            }
         }

         Iterable var28 = (Iterable)((List)var35);
         var30 = false;
         Iterator var33 = var28.iterator();

         Logger var42;
         while(var33.hasNext()) {
            var13 = var33.next();
            var14 = (ItemStack)var13;
            var15 = false;
            B.a var41 = B.vj;
            boolean var43 = false;
            if (var41.fV()) {
               StringBuilder var44;
               String var45;
               StringBuilder var47;
               Logger var48;
               label87: {
                  var42 = Bukkit.getLogger();
                  var47 = (new StringBuilder()).append("[SP DEBUG] ");
                  var48 = var42;
                  var20 = false;
                  var44 = (new StringBuilder()).append("colorable item detected: ");
                  if (var14 != null) {
                     Material var10001 = var14.getType();
                     if (var10001 != null) {
                        var45 = var10001.name();
                        break label87;
                     }
                  }

                  var45 = null;
               }

               String var21 = var44.append(var45).append(" (").append(var14 != null ? var14.getDurability() : null).append(')').toString();
               var48.info(var47.append(var21).toString());
            }

            var20 = false;
            int var22 = var1.getInventory().first(var14);
            var14.setDurability((short)var4);
            if (var26 && var22 != -1) {
               PlayerInventory var46 = var1.getInventory();
               Intrinsics.checkNotNullExpressionValue(var14, "it");
               var46.setItem(var22, a((short)var4, var14));
            }
         }

         if (var26) {
            ItemStack var29 = var5.ao().dH().am(var1);
            if (var29 != null && ArraysKt.contains(ga.strikepractice.fights.duel.a.fw, var29.getType())) {
               B.a var32 = B.vj;
               boolean var34 = false;
               if (var32.fV()) {
                  var42 = Bukkit.getLogger();
                  StringBuilder var23 = (new StringBuilder()).append("[SP DEBUG] ");
                  Logger var24 = var42;
                  boolean var36 = false;
                  String var25 = "colorable item detected in offhand: " + var29.getType().name() + " (" + var29.getDurability() + ')';
                  var24.info(var23.append(var25).toString());
               }

               var29.setDurability((short)var4);
               var5.ao().dH().a(var1, a((short)var4, var29));
            }
         }

         var1.updateInventory();
      }

      @JvmStatic
      @JvmOverloads
      public final boolean e(@NotNull Player var1, @Nullable Fight var2) {
         Intrinsics.checkNotNullParameter(var1, "p");
         AbstractFight var10000 = (AbstractFight)var2;
         int var3 = this.i(var1, var2);
         if (var2 != null && ((AbstractFight)var2).getKit() != null) {
            if (((AbstractFight)var2).getKit().isBridges()) {
               this.f(var1, var2);
            } else if (((AbstractFight)var2).getKit().isBedwars()) {
               if (var3 == 1 && ((AbstractFight)var2).isBed1Broken()) {
                  return true;
               }

               if (var3 == 2 && ((AbstractFight)var2).isBed2Broken()) {
                  return true;
               }

               B.a var4 = B.vj;
               boolean var5 = false;
               if (var4.fV()) {
                  Logger var10 = Bukkit.getLogger();
                  StringBuilder var8 = (new StringBuilder()).append("[SP DEBUG] ");
                  Logger var7 = var10;
                  boolean var6 = false;
                  String var9 = var1.getName() + " died in bedwars but bed is not broken. ownSpawn=" + var3 + ", fight=" + var2;
                  var7.info(var8.append(var9).toString());
               }

               this.f(var1, var2);
            }
         }

         return false;
      }

      // $FF: synthetic method
      public static boolean a(ga.strikepractice.fights.duel.a.a var0, Player var1, Fight var2, int var3, Object var4) {
         if ((var3 & 2) != 0) {
            var2 = AbstractFight.getCurrentFight(var1);
         }

         return var0.e(var1, var2);
      }

      @JvmStatic
      @JvmOverloads
      public final void f(@NotNull Player var1, @Nullable Fight var2) {
         Intrinsics.checkNotNullParameter(var1, "p");
         if (var2 != null && var2.getKit() != null) {
            StrikePractice var3 = StrikePractice.getInstance();
            B.a var4 = B.vj;
            boolean var5 = false;
            Logger var10000;
            boolean var6;
            Logger var7;
            StringBuilder var8;
            String var9;
            if (var4.fV()) {
               var10000 = Bukkit.getLogger();
               var8 = (new StringBuilder()).append("[SP DEBUG] ");
               var7 = var10000;
               var6 = false;
               var9 = "#respawn " + var1.getName() + " called (bedwars or similar)";
               var7.info(var8.append(var9).toString());
            }

            if (var3.ac().isSpectator(var1)) {
               var4 = B.vj;
               var5 = false;
               if (var4.fV()) {
                  var10000 = Bukkit.getLogger();
                  var8 = (new StringBuilder()).append("[SP DEBUG] ");
                  var7 = var10000;
                  var6 = false;
                  var9 = "Almost respawned spectator in bedwars (or similar)? Fight=" + var2 + ", name=" + var1.getName();
                  var7.info(var8.append(var9).toString());
               }

               return;
            }

            ga.strikepractice.playerkits.b.b.a var10 = (ga.strikepractice.playerkits.b.b.a)ga.strikepractice.playerkits.b.b.qQ.get(var1.getUniqueId());
            BattleKit var11 = var2.getKit();
            if (var11 != null) {
               if (var2.hasEnded()) {
                  var3.ac().removeSpectator(var1, false);
                  var3.clear(var1, true, true);
                  return;
               }

               Bukkit.getScheduler().runTaskLater((Plugin)var3, ga.strikepractice.fights.duel.a.a::a, 2L);
            }
         }

      }

      // $FF: synthetic method
      public static void b(ga.strikepractice.fights.duel.a.a var0, Player var1, Fight var2, int var3, Object var4) {
         if ((var3 & 2) != 0) {
            var2 = AbstractFight.getCurrentFight(var1);
         }

         var0.f(var1, var2);
      }

      private final boolean a(Location var1, Player var2) {
         StrikePracticeAPI var3 = StrikePractice.getAPI();
         Fight var4 = var3.getFight(var2);
         if (var4 != null) {
            if (var4 instanceof PartyFFA) {
               var3.forceWinRound(var2);
               return true;
            }

            Pair var5 = this.g(var2, var4);
            Location var6 = (Location)var5.component1();
            Location var7 = (Location)var5.component2();
            if (var1.distanceSquared(var6) > var1.distanceSquared(var7)) {
               var3.forceWinRound(var2);
               return true;
            }

            B.a var8 = B.vj;
            boolean var9 = false;
            if (var8.fV()) {
               Logger var10000 = Bukkit.getLogger();
               StringBuilder var12 = (new StringBuilder()).append("[SP DEBUG] ");
               Logger var11 = var10000;
               boolean var10 = false;
               String var13 = var2.getName() + " broke their own bed/jumped in their own portal? ownLoc = " + .a.a(var6) + "opponent = " + .a.a(var7);
               var11.info(var12.append(var13).toString());
            }
         }

         return false;
      }

      private final Pair<Location, Location> g(Player var1, Fight var2) {
         Location var3 = this.h(var1, var2);
         Location var4 = var2.getArena().getLoc1();
         if (var3.distanceSquared(var2.getArena().getLoc1()) < 1.0D) {
            var4 = var2.getArena().getLoc2();
         }

         if (Intrinsics.areEqual((Object)var3, (Object)var4)) {
            Bukkit.getLogger().warning("pos1 pos2 locations in bedwars/briges are the same?? fight=" + var2 + ", arena=" + var2.getArena());
         }

         return new Pair(var3, var4);
      }

      @JvmStatic
      @NotNull
      public final Location h(@NotNull Player var1, @NotNull Fight var2) {
         Intrinsics.checkNotNullParameter(var1, "p");
         Intrinsics.checkNotNullParameter(var2, "fight");
         Location var10000;
         switch(this.i(var1, var2)) {
         case 1:
            var10000 = var2.getArena().getLoc1();
            break;
         case 2:
            var10000 = var2.getArena().getLoc2();
            break;
         default:
            throw new IllegalArgumentException(var1.getName() + " invalid spawnpoint number " + var2);
         }

         var10000 = var10000.clone();
         Intrinsics.checkNotNullExpressionValue(var10000, "when (getSpawnPoint(p, f…t\")\n            }.clone()");
         return var10000;
      }

      @JvmStatic
      public final int i(@NotNull Player var1, @Nullable Fight var2) {
         Intrinsics.checkNotNullParameter(var1, "p");
         int var10000;
         if (var2 instanceof Duel) {
            if (Intrinsics.areEqual((Object)((Duel)var2).getP1(), (Object)var1.getName())) {
               var10000 = 1;
            } else {
               if (!Intrinsics.areEqual((Object)((Duel)var2).getP2(), (Object)var1.getName())) {
                  throw new IllegalArgumentException(var1.getName() + " is not in the fight " + var2);
               }

               var10000 = 2;
            }
         } else {
            var10000 = var2 instanceof PartySplit ? (((PartySplit)var2).getAlive1().contains(var1.getName()) ? 1 : 2) : (var2 instanceof PartyVsParty ? (((PartyVsParty)var2).getPartyAlive1().contains(var1.getName()) ? 1 : 2) : (Bukkit.getPlayer(var1.getUniqueId()) == null ? 2 : (var2 instanceof BotDuel ? 1 : (var2 instanceof PartyVsBots ? 1 : (StrikePractice.t.nextBoolean() ? 1 : 2)))));
         }

         return var10000;
      }

      @JvmStatic
      @JvmOverloads
      public final boolean A(@NotNull Player var1) {
         Intrinsics.checkNotNullParameter(var1, "p");
         return a(this, var1, (Fight)null, 2, (Object)null);
      }

      @JvmStatic
      @JvmOverloads
      public final void B(@NotNull Player var1) {
         Intrinsics.checkNotNullParameter(var1, "p");
         b(this, var1, (Fight)null, 2, (Object)null);
      }

      private static final ItemStack a(short var0, ItemStack var1) {
         ItemStack var2 = (new Wool(DyeColor.getByWoolData((byte)var0))).toItemStack(var1.getAmount());
         var2.setType(var1.getType());
         return var2;
      }

      private static final void C(Player var0) {
         Intrinsics.checkNotNullParameter(var0, "$p");
         var0.updateInventory();
      }

      private static final void a(Player var0, Location var1, BattleKit var2, ga.strikepractice.playerkits.b.b.a var3, Fight var4, StrikePractice var5) {
         var0.setFallDistance(0.0F);
         N.a(var0, var1, false, 4, (Object)null);
         BattleKit var6 = null;
         if ((var2.isEditable() || var2.getMergedEditor() != null) && var3 != null && var3.getFight() == var4) {
            var6 = var5.Y().getPlayerKits(var0).getEditedKit(var3.el());
         }

         if (var6 == null) {
            var6 = var2;
         }

         var2.giveKitStuff(var0, var6);
         Bukkit.getScheduler().runTaskLater((Plugin)var5, ga.strikepractice.fights.duel.a.a::C, 2L);
      }

      private static final void a(Player var0, StrikePractice var1, Fight var2, Location var3, BattleKit var4, ga.strikepractice.playerkits.b.b.a var5) {
         Intrinsics.checkNotNullParameter(var0, "$p");
         Intrinsics.checkNotNullParameter(var3, "$to");
         if (var0.isOnline()) {
            var1.ac().removeSpectator(var0, false);
            if (!var2.hasEnded()) {
               a(var0, var3, var4, var5, var2, var1);
            }
         }

      }

      private static final void a(Fight var0, Player var1, BattleKit var2, StrikePractice var3, ga.strikepractice.playerkits.b.b.a var4) {
         Intrinsics.checkNotNullParameter(var1, "$p");
         if (!var0.hasEnded()) {
            Location var5 = ga.strikepractice.fights.duel.a.fv.h(var1, var0);
            Block var6 = var5.clone().subtract(0.0D, 1.0D, 0.0D).getBlock();
            if (var6.getType() != null && var6.getType().isSolid()) {
               var5.add(0.0D, 1.0D, 0.0D);
            }

            for(int var7 = 0; var7 < 3; ++var7) {
               if (var5.getBlock().getType().isSolid()) {
                  var5.add(0.0D, 1.0D, 0.0D);
               }
            }

            if (!var2.isNoDeathCountdown()) {
               if (var2.isBridges()) {
                  i.a((Collection)SetsKt.setOf(var1.getName()), var2.isStickSpawn(), true);
                  a(var1, var5, var2, var4, var0, var3);
               } else if (var2.isBedwars()) {
                  B.a var13 = B.vj;
                  boolean var8 = false;
                  if (var13.fV()) {
                     Logger var10000 = Bukkit.getLogger();
                     StringBuilder var11 = (new StringBuilder()).append("[SP DEBUG] ");
                     Logger var10 = var10000;
                     boolean var9 = false;
                     String var12 = var1.getName() + ", starting bedwars countdown...";
                     var10.info(var11.append(var12).toString());
                  }

                  var3.ac().a(var1, var0, false);
                  i.a((Collection)SetsKt.setOf(var1.getName()), false, true, ga.strikepractice.fights.duel.a.a::a);
               } else {
                  i.a((Collection)SetsKt.setOf(var1.getName()), var2.isStickSpawn(), true);
                  a(var1, var5, var2, var4, var0, var3);
               }
            } else {
               a(var1, var5, var2, var4, var0, var3);
            }
         }

      }

      // $FF: synthetic method
      public a(DefaultConstructorMarker var1) {
         this();
      }
   }
}
