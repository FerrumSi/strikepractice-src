package ga.strikepractice.fights.duel;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class d implements Listener {
   @EventHandler
   public void d(PlayerInteractEvent var1) {
      if (var1.getAction().equals(Action.PHYSICAL) && var1.getClickedBlock().getType().toString().contains("PLATE")) {
         Player var2 = var1.getPlayer();
         Fight var3 = AbstractFight.getCurrentFight(var2);
         if (var3 != null && var3.getKit().isParkour()) {
            StrikePractice.getAPI().forceWinRound(var2);
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(EntityDamageEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2 = ((Player)var1.getEntity()).getPlayer();
         Fight var3 = AbstractFight.getCurrentFight(var2);
         if (var3 != null && var3.getKit() != null && var3.getKit().isParkour()) {
            var1.setCancelled(true);
         }
      }

   }
}
