package ga.strikepractice.fights.duel;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.events.DuelEndEvent;
import ga.strikepractice.events.DuelStartEvent;
import ga.strikepractice.events.RoundEndEvent;
import ga.strikepractice.events.RoundStartEvent;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.EloChange;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.FightStatistics;
import ga.strikepractice.fights.elo.EloCalculator;
import ga.strikepractice.fights.elo.EloChanges;
import ga.strikepractice.matchrecorder.recorder.Recordable;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.stats.Stats;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.u;
import ga.strikepractice.utils.y;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

@APIClass
public class Duel extends AbstractFight implements BestOfFight, Recordable {
   public static final Map<UUID, List<EloChange>> eloFights = new HashMap();
   private final StrikePractice plugin;
   private final String p1;
   private final String p2;
   private boolean breaktime;
   private boolean cancelled;
   private boolean doNotTeleport;
   private boolean queue;
   private boolean ended;
   private boolean premiumQueue;
   public int winnerEloChange;
   public int loserEloChange;
   private int winnerOldElo;
   private int loserOldElo;
   private ga.strikepractice.matchrecorder.recorder.fightrecorder.a recorder;
   private BestOf bestOf;

   public Duel(StrikePractice var1, String var2, String var3, BattleKit var4) {
      this.plugin = var1;
      this.p1 = var2;
      this.p2 = var3;
      super.kit = var4;
      this.handleStart();
   }

   public Duel(StrikePractice var1, String var2, String var3) {
      this.plugin = var1;
      this.p1 = var2;
      this.p2 = var3;
   }

   public void handleStart() {
      DuelStartEvent var1 = new DuelStartEvent(this, y.W(this.p1), y.W(this.p2), this.kit);
      Bukkit.getPluginManager().callEvent(var1);
      this.cancelled = var1.isCancelled();
      super.kit = var1.getKit();
      if (this.kit != null && this.bestOf == null) {
         this.bestOf = new BestOf(this.kit.getBestOf());
      }

   }

   public void start() {
      if (!this.cancelled) {
         super.start();
         this.setStartedAfterCountdown();
         this.plugin.Z().a(this.kit);
         Player var1 = y.W(this.p1);
         Player var2 = y.W(this.p2);
         Fight var3 = AbstractFight.getCurrentFight(var1);
         boolean var4 = false;
         if (var3 != null) {
            Bukkit.getLogger().warning(var1.getName() + " was kicked because they were in 2 different fights.");
            var4 = true;
         }

         Fight var5 = AbstractFight.getCurrentFight(var2);
         if (var5 != null) {
            Bukkit.getLogger().warning(var2.getName() + " was kicked because they were in 2 different fights.");
            var4 = true;
         }

         if (this.arena.isUsing()) {
            Bukkit.getLogger().warning("Both players were kicked because somehow the arena was already in use.");
            var4 = true;
         }

         if (var4) {
            String var10 = "Fight ended (" + this.p2 + " and " + this.p1 + ") because player was already in another fight.";
            var1.sendMessage(var10);
            var2.sendMessage(var10);
            Bukkit.broadcast(var10, ga.strikepractice.k.a.py.dY());
            var1.kickPlayer("Something went wrong... Please relog");
            var2.kickPlayer("Something went wrong... Please relog");
            Bukkit.getLogger().warning("Some debug: ");
            Bukkit.getLogger().warning("New fight " + this);
            Bukkit.getLogger().warning("f1: " + var3 + ", f2: " + var5);
            throw new IllegalStateException(var10);
         }

         ga.strikepractice.fights.queue.d.b(var1, true);
         ga.strikepractice.fights.queue.d.b(var2, true);
         DefaultPlayerStats var6 = DefaultPlayerStats.getStats(var1.getUniqueId(), true, true);
         DefaultPlayerStats var7 = DefaultPlayerStats.getStats(var2.getUniqueId(), true, true);
         if (this.premiumQueue) {
            var6.setPremiumMatches(var6.getPremiumMatches() - 1);
            var7.setPremiumMatches(var7.getPremiumMatches() - 1);
         } else if (this.queue) {
            if (this.kit.isElo()) {
               if (this.plugin.getConfig().getBoolean("limit-rankeds")) {
                  var6.removeRanked();
                  var7.removeRanked();
               }
            } else if (this.plugin.getConfig().getBoolean("limit-unrankeds")) {
               var6.removeUnranked();
               var7.removeUnranked();
            }
         }

         this.startRound(var1, var2, false);
         this.plugin.a(var1, "fight-start-message.duel", u.a("<opponent>", var2.getName()));
         this.plugin.a(var2, "fight-start-message.duel", u.a("<opponent>", var1.getName()));
         this.kit.sendFightInfo(var1);
         this.kit.sendFightInfo(var2);
         if (this.kit.isElo()) {
            int var8 = var6.getElo(this.kit);
            int var9 = var7.getElo(this.kit);
            this.plugin.a(var1, "fight-start-message.elo", u.a("<your_elo>", var8, "<opponent_elo>", var9, "<you>", var1.getName(), "<opponent>", var2.getName()));
            this.plugin.a(var2, "fight-start-message.elo", u.a("<your_elo>", var9, "<opponent_elo>", var8, "<you>", var2.getName(), "<opponent>", var1.getName()));
            if (this.plugin.getConfig().getBoolean("record-elo-fights")) {
               this.recorder = new ga.strikepractice.matchrecorder.recorder.fightrecorder.a(this, Arrays.asList(var1.getUniqueId(), var2.getUniqueId()));
               this.recorder.startRecording();
            }
         }

         if (this.recorder == null && this.plugin.getConfig().getBoolean("record-all-fights")) {
            this.recorder = new ga.strikepractice.matchrecorder.recorder.fightrecorder.a(this, Arrays.asList(var1.getUniqueId(), var2.getUniqueId()));
            this.recorder.startRecording();
         }
      }

   }

   public boolean allowSpectating() {
      return !this.plugin.getConfig().getBoolean("no-duel-spectating");
   }

   public void setArena(Arena var1) {
      this.arena = var1;
   }

   public void setKit(BattleKit var1) {
      this.kit = var1;
   }

   public boolean hasEnded() {
      return this.ended;
   }

   public boolean canStart() {
      if (super.arena == null) {
         if (this.kit != null && this.kit.isBuild()) {
            this.arena = ga.strikepractice.arena.c.b(y.W(this.p1), this.kit);
         } else {
            this.arena = ga.strikepractice.arena.c.d(y.W(this.p1), this.kit);
         }
      }

      return this.p1 != null && this.p2 != null && this.arena != null && !this.arena.needsRollback() && !this.arena.isUsing() && this.arena.getLoc1() != null && this.arena.getLoc2() != null && this.arena.getLoc1().getWorld() != null;
   }

   public void handleDeath(final Player var1) {
      B.debug(var1.getName() + " handling death in " + this);
      if (!this.ended && !this.breaktime) {
         String var2 = this.getP1();
         if (var2.equals(var1.getName())) {
            var2 = this.getP2();
         }

         final Player var3 = y.W(var2);
         if (var3 == null) {
            AbstractFight.setCurrentFight(var1, (Fight)null);
            this.plugin.clear(var1, true, true);
            this.arena.setUsing(false, (Fight)null);
            var1.sendMessage(ChatColor.RED + "An error occurred: opponent was not found");
            Bukkit.getLogger().warning(var2 + " player was not found. " + var1.getName() + " was teleported from fight alone: " + this);
         } else {
            if (this.bestOf != null && this.bestOf.getRounds() > 1) {
               boolean var4 = this.bestOf.endsNow(var1.getUniqueId());
               Bukkit.getPluginManager().callEvent(new RoundEndEvent(this, var4, Collections.singletonList(var3), Collections.singletonList(var1)));
            }

            this.plugin.a(var1);
            this.plugin.a(var3);
            if (this.bestOf != null && !this.bestOf.handleWin(var3.getUniqueId())) {
               this.breaktime = true;
               this.arena.rollbackArena(this);
               B.debug("bestof duel arena resetting (if set so)...");
               (new BukkitRunnable() {
                  public void run() {
                     Player var1 = y.W(Duel.this.p1);
                     Player var2 = y.W(Duel.this.p2);
                     if (var1 != null && var2 != null) {
                        B.debug("duel next round starting in " + this);
                        Duel.this.startRound(var1, var2, true);
                        Duel.this.breaktime = false;
                     } else {
                        B.debug("could not start next round in " + this);
                     }

                  }
               }).runTaskLater(this.plugin, !this.kit.isNoBestOfRollback() && this.kit.isBuild() ? 5L : 1L);
            } else {
               B.debug("Ending fight " + this);
               this.ended = true;
               super.ended = System.currentTimeMillis();
               Bukkit.getPluginManager().callEvent(new DuelEndEvent(this, var3, var1));
               FightInventory var9 = new FightInventory(var1, this.plugin);
               FightInventory var5 = new FightInventory(var3, this.plugin);
               var9.setNextInventory(var5);
               var5.setNextInventory(var9);
               this.plugin.clear(var1, !this.allowSpectating() || this.kit.isBedwars() || this.kit.isBridges() || this.kit.isParkour(), true);
               if (this.plugin.aa().vI) {
                  this.plugin.aa().bk(var1);
                  this.plugin.aa().bk(var3);
               }

               UUID var6 = var1.getUniqueId();
               UUID var7 = var3.getUniqueId();
               final ga.strikepractice.q.d var8 = this.plugin.ac();
               if (!this.doNotTeleport) {
                  (new BukkitRunnable() {
                     public void run() {
                        Duel.this.arena.setUsing(false, (Fight)null);
                        AbstractFight.setCurrentFight(var3, (Fight)null);
                        Duel.this.plugin.clear(var3, true, true);
                        if (var8.aV(var1) == Duel.this) {
                           var8.removeSpectator(var1, true);
                        }

                     }
                  }).runTaskLater(this.plugin, 20L * (long)this.plugin.getConfig().getInt("wait-before-teleport") + 1L);
               } else {
                  if (var8.isSpectator(var1)) {
                     var8.removeSpectator(var1, false);
                  }

                  this.plugin.clear(var3, false, true);
                  this.arena.setUsing(false, (Fight)null);
               }

               C.a(this.plugin.getConfig().getBoolean("async-match-end"), () -> {
                  this.plugin.a(var3, "you-won", u.a("<loser>", var1.getName(), "<winner>", var3.getName()));
                  this.plugin.a(var1, "did-not-win", u.a("<loser>", var1.getName(), "<winner>", var3.getName(), "<health>", Math.round(var5.getHealth())));
                  if (this.kit.isElo()) {
                     var1.setMetadata("StrikePracticeEloFightsCooldown", new FixedMetadataValue(this.plugin, System.currentTimeMillis()));
                     var3.setMetadata("StrikePracticeEloFightsCooldown", new FixedMetadataValue(this.plugin, System.currentTimeMillis()));
                     int var7x = DefaultPlayerStats.getStats(var7).getElo(this.kit);
                     int var8 = DefaultPlayerStats.getStats(var6).getElo(this.kit);
                     this.doElo(var3, var7x, var1, var8);
                  }

                  if (this.plugin.getConfig().getBoolean("clickable-messages")) {
                     FightInventory.duelMessage(var3, var1, var5, var9);
                  }

                  AbstractFight.setCurrentFight(var1, (Fight)null);
                  if (this.doNotTeleport) {
                     AbstractFight.setCurrentFight(var3, (Fight)null);
                  }

                  if (this.isQueue()) {
                     var1.setMetadata("StrikePracticeQueueFightsCooldown", new FixedMetadataValue(this.plugin, System.currentTimeMillis()));
                     var3.setMetadata("StrikePracticeQueueFightsCooldown", new FixedMetadataValue(this.plugin, System.currentTimeMillis()));
                  }

                  boolean var11 = this.plugin.getConfig().getBoolean("match-link-after-fight");
                  String var12 = null;
                  if (var11) {
                     var12 = f.K(this.plugin.getConfig().getString("match-link")).replace("<ended>", Long.toString(this.getEnded())).replace("<started>", Long.toString(this.getStarted()));
                     var1.sendMessage(var12);
                     var3.sendMessage(var12);
                  }

                  this.sendSpectatorMessages(Collections.singleton(var3.getName()), Collections.singleton(var1.getName()), var12);
                  final boolean var9x = this.plugin.getConfig().getBoolean("save-all-fights") || this.kit.isElo() && this.plugin.getConfig().getBoolean("save-elo-fights");
                  B.debug("fight saving enabled: " + var9x);
                  if (this.recorder != null && this.recorder.getRecordedMatch() != null && this.recorder.dm()) {
                     (new BukkitRunnable() {
                        public void run() {
                           ArrayList var1x = new ArrayList();
                           var1x.add(var6);
                           var1x.add(var3);
                           UUID var2x = Duel.this.recorder.stopRecording(var1x).getUUID();
                           if (var9) {
                              B.debug("Saving with replays...");
                              ga.strikepractice.fights.savedfights.b var3x = Duel.this.saveFight(Arrays.asList(var4), Arrays.asList(var5), Arrays.asList(var3), Arrays.asList(var6), var2x);
                              Duel.this.saveSavedFight(var3x);
                           }

                           if (var2x != null && Duel.this.plugin.getConfig().getBoolean("kill-cam")) {
                              ga.strikepractice.utils.d.b(var1, Duel.this.plugin.a(var1, "kill-cam", true, (Map)null)[0], "/replay " + var2x + " killcam 20");
                              ga.strikepractice.utils.d.b(var2, Duel.this.plugin.a(var2, "kill-cam", true, (Map)null)[0], "/replay " + var2x + " killcam 20");
                           }

                        }
                     }).runTaskLaterAsynchronously(this.plugin, 40L);
                  } else if (var9x) {
                     B.debug("Saving without replays...");
                     ga.strikepractice.fights.savedfights.b var10 = this.saveFight(Arrays.asList(var7), Arrays.asList(var6), Arrays.asList(var5), Arrays.asList(var9), (UUID)null);
                     this.saveSavedFight(var10);
                  }

               });
            }
         }
      } else {
         B.debug(var1.getName() + " died but not handled because ended=" + this.ended + ", breaktime=" + this.breaktime + ". This may be a bug.");
      }
   }

   private void saveSavedFight(ga.strikepractice.fights.savedfights.b var1) {
      B.debug("Saving SavedFight " + var1 + ", total players:" + var1.bY().size() + "/" + var1.bT().size());
      if (StrikePractice.getInstance().O == null) {
         B.debug("Never mind, SQL database is disabled...");
      } else {
         if (this.plugin.getConfig().getBoolean("legacy-fight-format")) {
            B.debug("Saving legacy");
            var1.bO();
         } else {
            B.debug("Saving non-legacy");
            var1.bP().saveToDatabase();
         }

      }
   }

   public void forceEnd(String var1) {
      try {
         Player var2;
         if (this.p1 != null) {
            var2 = y.W(this.p1);
            this.sendEndReasonAndClear(var1, var2);
         }

         if (this.p2 != null) {
            var2 = y.W(this.p2);
            this.sendEndReasonAndClear(var1, var2);
         }

         Bukkit.getPluginManager().callEvent(new DuelEndEvent(this, (Player)null, (Player)null));
         ga.strikepractice.hostedevents.b.a var11 = ga.strikepractice.hostedevents.b.b.iR;
         if (var11 != null && (var11.getP1() != null && var11.getP1().equals(this.p1) || var11.getP1() != null && var11.getP1().equals(this.p2) || var11.getP2() != null && var11.getP2().equals(this.p1) || var11.getP2() != null && var11.getP2().equals(this.p2))) {
            if (var1 != null) {
               Iterator var3 = var11.cz().keySet().iterator();

               while(var3.hasNext()) {
                  String var4 = (String)var3.next();
                  Player var5 = y.W(var4);
                  if (var5 != null && var1 != null) {
                     var5.sendMessage(var1);
                  }
               }
            }

            var11.stop();
         }
      } catch (Exception var9) {
         var9.printStackTrace();
      } finally {
         this.arena.setUsing(false, (Fight)null);
         this.ended = true;
         super.ended = System.currentTimeMillis();
      }

   }

   private void sendEndReasonAndClear(String var1, Player var2) {
      if (var2 != null) {
         if (var1 != null) {
            var2.sendMessage(var1);
         }

         AbstractFight.setCurrentFight(var2, (Fight)null);
         this.plugin.a(var2, true, true, true);
         if (this.plugin.aa().vI) {
            this.plugin.aa().bk(var2);
         }
      }

   }

   public ga.strikepractice.fights.savedfights.b saveFight(List<UUID> var1, List<UUID> var2, List<FightInventory> var3, List<FightInventory> var4, UUID var5) {
      ga.strikepractice.fights.savedfights.b var6 = new ga.strikepractice.fights.savedfights.b();
      var6.bT().put((UUID)var1.get(0), Bukkit.getOfflinePlayer((UUID)var1.get(0)).getName());
      var6.bY().put((UUID)var2.get(0), Bukkit.getOfflinePlayer((UUID)var2.get(0)).getName());
      var6.n(this.arena.getDisplayName());
      var6.o(this.kit.getName());
      var6.setCombo(this.kit.isCombo());
      var6.setElo(this.kit.isElo());
      var6.setBuild(this.kit.isBuild());
      var6.setHorse(this.kit.isHorse());
      var6.setOnlyBow(this.kit.isOnlyBow());
      var6.g(var4);
      var6.f(var3);
      var6.bX().add(this.loserOldElo + this.loserEloChange);
      var6.bW().add(this.loserOldElo);
      var6.bV().add(this.winnerOldElo + this.winnerEloChange);
      var6.bU().add(this.winnerOldElo);
      var6.setStarted(this.getStarted());
      var6.setEnded(this.getEnded());
      var6.d(var5);
      this.createSavedFight(var1, var6);
      this.createSavedFight(var2, var6);
      var6.hI = this.getFightStatistics();
      return var6;
   }

   public List<String> getTeammates(Player var1) {
      return Collections.singletonList(var1.getName());
   }

   public List<String> getOpponents(Player var1) {
      return Collections.singletonList(var1.getName().equals(this.p1) ? this.p2 : this.p1);
   }

   public boolean playersAreTeammates(Player var1, Player var2) {
      return false;
   }

   public boolean playersAreOpponents(Player var1, Player var2) {
      if (var1.getName().equals(this.p1) && var2.getName().equals(this.p2)) {
         return true;
      } else {
         return var2.getName().equals(this.p1) && var1.getName().equals(this.p2);
      }
   }

   private void createSavedFight(List<UUID> var1, ga.strikepractice.fights.savedfights.b var2) {
      Iterator var3 = var1.iterator();

      while(var3.hasNext()) {
         UUID var4 = (UUID)var3.next();
         FightStatistics var5 = this.getStatistics(var4);
         var2.cb().add(var5.getHits());
         var2.cc().add(var5.getLongestCombo());
         var2.cf().add(var5.getPotionsThrown());
         var2.ce().add(var5.getPotionsMissed());
         var2.cd().add(var5.getAccuracy());
      }

   }

   private void startRound(Player var1, Player var2, boolean var3) {
      Bukkit.getPluginManager().callEvent(new RoundStartEvent(this));
      if (var1.isDead()) {
         var1.spigot().respawn();
      }

      if (var2.isDead()) {
         var2.spigot().respawn();
      }

      this.plugin.clear(var1, false, false);
      this.plugin.clear(var2, false, false);
      this.arena.setUsing(true, this);
      if (this.plugin.aa().vI) {
         this.plugin.aa().a(var1, "team2", Collections.singletonList(var2.getUniqueId()));
         this.plugin.aa().a(var2, "team2", Collections.singletonList(var1.getUniqueId()));
         this.plugin.aa().a(var1, "team1", Collections.singletonList(var1.getUniqueId()));
         this.plugin.aa().a(var2, "team1", Collections.singletonList(var2.getUniqueId()));
      }

      if (N.a(var1, this.arena.getLoc1(), var3) && N.a(var2, this.arena.getLoc2(), var3)) {
         var1.hidePlayer(var2);
         var2.hidePlayer(var1);
         var1.showPlayer(var2);
         var2.showPlayer(var1);
         this.kit.giveKit(var1);
         this.kit.giveKit(var2);
         this.startCountdown();
         var1.updateInventory();
         var2.updateInventory();
         AbstractFight.setCurrentFight(var1, this);
         AbstractFight.setCurrentFight(var2, this);
         if (this.bestOf != null && this.bestOf.getRounds() > 1) {
            this.bestOf.message(var1, var2);
         }

         if (this.kit.isBedwars()) {
            this.bed1Broken = this.bed2Broken = false;
         }

      } else {
         this.forceEndDelayed(ChatColor.RED + "An error occurred in your fight and the fight was forced to end!");
      }
   }

   private void startCountdown() {
      i.a(Arrays.asList(this.p1, this.p2), this.kit == null || this.kit.isStickSpawn());
   }

   private void doElo(Player var1, int var2, Player var3, int var4) {
      this.winnerOldElo = var2;
      this.loserOldElo = var4;
      EloChanges var5 = new EloChanges(this.winnerOldElo, this.loserOldElo, this.winnerOldElo, this.loserOldElo);
      EloCalculator.getEloCalculator().calculateElo(var5);
      int var6 = var5.getWinnerNewElo();
      int var7 = var5.getLoserNewElo();
      int var8 = var5.getWinnerChange();
      int var9 = var5.getLoserChange();
      this.winnerEloChange = var8;
      this.loserEloChange = var9;
      UUID var10 = var1.getUniqueId();
      UUID var11 = var3.getUniqueId();
      DefaultPlayerStats var12 = DefaultPlayerStats.getStats(var10);
      DefaultPlayerStats var13 = DefaultPlayerStats.getStats(var11);
      if (this.plugin.getConfig().getBoolean("elo-is-global-elo")) {
         this.plugin.kits.forEach((var4x) -> {
            if (var4x.isElo()) {
               var12.getElos().put(Stats.eloColumn(var4x), var6);
               var13.getElos().put(Stats.eloColumn(var4x), var7);
            }

         });
      } else {
         var12.getElos().put(Stats.eloColumn(this.kit), var6);
         var13.getElos().put(Stats.eloColumn(this.kit), var7);
      }

      this.sendEloChangeMsg(var1, var3, var2, var4, var6, var7, var8, var9, var3.getName());
      this.sendEloChangeMsg(var1, var1, var2, var4, var6, var7, var8, var9, var3.getName());
      this.saveEloHistory(var10, var8);
      this.saveEloHistory(var11, var9);
   }

   private void sendEloChangeMsg(Player var1, Player var2, int var3, int var4, int var5, int var6, int var7, int var8, String var9) {
      this.plugin.a(var2, "elo-fight", u.a("<player1>", var1.getName(), "<player2>", var9, "<elo1>", var5, "<elo2>", var6, "<old1>", var3, "<old2>", var4, "<diff1>", var7, "<diff2>", var8));
   }

   private void saveEloHistory(UUID var1, int var2) {
      List var3 = (List)eloFights.getOrDefault(var1, new ArrayList());
      if (var3.size() >= 10) {
         var3.remove(0);
      }

      var3.add(new EloChange(this.kit, var2));
      eloFights.put(var1, var3);
   }

   public ga.strikepractice.matchrecorder.recorder.fightrecorder.a getRecorder() {
      return this.recorder;
   }

   public String getP1() {
      return this.p1;
   }

   public boolean isPremiumQueue() {
      return this.premiumQueue;
   }

   public void setPremiumQueue(boolean var1) {
      this.premiumQueue = var1;
   }

   public String getP2() {
      return this.p2;
   }

   public BestOf getBestOf() {
      return this.bestOf;
   }

   public void setBestOf(BestOf var1) {
      this.bestOf = var1;
   }

   public boolean isQueue() {
      return this.queue;
   }

   public void setQueue(boolean var1) {
      this.queue = var1;
   }

   public boolean isDoNotTeleport() {
      return this.doNotTeleport;
   }

   public void setDoNotTeleport(boolean var1) {
      this.doNotTeleport = var1;
   }

   public boolean isBreakTime() {
      return this.breaktime;
   }

   /** @deprecated */
   @Deprecated
   public String toString() {
      return "Duel{p1='" + this.p1 + '\'' + ", p2='" + this.p2 + '\'' + ", breaktime=" + this.breaktime + ", cancelled=" + this.cancelled + ", doNotTeleport=" + this.doNotTeleport + ", queue=" + this.queue + ", ended=" + this.ended + ", premiumQueue=" + this.premiumQueue + ", winnerEloChange=" + this.winnerEloChange + ", loserEloChange=" + this.loserEloChange + ", winnerOldElo=" + this.winnerOldElo + ", loserOldElo=" + this.loserOldElo + '}';
   }
}
