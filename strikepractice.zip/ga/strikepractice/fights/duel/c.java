package ga.strikepractice.fights.duel;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.battlekit.e;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.requests.DuelRequest;
import ga.strikepractice.fights.requests.FightRequest;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.playersettings.PlayerSettings;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.u;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;

public class c implements CommandExecutor, Listener {
   private final StrikePractice fN;
   private static final String fO = "StrikePracticeDuelCooldown";

   public c(StrikePractice var1) {
      this.fN = var1;
   }

   private boolean D(Player var1) {
      long var2 = this.fN.getConfig().getLong("request-cooldown");
      if (var1.hasMetadata("StrikePracticeDuelCooldown")) {
         MetadataValue var4 = this.fN.a((Metadatable)var1, (String)"StrikePracticeDuelCooldown");
         if (var4 != null && var4.value() != null && var4.asLong() + var2 > System.currentTimeMillis()) {
            return false;
         }
      }

      var1.setMetadata("StrikePracticeDuelCooldown", new FixedMetadataValue(this.fN, System.currentTimeMillis()));
      return true;
   }

   private int E(Player var1) {
      long var2 = this.fN.getConfig().getLong("request-cooldown");
      if (var1.hasMetadata("StrikePracticeDuelCooldown")) {
         MetadataValue var4 = this.fN.a((Metadatable)var1, (String)"StrikePracticeDuelCooldown");
         if (var4 != null && var4.value() != null && var4.asLong() + var2 > System.currentTimeMillis()) {
            return (int)((var4.asLong() + var2 - System.currentTimeMillis()) / 1000L);
         }
      }

      return 0;
   }

   @EventHandler
   public void a(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         if (var1.getClickedInventory() != null) {
            Player var2 = (Player)var1.getWhoClicked();
            Iterator var6;
            DuelRequest var7;
            Duel var8;
            if (var1.getView().getTitle().equals(f.K(this.fN.getConfig().getString("duel-inventory-pending")))) {
               label176: {
                  if (var1.getClickedInventory() != null && !var1.getClickedInventory().equals(var2.getInventory())) {
                     if (!r.h(var1.getCurrentItem())) {
                        break label176;
                     }

                     var1.setCancelled(true);
                     if (!var1.getCurrentItem().getItemMeta().hasDisplayName() || var1.getSlot() == var1.getInventory().getSize() - 1) {
                        break label176;
                     }

                     String var3 = ChatColor.stripColor(var1.getCurrentItem().getItemMeta().getDisplayName());
                     if (var3.length() <= 0) {
                        break label176;
                     }

                     if (var2.getName().equals(var3)) {
                        return;
                     }

                     Player var4 = Bukkit.getPlayer(var3);
                     if (var4 == null) {
                        this.fN.a(var2, "not-online");
                        return;
                     }

                     if (!PvPEvent.isInEvent(var4) && !AbstractFight.isInFight(var4) && !PvPEvent.isInEvent(var2) && !AbstractFight.isInFight(var2) && !ga.strikepractice.playerkits.b.d.aE(var2) && !ga.strikepractice.playerkits.b.d.aE(var4)) {
                        Collection var5 = FightRequest.getDuelRequestsForPlayer(var2);
                        var6 = var5.iterator();

                        while(true) {
                           if (!var6.hasNext()) {
                              break label176;
                           }

                           var7 = (DuelRequest)var6.next();
                           if (!var7.hasExpired() && var7.getDueled().equals(var2.getName())) {
                              var8 = (Duel)var7.getFight();
                              if (var8.getP1().equals(var4.getName()) && var8.getP2().equals(var2.getName()) && var8.getKit() != null) {
                                 var8.handleStart();
                                 if (var8.canStart()) {
                                    var5.remove(var7);
                                    var8.start();
                                    return;
                                 }

                                 ga.strikepractice.arena.c.e(var2);
                                 return;
                              }
                           }
                        }
                     }

                     this.fN.a(var2, "can-not-duel-that-player");
                     return;
                  }

                  return;
               }
            }

            if (var1.getView().getTitle().equals(f.K(this.fN.getConfig().getString("duel-inventory-title")))) {
               if (var1.getClickedInventory() != null && var1.getClickedInventory().equals(var2.getInventory())) {
                  return;
               }

               if (r.h(var1.getCurrentItem())) {
                  var1.setCancelled(true);
               }

               if (var1.getSlot() == 10) {
                  Inventory var11 = Bukkit.createInventory((InventoryHolder)null, 27, f.K(this.fN.getConfig().getString("duel-inventory-pending")));
                  Collection var13 = FightRequest.getDuelRequestsForPlayer(var2);
                  ArrayList var15 = new ArrayList();
                  var6 = var13.iterator();

                  while(var6.hasNext()) {
                     var7 = (DuelRequest)var6.next();
                     if (!var7.hasExpired() && var7.getDueled().equals(var2.getName()) && !var15.contains(var7.getDueler()) && this.G(var7.getPlayerDueled())) {
                        var8 = (Duel)var7.getFight();
                        var15.add(var7.getDueler());
                        ItemStack var9 = r.R(ChatColor.GOLD + var7.getDueler());
                        ArrayList var10 = new ArrayList();
                        var10.add(ChatColor.YELLOW + "Kit: " + var8.getKit());
                        var11.addItem(new ItemStack[]{var9});
                     }
                  }

                  var11.setItem(var11.getSize() - 1, ga.strikepractice.m.a.aJ(var2));
                  var2.openInventory(var11);
               } else if (var1.getSlot() == 13) {
                  ga.strikepractice.utils.b.a.a(var2, this.fN.a(var2, "type-name", false, (Map)null), (var2x) -> {
                     if (var2x != null && var2x.length > 0) {
                        String var3 = var2x[0].replace(" ", "");
                        Player var4 = Bukkit.getPlayer(var3);
                        if (var4 != null) {
                           if (var2.getName().equals(var4.getName())) {
                              var2.sendMessage("You cannot duel yourself.");
                              return;
                           }

                           if (AbstractFight.isInFight(var4)) {
                              this.fN.a(var2, "can-not-duel-that-player");
                           } else if (PlayerSettings.getPlayerSettings(var4).isDuelRequestsDisabled()) {
                              this.fN.a(var2, "has-requests-disabled", u.a("<player>", var4.getName()));
                           } else {
                              Duel var5 = new Duel(this.fN, var2.getName(), var4.getName());
                              this.fN.L.a(var2, new b(var2.getName(), var5), BattleKitType.DUEL);
                           }
                        } else {
                           this.fN.a(var2, "not-online");
                        }
                     }

                  });
               } else if (var1.getSlot() == 16) {
                  if (PlayerSettings.getPlayerSettings(var2).isDuelRequestsDisabled()) {
                     PlayerSettings.getPlayerSettings(var2).setDuelRequestsDisabled(false);
                     this.fN.a(var2, "duel-requests-on");
                  } else {
                     PlayerSettings.getPlayerSettings(var2).setDuelRequestsDisabled(true);
                     this.fN.a(var2, "duel-requests-off");
                  }

                  this.a(var2, var1.getInventory());
               }
            } else if (var1.getInventory().getHolder() instanceof b && ((b)var1.getInventory().getHolder()).bi().equals(var2.getName()) && var1.getView().getTitle().equals(f.K(this.fN.getConfig().getString("inventory-title")))) {
               if (var1.getClickedInventory().equals(var2.getInventory())) {
                  return;
               }

               if (r.h(var1.getCurrentItem())) {
                  var1.setCancelled(true);
                  if (var1.getCurrentItem().getItemMeta().hasDisplayName() && var1.getSlot() == var1.getInventory().getSize() - 1 && this.fN.getConfig().getBoolean("kit-editor-in-kit-selector")) {
                     this.fN.Y().az(var2);
                     return;
                  }

                  BattleKit var12 = BattleKit.getKit(var2, var1.getCurrentItem(), false);
                  BattleKit var14 = this.fN.Y().getPlayerKits(var2).getCustomKit();
                  if (var14 != null && var1.getCurrentItem().equals(var14.getIcon())) {
                     var12 = var14;
                  }

                  if (var12 == null) {
                     var2.sendMessage(ChatColor.RED + "Error: invalid kit.. please try another kit and contact admins!");
                     return;
                  }

                  if ((var1.getClick() == ClickType.SHIFT_LEFT || var1.getClick() == ClickType.SHIFT_RIGHT) && this.fN.getConfig().getBoolean("preview.shift-click-preview")) {
                     ga.strikepractice.m.a.a(var2, var12, this.fN);
                     return;
                  }

                  b var16 = (b)var1.getInventory().getHolder();
                  Duel var17 = var16.bh();
                  BattleKit var18 = e.a(var12, false, BattleKitType.ANY, BattleKitType.DUEL);
                  var17.setKit(var18);
                  this.a(var2, var17);
               }
            }

         }
      }
   }

   private void a(Player var1, Duel var2) {
      new ga.strikepractice.fights.a.b(var1, var2.getKit(), (var3) -> {
         Player var4 = Bukkit.getPlayer(var2.getP2());
         if (!var2.getP1().equals(var1.getName()) && !var2.getP2().equals(var1.getName())) {
            var1.closeInventory();
         } else if (var4 == null) {
            this.fN.a(var1, "not-online");
            var1.closeInventory();
         } else if (Party.getParty(var1) != null) {
            this.fN.a(var1, "can-not-do-while-in-party");
            var1.closeInventory();
         } else if (Party.getParty(var4) != null) {
            this.fN.a(var1, "can-not-do-while-in-party-other-player");
            var1.closeInventory();
         } else if (this.D(var1)) {
            var2.setArena(var3);
            FightRequest.addDuelRequest(var4, new DuelRequest(var1, var4, var2));
            a(var1, var4, var2.getKit(), var3);
            var1.closeInventory();
         } else {
            this.fN.a(var1, "cooldown-message", u.a("<time>", this.E(var1)));
         }

      });
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         if (var3.equalsIgnoreCase("dueltoggle")) {
            this.F(var5);
            return true;
         }

         if (PvPEvent.isInEvent(var5) || AbstractFight.isInFight(var5)) {
            this.fN.a(var5, "you-can-not-duel-now");
            return true;
         }

         Player var6;
         if (Party.getParty(var5) != null) {
            this.fN.a(var5, "can-not-do-while-in-party");
         } else if (var4.length == 0) {
            if (this.fN.getConfig().getBoolean("duel-inventory")) {
               a(var5, this.fN);
            } else {
               var5.sendMessage(ChatColor.YELLOW + "/duel <player> [rounds] || /duel accept <player> || /duel toggle || /duel requests ");
            }
         } else if (var4[0].equals("toggle")) {
            this.F(var5);
         } else if (!var4[0].equals("requests") && !var4[0].equals("settings")) {
            var6 = Bukkit.getPlayer(var4[0]);
            if (var6 != null) {
               if (var5.getName().equals(var6.getName())) {
                  return true;
               }

               if (!AbstractFight.isInFight(var6) && Party.getParty(var6) == null) {
                  if (PlayerSettings.getPlayerSettings(var6).isDuelRequestsDisabled()) {
                     this.fN.a(var5, "has-requests-disabled", u.a("<player>", var6.getName()));
                  } else {
                     Duel var7 = new Duel(this.fN, var5.getName(), var6.getName());
                     int var8 = 0;

                     try {
                        var8 = var4.length > 1 ? Integer.parseInt(var4[1]) : 0;
                     } catch (Exception var12) {
                     }

                     int var9 = this.fN.getConfig().getInt("duel-max-rounds");
                     if (var8 <= var9 && var8 >= 0) {
                        var7.setBestOf(new BestOf(var8));
                        if (var4.length > 2) {
                           BattleKit var10 = StrikePractice.getAPI().getKit(var4[2]);
                           if (var10 != null && !var10.isElo() && (var10.getKitTypes().contains(BattleKitType.DUEL) || var10.getKitTypes().contains(BattleKitType.ANY))) {
                              BattleKit var11 = e.a(var10, false, BattleKitType.DUEL, BattleKitType.ANY);
                              var7.setKit(var11);
                              this.a(var5, var7);
                              return true;
                           }

                           var5.sendMessage(ChatColor.RED + "Invalid kit!");
                        }

                        this.fN.L.a(var5, new b(var5.getName(), var7), BattleKitType.DUEL);
                     } else {
                        var5.sendMessage(ChatColor.YELLOW + "/duel <player> [rounds (1-" + var9 + ")] [kit]");
                     }
                  }
               } else {
                  this.fN.a(var5, "can-not-duel-that-player");
               }
            } else if (!var4[0].equalsIgnoreCase("accept")) {
               this.fN.a(var5, "not-online");
            }
         } else {
            a(var5, this.fN);
         }

         if (var4.length >= 2 && var4[0].equalsIgnoreCase("accept")) {
            if (var5.getName().equals(var4[1])) {
               return true;
            }

            var6 = Bukkit.getPlayer(var4[1]);
            if (var6 == null) {
               this.fN.a(var5, "not-online");
               return true;
            }

            if (Party.getParty(var5) != null) {
               this.fN.a(var5, "can-not-do-while-in-party");
               var5.closeInventory();
               return true;
            }

            if (!this.G(var6)) {
               this.fN.a(var5, "can-not-duel-that-player");
               return true;
            }

            Collection var13 = FightRequest.getDuelRequestsForPlayer(var5);
            Iterator var14 = var13.iterator();

            while(var14.hasNext()) {
               DuelRequest var15 = (DuelRequest)var14.next();
               if (!var15.hasExpired() && var15.getDueled().equals(var5.getName()) && var15.getDueler().equals(var6.getName())) {
                  Duel var16 = (Duel)var15.getFight();
                  var16.handleStart();
                  if (var16.getBestOf().getRounds() <= 1) {
                     var16.setBestOf(new BestOf(var16.getKit().getBestOf()));
                  }

                  if (var16.canStart()) {
                     var13.remove(var15);
                     var16.start();
                     return true;
                  }

                  ga.strikepractice.arena.c.e(var5);
                  return true;
               }
            }

            this.fN.a(var5, "has-not-dueled");
         }
      }

      return true;
   }

   private void F(Player var1) {
      if (PlayerSettings.getPlayerSettings(var1).isDuelRequestsDisabled()) {
         PlayerSettings.getPlayerSettings(var1).setDuelRequestsDisabled(false);
         this.fN.a(var1, "duel-requests-on");
      } else {
         PlayerSettings.getPlayerSettings(var1).setDuelRequestsDisabled(true);
         this.fN.a(var1, "duel-requests-off");
      }

   }

   private boolean G(Player var1) {
      return !PvPEvent.isInEvent(var1) && !AbstractFight.isInFight(var1) && !ga.strikepractice.playerkits.b.d.aE(var1);
   }

   public static void a(Player var0, StrikePractice var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 27, f.K(var1.getConfig().getString("duel-inventory-title")));
      var2.setItem(10, r.a(Material.BOOK, f.K(var1.getConfig().getString("duel-inventory-pending"))));
      var2.setItem(13, r.a(Material.SIGN, f.K(var1.getConfig().getString("duel-inventory-duel"))));
      if (PlayerSettings.getPlayerSettings(var0).isDuelRequestsDisabled()) {
         var2.setItem(16, r.a(Material.REDSTONE_TORCH_ON, f.K(var1.getConfig().getString("duel-inventory-toggle-disabled"))));
      } else {
         var2.setItem(16, r.a(Material.TORCH, f.K(var1.getConfig().getString("duel-inventory-toggle-enabled"))));
      }

      var2.setItem(var2.getSize() - 1, ga.strikepractice.m.a.aJ(var0));
      var0.openInventory(var2);
   }

   private void a(Player var1, Inventory var2) {
      if (PlayerSettings.getPlayerSettings(var1).isDuelRequestsDisabled()) {
         var2.setItem(16, r.a(Material.REDSTONE_TORCH_ON, f.K(this.fN.getConfig().getString("duel-inventory-toggle-disabled"))));
      } else {
         var2.setItem(16, r.a(Material.TORCH, f.K(this.fN.getConfig().getString("duel-inventory-toggle-enabled"))));
      }

   }

   public static boolean a(Player var0, Player var1, BattleKit var2, Arena var3) {
      if (var0 != null && var1 != null && var2 != null) {
         StrikePractice var4 = StrikePractice.getInstance();
         boolean var5 = var4.getConfig().getBoolean("clickable-messages");
         var4.a(var0, "request-sent", u.a("<player>", var0.getName(), "<target>", var1.getName(), "<sender>", var0.getName(), "<kit>", var2.getFancyName(), "<arena>", var3 == null ? "random" : var3.getDisplayName(), "<combo>", var2.isCombo(), "<horse>", var2.isHorse(), "<bow>", var2.isOnlyBow()));
         BattleKit var6 = var4.Y().getPlayerKits(var0).getCustomKit();
         if (var6 != null && var6.getName().equals(var2.getName())) {
            if (var5) {
               UUID var7 = UUID.randomUUID();
               ga.strikepractice.m.a.rm.put(var7, var6);
               String var8 = f.K(var4.getConfig().getString("preview-custom-kit"));
               ga.strikepractice.utils.d.b(var1, var8, "/previewkit " + var7);
            }

            var4.a(var1, "wants-duel-with-custom-kit", u.a("<player>", var0.getName(), "<sender>", var0.getName(), "<target>", var1.getName(), "<kit>", var2.getFancyName(), "<arena>", var3 == null ? "random" : var3.getDisplayName(), "<combo>", var2.isCombo(), "<horse>", var2.isHorse(), "<bow>", var2.isOnlyBow()));
         } else {
            var4.a(var1, "wants-duel", u.a("<player>", var0.getName(), "<sender>", var0.getName(), "<target>", var1.getName(), "<kit>", var2.getFancyName(), "<arena>", var3 == null ? "random" : var3.getDisplayName(), "<combo>", var2.isCombo(), "<horse>", var2.isHorse(), "<bow>", var2.isOnlyBow()));
         }

         int var9 = a(var1, var0, var2);
         if (var9 > 1) {
            var4.a(var1, "bestof-duel-request", u.a("<rounds>", var9));
            var4.a(var0, "bestof-duel-request", u.a("<rounds>", var9));
         }

         if (var5) {
            ga.strikepractice.utils.d.b(var1, f.K(var4.getConfig().getString("clickable-message")), "/duel accept " + var0.getName());
         }

         return true;
      } else {
         return false;
      }
   }

   private static int a(Player var0, Player var1, BattleKit var2) {
      Duel var3 = a(var0, var1);
      return var3 != null && var3.getBestOf() != null ? var3.getBestOf().getRounds() : var2.getBestOf();
   }

   private static Duel a(Player var0, Player var1) {
      Collection var2 = FightRequest.getDuelRequestsForPlayer(var0);
      Iterator var3 = var2.iterator();

      while(var3.hasNext()) {
         DuelRequest var4 = (DuelRequest)var3.next();
         if (!var4.hasExpired() && var4.getDueled().equals(var0.getName())) {
            Duel var5 = (Duel)var4.getFight();
            if (var5.getP1().equals(var1.getName()) && var5.getP2().equals(var0.getName()) && var5.getKit() != null) {
               return var5;
            }
         }
      }

      return null;
   }
}
