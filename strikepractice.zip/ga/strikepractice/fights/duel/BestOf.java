package ga.strikepractice.fights.duel;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.utils.u;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.entity.Player;

@APIClass
public class BestOf {
   public static final int TICKS_BEFORE_NEXT_ROUND = 5;
   private int currentRound = 1;
   private final int rounds;
   private final Map<UUID, Integer> wins = new HashMap(2);

   public BestOf(int var1) {
      this.rounds = var1;
   }

   public boolean handleWin(UUID var1) {
      int var2 = (Integer)this.wins.getOrDefault(var1, 0) + 1;
      this.wins.put(var1, var2);
      int var3 = this.rounds / 2;
      ++this.currentRound;
      return var2 > var3;
   }

   public void message(Player var1, Player var2) {
      StrikePractice var3 = StrikePractice.getInstance();
      this.sendMessage(var1, var2);
      this.sendMessage(var2, var1);
   }

   private void sendMessage(Player var1, Player var2) {
      StrikePractice.getInstance().a(var1, "best-of-round", u.a("<player1>", var1.getName(), "<player2>", var2.getName(), "<total_rounds>", this.rounds, "<round>", this.currentRound, "<player1_wins>", this.wins.getOrDefault(var1.getUniqueId(), 0), "<player2_wins>", this.wins.getOrDefault(var2.getUniqueId(), 0)));
   }

   public void message(Player var1, UUID var2, String var3) {
      StrikePractice var4 = StrikePractice.getInstance();
      var4.a(var1, "best-of-round", u.a("<player1>", var1.getName(), "<player2>", var3, "<total_rounds>", this.rounds, "<round>", this.currentRound, "<player1_wins>", this.wins.getOrDefault(var1.getUniqueId(), 0), "<player2_wins>", this.wins.getOrDefault(var2, 0)));
   }

   public int getRounds() {
      return this.rounds;
   }

   public int getCurrentRound() {
      return this.currentRound;
   }

   /** @deprecated */
   @Deprecated
   public HashMap<UUID, Integer> getWins() {
      return (HashMap)this.wins;
   }

   public Map<UUID, Integer> getRoundsWon() {
      return this.wins;
   }

   public int getWins(Player var1) {
      return (Integer)this.wins.getOrDefault(var1.getUniqueId(), 0);
   }

   public int getBotWins(Player var1) {
      Iterator var2 = this.wins.entrySet().iterator();

      Entry var3;
      do {
         if (!var2.hasNext()) {
            return 0;
         }

         var3 = (Entry)var2.next();
      } while(var1.getUniqueId().equals(var3.getKey()));

      return (Integer)var3.getValue();
   }

   public boolean endsNow(UUID var1) {
      if (this.rounds == 1) {
         return true;
      } else {
         Iterator var2 = this.wins.entrySet().iterator();

         Entry var3;
         do {
            if (!var2.hasNext()) {
               return false;
            }

            var3 = (Entry)var2.next();
         } while(((UUID)var3.getKey()).equals(var1));

         int var4 = (Integer)var3.getValue();
         int var5 = this.rounds / 2;
         return var4 + 1 > var5;
      }
   }

   public String toString() {
      return "BestOf{currentRound=" + this.currentRound + ", rounds=" + this.rounds + ", wins=" + this.wins + '}';
   }
}
