package ga.strikepractice.fights.duel;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

class b implements InventoryHolder {
   private final Duel fL;
   private final String fM;

   public b(String var1, Duel var2) {
      this.fL = var2;
      this.fM = var1;
   }

   public Inventory getInventory() {
      return null;
   }

   public Duel bh() {
      return this.fL;
   }

   public String bi() {
      return this.fM;
   }
}
