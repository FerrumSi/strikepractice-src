package ga.strikepractice.fights.duel;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.Fight;
import org.jetbrains.annotations.Nullable;

@APIClass
public interface BestOfFight extends Fight {
   BestOf getBestOf();

   void setBestOf(@Nullable BestOf var1);

   boolean isBreakTime();
}
