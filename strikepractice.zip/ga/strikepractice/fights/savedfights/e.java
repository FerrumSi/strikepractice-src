package ga.strikepractice.fights.savedfights;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.utils.g;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0003J\"\u0010\u0004\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016¨\u0006\u000b"},
   d2 = {"Lga/strikepractice/fights/savedfights/SerializableDeserializer;", "Lcom/google/gson/JsonDeserializer;", "Lorg/bukkit/configuration/serialization/ConfigurationSerializable;", "()V", "deserialize", "el", "Lcom/google/gson/JsonElement;", "type", "Ljava/lang/reflect/Type;", "context", "Lcom/google/gson/JsonDeserializationContext;", "strikepractice-core"}
)
public final class e implements JsonDeserializer<ConfigurationSerializable> {
   @NotNull
   public static final e ig = new e();

   private e() {
   }

   @Nullable
   public ConfigurationSerializable a(@NotNull JsonElement var1, @NotNull Type var2, @NotNull JsonDeserializationContext var3) {
      Intrinsics.checkNotNullParameter(var1, "el");
      Intrinsics.checkNotNullParameter(var2, "type");
      Intrinsics.checkNotNullParameter(var3, "context");

      try {
         Object var10000 = var3.deserialize(var1, g.fp());
         Intrinsics.checkNotNullExpressionValue(var10000, "context.deserialize(el, MAP_TYPE)");
         Map var4 = (Map)var10000;
         Class var5 = Class.forName(var2.getTypeName());
         Class[] var7 = new Class[]{Map.class};
         Method var9 = var5.getMethod("deserialize", var7);
         Object[] var10 = new Object[]{var4};
         Object var6 = var9.invoke((Object)null, var10);
         return (ConfigurationSerializable)var6;
      } catch (Exception var8) {
         Bukkit.getLogger().warning("Failed to deserialize from json: " + var2.getTypeName() + ", " + var1);
         var8.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) {
      return this.a(var1, var2, var3);
   }
}
