package ga.strikepractice.fights.savedfights;

import com.google.gson.annotations.SerializedName;
import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.FightStatistics;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.JvmStatic;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.io.Serializable;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@APIClass
@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0018\b\u0007\u0018\u0000 \"2\u00020\u0001:\u0001\"B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\u000b¢\u0006\u0002\u0010\rJ\u000e\u0010\u001f\u001a\n  *\u0004\u0018\u00010\u00030\u0003J\b\u0010!\u001a\u00020\u0003H\u0016R\u0016\u0010\u0006\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0018\u0010\b\u001a\u0004\u0018\u00010\t8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0016\u0010\u0012\u001a\u00020\u000b8\u0006X\u0087D¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0016\u0010\f\u001a\u00020\u000b8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0014R\u0016\u0010\n\u001a\u00020\u000b8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0016\u0010\u0019\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0016R\u0016\u0010\u001b\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0016R\u0016\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001e¨\u0006#"},
   d2 = {"Lga/strikepractice/fights/savedfights/SavedPlayer;", "Ljava/io/Serializable;", "name", "", "uuid", "Ljava/util/UUID;", "fightInventory", "Lga/strikepractice/fightinventory/FightInventory;", "fightStatistics", "Lga/strikepractice/fights/FightStatistics;", "oldElo", "", "newElo", "(Ljava/lang/String;Ljava/util/UUID;Lga/strikepractice/fightinventory/FightInventory;Lga/strikepractice/fights/FightStatistics;II)V", "getFightInventory", "()Lga/strikepractice/fightinventory/FightInventory;", "getFightStatistics", "()Lga/strikepractice/fights/FightStatistics;", "jsonVersion", "getJsonVersion", "()I", "getName", "()Ljava/lang/String;", "getNewElo", "getOldElo", "pluginVersion", "getPluginVersion", "serverVersion", "getServerVersion", "getUuid", "()Ljava/util/UUID;", "toJson", "ga.strikepractice.kotlin.jvm.PlatformType", "toString", "Companion", "strikepractice-core"}
)
public final class SavedPlayer implements Serializable {
   @NotNull
   public static final SavedPlayer.a Companion = new SavedPlayer.a((DefaultConstructorMarker)null);
   @SerializedName("name")
   @NotNull
   private final String name;
   @SerializedName("uuid")
   @NotNull
   private final UUID uuid;
   @SerializedName("fightInventory")
   @NotNull
   private final FightInventory fightInventory;
   @SerializedName("fightStatistics")
   @Nullable
   private final FightStatistics fightStatistics;
   @SerializedName("oldElo")
   private final int oldElo;
   @SerializedName("newElo")
   private final int newElo;
   @SerializedName("jsonVersion")
   private final int jsonVersion;
   @SerializedName("pluginVersion")
   @NotNull
   private final String pluginVersion;
   @SerializedName("serverVersion")
   @NotNull
   private final String serverVersion;

   public SavedPlayer(@NotNull String var1, @NotNull UUID var2, @NotNull FightInventory var3, @Nullable FightStatistics var4, int var5, int var6) {
      Intrinsics.checkNotNullParameter(var1, "name");
      Intrinsics.checkNotNullParameter(var2, "uuid");
      Intrinsics.checkNotNullParameter(var3, "fightInventory");
      super();
      this.name = var1;
      this.uuid = var2;
      this.fightInventory = var3;
      this.fightStatistics = var4;
      this.oldElo = var5;
      this.newElo = var6;
      this.jsonVersion = 1;
      String var10001 = StrikePractice.getInstance().getDescription().getVersion();
      Intrinsics.checkNotNullExpressionValue(var10001, "getInstance().description.version");
      this.pluginVersion = var10001;
      var10001 = Bukkit.getVersion();
      Intrinsics.checkNotNullExpressionValue(var10001, "getVersion()");
      this.serverVersion = var10001;
   }

   @NotNull
   public final String getName() {
      return this.name;
   }

   @NotNull
   public final UUID getUuid() {
      return this.uuid;
   }

   @NotNull
   public final FightInventory getFightInventory() {
      return this.fightInventory;
   }

   @Nullable
   public final FightStatistics getFightStatistics() {
      return this.fightStatistics;
   }

   public final int getOldElo() {
      return this.oldElo;
   }

   public final int getNewElo() {
      return this.newElo;
   }

   public final int getJsonVersion() {
      return this.jsonVersion;
   }

   @NotNull
   public final String getPluginVersion() {
      return this.pluginVersion;
   }

   @NotNull
   public final String getServerVersion() {
      return this.serverVersion;
   }

   public final String toJson() {
      return d.cj().toJson(this);
   }

   @NotNull
   public String toString() {
      String var10000 = this.toJson();
      Intrinsics.checkNotNullExpressionValue(var10000, "toJson()");
      return var10000;
   }

   @JvmStatic
   public static final SavedPlayer fromJson(@Nullable String var0) {
      return Companion.q(var0);
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001a\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u00042\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0007¨\u0006\b"},
      d2 = {"Lga/strikepractice/fights/savedfights/SavedPlayer$Companion;", "", "()V", "fromJson", "Lga/strikepractice/fights/savedfights/SavedPlayer;", "ga.strikepractice.kotlin.jvm.PlatformType", "json", "", "strikepractice-core"}
   )
   public static final class a {
      private a() {
      }

      @JvmStatic
      public final SavedPlayer q(@Nullable String var1) {
         return (SavedPlayer)d.cj().fromJson(var1, SavedPlayer.class);
      }

      // $FF: synthetic method
      public a(DefaultConstructorMarker var1) {
         this();
      }
   }
}
