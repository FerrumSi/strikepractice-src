package ga.strikepractice.fights.savedfights;

import com.google.gson.JsonElement;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.lang.reflect.Type;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0003J \u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016¨\u0006\u000b"},
   d2 = {"Lga/strikepractice/fights/savedfights/SerializableSerializer;", "Lcom/google/gson/JsonSerializer;", "Lorg/bukkit/configuration/serialization/ConfigurationSerializable;", "()V", "serialize", "Lcom/google/gson/JsonElement;", "serializable", "type", "Ljava/lang/reflect/Type;", "context", "Lcom/google/gson/JsonSerializationContext;", "strikepractice-core"}
)
public final class f implements JsonSerializer<ConfigurationSerializable> {
   @NotNull
   public static final f ih = new f();

   private f() {
   }

   @NotNull
   public JsonElement a(@NotNull ConfigurationSerializable var1, @NotNull Type var2, @NotNull JsonSerializationContext var3) {
      Intrinsics.checkNotNullParameter(var1, "serializable");
      Intrinsics.checkNotNullParameter(var2, "type");
      Intrinsics.checkNotNullParameter(var3, "context");
      JsonElement var10000 = var3.serialize(var1.serialize());
      Intrinsics.checkNotNullExpressionValue(var10000, "context.serialize(serializable.serialize())");
      return var10000;
   }

   // $FF: synthetic method
   public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
      return this.a((ConfigurationSerializable)var1, var2, var3);
   }
}
