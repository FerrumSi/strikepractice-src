package ga.strikepractice.fights.savedfights;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import ga.strikepractice.kotlin.Metadata;
import org.bukkit.configuration.serialization.ConfigurationSerializable;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0010\u0010\u0000\u001a\n \u0002*\u0004\u0018\u00010\u00010\u0001H\u0000¨\u0006\u0003"},
   d2 = {"newGson", "Lcom/google/gson/Gson;", "ga.strikepractice.kotlin.jvm.PlatformType", "strikepractice-core"}
)
public final class d {
   public static final Gson cj() {
      return (new GsonBuilder()).registerTypeHierarchyAdapter(ConfigurationSerializable.class, e.ig).registerTypeHierarchyAdapter(ConfigurationSerializable.class, f.ih).create();
   }
}
