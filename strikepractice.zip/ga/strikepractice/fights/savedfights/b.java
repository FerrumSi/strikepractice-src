package ga.strikepractice.fights.savedfights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.FightStatistics;
import ga.strikepractice.utils.B;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.Map.Entry;

/** @deprecated */
@Deprecated
public class b {
   private UUID playbackUUID;
   private String ht;
   private String hu;
   private List<Integer> hv = new ArrayList(1);
   private List<Integer> hw = new ArrayList(1);
   private List<Integer> hx = new ArrayList(1);
   private List<Integer> hy = new ArrayList(1);
   private final List<Integer> hz = new ArrayList(1);
   private final List<Integer> hA = new ArrayList(1);
   private final List<Integer> hB = new ArrayList(1);
   private final List<Integer> hC = new ArrayList(1);
   private final List<Integer> hD = new ArrayList(1);
   private Map<UUID, String> hE = new HashMap(1);
   private Map<UUID, String> hF = new HashMap(1);
   private List<FightInventory> hG = new ArrayList(1);
   private List<FightInventory> hH = new ArrayList(1);
   private boolean bS;
   private boolean bQ;
   private boolean bP;
   private boolean bR;
   private boolean bi;
   private long ended;
   private long started;
   public Map<UUID, FightStatistics> hI;

   /** @deprecated */
   @Deprecated
   public void bO() {
      if (StrikePractice.getInstance().H) {
         String var1 = this.hu + ":elo=" + this.bS + ":horse=" + this.bQ + ":onlyBow=" + this.bP + ":combo=" + this.bR + ":build=" + this.bi;
         StringBuilder var2 = new StringBuilder();
         String var3 = "";

         for(Iterator var4 = this.hF.entrySet().iterator(); var4.hasNext(); var3 = ", ") {
            Entry var5 = (Entry)var4.next();
            var2.append(var3);
            var2.append(var5.getKey()).append(":").append((String)var5.getValue());
         }

         StringBuilder var17 = new StringBuilder();
         var3 = "";

         for(Iterator var18 = this.hE.entrySet().iterator(); var18.hasNext(); var3 = ", ") {
            Entry var6 = (Entry)var18.next();
            var17.append(var3);
            var17.append(var6.getKey()).append(":").append((String)var6.getValue());
         }

         String var19 = this.hx.toString().replace("[", "").replace("]", "");
         String var20 = this.hv.toString().replace("[", "").replace("]", "");
         String var7 = this.hy.toString().replace("[", "").replace("]", "");
         String var8 = this.hw.toString().replace("[", "").replace("]", "");
         String var9 = this.hz.toString().replace("[", "").replace("]", "");
         String var10 = this.hA.toString().replace("[", "").replace("]", "");
         String var11 = this.hB.toString().replace("[", "").replace("]", "");
         String var12 = this.hC.toString().replace("[", "").replace("]", "");
         String var13 = this.hD.toString().replace("[", "").replace("]", "");
         ArrayList var14 = new ArrayList();
         Iterator var15 = this.hG.iterator();

         FightInventory var16;
         while(var15.hasNext()) {
            var16 = (FightInventory)var15.next();
            var14.add(var16.toString());
         }

         var15 = this.hH.iterator();

         while(var15.hasNext()) {
            var16 = (FightInventory)var15.next();
            var14.add(var16.toString());
         }

         String var21 = var14.toString().replace("[", "").replace("]", "").replace(",", ";");
         String var22 = this.playbackUUID == null ? "not recorded" : this.playbackUUID.toString();
         StrikePractice.getInstance().aq().a("INSERT INTO fights (playback, winners, losers, kit_info, arena, started, ended, winners_old_elos, losers_old_elos, winners_new_elos, losers_new_elos, inventories, hits, longest_combo, potions_thrown, potions_missed, potion_accuracy) VALUES(?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?,?, ?, ?, ?)", var22, var17.toString(), var2.toString(), var1, this.ht, this.started, this.ended, var20, var19, var8, var7, var21, var9, var10, var11, var12, var13);
      }

   }

   /** @deprecated */
   @Deprecated
   public static b a(String var0, String var1, String var2, String var3, long var4, long var6, String var8, String var9, String var10, String var11, String var12, String var13, String var14, String var15, String var16, String var17) {
      b var18 = new b();
      String[] var19 = var2.replace("elo=", "").replace("horse=", "").replace("onlyBow=", "").replace("combo=", "").replace("build=", "").split(":");
      var18.o(var19[0]);
      var18.setElo(Boolean.parseBoolean(var19[1]));
      var18.setHorse(Boolean.parseBoolean(var19[2]));
      var18.setOnlyBow(Boolean.parseBoolean(var19[3]));
      var18.setCombo(Boolean.parseBoolean(var19[4]));
      var18.setCombo(Boolean.parseBoolean(var19[5]));
      var18.n(var3);
      var18.started = var4;
      var18.ended = var6;
      String[] var20 = var1.split(", ");
      int var21 = var20.length;

      int var22;
      String var23;
      String[] var24;
      for(var22 = 0; var22 < var21; ++var22) {
         var23 = var20[var22];
         var24 = var23.split(":");
         var18.bY().put(UUID.fromString(var24[0]), var24[1]);
      }

      var20 = var0.split(", ");
      var21 = var20.length;

      for(var22 = 0; var22 < var21; ++var22) {
         var23 = var20[var22];
         var24 = var23.split(":");
         var18.bT().put(UUID.fromString(var24[0]), var24[1]);
      }

      var20 = var9.split(", ");
      var21 = var20.length;

      for(var22 = 0; var22 < var21; ++var22) {
         var23 = var20[var22];
         var18.bW().add(Integer.parseInt(var23));
      }

      var20 = var8.split(", ");
      var21 = var20.length;

      for(var22 = 0; var22 < var21; ++var22) {
         var23 = var20[var22];
         var18.bU().add(Integer.parseInt(var23));
      }

      var20 = var11.split(", ");
      var21 = var20.length;

      for(var22 = 0; var22 < var21; ++var22) {
         var23 = var20[var22];
         var18.bX().add(Integer.parseInt(var23));
      }

      var20 = var10.split(", ");
      var21 = var20.length;

      for(var22 = 0; var22 < var21; ++var22) {
         var23 = var20[var22];
         var18.bV().add(Integer.parseInt(var23));
      }

      String var27 = (String)var18.bY().values().iterator().next() + ":";
      boolean var28 = false;
      String[] var31 = var12.split(var27);
      int var30 = var31.length;

      String var25;
      int var29;
      for(var29 = 0; var29 < var30; ++var29) {
         var25 = var31[var29];
         if (var28) {
            var25 = var27 + var25;
         } else {
            var28 = true;
         }

         FightInventory var26 = FightInventory.fromLegacyString(var25);
         if (var18.bZ().isEmpty()) {
            var18.bZ().add(var26);
         } else {
            var18.ca().add(var26);
         }
      }

      var31 = var13.split(", ");
      var30 = var31.length;

      for(var29 = 0; var29 < var30; ++var29) {
         var25 = var31[var29];
         var18.cb().add(Integer.parseInt(var25));
      }

      var31 = var14.split(", ");
      var30 = var31.length;

      for(var29 = 0; var29 < var30; ++var29) {
         var25 = var31[var29];
         var18.cc().add(Integer.parseInt(var25));
      }

      var31 = var15.split(", ");
      var30 = var31.length;

      for(var29 = 0; var29 < var30; ++var29) {
         var25 = var31[var29];
         var18.cf().add(Integer.parseInt(var25));
      }

      var31 = var16.split(", ");
      var30 = var31.length;

      for(var29 = 0; var29 < var30; ++var29) {
         var25 = var31[var29];
         var18.ce().add(Integer.parseInt(var25));
      }

      var31 = var17.split(", ");
      var30 = var31.length;

      for(var29 = 0; var29 < var30; ++var29) {
         var25 = var31[var29];
         var18.cd().add(Integer.parseInt(var25));
      }

      return var18;
   }

   public static b a(String[] var0, UUID var1) {
      String var2 = var0[0];
      String var3 = var0[1];
      String var4 = var0[2];
      String var5 = var0[3];
      String var6 = var0[4];
      String var7 = var0[5];
      String var8 = var0[6];
      String var9 = var0[7];
      String var10 = var0[8];
      String var11 = var0[9];
      String var12 = var0[10];
      String var13 = var0[11];
      String var14 = var0[12];
      String var15 = var0[13];
      String var16 = var0[14];
      String var17 = var0[15];
      b var18 = a(var2, var3, var4, var5, Long.parseLong(var6), Long.parseLong(var7), var8, var9, var10, var11, var12, var13, var14, var15, var16, var17);
      var18.d(var1);
      return var18;
   }

   public SavedFight bP() {
      StrikePractice var1 = StrikePractice.getInstance();
      Optional var2 = var1.M.stream().filter((var1x) -> {
         return var1x.getName().equals(this.ht);
      }).findFirst();
      Optional var3 = var1.kits.stream().filter((var1x) -> {
         return var1x.getName().equals(this.hu);
      }).findFirst();
      ArrayList var4 = new ArrayList(1);
      UUID var5 = (UUID)this.hF.keySet().stream().findAny().get();
      var4.add(new SavedPlayer((String)this.hF.values().stream().filter(Objects::nonNull).findAny().orElse("unknown"), var5, (FightInventory)this.hH.get(0), (FightStatistics)this.hI.get(var5), this.hx.isEmpty() ? 0 : (Integer)this.hx.get(0), this.hy.isEmpty() ? 0 : (Integer)this.hy.get(0)));
      ArrayList var6 = new ArrayList(1);
      UUID var7 = (UUID)this.hE.keySet().stream().findAny().get();
      var6.add(new SavedPlayer((String)this.hE.values().stream().filter(Objects::nonNull).findAny().orElse("unknown"), var7, (FightInventory)this.hG.get(0), (FightStatistics)this.hI.get(var7), this.hv.isEmpty() ? 0 : (Integer)this.hv.get(0), this.hw.isEmpty() ? 0 : (Integer)this.hw.get(0)));
      SavedFight var8 = new SavedFight(this.playbackUUID, (Arena)var2.orElseGet(() -> {
         return new ga.strikepractice.arena.c(this.ht);
      }), (BattleKit)var3.orElseGet(() -> {
         return new ga.strikepractice.battlekit.b(this.ht);
      }), this.ended, this.started, (Fight)null, var4, var6);
      B.debug("Converted to new format: " + var8);
      return var8;
   }

   public UUID bQ() {
      return this.playbackUUID;
   }

   public void d(UUID var1) {
      this.playbackUUID = var1;
   }

   public boolean isElo() {
      return this.bS;
   }

   public void setElo(boolean var1) {
      this.bS = var1;
   }

   public boolean isHorse() {
      return this.bQ;
   }

   public void setHorse(boolean var1) {
      this.bQ = var1;
   }

   public boolean isOnlyBow() {
      return this.bP;
   }

   public void setOnlyBow(boolean var1) {
      this.bP = var1;
   }

   public boolean isCombo() {
      return this.bR;
   }

   public void setCombo(boolean var1) {
      this.bR = var1;
   }

   public String bR() {
      return this.ht;
   }

   public void n(String var1) {
      this.ht = var1;
   }

   public String bS() {
      return this.hu;
   }

   public boolean isBuild() {
      return this.bi;
   }

   public void setBuild(boolean var1) {
      this.bi = var1;
   }

   public void o(String var1) {
      this.hu = var1;
   }

   public Map<UUID, String> bT() {
      return this.hE;
   }

   public void e(Map<UUID, String> var1) {
      this.hE = var1;
   }

   public List<Integer> bU() {
      return this.hv;
   }

   public void b(List<Integer> var1) {
      this.hv = var1;
   }

   public List<Integer> bV() {
      return this.hw;
   }

   public void c(List<Integer> var1) {
      this.hw = var1;
   }

   public List<Integer> bW() {
      return this.hx;
   }

   public void d(List<Integer> var1) {
      this.hx = var1;
   }

   public List<Integer> bX() {
      return this.hy;
   }

   public void e(List<Integer> var1) {
      this.hy = var1;
   }

   public Map<UUID, String> bY() {
      return this.hF;
   }

   public long getEnded() {
      return this.ended;
   }

   public void setEnded(long var1) {
      this.ended = var1;
   }

   public long getStarted() {
      return this.started;
   }

   public void setStarted(long var1) {
      this.started = var1;
   }

   public void f(Map<UUID, String> var1) {
      this.hF = var1;
   }

   public List<FightInventory> bZ() {
      return this.hG;
   }

   public void f(List<FightInventory> var1) {
      this.hG = var1;
   }

   public List<FightInventory> ca() {
      return this.hH;
   }

   public void g(List<FightInventory> var1) {
      this.hH = var1;
   }

   public List<Integer> cb() {
      return this.hz;
   }

   public List<Integer> cc() {
      return this.hA;
   }

   public List<Integer> cd() {
      return this.hD;
   }

   public List<Integer> ce() {
      return this.hC;
   }

   public List<Integer> cf() {
      return this.hB;
   }

   public String toString() {
      return "LegacySavedFight{playbackUUID=" + this.playbackUUID + ", arena='" + this.ht + '\'' + ", kit='" + this.hu + '\'' + ", winnersOldElo=" + this.hv + ", winnersNewElo=" + this.hw + ", losersOldElo=" + this.hx + ", losersNewElo=" + this.hy + ", hits=" + this.hz + ", longestCombo=" + this.hA + ", potionsThrown=" + this.hB + ", potionsMissed=" + this.hC + ", potionAccuracy=" + this.hD + ", winners=" + this.hE + ", losers=" + this.hF + ", winnersInventories=" + this.hG + ", losersInventories=" + this.hH + ", elo=" + this.bS + ", horse=" + this.bQ + ", onlyBow=" + this.bP + ", combo=" + this.bR + ", build=" + this.bi + ", ended=" + this.ended + ", started=" + this.started + ", fightStatistics=" + this.hI + '}';
   }
}
