package ga.strikepractice.fights.savedfights;

import ga.strikepractice.StrikePractice;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class c {
   /** @deprecated */
   @Deprecated
   public static final String hP = "arena";
   /** @deprecated */
   @Deprecated
   public static final String hQ = "started";
   /** @deprecated */
   @Deprecated
   public static final String hR = "ended";
   /** @deprecated */
   @Deprecated
   public static final String hS = "winners";
   /** @deprecated */
   @Deprecated
   public static final String hT = "losers";
   /** @deprecated */
   @Deprecated
   public static final String hU = "kit_info";
   /** @deprecated */
   @Deprecated
   public static final String hV = "losers_old_elos";
   /** @deprecated */
   @Deprecated
   public static final String hW = "winners_old_elos";
   /** @deprecated */
   @Deprecated
   public static final String hX = "losers_new_elos";
   /** @deprecated */
   @Deprecated
   public static final String hY = "winners_new_elos";
   /** @deprecated */
   @Deprecated
   public static final String hZ = "inventories";
   /** @deprecated */
   @Deprecated
   public static final String ia = "hits";
   /** @deprecated */
   @Deprecated
   public static final String ib = "longest_combo";
   /** @deprecated */
   @Deprecated
   public static final String ic = "potions_thrown";
   /** @deprecated */
   @Deprecated
   public static final String id = "potions_missed";
   /** @deprecated */
   @Deprecated
   public static final String ie = "potion_accuracy";
   private final StrikePractice if;

   public c(StrikePractice var1) {
      this.if = var1;
   }

   public String[] f(UUID var1) {
      if (this.a(var1)) {
         try {
            Connection var2 = this.if.O.aN();

            String[] var6;
            try {
               PreparedStatement var3 = var2.prepareStatement("SELECT * FROM fights WHERE playback=?");

               try {
                  var3.setString(1, var1.toString());
                  ResultSet var4 = var3.executeQuery();
                  String[] var5 = new String[16];
                  if (var4.next()) {
                     var5[0] = var4.getString("winners");
                     var5[1] = var4.getString("losers");
                     var5[2] = var4.getString("kit_info");
                     var5[3] = var4.getString("arena");
                     var5[4] = var4.getString("started");
                     var5[5] = var4.getString("ended");
                     var5[6] = var4.getString("winners_old_elos");
                     var5[7] = var4.getString("losers_old_elos");
                     var5[8] = var4.getString("winners_new_elos");
                     var5[9] = var4.getString("losers_new_elos");
                     var5[10] = var4.getString("inventories");
                     var5[11] = var4.getString("hits");
                     var5[12] = var4.getString("longest_combo");
                     var5[13] = var4.getString("potions_thrown");
                     var5[14] = var4.getString("potions_missed");
                     var5[15] = var4.getString("potion_accuracy");
                  }

                  var4.close();
                  var6 = var5;
               } catch (Throwable var9) {
                  if (var3 != null) {
                     try {
                        var3.close();
                     } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                     }
                  }

                  throw var9;
               }

               if (var3 != null) {
                  var3.close();
               }
            } catch (Throwable var10) {
               if (var2 != null) {
                  try {
                     var2.close();
                  } catch (Throwable var7) {
                     var10.addSuppressed(var7);
                  }
               }

               throw var10;
            }

            if (var2 != null) {
               var2.close();
            }

            return var6;
         } catch (Exception var11) {
            var11.printStackTrace();
         }
      }

      return null;
   }

   private boolean a(UUID var1) {
      try {
         Connection var2 = this.if.O.aN();

         boolean var6;
         label89: {
            try {
               PreparedStatement var3 = var2.prepareStatement("SELECT * FROM fights WHERE playback=?");

               label80: {
                  try {
                     var3.setString(1, var1.toString());
                     ResultSet var4 = var3.executeQuery();
                     if (!var4.next()) {
                        break label80;
                     }

                     boolean var5 = var4.getString("playback") != null;
                     var4.close();
                     var6 = var5;
                  } catch (Throwable var9) {
                     if (var3 != null) {
                        try {
                           var3.close();
                        } catch (Throwable var8) {
                           var9.addSuppressed(var8);
                        }
                     }

                     throw var9;
                  }

                  if (var3 != null) {
                     var3.close();
                  }
                  break label89;
               }

               if (var3 != null) {
                  var3.close();
               }
            } catch (Throwable var10) {
               if (var2 != null) {
                  try {
                     var2.close();
                  } catch (Throwable var7) {
                     var10.addSuppressed(var7);
                  }
               }

               throw var10;
            }

            if (var2 != null) {
               var2.close();
            }

            return false;
         }

         if (var2 != null) {
            var2.close();
         }

         return var6;
      } catch (SQLException var11) {
         var11.printStackTrace();
         return false;
      }
   }
}
