package ga.strikepractice.fights.savedfights;

import com.google.gson.annotations.SerializedName;
import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.jvm.JvmStatic;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@APIClass
@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0007\u0018\u0000 12\u00020\u0001:\u000212Bc\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\t\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\f\u0012\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e\u0012\u000e\b\u0002\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e¢\u0006\u0002\u0010\u0011J\f\u0010*\u001a\b\u0012\u0004\u0012\u00020+0\u000eJ\f\u0010,\u001a\b\u0012\u0004\u0012\u00020+0\u000eJ\u0006\u0010-\u001a\u00020.J\b\u0010/\u001a\u00020!H\u0002J\b\u00100\u001a\u00020!H\u0016R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0016\u0010\b\u001a\u00020\t8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\f¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0016\u0010\u0018\u001a\u00020\u00198\u0006X\u0087D¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0016\u0010\u0006\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0016\u0010 \u001a\u00020!8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010#R\u0018\u0010\u0002\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u0016\u0010&\u001a\u00020!8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b'\u0010#R\u0016\u0010\n\u001a\u00020\t8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\u0015R\u0017\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e¢\u0006\b\n\u0000\u001a\u0004\b)\u0010\u001f¨\u00063"},
   d2 = {"Lga/strikepractice/fights/savedfights/SavedFight;", "Ljava/io/Serializable;", "replayUUID", "Ljava/util/UUID;", "arena", "Lga/strikepractice/arena/Arena;", "kit", "Lga/strikepractice/battlekit/BattleKit;", "ended", "", "started", "fight", "Lga/strikepractice/fights/Fight;", "losers", "", "Lga/strikepractice/fights/savedfights/SavedPlayer;", "winners", "(Ljava/util/UUID;Lga/strikepractice/arena/Arena;Lga/strikepractice/battlekit/BattleKit;JJLga/strikepractice/fights/Fight;Ljava/util/List;Ljava/util/List;)V", "getArena", "()Lga/strikepractice/arena/Arena;", "getEnded", "()J", "getFight", "()Lga/strikepractice/fights/Fight;", "jsonVersion", "", "getJsonVersion", "()I", "getKit", "()Lga/strikepractice/battlekit/BattleKit;", "getLosers", "()Ljava/util/List;", "pluginVersion", "", "getPluginVersion", "()Ljava/lang/String;", "getReplayUUID", "()Ljava/util/UUID;", "serverVersion", "getServerVersion", "getStarted", "getWinners", "getLosersInventories", "Lga/strikepractice/fightinventory/FightInventory;", "getWinnersInventories", "saveToDatabase", "", "toJson", "toString", "Companion", "FightMode", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nSavedFight.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SavedFight.kt\nga/strikepractice/fights/savedfights/SavedFight\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n*L\n1#1,191:1\n1549#2:192\n1620#2,3:193\n1549#2:196\n1620#2,3:197\n1549#2:210\n1620#2,3:211\n1855#2,2:215\n1855#2,2:217\n81#3,4:200\n81#3,4:204\n81#3,2:208\n84#3:214\n*S KotlinDebug\n*F\n+ 1 SavedFight.kt\nga/strikepractice/fights/savedfights/SavedFight\n*L\n85#1:192\n85#1:193,3\n86#1:196\n86#1:197,3\n91#1:210\n91#1:211,3\n110#1:215,2\n111#1:217,2\n107#1:200,4\n90#1:204,4\n91#1:208,2\n91#1:214\n*E\n"})
public final class SavedFight implements Serializable {
   @NotNull
   public static final SavedFight.a Companion = new SavedFight.a((DefaultConstructorMarker)null);
   @SerializedName("replayUUID")
   @Nullable
   private final UUID replayUUID;
   @Nullable
   private final transient Arena arena;
   @SerializedName("kit")
   @NotNull
   private final BattleKit kit;
   @SerializedName("ended")
   private final long ended;
   @SerializedName("started")
   private final long started;
   @Nullable
   private final transient Fight fight;
   @NotNull
   private final transient List<SavedPlayer> losers;
   @NotNull
   private final transient List<SavedPlayer> winners;
   @SerializedName("jsonVersion")
   private final int jsonVersion;
   @SerializedName("pluginVersion")
   @NotNull
   private final String pluginVersion;
   @SerializedName("serverVersion")
   @NotNull
   private final String serverVersion;

   public SavedFight(@Nullable UUID var1, @Nullable Arena var2, @NotNull BattleKit var3, long var4, long var6, @Nullable Fight var8, @NotNull List<SavedPlayer> var9, @NotNull List<SavedPlayer> var10) {
      Intrinsics.checkNotNullParameter(var3, "kit");
      Intrinsics.checkNotNullParameter(var9, "losers");
      Intrinsics.checkNotNullParameter(var10, "winners");
      super();
      this.replayUUID = var1;
      this.arena = var2;
      this.kit = var3;
      this.ended = var4;
      this.started = var6;
      this.fight = var8;
      this.losers = var9;
      this.winners = var10;
      this.jsonVersion = 1;
      String var10001 = StrikePractice.getInstance().getDescription().getVersion();
      Intrinsics.checkNotNullExpressionValue(var10001, "getInstance().description.version");
      this.pluginVersion = var10001;
      var10001 = Bukkit.getVersion();
      Intrinsics.checkNotNullExpressionValue(var10001, "getVersion()");
      this.serverVersion = var10001;
   }

   // $FF: synthetic method
   public SavedFight(UUID var1, Arena var2, BattleKit var3, long var4, long var6, Fight var8, List var9, List var10, int var11, DefaultConstructorMarker var12) {
      if ((var11 & 1) != 0) {
         var1 = null;
      }

      if ((var11 & 8) != 0) {
         var4 = 0L;
      }

      if ((var11 & 16) != 0) {
         var6 = 0L;
      }

      if ((var11 & 32) != 0) {
         var8 = null;
      }

      if ((var11 & 64) != 0) {
         var9 = (List)(new ArrayList(1));
      }

      if ((var11 & 128) != 0) {
         var10 = (List)(new ArrayList(1));
      }

      this(var1, var2, var3, var4, var6, var8, var9, var10);
   }

   @Nullable
   public final UUID getReplayUUID() {
      return this.replayUUID;
   }

   @Nullable
   public final Arena getArena() {
      return this.arena;
   }

   @NotNull
   public final BattleKit getKit() {
      return this.kit;
   }

   public final long getEnded() {
      return this.ended;
   }

   public final long getStarted() {
      return this.started;
   }

   @Nullable
   public final Fight getFight() {
      return this.fight;
   }

   @NotNull
   public final List<SavedPlayer> getLosers() {
      return this.losers;
   }

   @NotNull
   public final List<SavedPlayer> getWinners() {
      return this.winners;
   }

   public final int getJsonVersion() {
      return this.jsonVersion;
   }

   @NotNull
   public final String getPluginVersion() {
      return this.pluginVersion;
   }

   @NotNull
   public final String getServerVersion() {
      return this.serverVersion;
   }

   private final String toJson() {
      String var10000 = d.cj().toJson(this);
      Intrinsics.checkNotNullExpressionValue(var10000, "newGson().toJson(this)");
      return var10000;
   }

   @NotNull
   public String toString() {
      return this.toJson();
   }

   @NotNull
   public final List<FightInventory> getLosersInventories() {
      Iterable var1 = (Iterable)this.losers;
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var1, 10)));
      boolean var5 = false;
      Iterator var6 = var1.iterator();

      while(var6.hasNext()) {
         Object var7 = var6.next();
         SavedPlayer var8 = (SavedPlayer)var7;
         boolean var9 = false;
         var4.add(var8.getFightInventory());
      }

      return (List)var4;
   }

   @NotNull
   public final List<FightInventory> getWinnersInventories() {
      Iterable var1 = (Iterable)this.winners;
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var1, 10)));
      boolean var5 = false;
      Iterator var6 = var1.iterator();

      while(var6.hasNext()) {
         Object var7 = var6.next();
         SavedPlayer var8 = (SavedPlayer)var7;
         boolean var9 = false;
         var4.add(var8.getFightInventory());
      }

      return (List)var4;
   }

   public final void saveToDatabase() {
      C.c(SavedFight::saveToDatabase$lambda$10);
   }

   private static final void saveToDatabase$lambda$10$insertPlayer(StrikePractice var0, long var1, SavedPlayer var3, boolean var4) {
      ga.strikepractice.b.a var10000 = var0.aq();
      Object[] var5 = new Object[]{var3.getUuid(), var3.getName(), var1, var4, var3.toJson()};
      var10000.b("INSERT INTO fight_players(uuid, username, fight, is_winner, player_data)VALUES(?, ?, ?, ?, ?)", var5);
      Unit var14 = Unit.INSTANCE;
      boolean var7 = false;
      B.a var8 = B.vj;
      boolean var9 = false;
      if (var8.fV()) {
         Logger var15 = Bukkit.getLogger();
         StringBuilder var10 = (new StringBuilder()).append("[SP DEBUG] ");
         Logger var11 = var15;
         boolean var12 = false;
         String var13 = "Saving player " + var3.getName();
         var11.info(var10.append(var13).toString());
      }

   }

   private static final void saveToDatabase$lambda$10(SavedFight var0) {
      Intrinsics.checkNotNullParameter(var0, "this$0");
      B.a var1 = B.vj;
      boolean var2 = false;
      boolean var3;
      Logger var15;
      Logger var10000;
      StringBuilder var16;
      String var17;
      if (var1.fV()) {
         var10000 = Bukkit.getLogger();
         var16 = (new StringBuilder()).append("[SP DEBUG] ");
         var15 = var10000;
         var3 = false;
         var17 = "Saving fight to database: " + var0;
         var15.info(var16.append(var17).toString());
      }

      var1 = B.vj;
      var2 = false;
      Iterable var4;
      boolean var9;
      if (var1.fV()) {
         var10000 = Bukkit.getLogger();
         var16 = (new StringBuilder()).append("[SP DEBUG] ");
         var15 = var10000;
         var3 = false;
         StringBuilder var24 = (new StringBuilder()).append("winners: ");
         var4 = (Iterable)var0.winners;
         StringBuilder var5 = var24;
         boolean var6 = false;
         Collection var8 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var4, 10)));
         var9 = false;
         Iterator var10 = var4.iterator();

         Object var11;
         SavedPlayer var12;
         boolean var14;
         while(var10.hasNext()) {
            var11 = var10.next();
            var12 = (SavedPlayer)var11;
            var14 = false;
            var8.add(var12.toJson());
         }

         var24 = var5.append((List)var8).append(", losers: ");
         var4 = (Iterable)var0.losers;
         var5 = var24;
         var6 = false;
         var8 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var4, 10)));
         var9 = false;
         var10 = var4.iterator();

         while(var10.hasNext()) {
            var11 = var10.next();
            var12 = (SavedPlayer)var11;
            var14 = false;
            var8.add(var12.toJson());
         }

         var17 = var5.append((List)var8).toString();
         var15.info(var16.append(var17).toString());
      }

      StrikePractice var18 = StrikePractice.getInstance();
      long var19 = var0.started;
      ga.strikepractice.b.a var25 = var18.aq();
      Object[] var20 = new Object[7];
      var20[0] = var0.replayUUID;
      var20[1] = var0.kit.getName();
      Arena var10004 = var0.arena;
      var20[2] = var10004 != null ? var10004.getName() : null;
      var20[3] = var0.started;
      var20[4] = var0.ended;
      var20[5] = SavedFight.b.hJ.a(var0);
      var20[6] = var0.toJson();
      var25.b("INSERT INTO fights(replay_id, kit, arena, started, ended, mode, fight_data)VALUES(?, ?, ?, ?, ?, ?, ?)", var20);
      var4 = (Iterable)var0.winners;
      boolean var21 = false;
      Iterator var22 = var4.iterator();

      Object var7;
      SavedPlayer var23;
      while(var22.hasNext()) {
         var7 = var22.next();
         var23 = (SavedPlayer)var7;
         var9 = false;
         saveToDatabase$lambda$10$insertPlayer(var18, var19, var23, true);
      }

      var4 = (Iterable)var0.losers;
      var21 = false;
      var22 = var4.iterator();

      while(var22.hasNext()) {
         var7 = var22.next();
         var23 = (SavedPlayer)var7;
         var9 = false;
         saveToDatabase$lambda$10$insertPlayer(var18, var19, var23, false);
      }

   }

   @JvmStatic
   @Nullable
   public static final SavedFight byReplayId(@NotNull UUID var0) {
      return Companion.e(var0);
   }

   @JvmStatic
   @Nullable
   public static final SavedFight fromJson(@Nullable String var0) {
      return Companion.p(var0);
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0014\u0010\u0007\u001a\u0004\u0018\u00010\u00042\b\u0010\b\u001a\u0004\u0018\u00010\tH\u0007¨\u0006\n"},
      d2 = {"Lga/strikepractice/fights/savedfights/SavedFight$Companion;", "", "()V", "byReplayId", "Lga/strikepractice/fights/savedfights/SavedFight;", "uuid", "Ljava/util/UUID;", "fromJson", "json", "", "strikepractice-core"}
   )
   public static final class a {
      private a() {
      }

      @JvmStatic
      @Nullable
      public final SavedFight e(@NotNull UUID var1) {
         Intrinsics.checkNotNullParameter(var1, "uuid");
         Bukkit.getLogger().warning("Replay inventories are temporarily disabled.");
         return null;
      }

      @JvmStatic
      @Nullable
      public final SavedFight p(@Nullable String var1) {
         return (SavedFight)d.cj().fromJson(var1, SavedFight.class);
      }

      // $FF: synthetic method
      public a(DefaultConstructorMarker var1) {
         this();
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0086\u0001\u0018\u0000 \u00072\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0007B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\b"},
      d2 = {"Lga/strikepractice/fights/savedfights/SavedFight$FightMode;", "", "(Ljava/lang/String;I)V", "DUEL", "DUEL_QUEUE", "DUEL_QUEUE_RANKED", "DUEL_QUEUE_PREMIUM", "Companion", "strikepractice-core"}
   )
   public static enum b {
      @NotNull
      public static final SavedFight.b.a hJ = new SavedFight.b.a((DefaultConstructorMarker)null);
      @SerializedName("DUEL")
      hK,
      @SerializedName("DUEL_QUEUE")
      hL,
      @SerializedName("DUEL_QUEUE_RANKED")
      hM,
      @SerializedName("DUEL_QUEUE_PREMIUM")
      hN;

      // $FF: synthetic method
      private static final SavedFight.b[] ci() {
         SavedFight.b[] var0 = new SavedFight.b[]{hK, hL, hM, hN};
         return var0;
      }

      @Metadata(
         mv = {1, 8, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"},
         d2 = {"Lga/strikepractice/fights/savedfights/SavedFight$FightMode$Companion;", "", "()V", "getMode", "Lga/strikepractice/fights/savedfights/SavedFight$FightMode;", "sf", "Lga/strikepractice/fights/savedfights/SavedFight;", "strikepractice-core"}
      )
      public static final class a {
         private a() {
         }

         @NotNull
         public final SavedFight.b a(@NotNull SavedFight var1) {
            Intrinsics.checkNotNullParameter(var1, "sf");
            return var1.getKit().getKitTypes().contains(BattleKitType.PREMIUM_QUEUE) ? SavedFight.b.hN : (var1.getKit().isElo() ? SavedFight.b.hM : (var1.getFight() instanceof Duel && ((Duel)var1.getFight()).isQueue() ? SavedFight.b.hL : SavedFight.b.hK));
         }

         // $FF: synthetic method
         public a(DefaultConstructorMarker var1) {
            this();
         }
      }
   }
}
