package ga.strikepractice.fights.savedfights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.FightStatistics;
import ga.strikepractice.utils.r;
import java.util.Arrays;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class a {
   private a() {
   }

   public static b bN() {
      return a(((BattleKit)StrikePractice.getInstance().kits.get(0)).getInv());
   }

   public static b a(ItemStack[] var0) {
      b var1 = new b();
      UUID var2 = UUID.randomUUID();
      UUID var3 = UUID.randomUUID();
      var1.bT().put(var2, "exampleWinner");
      var1.bY().put(var3, "exampleLoser");
      var1.n("Arena Name");
      var1.o("kit name");
      var1.setCombo(true);
      var1.setElo(true);
      var1.setBuild(true);
      var1.setHorse(true);
      var1.setOnlyBow(true);
      FightInventory var4 = new FightInventory(StrikePractice.getInstance());
      var4.setStatistics(new FightStatistics());
      var4.setBoots(r.a((Material)Material.DIAMOND_BOOTS, (String)null, (byte)37));
      var4.setChestplate(r.a((Material)Material.DIAMOND_CHESTPLATE, (String)null, (byte)37));
      var4.setLeggings(r.a((Material)Material.DIAMOND_LEGGINGS, (String)null, (byte)37));
      var4.setHelmet(r.a((Material)Material.DIAMOND_HELMET, (String)null, (byte)37));
      var4.setDead(true);
      var4.setFood(16);
      var4.setEffects(Arrays.asList(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 150, 0)));
      var4.setHealth(0.0D);
      var4.setOwner("exampleLoser");
      var4.setUUID(UUID.randomUUID());
      var4.setOwnerUUID(var3);
      var4.setMainInv(var0);
      FightInventory var5 = new FightInventory(StrikePractice.getInstance());
      var5.setStatistics(new FightStatistics());
      var5.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
      var5.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
      var5.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
      var5.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
      var5.setDead(false);
      var5.setFood(20);
      var5.setEffects(Arrays.asList(new PotionEffect(PotionEffectType.SPEED, 30, 1), new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 150, 0)));
      var5.setHealth(20.0D);
      var5.setOwner("exampleWinner");
      var5.setUUID(UUID.randomUUID());
      var5.setOwnerUUID(var2);
      var5.setMainInv(var0);
      var1.g(Arrays.asList(var4));
      var1.f(Arrays.asList(var5));
      short var6 = 1010;
      Integer var7 = 1000;
      byte var8 = 7;
      var1.bX().add(var6 - var8);
      var1.bW().add(Integer.valueOf(var6));
      var1.bV().add(var7 + var8);
      var1.bU().add(var7);
      var1.setStarted((long)((double)System.currentTimeMillis() - 210000.0D));
      var1.setEnded(System.currentTimeMillis());
      var1.d(UUID.randomUUID());
      var1.cb().add(68);
      var1.cc().add(6);
      var1.cf().add(13);
      var1.ce().add(2);
      var1.cd().add(35);
      var1.cb().add(37);
      var1.cc().add(4);
      var1.cf().add(21);
      var1.ce().add(4);
      var1.cd().add(40);
      return var1;
   }
}
