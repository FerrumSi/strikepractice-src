package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.CachedBlockChange;
import ga.strikepractice.arena.DefaultCachedBlockChange;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.other.FFAFight;
import ga.strikepractice.fights.party.partyfights.PartyFight;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.C;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;

@APIClass
public abstract class AbstractFight implements Fight {
   public static final String currentFight = "StrikePracticeCurrentFight";
   private static final ConcurrentMap<UUID, Fight> fights = new ConcurrentHashMap();
   protected Map<Location, DefaultCachedBlockChange> blockChanges = new HashMap(128);
   protected Map<UUID, FightStatistics> statistics = new HashMap(2);
   protected boolean bed1Broken;
   protected boolean bed2Broken;
   protected BattleKit kit;
   protected Arena arena;
   protected long started;
   protected long ended;
   protected boolean blockLimitReached;
   private boolean blockLimitMessageSent = false;
   protected MatchDurationLimit durationLimit;
   protected int maxBlockChanges = 0;

   protected int getMaxBlockChanges() {
      if (this.maxBlockChanges == 0) {
         int var1 = StrikePractice.getInstance().getConfig().getInt("max-block-changes");
         if (var1 != 0) {
            this.maxBlockChanges = var1;
         } else {
            try {
               this.maxBlockChanges = 5000 + this.getPlayerNames().size() * 1000;
            } catch (Exception var3) {
               this.maxBlockChanges = 3000;
            }
         }
      }

      return this.maxBlockChanges;
   }

   public static ConcurrentMap<UUID, Fight> getFights() {
      return fights;
   }

   public void start() {
      this.durationLimit = new DefaultMatchDurationLimit(this, StrikePractice.getInstance());
      this.durationLimit.onFightStart();
   }

   public Arena getArena() {
      return this.arena;
   }

   public void setArena(Arena var1) {
      this.arena = var1;
   }

   public void setKit(BattleKit var1) {
      this.kit = var1;
   }

   public FightStatistics getStatistics(UUID var1) {
      FightStatistics var2 = (FightStatistics)this.statistics.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         FightStatistics var3 = new FightStatistics();
         this.statistics.put(var1, var3);
         return var3;
      }
   }

   public FightStatistics getStatistics(Player var1) {
      return this.getStatistics(var1.getUniqueId());
   }

   public HashMap<UUID, FightStatistics> getStatistics() {
      return (HashMap)this.statistics;
   }

   public BattleKit getKit() {
      return this.kit;
   }

   public boolean isBed1Broken() {
      return this.bed1Broken;
   }

   public boolean isBed2Broken() {
      return this.bed2Broken;
   }

   public void setBed1Broken(boolean var1) {
      this.bed1Broken = var1;
   }

   public void setBed2Broken(boolean var1) {
      this.bed2Broken = var1;
   }

   public long getStarted() {
      return this.started;
   }

   public long getEnded() {
      return this.ended;
   }

   public void setStartedAfterCountdown() {
      this.started = System.currentTimeMillis() + (long)(StrikePractice.getInstance().getConfig().getInt("countdown-time") * 1000) + 1000L;
   }

   public long getDuration() {
      if (!this.hasStarted()) {
         return 0L;
      } else {
         return this.hasEnded() ? this.ended - this.started : System.currentTimeMillis() - this.started;
      }
   }

   public Set<DefaultCachedBlockChange> getBlockChanges() {
      return new HashSet(this.blockChanges.values());
   }

   public Map<Location, DefaultCachedBlockChange> getBlockChangesMap() {
      return this.blockChanges;
   }

   public MatchDurationLimit getDurationLimit() {
      return this.durationLimit;
   }

   public boolean addBlockChange(DefaultCachedBlockChange var1) {
      if (!this.blockLimitReached) {
         if (var1.isResetSupported()) {
            this.blockChanges.putIfAbsent(var1.getLocation(), var1);
            this.handleDisappear(var1);
            this.blockLimitReached = this.blockChanges.size() > this.getMaxBlockChanges();
            return true;
         }
      } else if (!this.blockLimitMessageSent) {
         this.blockLimitMessageSent = true;
         Iterator var2 = this.getPlayersInFight().iterator();

         Player var3;
         while(var2.hasNext()) {
            var3 = (Player)var2.next();
            var3.sendMessage(StrikePractice.getInstance().X() + ChatColor.RED + ChatColor.BOLD + "THE FIGHT HAS REACHED THE BLOCK LIMIT! Players can not modify blocks anymore in this fight!");
         }

         var2 = this.getSpectators().iterator();

         while(var2.hasNext()) {
            var3 = (Player)var2.next();
            var3.sendMessage(StrikePractice.getInstance().X() + ChatColor.RED + ChatColor.BOLD + "THE FIGHT HAS REACHED THE BLOCK LIMIT! Players can not modify blocks anymore in this fight!");
         }
      }

      return false;
   }

   protected void handleDisappear(CachedBlockChange var1) {
      if (this.kit.getBlockDisappear() > 0 && this.kit.isBuild()) {
         C.a(() -> {
            if (!this.hasEnded()) {
               Block var2 = var1.getLocation().getBlock();
               if (var2 != null && var2.getType() != null && var2.getType() != Material.AIR) {
                  var1.reset(true);
                  this.blockChanges.remove(var1.getLocation());
               }
            }

         }, (long)this.kit.getBlockDisappear());
      }

   }

   public void clearBlockChanges() {
      this.blockChanges = new HashMap(1);
      this.blockLimitReached = false;
   }

   public void setMaxBlockChanges(int var1) {
      this.maxBlockChanges = var1;
   }

   protected void sendSpectatorMessages(Collection<String> var1, Collection<String> var2, String var3) {
      if (var1 != null && var2 != null && StrikePractice.getInstance().getConfig().getBoolean("spectator-inventory-messages")) {
         Party[] var4 = this instanceof PartyFight ? ((PartyFight)this).getParties() : null;
         Iterator var5 = this.getSpectators().iterator();

         while(true) {
            Player var6;
            do {
               if (!var5.hasNext()) {
                  return;
               }

               var6 = (Player)var5.next();
            } while(var4 != null && this.sameParty(var6, var4));

            if (!var1.contains(var6.getName()) && !var2.contains(var6.getName())) {
               if (var3 != null) {
                  var6.sendMessage(var3);
               }

               FightInventory.inventoryMessage(var6, var1, var2);
            }
         }
      }
   }

   private boolean sameParty(Player var1, Party[] var2) {
      Party var3 = Party.getParty(var1);
      Party[] var4 = var2;
      int var5 = var2.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         Party var7 = var4[var6];
         if (var3 == var7) {
            return true;
         }
      }

      return false;
   }

   protected void sendSpectatorMessages(Collection<String> var1, Collection<String> var2) {
      this.sendSpectatorMessages(var1, var2, (String)null);
   }

   @Nullable
   public static Fight getCurrentFight(Player var0) {
      return getCurrentFight(var0.getUniqueId());
   }

   public static Fight getCurrentFight(UUID var0) {
      return (Fight)fights.get(var0);
   }

   public static void setCurrentFight(Player var0, Fight var1) {
      UUID var2 = var0.getUniqueId();
      if (var1 == null) {
         Fight var3 = (Fight)fights.get(var2);
         if (var3 instanceof FFAFight) {
            ((FFAFight)var3).getPlayers().remove(var2);
         }

         fights.remove(var2);
      } else {
         fights.put(var2, var1);
      }

   }

   public static boolean isInFight(Player var0) {
      return getCurrentFight(var0) != null;
   }
}
