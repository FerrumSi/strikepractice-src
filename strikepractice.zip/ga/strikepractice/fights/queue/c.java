package ga.strikepractice.fights.queue;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.C;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class c implements CommandExecutor {
   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length != 3 || !var4[0].equalsIgnoreCase("set") && !var4[0].equalsIgnoreCase("add")) {
         var1.sendMessage(ChatColor.YELLOW + "/premiummatches add <player> <number>");
         var1.sendMessage(ChatColor.YELLOW + "/premiummatches set <player> <number>");
      } else {
         Player var5 = Bukkit.getPlayer(var4[1]);
         boolean var6 = var4[0].equalsIgnoreCase("set");

         int var7;
         try {
            var7 = Integer.parseInt(var4[2]);
         } catch (NumberFormatException var9) {
            var1.sendMessage(ChatColor.YELLOW + "/premiummatches add <player> <number>");
            var1.sendMessage(ChatColor.YELLOW + "/premiummatches set <player> <number>");
            return true;
         }

         C.c(() -> {
            UUID var5x = var5 != null ? var5.getUniqueId() : Bukkit.getOfflinePlayer(var4[1]).getUniqueId();
            DefaultPlayerStats var6x = DefaultPlayerStats.getStats(var5x, false, false);
            int var7x = var6x.getPremiumMatches();
            var6x.setPremiumMatches(var6 ? var7 : var6x.getPremiumMatches() + var7);
            var6x.save(false);
            if (var6) {
               var1.sendMessage(ChatColor.GOLD + "Premium matches set to " + var7 + " for " + (var5 != null ? var5.getName() : var5x));
            } else {
               var1.sendMessage(ChatColor.GOLD + Integer.toString(var7) + " premium matches added for " + (var5 != null ? var5.getName() : var5x));
            }

            int var8 = var6x.getPremiumMatches() - var7x;
            if (var5 != null && var8 > 0) {
               var5.sendMessage(StrikePractice.getInstance().X() + ChatColor.GREEN + "You have received " + var8 + " premium " + (var8 > 1 ? "matches!" : "match!"));
            }

         });
      }

      return true;
   }
}
