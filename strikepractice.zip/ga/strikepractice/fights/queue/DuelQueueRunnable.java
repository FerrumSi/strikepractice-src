package ga.strikepractice.fights.queue;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.u;
import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.Iterator;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.scheduler.BukkitRunnable;

@APIClass
public class DuelQueueRunnable implements QueueRunnable {
   public static final String RANKED_QUEUE = "StrikePracticeRankedQueue";
   private final StrikePractice plugin;
   private final int currentElo;
   private boolean anyone;
   private final boolean premium;
   private int counter;
   private final BattleKit kit;
   private final UUID uuid;
   private WeakReference<Player> player;
   private int range;
   private final int anyoneAfter;
   private final int eloRangeTime;
   private final int rangeIncrease;

   public DuelQueueRunnable(StrikePractice var1, Player var2, BattleKit var3, boolean var4) {
      this.uuid = var2.getUniqueId();
      this.plugin = var1;
      this.kit = var3;
      this.premium = var4;
      this.currentElo = DefaultPlayerStats.getStats(this.uuid).getElo(var3);
      this.player = new WeakReference(var2);
      var2.setMetadata("StrikePracticeRankedQueue", new FixedMetadataValue(var1, this));
      this.range = var1.getConfig().getInt("ranked.elo-range-increase");
      this.anyoneAfter = this.plugin.getConfig().getInt("ranked.anyone-after");
      this.eloRangeTime = this.plugin.getConfig().getInt("ranked.elo-range-time");
      this.rangeIncrease = this.plugin.getConfig().getInt("ranked.elo-range-increase");
   }

   public void run() {
      Player var1 = this.getPlayer();
      ++this.counter;
      if (this.counter >= this.anyoneAfter) {
         if (!this.anyone) {
            this.plugin.a(var1, "ranked-anyone");
         }

         this.anyone = true;
      } else {
         DuelQueueRunnable var2 = this.checkQueue();
         if (var2 != null) {
            e.b(var2);
            e.b(this);
            d.bs();
         } else if (this.counter % this.eloRangeTime == 0) {
            this.range += this.rangeIncrease;
            this.plugin.a(var1, "ranked-range", u.a("<range1>", this.getFromRange(), "<range2>", this.getToRange()));
         }
      }

   }

   private DuelQueueRunnable checkQueue() {
      final Player var1 = this.getPlayer();
      Iterator var2 = ((Collection)d.gF.get(this.kit)).iterator();

      DuelQueueRunnable var3;
      final Player var4;
      do {
         do {
            do {
               do {
                  do {
                     do {
                        if (!var2.hasNext()) {
                           return null;
                        }

                        var3 = (DuelQueueRunnable)var2.next();
                     } while(var3 == this);

                     var4 = var3.getPlayer();
                  } while(var4 == null);
               } while(var3.getKit() != this.kit);
            } while(var3.premium != this.premium);
         } while((Math.abs(var3.getCurrentElo() - this.getCurrentElo()) >= this.range || Math.abs(var3.getCurrentElo() - this.getCurrentElo()) >= var3.getRange()) && (!var3.isAnyone() || !this.anyone));
      } while(!var3.isValidQueue() || !this.isValidQueue());

      var4.removeMetadata("StrikePracticeRankedQueue", this.plugin);
      var1.removeMetadata("StrikePracticeRankedQueue", this.plugin);
      var4.removeMetadata("StrikePracticeWaitingQueue", this.plugin);
      var1.removeMetadata("StrikePracticeWaitingQueue", this.plugin);
      (new BukkitRunnable() {
         public void run() {
            var1.closeInventory();
            var4.closeInventory();
            BattleKit var1x = ga.strikepractice.battlekit.e.a(DuelQueueRunnable.this.kit, (var0) -> {
               return var0.isElo() && d.g(var0);
            });
            Duel var2 = new Duel(DuelQueueRunnable.this.plugin, var1.getName(), var4.getName(), var1x);
            if (var2.canStart()) {
               var2.setQueue(true);
               var2.setPremiumQueue(DuelQueueRunnable.this.premium);
               var2.start();
            } else {
               DuelQueueRunnable.this.plugin.L.bh(var1);
               DuelQueueRunnable.this.plugin.L.bh(var4);
               ga.strikepractice.arena.c.e(var4);
               ga.strikepractice.arena.c.e(var1);
            }

         }
      }).runTaskLater(this.plugin, 5L);
      return var3;
   }

   public static DuelQueueRunnable getRanked(Player var0) {
      MetadataValue var1 = StrikePractice.getInstance().a((Metadatable)var0, (String)"StrikePracticeRankedQueue");
      return var1 != null && var1.value() instanceof DuelQueueRunnable ? (DuelQueueRunnable)var1.value() : null;
   }

   public Player getPlayer() {
      if (this.player == null) {
         this.player = new WeakReference(Bukkit.getPlayer(this.getUUID()));
      }

      return (Player)this.player.get();
   }

   public boolean isValidQueue() {
      return this.getPlayer() != null && getRanked(this.getPlayer()) == this && AbstractFight.getCurrentFight(this.getPlayer()) == null;
   }

   public int getCurrentElo() {
      return this.currentElo;
   }

   public boolean isPremium() {
      return this.premium;
   }

   public int getRange() {
      return this.range;
   }

   public BattleKit getKit() {
      return this.kit;
   }

   public void setRange(int var1) {
      this.range = var1;
   }

   public boolean isAnyone() {
      return this.anyone;
   }

   public void setAnyone(boolean var1) {
      this.anyone = var1;
   }

   public int getCounter() {
      return this.counter;
   }

   public void setCounter(int var1) {
      this.counter = var1;
   }

   public int getFromRange() {
      return Math.max(0, this.currentElo - this.range);
   }

   public int getToRange() {
      return this.currentElo + this.range;
   }

   public UUID getUUID() {
      return this.uuid;
   }
}
