package ga.strikepractice.fights.queue;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.party.partyfights.partyqueue.PartyQueueRunnable;
import java.util.Collection;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

public class e extends BukkitRunnable {
   public e(StrikePractice var1) {
      this.runTaskTimerAsynchronously(var1, 60L, 60L);
   }

   public void run() {
      Iterator var1 = d.gF.values().iterator();

      Collection var2;
      Iterator var3;
      QueueRunnable var4;
      while(var1.hasNext()) {
         var2 = (Collection)var1.next();
         var3 = var2.iterator();

         while(var3.hasNext()) {
            var4 = (QueueRunnable)var3.next();
            this.a(var4);
         }
      }

      var1 = ga.strikepractice.fights.party.partyfights.partyqueue.a.gF.values().iterator();

      while(var1.hasNext()) {
         var2 = (Collection)var1.next();
         var3 = var2.iterator();

         while(var3.hasNext()) {
            var4 = (QueueRunnable)var3.next();
            this.a(var4);
         }
      }

   }

   private void a(QueueRunnable var1) {
      try {
         if (var1.isValidQueue()) {
            var1.run();
         } else {
            b(var1);
         }
      } catch (Exception var3) {
         Bukkit.getLogger().warning("An error occurred in queue. Cancelling the queue");
         var3.printStackTrace();
         b(var1);
      }

   }

   public static boolean b(QueueRunnable var0) {
      Collection var1;
      if (var0 instanceof DuelQueueRunnable) {
         var1 = (Collection)d.gF.get(var0.getKit());
         if (var1 != null) {
            return var1.remove(var0);
         }

         d.bs();
      } else if (var0 instanceof PartyQueueRunnable) {
         var1 = (Collection)ga.strikepractice.fights.party.partyfights.partyqueue.a.gF.get(var0.getKit());
         if (var1 != null) {
            return var1.remove(var0);
         }

         ga.strikepractice.fights.party.partyfights.partyqueue.a.bo();
      }

      return false;
   }
}
