package ga.strikepractice.fights.queue;

import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.C;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

@ga.strikepractice.utils.e(
   fj = {"update", "add", "set"}
)
public class a implements CommandExecutor {
   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      Player var5;
      if (var4.length == 2 && var4[0].equalsIgnoreCase("update")) {
         var5 = Bukkit.getPlayer(var4[1]);
         if (var5 == null) {
            var1.sendMessage(ChatColor.RED + "The player is not online!");
         } else {
            DefaultPlayerStats var11 = DefaultPlayerStats.getStats(var5.getUniqueId());
            var11.checkAndResetNow();
            var1.sendMessage(ChatColor.GREEN + "Update done!");
            var1.sendMessage(ChatColor.GREEN + "Rankeds left: " + var11.getRankedsLeft());
            var1.sendMessage(ChatColor.GREEN + "Unrankeds left: " + var11.getUnrankedsLeft());
         }
      } else if (var4.length == 4 && (var4[1].equalsIgnoreCase("ranked") || var4[1].equalsIgnoreCase("unranked")) && (var4[0].equalsIgnoreCase("set") || var4[0].equalsIgnoreCase("add"))) {
         var5 = Bukkit.getPlayer(var4[2]);
         boolean var6 = var4[1].equalsIgnoreCase("ranked");
         boolean var7 = var4[0].equalsIgnoreCase("set");
         boolean var8 = false;

         int var12;
         try {
            var12 = Integer.parseInt(var4[3]);
         } catch (NumberFormatException var10) {
            var1.sendMessage(ChatColor.YELLOW + "/matchlimit add unranked/ranked <player> <number>");
            var1.sendMessage(ChatColor.YELLOW + "/matchlimit set unranked/ranked <player> <number>");
            var1.sendMessage(ChatColor.YELLOW + "/matchlimit update <player>");
            return true;
         }

         C.c(() -> {
            UUID var6x = var5 != null ? var5.getUniqueId() : Bukkit.getOfflinePlayer(var4[2]).getUniqueId();
            DefaultPlayerStats var7x = DefaultPlayerStats.getStats(var6x, false, false);
            if (var6) {
               var7x.setRankedsLeft(var7 ? var12 : var7x.getRankedsLeft() + var12);
            } else {
               var7x.setUnrankedsLeft(var7 ? var12 : var7x.getUnrankedsLeft() + var12);
            }

            var7x.save(false);
            if (var7) {
               var1.sendMessage(ChatColor.GOLD + (var6 ? "Rankeds" : "Unrankeds") + " set to " + var12 + " for " + (var5 != null ? var5.getName() : var6x));
            } else {
               var1.sendMessage(ChatColor.GOLD + Integer.toString(var12) + (var6 ? " rankeds" : " unrankeds") + " added for " + (var5 != null ? var5.getName() : var6x));
            }

         });
      } else {
         var1.sendMessage(ChatColor.YELLOW + "/matchlimit add unranked/ranked <player> <number>");
         var1.sendMessage(ChatColor.YELLOW + "/matchlimit set unranked/ranked <player> <number>");
         var1.sendMessage(ChatColor.YELLOW + "/matchlimit update <player>");
      }

      return true;
   }
}
