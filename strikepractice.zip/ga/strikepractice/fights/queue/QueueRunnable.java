package ga.strikepractice.fights.queue;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.battlekit.BattleKit;

@APIClass
public interface QueueRunnable extends Runnable {
   int getCurrentElo();

   int getRange();

   BattleKit getKit();

   void setRange(int var1);

   boolean isAnyone();

   void setAnyone(boolean var1);

   int getCounter();

   void setCounter(int var1);

   boolean isValidQueue();

   int getFromRange();

   int getToRange();
}
