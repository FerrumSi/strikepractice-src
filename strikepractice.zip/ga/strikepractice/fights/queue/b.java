package ga.strikepractice.fights.queue;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.stats.DefaultPlayerStats;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class b extends BukkitRunnable {
   private final boolean gR;
   private final boolean gS;

   public b(StrikePractice var1, boolean var2, boolean var3) {
      this.gR = var2;
      this.gS = var3;
      this.runTaskTimerAsynchronously(var1, 1200L, 18000L);
   }

   public void run() {
      Iterator var1 = Bukkit.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player var2 = (Player)var1.next();
         DefaultPlayerStats var3 = DefaultPlayerStats.getStats(var2.getUniqueId(), true, false);
         var3.checkMatchLimitUpdate(this.gR, this.gS);
      }

   }
}
