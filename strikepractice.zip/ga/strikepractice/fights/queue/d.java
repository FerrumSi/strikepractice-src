package ga.strikepractice.fights.queue;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.TuplesKt;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.collections.MapsKt;
import ga.strikepractice.kotlin.collections.SetsKt;
import ga.strikepractice.kotlin.jvm.JvmField;
import ga.strikepractice.kotlin.jvm.JvmStatic;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.Regex;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.party.Party;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.stats.PlayerStats;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.g;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.x;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ga.strikepractice.utils.e(
   fj = {"leave"}
)
@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u0000 %2\u00020\u00012\u00020\u0002:\u0001%B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J \u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0002J\u0010\u0010\u000e\u001a\u00020\r2\u0006\u0010\b\u001a\u00020\tH\u0002J\u0010\u0010\u000f\u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020\u0011H\u0007J3\u0010\u0012\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00180\u001aH\u0016¢\u0006\u0002\u0010\u001bJ\u0010\u0010\u001c\u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020\u001dH\u0007J\u0010\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020\u001fH\u0007J\u0010\u0010 \u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020!H\u0007J\u0018\u0010\"\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J \u0010#\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000b2\u0006\u0010$\u001a\u00020\rR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006&"},
   d2 = {"Lga/strikepractice/fights/queue/QueueManager;", "Lorg/bukkit/event/Listener;", "Lorg/bukkit/command/CommandExecutor;", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "addToQueue", "", "p", "Lorg/bukkit/entity/Player;", "kit", "Lga/strikepractice/battlekit/BattleKit;", "premium", "", "canJoin", "onClose", "e", "Lorg/bukkit/event/inventory/InventoryCloseEvent;", "onCommand", "sender", "Lorg/bukkit/command/CommandSender;", "cmd", "Lorg/bukkit/command/Command;", "label", "", "args", "", "(Lorg/bukkit/command/CommandSender;Lorg/bukkit/command/Command;Ljava/lang/String;[Ljava/lang/String;)Z", "onDeath", "Lorg/bukkit/event/entity/PlayerDeathEvent;", "onInventoryClick", "Lorg/bukkit/event/inventory/InventoryClickEvent;", "onQuit", "Lorg/bukkit/event/player/PlayerQuitEvent;", "selectQueueKit", "tryToJoin", "premiumQueue", "Companion", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nQueueManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 QueueManager.kt\nga/strikepractice/fights/queue/QueueManager\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n*L\n1#1,556:1\n1747#2,3:557\n288#2,2:568\n81#3,4:560\n81#3,4:564\n*S KotlinDebug\n*F\n+ 1 QueueManager.kt\nga/strikepractice/fights/queue/QueueManager\n*L\n71#1:557,3\n136#1:568,2\n87#1:560,4\n95#1:564,4\n*E\n"})
public final class d implements CommandExecutor, Listener {
   @NotNull
   public static final d.a gT = new d.a((DefaultConstructorMarker)null);
   @NotNull
   private final StrikePractice gU;
   @NotNull
   public static final String gV = "StrikePracticeEloFightsCooldown";
   @NotNull
   public static final String gW = "StrikePracticeQueueFightsCooldown";
   @NotNull
   public static final String gX = "StrikePracticeWaitingQueue";
   @JvmField
   @NotNull
   public static Map<BattleKit, String> gE = (Map)(new ConcurrentHashMap());
   @JvmField
   @NotNull
   public static Map<BattleKit, Collection<DuelQueueRunnable>> gF = (Map)(new ConcurrentHashMap());
   @NotNull
   private static final Map<UUID, Inventory> gY = (Map)(new ConcurrentHashMap());
   @NotNull
   private static String gK;
   @NotNull
   private static String gJ;
   @NotNull
   private static String gZ;
   @NotNull
   private static final InventoryHolder ha;
   @NotNull
   private static final InventoryHolder hb;
   @NotNull
   private static final InventoryHolder hc;
   private static final int hd;

   public d(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.gU = var1;
   }

   public boolean onCommand(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      Intrinsics.checkNotNullParameter(var1, "sender");
      Intrinsics.checkNotNullParameter(var2, "cmd");
      Intrinsics.checkNotNullParameter(var3, "label");
      Intrinsics.checkNotNullParameter(var4, "args");
      if (var1 instanceof Player) {
         if (var4.length != 0) {
            String var5 = var4[0];
            if (StringsKt.equals(var5, "leave", true)) {
               this.gU.a((Player)var1, "left-queue");
               gT.c((Player)var1, false);
               if (!AbstractFight.isInFight((Player)var1)) {
                  StrikePractice.getInstance().L.bh((Player)var1);
               }

               return true;
            }

            BattleKit var6 = StrikePractice.getAPI().getKit(var5);
            BattleKitType[] var8 = new BattleKitType[]{BattleKitType.ANY, BattleKitType.QUEUE, BattleKitType.PREMIUM_QUEUE};
            Set var7 = SetsKt.setOf(var8);
            if (var6 != null) {
               Set var10000 = var6.getKitTypes();
               Intrinsics.checkNotNullExpressionValue(var10000, "kit.kitTypes");
               Iterable var14 = (Iterable)var10000;
               boolean var9 = false;
               boolean var15;
               if (var14 instanceof Collection && ((Collection)var14).isEmpty()) {
                  var15 = false;
               } else {
                  Iterator var10 = var14.iterator();

                  while(true) {
                     if (!var10.hasNext()) {
                        var15 = false;
                        break;
                     }

                     Object var11 = var10.next();
                     BattleKitType var12 = (BattleKitType)var11;
                     boolean var13 = false;
                     if (var7.contains(var12)) {
                        var15 = true;
                        break;
                     }
                  }
               }

               if (var15) {
                  if (this.I((Player)var1)) {
                     this.a((Player)var1, var6, var6.getKitTypes().contains(BattleKitType.PREMIUM_QUEUE));
                  }

                  return true;
               }
            }
         }

         this.e((Player)var1, var3);
      }

      return true;
   }

   @EventHandler
   public final void b(@NotNull PlayerQuitEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      d.a var10000 = gT;
      Player var10001 = var1.getPlayer();
      Intrinsics.checkNotNullExpressionValue(var10001, "e.player");
      var10000.c(var10001, true);
      if (gY.remove(var1.getPlayer().getUniqueId()) != null) {
         B.a var2 = B.vj;
         boolean var3 = false;
         if (var2.fV()) {
            Logger var8 = Bukkit.getLogger();
            StringBuilder var6 = (new StringBuilder()).append("[SP DEBUG] ");
            Logger var5 = var8;
            boolean var4 = false;
            String var7 = var1.getPlayer().getName() + " removed from queue view (quit)";
            var5.info(var6.append(var7).toString());
         }
      }

   }

   @EventHandler
   public final void a(@NotNull InventoryCloseEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      UUID var2 = var1.getPlayer().getUniqueId();
      if (gY.remove(var2) != null) {
         B.a var3 = B.vj;
         boolean var4 = false;
         if (var3.fV()) {
            Logger var10000 = Bukkit.getLogger();
            StringBuilder var7 = (new StringBuilder()).append("[SP DEBUG] ");
            Logger var6 = var10000;
            boolean var5 = false;
            String var8 = var1.getPlayer().getName() + " removed from queue view (close)";
            var6.info(var7.append(var8).toString());
         }
      }

   }

   @EventHandler
   public final void b(@NotNull PlayerDeathEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      d.a var10000 = gT;
      Player var10001 = var1.getEntity();
      Intrinsics.checkNotNullExpressionValue(var10001, "e.entity");
      var10000.c(var10001, true);
   }

   @EventHandler
   public final void d(@NotNull InventoryClickEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      ItemStack var2 = var1.getCurrentItem();
      if (var2 != null && var1.getInventory() != null && var1.getView().getTitle() != null) {
         boolean var3 = Intrinsics.areEqual((Object)var1.getInventory().getHolder(), (Object)hc);
         boolean var4 = var3 || Intrinsics.areEqual((Object)var1.getInventory().getHolder(), (Object)hb);
         if (var4 || Intrinsics.areEqual((Object)var1.getInventory().getHolder(), (Object)ha)) {
            var1.setCancelled(true);
            if (var1.getWhoClicked() instanceof Player && r.h(var1.getCurrentItem())) {
               HumanEntity var10000 = var1.getWhoClicked();
               Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.bukkit.entity.Player");
               Player var5 = (Player)var10000;
               if (!Intrinsics.areEqual((Object)var1.getClickedInventory(), (Object)var5.getInventory())) {
                  boolean var6 = this.gU.getConfig().getBoolean("leave-queue-item");
                  if (var6 && var2.getType() == Material.WOOL && var2.getItemMeta().hasDisplayName() && var1.getSlot() == var1.getInventory().getSize() - 1) {
                     this.gU.a(var5, "left-queue");
                     gT.c(var5, false);
                     StrikePractice.getInstance().L.bh(var5);
                  } else if (var2.getItemMeta().hasDisplayName() && var1.getSlot() == var1.getInventory().getSize() - (var6 ? 2 : 1) && this.gU.getConfig().getBoolean("kit-editor-in-kit-selector")) {
                     this.gU.Y().az(var5);
                  } else {
                     List var14 = BattleKit.getKits(var2);
                     Intrinsics.checkNotNullExpressionValue(var14, "getKits(item)");
                     Iterable var8 = (Iterable)var14;
                     boolean var9 = false;
                     Iterator var10 = var8.iterator();

                     Object var15;
                     while(true) {
                        if (var10.hasNext()) {
                           Object var11 = var10.next();
                           BattleKit var12 = (BattleKit)var11;
                           boolean var13 = false;
                           if (var4 != var12.isElo()) {
                              continue;
                           }

                           var15 = var11;
                           break;
                        }

                        var15 = null;
                        break;
                     }

                     BattleKit var7 = (BattleKit)var15;
                     if (var7 == null) {
                        var5.sendMessage(g.P("&cInvalid kit!"));
                     } else if ((var1.getClick() == ClickType.SHIFT_LEFT || var1.getClick() == ClickType.SHIFT_RIGHT) && this.gU.getConfig().getBoolean("preview.shift-click-preview")) {
                        ga.strikepractice.m.a.a(var5, var7, this.gU);
                     } else if (this.I(var5)) {
                        this.a(var5, var7, var3);
                     }
                  }
               }
            }
         }
      }
   }

   public final void a(@NotNull Player var1, @Nullable BattleKit var2, boolean var3) {
      Intrinsics.checkNotNullParameter(var1, "p");
      int var4 = this.gU.ao().dH().ai(var1);
      if (var2 == null) {
         var1.sendMessage(ChatColor.RED.toString() + "Error: invalid kit... try another kit and contact admins!");
      } else if (!DefaultPlayerStats.getStats().containsKey(var1.getUniqueId())) {
         var1.sendMessage(ChatColor.RED.toString() + "Please try again!");
      } else {
         DefaultPlayerStats var10000 = DefaultPlayerStats.getStats(var1.getUniqueId());
         Intrinsics.checkNotNullExpressionValue(var10000, "getStats(p.uniqueId)");
         PlayerStats var5 = (PlayerStats)var10000;
         if (var2.isElo() && !var3 && this.gU.getConfig().getBoolean("limit-rankeds") && var5.getRankedsLeft() <= 0) {
            this.gU.a(var1, "no-rankeds-left");
         } else if (!var2.isElo() && !var3 && this.gU.getConfig().getBoolean("limit-unrankeds") && var5.getUnrankedsLeft() <= 0) {
            this.gU.a(var1, "no-unrankeds-left");
         } else if (var3 && var5.getPremiumMatches() <= 0) {
            this.gU.a(var1, "no-premium-matches-left");
         } else if (var2.isElo() && var4 > this.gU.getConfig().getInt("max-ranked-queue-ping")) {
            this.gU.a(var1, "queue-ping-limit", MapsKt.mapOf(TuplesKt.to("<ping>", var4)));
         } else {
            MetadataValue var6;
            int var7;
            if (var1.hasMetadata("StrikePracticeQueueFightsCooldown") && !ga.strikepractice.k.b.a((CommandSender)var1, ga.strikepractice.k.a.pA) && this.gU.getConfig().getBoolean("queue-cooldown")) {
               var6 = this.gU.a((Metadatable)var1, "StrikePracticeQueueFightsCooldown");
               if ((var6 != null ? var6.value() : null) != null) {
                  var7 = this.gU.getConfig().getInt("queue-cooldown-time") * 1000;
                  if (var6.asLong() + (long)var7 > System.currentTimeMillis()) {
                     this.gU.a(var1, "queue-cooldown", MapsKt.mapOf(TuplesKt.to("<time>", (var6.asLong() + (long)var7 - System.currentTimeMillis()) / (long)1000)));
                     x.uZ.a((HumanEntity)var1);
                     return;
                  }
               }
            }

            if (var2.isElo() && var1.hasMetadata("StrikePracticeQueueFightsCooldown") && !ga.strikepractice.k.b.a((CommandSender)var1, ga.strikepractice.k.a.pA) && this.gU.getConfig().getBoolean("elo-queue-cooldown")) {
               var6 = this.gU.a((Metadatable)var1, "StrikePracticeQueueFightsCooldown");
               if ((var6 != null ? var6.value() : null) != null) {
                  var7 = this.gU.getConfig().getInt("elo-queue-cooldown-time") * 1000;
                  if (var6.asLong() + (long)var7 > System.currentTimeMillis()) {
                     this.gU.a(var1, "elo-queue-cooldown", MapsKt.mapOf(TuplesKt.to("<time>", (var6.asLong() + (long)var7 - System.currentTimeMillis()) / (long)1000)));
                     x.uZ.a((HumanEntity)var1);
                     return;
                  }
               }
            }

            gT.c(var1, false);
            if (var2.isElo()) {
               int var10 = DefaultPlayerStats.getStats(var1.getUniqueId()).getKills();
               var7 = this.gU.getConfig().getInt("ranked.kills-required");
               boolean var8 = ga.strikepractice.k.b.a((CommandSender)var1, ga.strikepractice.k.a.qb);
               if (var10 < var7 && !var8) {
                  StrikePractice var11 = this.gU;
                  Pair[] var9 = new Pair[]{TuplesKt.to("<kills>", var10), TuplesKt.to("<needed>", var7 - var10), TuplesKt.to("<required>", var7)};
                  var11.a(var1, "ranked-kills-required", MapsKt.mapOf(var9));
                  return;
               }

               if (ga.strikepractice.k.b.a((CommandSender)var1, ga.strikepractice.k.a.pz) && var10 < var7) {
                  var1.sendMessage("§7[SP] Bypassing 'ranked.kills-required' with " + ga.strikepractice.k.a.qb);
               }
            }

            this.b(var1, var2, var3);
         }
      }
   }

   private final boolean I(Player var1) {
      if (!AbstractFight.isInFight(var1) && !PvPEvent.isInEvent(var1)) {
         if (Party.getParty(var1) != null) {
            this.gU.a(var1, "can-not-do-while-in-party");
            return false;
         } else {
            return true;
         }
      } else {
         this.gU.a(var1, "you-can-not-duel-now");
         return false;
      }
   }

   private final void b(Player var1, BattleKit var2, boolean var3) {
      this.gU.a(var1, "waiting-for-duel", MapsKt.mapOf(TuplesKt.to("<kit>", var2.getFancyName())));
      if (var2.isElo()) {
         DuelQueueRunnable var4 = new DuelQueueRunnable(this.gU, var1, var2, var3);
         Object var10000 = gF.computeIfAbsent(var2, d::d);
         Intrinsics.checkNotNullExpressionValue(var10000, "ranked.computeIfAbsent(k…HashMap(4))\n            }");
         Collection var5 = (Collection)var10000;
         var5.add(var4);
         x.uZ.a((HumanEntity)var1);
         var1.setMetadata("StrikePracticeWaitingQueue", (MetadataValue)(new FixedMetadataValue((Plugin)this.gU, System.currentTimeMillis())));
         this.gU.L.bh(var1);
         gT.bC();
      } else {
         String var8 = (String)gE.get(var2);
         if (var8 != null && Bukkit.getPlayer(var8) != null) {
            gE.remove(var2);
            Player var10 = Bukkit.getPlayer(var8);
            var10.removeMetadata("StrikePracticeWaitingQueue", (Plugin)this.gU);
            this.gU.L.bh(var10);
            var1.removeMetadata("StrikePracticeWaitingQueue", (Plugin)this.gU);
            this.gU.L.bh(var1);
            gT.bC();
            x.uZ.a((HumanEntity)var1);
            BattleKit var12 = ga.strikepractice.battlekit.e.a(var2, d::f);
            Duel var7 = new Duel(this.gU, var8, var1.getName(), var12);
            if (var7.canStart()) {
               var7.setQueue(true);
               var7.start();
            } else {
               ga.strikepractice.arena.c.e(var1);
               ga.strikepractice.arena.c.e(var10);
            }
         } else {
            x.uZ.a((HumanEntity)var1);
            Map var9 = gE;
            String var11 = var1.getName();
            Intrinsics.checkNotNullExpressionValue(var11, "p.name");
            String var6 = var11;
            var9.put(var2, var6);
            gT.bC();
            var1.setMetadata("StrikePracticeWaitingQueue", (MetadataValue)(new FixedMetadataValue((Plugin)this.gU, System.currentTimeMillis())));
            this.gU.L.bh(var1);
         }
      }

      ga.strikepractice.o.g.i(var1.getUniqueId());
   }

   private final void e(Player var1, String var2) {
      Inventory var3 = null;
      if (StringsKt.equals(var2, "ranked", true) && this.gU.getConfig().getBoolean("separate-queues")) {
         var3 = gT.bF();
      } else {
         String var10000 = var2.toLowerCase();
         Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase()");
         if (StringsKt.contains$default((CharSequence)var10000, (CharSequence)"premium", false, 2, (Object)null)) {
            if (ga.strikepractice.k.b.a((CommandSender)var1, ga.strikepractice.k.a.pY)) {
               var3 = gT.bG();
            } else {
               StringBuilder var10001 = (new StringBuilder()).append(this.gU.X());
               String var10002 = this.gU.getConfig().getString("premium-permission-message");
               Intrinsics.checkNotNullExpressionValue(var10002, "plugin.config.getString(…mium-permission-message\")");
               var1.sendMessage(var10001.append(g.P(var10002)).toString());
            }
         } else {
            var3 = gT.bE();
         }
      }

      if (var3 != null) {
         Map var4 = gY;
         UUID var5 = var1.getUniqueId();
         Intrinsics.checkNotNullExpressionValue(var5, "p.uniqueId");
         var4.put(var5, var3);
         var1.openInventory(var3);
         gT.bC();
      }

   }

   private static final Collection d(Function1 var0, Object var1) {
      Intrinsics.checkNotNullParameter(var0, "$tmp0");
      return (Collection)var0.invoke(var1);
   }

   private static final boolean f(BattleKit var0) {
      d.a var10000 = gT;
      Intrinsics.checkNotNullExpressionValue(var0, "it");
      return var10000.h(var0) && !var0.isElo() && !var0.getKitTypes().contains(BattleKitType.PREMIUM_QUEUE);
   }

   private static final Inventory bp() {
      return null;
   }

   private static final Inventory bq() {
      return null;
   }

   private static final Inventory br() {
      return null;
   }

   @JvmStatic
   public static final void b(@NotNull Player var0, boolean var1) {
      gT.c(var0, var1);
   }

   @JvmStatic
   public static final void bs() {
      gT.bC();
   }

   @JvmStatic
   public static final boolean g(@NotNull BattleKit var0) {
      return gT.h(var0);
   }

   static {
      String var10000 = StrikePractice.getInstance().getConfig().getString("queue-inventory-title");
      Intrinsics.checkNotNullExpressionValue(var10000, "getInstance().config.get…(\"queue-inventory-title\")");
      gK = g.P(var10000);
      var10000 = StrikePractice.getInstance().getConfig().getString("ranked-queue-inventory-title");
      Intrinsics.checkNotNullExpressionValue(var10000, "getInstance().config.get…d-queue-inventory-title\")");
      gJ = g.P(var10000);
      var10000 = StrikePractice.getInstance().getConfig().getString("premium-queue-inventory-title");
      Intrinsics.checkNotNullExpressionValue(var10000, "getInstance().config.get…m-queue-inventory-title\")");
      gZ = g.P(var10000);
      ha = d::bp;
      hb = d::bq;
      hc = d::br;
      d.a var0 = gT;
      boolean var1 = false;
      StrikePractice var2 = StrikePractice.getInstance();
      int var3 = 0;
      if (var2.getConfig().getBoolean("kit-editor-in-kit-selector")) {
         ++var3;
      }

      if (var2.getConfig().getBoolean("leave-queue-item")) {
         ++var3;
      }

      hd = var3;
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u001f\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0019\u001a\u00020\u001aH\u0002J \u0010\u001b\u001a\u00020\f2\u0006\u0010\u001c\u001a\u00020\u00042\u0006\u0010\u001d\u001a\u00020\b2\u0006\u0010\u001e\u001a\u00020\u000eH\u0002J\b\u0010\u001f\u001a\u00020\fH\u0002J\b\u0010 \u001a\u00020\fH\u0002J\b\u0010!\u001a\u00020\fH\u0002J\u0010\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020\u0013H\u0007J\u0018\u0010%\u001a\u00020\u001a2\u0006\u0010&\u001a\u00020'2\u0006\u0010(\u001a\u00020#H\u0007J\u0018\u0010)\u001a\u00020\b2\u0006\u0010*\u001a\u00020\u00132\u0006\u0010+\u001a\u00020#H\u0002J\b\u0010,\u001a\u00020\u001aH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\f0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R$\u0010\u0012\u001a\u0014\u0012\u0004\u0012\u00020\u0013\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00150\u00140\n8\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u00040\n8\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000¨\u0006-"},
      d2 = {"Lga/strikepractice/fights/queue/QueueManager$Companion;", "", "()V", "ELO_COOLDOWN", "", "QUEUE_COOLDOWN", "WAITING_QUEUE", "extraSlots", "", "inventoryViews", "", "Ljava/util/UUID;", "Lorg/bukkit/inventory/Inventory;", "mainHolder", "Lorg/bukkit/inventory/InventoryHolder;", "mainQueueTitle", "premiumHolder", "premiumQueueTitle", "ranked", "Lga/strikepractice/battlekit/BattleKit;", "", "Lga/strikepractice/fights/queue/DuelQueueRunnable;", "rankedHolder", "rankedQueueTitle", "unranked", "_updateQueueViews", "", "createInv", "title", "size", "holder", "createMainQueue", "createPremiumQueue", "createRankedQueue", "isAllowedKit", "", "k", "leaveQueue", "p", "Lorg/bukkit/entity/Player;", "close", "playersInRankedQueue", "kit", "premium", "updateQueueViews", "strikepractice-core"}
   )
   @SourceDebugExtension({"SMAP\nQueueManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 QueueManager.kt\nga/strikepractice/fights/queue/QueueManager$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 4 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,556:1\n766#2:557\n857#2,2:558\n1855#2,2:560\n1855#2:562\n1549#2:571\n1620#2,3:572\n766#2:575\n857#2,2:576\n1856#2:584\n1774#2,4:587\n1549#2:591\n1620#2,3:592\n766#2:595\n857#2,2:596\n37#3,2:563\n37#3,2:565\n37#3,2:567\n37#3,2:569\n215#4,2:578\n215#4,2:580\n215#4,2:582\n215#4,2:585\n*S KotlinDebug\n*F\n+ 1 QueueManager.kt\nga/strikepractice/fights/queue/QueueManager$Companion\n*L\n394#1:557\n394#1:558,2\n398#1:560,2\n409#1:562\n439#1:571\n439#1:572,3\n440#1:575\n440#1:576,2\n409#1:584\n489#1:587,4\n448#1:591\n448#1:592,3\n449#1:595\n449#1:596,2\n418#1:563,2\n419#1:565,2\n428#1:567,2\n429#1:569,2\n457#1:578,2\n467#1:580,2\n474#1:582,2\n483#1:585,2\n*E\n"})
   public static final class a {
      private a() {
      }

      @JvmStatic
      public final void c(@NotNull final Player var1, boolean var2) {
         Intrinsics.checkNotNullParameter(var1, "p");
         boolean var3 = d.gE.entrySet().removeIf(d.a::e);
         DuelQueueRunnable var4 = DuelQueueRunnable.getRanked(var1);
         if (var4 != null) {
            var3 = true;
            Collection var5 = (Collection)d.gF.get(var4.getKit());
            if (var5 != null) {
               var5.remove(var4);
            }
         }

         if (var2) {
            x.uZ.a((HumanEntity)var1);
         }

         if (var3) {
            var1.removeMetadata("StrikePracticeWaitingQueue", (Plugin)StrikePractice.getInstance());
            var1.removeMetadata("StrikePracticeRankedQueue", (Plugin)StrikePractice.getInstance());
            ga.strikepractice.o.g.i(var1.getUniqueId());
            this.bC();
         }

      }

      @JvmStatic
      public final void bC() {
         if (StrikePractice.getInstance().getConfig().getBoolean("no-async-inventories")) {
            this.bD();
         } else {
            C.b(d.a::bH, 1L);
         }

      }

      @JvmStatic
      public final boolean h(@NotNull BattleKit var1) {
         Intrinsics.checkNotNullParameter(var1, "k");
         return (var1.getKitTypes().contains(BattleKitType.ANY) || var1.getKitTypes().contains(BattleKitType.QUEUE) || var1.getKitTypes().contains(BattleKitType.PREMIUM_QUEUE)) && var1.getIcon() != null;
      }

      private final void bD() {
         StrikePractice var1 = StrikePractice.getInstance();
         String var10000 = var1.getConfig().getString("in-queue");
         Intrinsics.checkNotNullExpressionValue(var10000, "plugin.config.getString(\"in-queue\")");
         String var2 = g.P(var10000);
         var10000 = var1.getConfig().getString("in-match");
         Intrinsics.checkNotNullExpressionValue(var10000, "plugin.config.getString(\"in-match\")");
         String var3 = g.P(var10000);
         boolean var4 = var1.getConfig().getBoolean("change-icon-amount");
         boolean var5 = var1.getConfig().getBoolean("separate-queues");
         List var88 = var1.kits;
         Intrinsics.checkNotNullExpressionValue(var88, "plugin.kits");
         Iterable var7 = (Iterable)var88;
         boolean var8 = false;
         Collection var10 = (Collection)(new ArrayList());
         boolean var11 = false;
         Iterator var12 = var7.iterator();

         d.a var89;
         while(var12.hasNext()) {
            Object var13 = var12.next();
            BattleKit var14 = (BattleKit)var13;
            boolean var15 = false;
            var89 = d.gT;
            Intrinsics.checkNotNullExpressionValue(var14, "it");
            if (var89.h(var14)) {
               var10.add(var13);
            }
         }

         Set var6 = CollectionsKt.toSet((Iterable)((List)var10));
         Map var34 = (Map)(new HashMap(var6.size()));
         Map var35 = (Map)(new HashMap(var6.size()));
         Collection var90 = Bukkit.getOnlinePlayers();
         Intrinsics.checkNotNullExpressionValue(var90, "getOnlinePlayers()");
         Iterable var9 = (Iterable)var90;
         boolean var37 = false;
         Iterator var39 = var9.iterator();

         BattleKit var16;
         while(var39.hasNext()) {
            Object var41 = var39.next();
            Player var44 = (Player)var41;
            boolean var46 = false;
            Fight var48 = AbstractFight.getCurrentFight(var44);
            if (var48 instanceof Duel && ((Duel)var48).isQueue()) {
               var16 = ((Duel)var48).getKit();
               Integer var19;
               Integer var91;
               if (((Duel)var48).isPremiumQueue()) {
                  Intrinsics.checkNotNullExpressionValue(var16, "kit");
                  var91 = (Integer)var35.get(var16);
                  var19 = (var91 != null ? var91 : 0) + 1;
                  var35.put(var16, var19);
               } else {
                  Intrinsics.checkNotNullExpressionValue(var16, "kit");
                  var91 = (Integer)var34.get(var16);
                  var19 = (var91 != null ? var91 : 0) + 1;
                  var34.put(var16, var19);
               }
            }
         }

         int var36 = 0;
         int var38 = 0;
         int var40 = 0;
         Iterable var42 = (Iterable)var6;
         boolean var45 = false;
         Iterator var47 = var42.iterator();

         boolean var17;
         while(var47.hasNext()) {
            Object var49 = var47.next();
            var16 = (BattleKit)var49;
            var17 = false;
            ItemStack var92 = var16.getIcon().clone();
            Intrinsics.checkNotNullExpressionValue(var92, "kit.icon.clone()");
            ItemStack var18 = var92;
            ItemMeta var51 = var18.getItemMeta();
            List var20 = (List)(new ArrayList(4));
            int var93;
            if (var16.isElo()) {
               var89 = d.gT;
               Intrinsics.checkNotNullExpressionValue(var16, "kit");
               var93 = var89.b(var16, false);
            } else {
               String var21 = (String)d.gE.get(var16);
               var93 = var21 != null && Bukkit.getPlayer(var21) != null ? 1 : 0;
            }

            int var22 = var93;
            if (var4) {
               var18.setAmount(var22 + 1);
            }

            CharSequence var23 = (CharSequence)var2;
            Regex var24 = new Regex("\\\\n");
            byte var25 = 0;
            Collection var54 = (Collection)var24.split(var23, var25);
            boolean var56 = false;
            String[] var52 = (String[])var54.toArray(new String[0]);
            int var55 = 0;

            String var10001;
            String var10003;
            int var58;
            int var72;
            for(var58 = var52.length; var55 < var58; ++var55) {
               String var62 = var52[var55];
               CharSequence var26 = (CharSequence)var62;
               Regex var27 = new Regex(".split");
               byte var28 = 0;
               Collection var67 = (Collection)var27.split(var26, var28);
               boolean var70 = false;
               String[] var29 = (String[])var67.toArray(new String[0]);
               int var68 = 0;

               for(var72 = var29.length; var68 < var72; ++var68) {
                  String var76 = var29[var68];
                  var10001 = StringsKt.replace$default(var76, "<players>", String.valueOf(var22), false, 4, (Object)null);
                  var10003 = var16.getFancyName();
                  Intrinsics.checkNotNullExpressionValue(var10003, "kit.fancyName");
                  var20.add(StringsKt.replace$default(var10001, "<kit>", var10003, false, 4, (Object)null));
               }
            }

            Intrinsics.checkNotNullExpressionValue(var16, "kit");
            int var53 = ((Number)var34.getOrDefault(var16, 0)).intValue();
            CharSequence var60 = (CharSequence)var3;
            Regex var64 = new Regex("\\\\n");
            byte var80 = 0;
            Collection var61 = (Collection)var64.split(var60, var80);
            boolean var65 = false;
            String[] var57 = (String[])var61.toArray(new String[0]);
            var58 = 0;

            boolean var79;
            String var86;
            for(int var66 = var57.length; var58 < var66; ++var58) {
               String var83 = var57[var58];
               CharSequence var74 = (CharSequence)var83;
               Regex var78 = new Regex(".split");
               byte var30 = 0;
               Collection var75 = (Collection)var78.split(var74, var30);
               var79 = false;
               String[] var71 = (String[])var75.toArray(new String[0]);
               var72 = 0;

               for(int var82 = var71.length; var72 < var82; ++var72) {
                  var86 = var71[var72];
                  var10001 = StringsKt.replace$default(var86, "<players>", String.valueOf(var53), false, 4, (Object)null);
                  var10003 = var16.getFancyName();
                  Intrinsics.checkNotNullExpressionValue(var10003, "kit.fancyName");
                  var10001 = StringsKt.replace$default(var10001, "<kit>", var10003, false, 4, (Object)null);
                  var10003 = var16.getName();
                  Intrinsics.checkNotNullExpressionValue(var10003, "kit.name");
                  var20.add(StringsKt.replace$default(var10001, "<raw_kit>", var10003, false, 4, (Object)null));
               }
            }

            Iterable var59 = (Iterable)var20;
            var56 = false;
            Collection var85 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var59, 10)));
            boolean var73 = false;
            Iterator var81 = var59.iterator();

            boolean var33;
            Object var84;
            while(var81.hasNext()) {
               var84 = var81.next();
               var86 = (String)var84;
               var33 = false;
               var85.add(var1.ah().a((Player)null, (String)var86, (String)""));
            }

            var59 = (Iterable)((List)var85);
            var56 = false;
            var85 = (Collection)(new ArrayList());
            var73 = false;
            var81 = var59.iterator();

            while(var81.hasNext()) {
               var84 = var81.next();
               var86 = (String)var84;
               var33 = false;
               Intrinsics.checkNotNullExpressionValue(var86, "it");
               if (!StringsKt.contains$default((CharSequence)var86, (CharSequence)"[display=false]", false, 2, (Object)null)) {
                  var85.add(var84);
               }
            }

            var51.setLore((List)var85);
            var18.setItemMeta(var51);
            Set var63 = var16.getKitTypes();
            Map var69;
            Entry var77;
            Iterator var87;
            if (var16.isElo() && var63.contains(BattleKitType.PREMIUM_QUEUE)) {
               var18.setAmount(d.gT.b(var16, true) + 1);
               var69 = d.gY;
               var65 = false;
               var87 = var69.entrySet().iterator();

               while(var87.hasNext()) {
                  var77 = (Entry)var87.next();
                  var79 = false;
                  if (Intrinsics.areEqual((Object)((Inventory)var77.getValue()).getHolder(), (Object)d.hc)) {
                     ((Inventory)var77.getValue()).setItem(var38, a(var18, var20, var1, (UUID)var77.getKey()));
                  }
               }

               ++var38;
            }

            if (var63.contains(BattleKitType.QUEUE) || var63.contains(BattleKitType.ANY)) {
               if (var5 && var16.isElo()) {
                  var69 = d.gY;
                  var65 = false;
                  var87 = var69.entrySet().iterator();

                  while(var87.hasNext()) {
                     var77 = (Entry)var87.next();
                     var79 = false;
                     if (Intrinsics.areEqual((Object)((Inventory)var77.getValue()).getHolder(), (Object)d.hb)) {
                        ((Inventory)var77.getValue()).setItem(var36, a(var18, var20, var1, (UUID)var77.getKey()));
                     }
                  }

                  ++var36;
               } else {
                  var69 = d.gY;
                  var65 = false;
                  var87 = var69.entrySet().iterator();

                  while(var87.hasNext()) {
                     var77 = (Entry)var87.next();
                     var79 = false;
                     if (Intrinsics.areEqual((Object)((Inventory)var77.getValue()).getHolder(), (Object)d.ha)) {
                        ((Inventory)var77.getValue()).setItem(var40, a(var18, var20, var1, (UUID)var77.getKey()));
                     }
                  }

                  ++var40;
               }
            }
         }

         Map var43 = d.gY;
         var45 = false;
         var47 = var43.entrySet().iterator();

         while(var47.hasNext()) {
            Entry var50 = (Entry)var47.next();
            var17 = false;
            Player var94 = Bukkit.getPlayer((UUID)var50.getKey());
            if (var94 != null) {
               var94.updateInventory();
            }
         }

      }

      private final int b(BattleKit var1, boolean var2) {
         Collection var10000 = (Collection)d.gF.get(var1);
         int var10;
         if (var10000 != null) {
            Iterable var3 = (Iterable)var10000;
            boolean var4 = false;
            if (var3 instanceof Collection && ((Collection)var3).isEmpty()) {
               var10 = 0;
            } else {
               int var5 = 0;
               Iterator var6 = var3.iterator();

               while(var6.hasNext()) {
                  Object var7 = var6.next();
                  DuelQueueRunnable var8 = (DuelQueueRunnable)var7;
                  boolean var9 = false;
                  if (var8.isPremium() == var2) {
                     ++var5;
                     if (var5 < 0) {
                        CollectionsKt.throwCountOverflow();
                     }
                  }
               }

               var10 = var5;
            }
         } else {
            var10 = 0;
         }

         return var10;
      }

      private final Inventory bE() {
         StrikePractice var1 = StrikePractice.getInstance();
         return this.a(d.gK, var1.L.a(false, !var1.getConfig().getBoolean("separate-queues"), BattleKitType.QUEUE, d.hd), d.ha);
      }

      private final Inventory bF() {
         return this.a(d.gJ, StrikePractice.getInstance().L.a(false, true, true, BattleKitType.QUEUE, d.hd), d.hb);
      }

      private final Inventory bG() {
         return this.a(d.gZ, StrikePractice.getInstance().L.a(false, true, true, BattleKitType.PREMIUM_QUEUE, d.hd), d.hc);
      }

      private final Inventory a(String var1, int var2, InventoryHolder var3) {
         StrikePractice var4 = StrikePractice.getInstance();
         int var5 = 0;
         ItemStack var6 = null;
         String var10001;
         if (var4.getConfig().getBoolean("kit-editor-in-kit-selector")) {
            ++var5;
            var6 = new ItemStack(Material.getMaterial(var4.getConfig().getString("kit-selector-editor-material")));
            ItemMeta var7 = var6.getItemMeta();
            var10001 = var4.getConfig().getString("kit-selector-editor-name");
            Intrinsics.checkNotNullExpressionValue(var10001, "plugin.config.getString(…it-selector-editor-name\")");
            var7.setDisplayName(g.P(var10001));
            var6.setItemMeta(var7);
         }

         ItemStack var9 = null;
         if (var4.getConfig().getBoolean("leave-queue-item")) {
            ++var5;
            var9 = new ItemStack(Material.WOOL);
            var9.setDurability((short)14);
            ItemMeta var8 = var9.getItemMeta();
            var10001 = var4.getConfig().getString("quit-item-name");
            Intrinsics.checkNotNullExpressionValue(var10001, "plugin.config.getString(\"quit-item-name\")");
            var8.setDisplayName(g.P(var10001));
            var9.setItemMeta(var8);
         }

         Inventory var10 = Bukkit.createInventory(var3, var2, var1);
         if (var6 != null) {
            if (var9 == null) {
               var10.setItem(var10.getSize() - 1, var6);
            } else {
               var10.setItem(var10.getSize() - 2, var6);
            }
         }

         if (var9 != null) {
            var10.setItem(var10.getSize() - 1, var9);
         }

         this.bC();
         Intrinsics.checkNotNullExpressionValue(var10, "inv");
         return var10;
      }

      private static final boolean e(Function1 var0, Object var1) {
         Intrinsics.checkNotNullParameter(var0, "$tmp0");
         return (Boolean)var0.invoke(var1);
      }

      private static final void bH() {
         d.gT.bD();
      }

      private static final ItemStack a(ItemStack var0, List<String> var1, StrikePractice var2, UUID var3) {
         ItemStack var4 = var0.clone();
         boolean var6 = false;
         Player var7 = Bukkit.getPlayer(var3);
         if (var7 != null) {
            ItemMeta var8 = var4.getItemMeta();
            boolean var11 = false;
            Iterable var12 = (Iterable)var1;
            boolean var14 = false;
            Collection var16 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var12, 10)));
            boolean var17 = false;
            Iterator var18 = var12.iterator();

            Object var19;
            String var20;
            boolean var22;
            while(var18.hasNext()) {
               var19 = var18.next();
               var20 = (String)var19;
               var22 = false;
               var16.add(var2.ah().a(var7, var20, "", false));
            }

            var12 = (Iterable)((List)var16);
            var14 = false;
            var16 = (Collection)(new ArrayList());
            var17 = false;
            var18 = var12.iterator();

            while(var18.hasNext()) {
               var19 = var18.next();
               var20 = (String)var19;
               var22 = false;
               Intrinsics.checkNotNullExpressionValue(var20, "str");
               if (!StringsKt.contains$default((CharSequence)var20, (CharSequence)"[display=false]", false, 2, (Object)null)) {
                  var16.add(var19);
               }
            }

            var8.setLore((List)var16);
            var4.setItemMeta(var8);
         }

         Intrinsics.checkNotNullExpressionValue(var4, "icon.clone().also {\n    …      }\n                }");
         return var4;
      }

      // $FF: synthetic method
      public a(DefaultConstructorMarker var1) {
         this();
      }
   }
}
