package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

@APIClass
public class SimpleFight extends AbstractFight {
   public void start() {
   }

   public boolean allowSpectating() {
      return false;
   }

   public boolean hasEnded() {
      return this.ended != 0L;
   }

   public boolean canStart() {
      return true;
   }

   public void handleDeath(Player var1) {
      AbstractFight.setCurrentFight(var1, (Fight)null);
   }

   public void forceEnd(String var1) {
      Iterator var2 = Bukkit.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         Player var3 = (Player)var2.next();
         Fight var4 = AbstractFight.getCurrentFight(var3);
         if (var4 != null && var4.equals(this)) {
            if (var1 != null) {
               var3.sendMessage(var1);
            }

            AbstractFight.setCurrentFight(var3, (Fight)null);
            StrikePractice.getInstance().clear(var3, true, true);
         }
      }

   }

   public List<String> getOpponents(Player var1) {
      return Collections.emptyList();
   }

   public List<String> getTeammates(Player var1) {
      return Collections.emptyList();
   }
}
