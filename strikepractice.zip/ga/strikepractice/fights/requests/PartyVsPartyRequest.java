package ga.strikepractice.fights.requests;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.party.Party;

@APIClass
public class PartyVsPartyRequest implements FightRequest {
   private final long startTime = System.currentTimeMillis();
   private static final int seconds = 30;
   private final Party dueler;
   private final Party dueled;
   private final PartyVsParty fight;

   public PartyVsPartyRequest(Party var1, Party var2, PartyVsParty var3) {
      this.dueler = var1;
      this.dueled = var2;
      this.fight = var3;
   }

   public boolean hasExpired() {
      return this.startTime / 1000L + 30L < System.currentTimeMillis() / 1000L;
   }

   public Fight getFight() {
      return this.fight;
   }

   public Party getDueled() {
      return this.dueled;
   }

   public Party getDueler() {
      return this.dueler;
   }
}
