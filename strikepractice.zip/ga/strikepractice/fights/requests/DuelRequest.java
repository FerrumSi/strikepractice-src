package ga.strikepractice.fights.requests;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.duel.Duel;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

@APIClass
public class DuelRequest implements FightRequest {
   private final long startTime = System.currentTimeMillis();
   private static final int seconds = 30;
   private final String dueler;
   private final String dueled;
   private final Duel duel;

   public DuelRequest(Player var1, Player var2, Duel var3) {
      this.dueler = var1.getName();
      this.dueled = var2.getName();
      this.duel = var3;
   }

   public boolean hasExpired() {
      return this.startTime / 1000L + 30L < System.currentTimeMillis() / 1000L;
   }

   public Fight getFight() {
      return this.duel;
   }

   public String getDueled() {
      return this.dueled;
   }

   public String getDueler() {
      return this.dueler;
   }

   public Player getPlayerDueled() {
      return Bukkit.getPlayer(this.getDueled());
   }

   public Player getPlayerDueler() {
      return Bukkit.getPlayer(this.getDueler());
   }
}
