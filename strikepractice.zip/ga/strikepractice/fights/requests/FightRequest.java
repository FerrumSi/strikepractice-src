package ga.strikepractice.fights.requests;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.fights.Fight;
import java.util.Collection;
import java.util.HashSet;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;

@APIClass
public interface FightRequest {
   String DUEL_REQUEST = "SPDuelRequest";
   String PARTY_REQUESTS = "SPPartyRequest";

   static void addDuelRequest(Player var0, DuelRequest var1) {
      Collection var2 = getDuelRequestsForPlayer(var0);
      var2.removeIf((var1x) -> {
         return var1x.hasExpired() || var1.getDueler().equals(var1x.getDueler());
      });
      var2.add(var1);
   }

   static Collection<DuelRequest> getDuelRequestsForPlayer(Player var0) {
      MetadataValue var1 = StrikePractice.getInstance().a((Metadatable)var0, (String)"SPDuelRequest");
      if (var1 != null && var1.value() != null && var1.value() instanceof Collection) {
         return (Collection)var1.value();
      } else {
         HashSet var2 = new HashSet(2);
         var0.setMetadata("SPDuelRequest", new FixedMetadataValue(StrikePractice.getInstance(), var2));
         return var2;
      }
   }

   static void addPartyRequest(Player var0, PartyVsPartyRequest var1) {
      Collection var2 = getPartyRequestsForPlayer(var0);
      var2.removeIf((var1x) -> {
         return var1x.hasExpired() || var1x.getDueler() == var1.getDueler();
      });
      var2.add(var1);
   }

   static Collection<PartyVsPartyRequest> getPartyRequestsForPlayer(Player var0) {
      MetadataValue var1 = StrikePractice.getInstance().a((Metadatable)var0, (String)"SPPartyRequest");
      if (var1 != null && var1.value() != null && var1.value() instanceof Collection) {
         return (Collection)var1.value();
      } else {
         HashSet var2 = new HashSet(2);
         var0.setMetadata("SPPartyRequest", new FixedMetadataValue(StrikePractice.getInstance(), var2));
         return var2;
      }
   }

   static void clearAll(Player var0) {
      var0.removeMetadata("SPDuelRequest", StrikePractice.getInstance());
      var0.removeMetadata("SPPartyRequest", StrikePractice.getInstance());
   }

   boolean hasExpired();

   Fight getFight();
}
