package ga.strikepractice.fights.a;

import ga.strikepractice.arena.Arena;

public abstract class a {
   public abstract void c(Arena var1);
}
