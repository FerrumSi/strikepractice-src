package ga.strikepractice.fights.a;

import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import java.util.Iterator;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class c implements Listener {
   @EventHandler
   public void a(InventoryClickEvent var1) {
      if (var1.getInventory() != null && var1.getCurrentItem() != null && var1.getCurrentItem().hasItemMeta() && var1.getCurrentItem().getItemMeta().hasDisplayName() && var1.getWhoClicked() instanceof Player && var1.getInventory().getHolder() != null) {
         if (var1.getInventory().getHolder() instanceof b) {
            var1.setCancelled(true);
            b var2 = (b)var1.getInventory().getHolder();
            ItemStack var3 = var1.getCurrentItem();
            ItemMeta var4 = var3.getItemMeta();
            String var5 = var4.getDisplayName();
            Player var6 = (Player)var1.getWhoClicked();
            BattleKit var7 = var2.getKit();
            Arena var8 = null;
            Iterator var9 = (var2.getKit().isBuild() ? ga.strikepractice.arena.c.a(var6, var7) : ga.strikepractice.arena.c.c(var6, var7)).iterator();

            while(var9.hasNext()) {
               Arena var10 = (Arena)var9.next();
               ItemStack var11 = var10.getIcon();
               String var12 = var11.getItemMeta().getDisplayName();
               if (var12.equals(var5) && var3.getType() == var11.getType() && var3.getDurability() == var11.getDurability()) {
                  var8 = var10;
                  break;
               }
            }

            if (var8 == null) {
               if (var7.isBuild()) {
                  var8 = ga.strikepractice.arena.c.b(var6, var7);
               } else {
                  var8 = ga.strikepractice.arena.c.d(var6, var7);
               }
            }

            var2.bf().accept(var8);
         }

      }
   }
}
