package ga.strikepractice.fights.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class b implements InventoryHolder {
   public static String fh;
   public static ItemStack fi;
   private final Consumer<Arena> fj;
   private BattleKit kit;

   public b(Player var1, BattleKit var2, Consumer<Arena> var3) {
      this.fj = var3;

      try {
         if (fh != null && fi != null && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.qa)) {
            this.kit = var2;
            List var4 = var2.isBuild() ? ga.strikepractice.arena.c.a(var1, var2) : ga.strikepractice.arena.c.c(var1, var2);
            int var5 = StrikePractice.getInstance().L.q(var4.size() + 18);
            Inventory var6 = Bukkit.createInventory(this, var5, fh);
            HashSet var7 = new HashSet(var4.size() / 3 + 5);
            Iterator var8 = var4.iterator();

            while(var8.hasNext()) {
               Arena var9 = (Arena)var8.next();
               ItemStack var10 = var9.getIcon();
               if (var10 == null) {
                  Bukkit.getLogger().warning("Invalid arena icon " + var9.getName());
               } else {
                  var7.add(var10);
               }
            }

            var8 = var7.iterator();

            while(var8.hasNext()) {
               ItemStack var12 = (ItemStack)var8.next();
               var6.addItem(new ItemStack[]{var12});
            }

            var6.setItem(var6.getSize() - 5, fi);
            var1.openInventory(var6);
         } else {
            this.fj.accept((Object)null);
         }
      } catch (Exception var11) {
         var11.printStackTrace();
      }

   }

   public Consumer<Arena> bf() {
      return this.fj;
   }

   public BattleKit getKit() {
      return this.kit;
   }

   public Inventory getInventory() {
      return null;
   }
}
