package ga.strikepractice.fights;

import com.google.gson.annotations.SerializedName;
import ga.strikepractice.api.APIClass;
import java.io.Serializable;

@APIClass
public class FightStatistics implements Serializable {
   @SerializedName("kits")
   private int hits;
   @SerializedName("currentCombo")
   private int currentCombo;
   @SerializedName("longestCombo")
   private int longestCombo;
   @SerializedName("potionsThrown")
   private int potionsThrown;
   @SerializedName("potionsMissed")
   private int potionsMissed;
   @SerializedName("potionIntensities")
   private double potionIntensities;
   private transient long lastHit;

   public FightStatistics() {
   }

   public FightStatistics(int var1, int var2, int var3, int var4, double var5) {
      this.hits = var1;
      this.longestCombo = var2;
      this.potionsThrown = var3;
      this.potionsMissed = var4;
      this.potionIntensities = var5;
   }

   public int getHits() {
      return this.hits;
   }

   public void setHits(int var1) {
      this.hits = var1;
   }

   public int getCurrentCombo() {
      return this.currentCombo;
   }

   public void setCurrentCombo(int var1) {
      this.currentCombo = var1;
      if (var1 > this.longestCombo) {
         this.longestCombo = var1;
      }

   }

   public int getLongestCombo() {
      return this.longestCombo;
   }

   public void setLongestCombo(int var1) {
      this.longestCombo = var1;
   }

   public int getPotionsThrown() {
      return this.potionsThrown;
   }

   public void setPotionsThrown(int var1) {
      this.potionsThrown = var1;
   }

   public int getPotionsMissed() {
      return this.potionsMissed;
   }

   public void setPotionsMissed(int var1) {
      this.potionsMissed = var1;
   }

   public void addIntensity(double var1) {
      this.potionIntensities += var1;
   }

   public long getLastHit() {
      return this.lastHit;
   }

   public void setLastHit(long var1) {
      this.lastHit = var1;
   }

   public int getAccuracy() {
      int var1 = this.potionsThrown;
      return var1 == 0 ? 0 : (int)Math.round(Math.ceil(this.potionIntensities / (double)var1 * 100.0D));
   }
}
