package ga.strikepractice.fights;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.npc.CitizensNPC;
import java.util.Collection;
import org.bukkit.metadata.Metadatable;

@APIClass
public interface BotFight extends Fight {
   CitizensNPC.Difficulty getDifficulty();

   void setDifficulty(CitizensNPC.Difficulty var1);

   void handleBotDeath(Metadatable var1);

   Collection<CitizensNPC> getBots();
}
