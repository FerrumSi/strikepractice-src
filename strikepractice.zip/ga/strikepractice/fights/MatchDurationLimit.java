package ga.strikepractice.fights;

import ga.strikepractice.api.APIClass;

@APIClass
public interface MatchDurationLimit {
   void onFightStart();

   boolean isEndingSoon();
}
