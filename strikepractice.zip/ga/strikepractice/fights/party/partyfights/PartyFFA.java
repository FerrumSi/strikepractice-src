package ga.strikepractice.fights.party.partyfights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.events.PartyFFAEndEvent;
import ga.strikepractice.events.PartyFFAStartEvent;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.t;
import ga.strikepractice.utils.u;
import ga.strikepractice.utils.y;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;

@APIClass
public class PartyFFA extends AbstractFight implements PartyFight {
   private final StrikePractice plugin;
   private final Party party;
   private boolean cancelled;
   private final HashSet<String> alive = new HashSet();
   private final Collection<String> players;
   private boolean ended;

   public PartyFFA(StrikePractice var1, Party var2, BattleKit var3) {
      this.plugin = var1;
      this.party = var2;
      this.kit = var3;
      this.players = new HashSet(var2.getMembersNames());
   }

   public boolean canStart() {
      if (this.arena == null) {
         if (this.kit.isBuild()) {
            this.arena = c.b(y.W(this.party.getOwner()), this.kit);
         } else {
            this.arena = c.d(y.W(this.party.getOwner()), this.kit);
         }
      }

      return this.arena != null && !this.arena.needsRollback() && !this.arena.isUsing() && this.arena.getLoc1() != null && this.arena.getLoc2() != null && this.arena.getLoc1().getWorld() != null && this.arena.getLoc1().getWorld().getName().equals(this.arena.getLoc2().getWorld().getName());
   }

   public void start() {
      super.start();
      PartyFFAStartEvent var1 = new PartyFFAStartEvent(this, this.party);
      Bukkit.getPluginManager().callEvent(var1);
      this.cancelled = var1.isCancelled();
      if (!this.cancelled) {
         this.setStartedAfterCountdown();
         int var2 = this.plugin.getConfig().getInt("circle-radius");
         List var3 = t.a(this.arena.getCenter(), (float)var2, this.party.getMembersNames().size());
         this.arena.setUsing(true, this);
         this.party.setFight(this);
         Iterator var4 = this.party.getMembersNames().iterator();

         while(var4.hasNext()) {
            String var5 = (String)var4.next();
            if (var5 != null) {
               this.alive.add(var5);
               Player var6 = y.W(var5);
               if (var6.isDead()) {
                  var6.spigot().respawn();
               }

               this.plugin.clear(var6, false, false);
               Location var7 = this.arena.getCenter().clone();
               Location var8 = (Location)var3.get(0);
               Location var9 = var8.setDirection(var7.subtract(var8).toVector());
               if (!N.e(var6, var9)) {
                  this.forceEndDelayed(ChatColor.RED + "An error occurred in your fight and the fight was forced to end!");
                  return;
               }

               AbstractFight.setCurrentFight(var6, this);
               this.kit.giveKit(var6);
               var3.remove(0);
               this.plugin.a(var6, "fight-start-message.party-ffa");
               this.kit.sendFightInfo(var6);
               if (this.plugin.aa().vI) {
                  ArrayList var10 = new ArrayList(this.party.getMembersNames());
                  var10.remove(var6.getName());
                  this.plugin.aa().b(var6, "team2", var10);
                  this.plugin.aa().b(var6, "team1", Collections.singletonList(var6.getName()));
               }
            }
         }

         this.startCountdown();
         this.plugin.Z().a(this.kit);
      }

   }

   private void startCountdown() {
      i.a(this.party.getMembersNames(), this.kit == null || this.kit.isStickSpawn());
   }

   public Party[] getParties() {
      return new Party[]{this.party};
   }

   public void handleDeath(Player var1) {
      if (this.alive.contains(var1.getName())) {
         this.alive.remove(var1.getName());
         int var2 = this.alive.size();
         new FightInventory(var1, this.plugin);
         Iterator var3 = this.party.getMembersNames().iterator();

         String var4;
         while(var3.hasNext()) {
            var4 = (String)var3.next();
            Player var5 = y.W(var4);
            if (var5 != null) {
               this.plugin.a(var5, "ffa-died", u.a("<player>", var1.getName(), "<alive>", var2 + ""));
            }
         }

         this.plugin.clear(var1, false, true);
         if (this.plugin.aa().vI) {
            this.plugin.aa().bk(var1);
         }

         AbstractFight.setCurrentFight(var1, (Fight)null);
         if (var2 == 1) {
            this.ended = true;
            super.ended = System.currentTimeMillis();
            Player var7 = null;

            Iterator var8;
            String var9;
            for(var8 = this.alive.iterator(); var8.hasNext(); var7 = y.W(var9)) {
               var9 = (String)var8.next();
            }

            if (var7 != null) {
               if (this.plugin.aa().vI) {
                  this.plugin.aa().bk(var7);
               }

               new FightInventory(var7, this.plugin);
               Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, () -> {
                  if (this.arena != null) {
                     this.arena.setUsing(false, (Fight)null);
                  }

                  if (this.party != null) {
                     this.party.setFight((Fight)null);
                  }

                  boolean var2 = this.allowSpectating();
                  Iterator var3 = this.party.getMembersNames().iterator();

                  while(var3.hasNext()) {
                     String var4 = (String)var3.next();
                     Player var5 = y.W(var4);
                     if (var5 != null) {
                        if (var2 && this.plugin.ac().isSpectator(var5)) {
                           this.plugin.ac().removeSpectator(var5, true);
                        }

                        AbstractFight.setCurrentFight(var5, (Fight)null);
                     }
                  }

                  this.plugin.clear(var7, true, true);
               }, (long)(20 * this.plugin.getConfig().getInt("wait-before-teleport")));
            }

            Bukkit.getPluginManager().callEvent(new PartyFFAEndEvent(this, this.party, var7));
            var8 = this.party.getMembersNames().iterator();

            while(var8.hasNext()) {
               var9 = (String)var8.next();
               Player var6 = y.W(var9);
               this.plugin.a(var6, "ffa-winner", u.a("<player>", var7.getName()));
            }

            if (this.plugin.getConfig().getBoolean("clickable-messages")) {
               var4 = var7.getName();
               C.c(() -> {
                  ArrayList var2 = new ArrayList(this.players.size());
                  Iterator var3 = this.players.iterator();

                  String var4x;
                  while(var3.hasNext()) {
                     var4x = (String)var3.next();
                     var2.add(this.plugin.am().c(this.plugin.am().j(var4x)));
                  }

                  if (!var2.isEmpty()) {
                     for(int var6 = 0; var6 < var2.size() - 1; ++var6) {
                        FightInventory var8 = (FightInventory)var2.get(var6);
                        if (var8 != null) {
                           var8.setNextInventory((FightInventory)var2.get(var6 + 1));
                        }
                     }

                     FightInventory var7 = (FightInventory)var2.get(var2.size() - 1);
                     if (var7 != null) {
                        var7.setNextInventory((FightInventory)var2.get(0));
                     }
                  }

                  var3 = this.party.getMembersNames().iterator();

                  while(var3.hasNext()) {
                     var4x = (String)var3.next();
                     Player var5 = y.W(var4x);
                     if (var5 != null) {
                        FightInventory.inventoryMessage(var5, var2);
                     }
                  }

                  this.sendSpectatorMessages(Collections.singleton(var4), this.party.getMembersNames());
               });
            }
         }

      }
   }

   public boolean allowSpectating() {
      return this.plugin.getConfig().getBoolean("allow-spectating");
   }

   public boolean hasEnded() {
      return this.ended;
   }

   public Party getParty() {
      return this.party;
   }

   public HashSet<String> getAlive() {
      return this.alive;
   }

   public List<String> getTeammates(Player var1) {
      return Collections.singletonList(var1.getName());
   }

   public List<String> getOpponents(Player var1) {
      String var2 = var1.getName();
      return (List)this.party.getMembersNames().stream().filter((var1x) -> {
         return !var2.equals(var1x);
      }).collect(Collectors.toList());
   }

   public void forceEnd(String var1) {
      Bukkit.getPluginManager().callEvent(new PartyFFAEndEvent(this, this.party, (Player)null));
      if (this.party != null) {
         Iterator var2 = this.party.getMembersNames().iterator();

         while(var2.hasNext()) {
            String var3 = (String)var2.next();
            Player var4 = y.W(var3);
            if (var4 != null) {
               if (var1 != null) {
                  var4.sendMessage(var1);
               }

               AbstractFight.setCurrentFight(var4, (Fight)null);
               if (this.plugin.ac().isSpectator(var4)) {
                  this.plugin.ac().removeSpectator(var4, true);
               }

               this.plugin.a(var4, true, true, true);
               this.party.setFight((Fight)null);
               if (this.plugin.aa().vI) {
                  this.plugin.aa().bk(var4);
               }
            }
         }

         if (this.arena != null) {
            this.arena.setUsing(false, (Fight)null);
         }

         this.ended = true;
         super.ended = System.currentTimeMillis();
      }
   }

   public boolean playersAreOpponents(Player var1, Player var2) {
      return var1 != var2 && this.players.contains(var1.getName()) && this.players.contains(var2.getName());
   }

   public boolean playersAreTeammates(Player var1, Player var2) {
      return var1 == var2;
   }
}
