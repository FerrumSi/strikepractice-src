package ga.strikepractice.fights.party.partyfights.partyqueue;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.fights.queue.QueueRunnable;
import ga.strikepractice.fights.queue.e;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.u;
import ga.strikepractice.utils.x;
import java.util.Collection;
import java.util.Iterator;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.scheduler.BukkitRunnable;

@APIClass
public class PartyQueueRunnable implements QueueRunnable {
   public static final String RANKED_QUEUE = "StrikePractice2v2RankedQueue";
   private final StrikePractice plugin;
   private final int currentElo;
   private int range;
   private boolean anyone;
   private int counter;
   private final BattleKit kit;
   private final Party party;

   public PartyQueueRunnable(StrikePractice var1, Party var2, BattleKit var3) {
      this.party = var2;
      this.plugin = var1;
      this.kit = var3;
      int var4 = 0;
      Iterator var5 = var2.getPlayers().iterator();

      while(var5.hasNext()) {
         Player var6 = (Player)var5.next();
         var4 += DefaultPlayerStats.getStats(var6.getUniqueId()).getElo(var3);
         var6.setMetadata("StrikePractice2v2RankedQueue", new FixedMetadataValue(var1, this));
      }

      var4 /= var2.getMembersNames().size();
      this.currentElo = var4;
      this.range += var1.getConfig().getInt("ranked.elo-range-increase");
   }

   public void run() {
      ++this.counter;
      Iterator var1;
      Player var2;
      if (this.counter >= this.plugin.getConfig().getInt("ranked.anyone-after")) {
         if (!this.anyone) {
            var1 = this.party.getPlayers().iterator();

            while(var1.hasNext()) {
               var2 = (Player)var1.next();
               this.plugin.a(var2, "ranked-anyone");
            }
         }

         this.anyone = true;
      } else {
         ++this.counter;
         if (this.counter % this.plugin.getConfig().getInt("ranked.elo-range-time") == 0) {
            this.range += this.plugin.getConfig().getInt("ranked.elo-range-increase");
            var1 = this.party.getPlayers().iterator();

            while(var1.hasNext()) {
               var2 = (Player)var1.next();
               this.plugin.a(var2, "ranked-range", u.a("<range1>", this.getFromRange(), "<range2>", this.getToRange()));
            }
         }
      }

      PartyQueueRunnable var3 = this.getOpponent();
      if (var3 != null) {
         e.b(var3);
         e.b(this);
      }

   }

   private PartyQueueRunnable getOpponent() {
      Iterator var1 = ((Collection)ga.strikepractice.fights.party.partyfights.partyqueue.a.gF.get(this.kit)).iterator();

      PartyQueueRunnable var2;
      final Party var3;
      do {
         do {
            do {
               do {
                  do {
                     if (!var1.hasNext()) {
                        return null;
                     }

                     var2 = (PartyQueueRunnable)var1.next();
                  } while(var2.equals(this));

                  var3 = var2.getParty();
               } while(var3 == null);
            } while(!var2.getKit().equals(this.kit));
         } while((Math.abs(var2.getCurrentElo() - this.getCurrentElo()) >= this.range || Math.abs(var2.getCurrentElo() - this.getCurrentElo()) >= var2.getRange()) && (!var2.isAnyone() || !this.anyone));
      } while(!this.isValidQueue() || !var2.isValidQueue());

      Iterator var4 = this.party.getPlayers().iterator();

      Player var5;
      while(var4.hasNext()) {
         var5 = (Player)var4.next();
         var5.removeMetadata("StrikePracticeWaiting2v2Queue", this.plugin);
         x.bb(var5);
      }

      var4 = var3.getPlayers().iterator();

      while(var4.hasNext()) {
         var5 = (Player)var4.next();
         var5.removeMetadata("StrikePracticeWaiting2v2Queue", this.plugin);
         x.bb(var5);
      }

      (new BukkitRunnable() {
         public void run() {
            BattleKit var1 = ga.strikepractice.battlekit.e.a(PartyQueueRunnable.this.kit, true, BattleKitType.PARTY_QUEUE, BattleKitType.ANY);
            PartyVsParty var2 = new PartyVsParty(PartyQueueRunnable.this.plugin, PartyQueueRunnable.this.party, var3, var1);
            Iterator var3x;
            Player var4;
            if (PartyQueueRunnable.this.party.getMembersNames().size() != 2) {
               var3x = PartyQueueRunnable.this.party.getPlayers().iterator();

               while(var3x.hasNext()) {
                  var4 = (Player)var3x.next();
                  var4.sendMessage(ChatColor.RED + "Your party must have 2 players.");
               }

               var3x = var3.getPlayers().iterator();

               while(var3x.hasNext()) {
                  var4 = (Player)var3x.next();
                  var4.sendMessage(ChatColor.RED + "Fight cancelled, opposite party tried to abuse :(");
               }

            } else if (var3.getMembersNames().size() != 2) {
               var3x = var3.getPlayers().iterator();

               while(var3x.hasNext()) {
                  var4 = (Player)var3x.next();
                  var4.sendMessage(ChatColor.RED + "Your party must have 2 players.");
               }

               var3x = PartyQueueRunnable.this.party.getPlayers().iterator();

               while(var3x.hasNext()) {
                  var4 = (Player)var3x.next();
                  var4.sendMessage(ChatColor.RED + "Fight cancelled, opposite party tried to abuse :(");
               }

            } else {
               if (var2.canStart()) {
                  var2.setQueue(true);
                  var2.start();
               } else {
                  var3x = PartyQueueRunnable.this.party.getPlayers().iterator();

                  while(var3x.hasNext()) {
                     var4 = (Player)var3x.next();
                     c.e(var4);
                     PartyQueueRunnable.this.plugin.L.bh(var4);
                  }

                  var3x = PartyQueueRunnable.this.party.getPlayers().iterator();

                  while(var3x.hasNext()) {
                     var4 = (Player)var3x.next();
                     c.e(var4);
                     PartyQueueRunnable.this.plugin.L.bh(var4);
                  }
               }

            }
         }
      }).runTask(this.plugin);
      return var2;
   }

   public static PartyQueueRunnable getRanked(Player var0) {
      MetadataValue var1 = StrikePractice.getInstance().a((Metadatable)var0, (String)"StrikePractice2v2RankedQueue");
      return var1 != null && var1.value() instanceof PartyQueueRunnable ? (PartyQueueRunnable)var1.value() : null;
   }

   public boolean isValidQueue() {
      if (this.party != null && this.party.getMembersNames().size() == 2 && !this.party.isInFight() && !this.party.getPlayers().stream().anyMatch((var0) -> {
         return AbstractFight.isInFight(var0) || PvPEvent.isInEvent(var0);
      })) {
         Player var1 = this.party.getOwnerPlayer();
         return var1 != null && getRanked(var1) == this;
      } else {
         return false;
      }
   }

   public int getFromRange() {
      return Math.max(0, this.currentElo - this.range);
   }

   public int getToRange() {
      return this.currentElo + this.range;
   }

   public int getCurrentElo() {
      return this.currentElo;
   }

   public int getRange() {
      return this.range;
   }

   public BattleKit getKit() {
      return this.kit;
   }

   public void setRange(int var1) {
      this.range = var1;
   }

   public boolean isAnyone() {
      return this.anyone;
   }

   public void setAnyone(boolean var1) {
      this.anyone = var1;
   }

   public int getCounter() {
      return this.counter;
   }

   public void setCounter(int var1) {
      this.counter = var1;
   }

   public Party getParty() {
      return this.party;
   }
}
