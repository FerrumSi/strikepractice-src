package ga.strikepractice.fights.party.partyfights.partyqueue;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.events.PartyDisbandEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.o.g;
import ga.strikepractice.party.Party;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.e;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.u;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

@e(
   fj = {"leave"}
)
public class a implements CommandExecutor, Listener {
   public static final String gD = "StrikePracticeWaiting2v2Queue";
   public static final Map<BattleKit, Party> gE = new ConcurrentHashMap();
   public static final Map<BattleKit, Collection<PartyQueueRunnable>> gF = new ConcurrentHashMap();
   private static Inventory gG;
   private static Inventory gH;
   private static int gI;
   private static String gJ;
   private static String gK;
   private final StrikePractice gL;

   public a(StrikePractice var1) {
      this.gL = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         Party var6 = Party.getParty(var5);
         if (var6 == null || !var6.getOwner().equals(var5.getName())) {
            this.gL.a(var5, "not-own-party");
            return true;
         }

         if (var4.length > 0 && var4[0].equalsIgnoreCase("leave")) {
            Iterator var7 = var6.getPlayers().iterator();

            while(var7.hasNext()) {
               Player var8 = (Player)var7.next();
               this.gL.a(var8, "left-queue");
               a(var8, false);
               if (!AbstractFight.isInFight(var8)) {
                  StrikePractice.getInstance().L.bh(var8);
               }
            }

            return true;
         }

         this.d(var5, var4.length > 0 ? var4[0] : "");
      }

      return true;
   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      a(var1.getPlayer(), true);
      var1.getPlayer().removeMetadata("StrikePracticeWaiting2v2Queue", this.gL);
   }

   @EventHandler(
      priority = EventPriority.LOW
   )
   public void a(PartyDisbandEvent var1) {
      Iterator var2 = var1.getParty().getPlayers().iterator();

      while(var2.hasNext()) {
         Player var3 = (Player)var2.next();
         a(var3, true);
      }

   }

   @EventHandler
   public void a(PlayerDeathEvent var1) {
      a(var1.getEntity(), true);
   }

   @EventHandler
   public void c(InventoryClickEvent var1) {
      ItemStack var2 = var1.getCurrentItem();
      if (var2 != null && var1.getInventory() != null) {
         boolean var3 = var1.getView().getTitle().equals(gJ);
         if (var3 || var1.getView().getTitle().equals(gK)) {
            var1.setCancelled(true);
            if (var1.getWhoClicked() instanceof Player && r.h(var1.getCurrentItem()) && var1.getClickedInventory() != null) {
               var1.getWhoClicked().closeInventory();
               Player var4 = (Player)var1.getWhoClicked();
               if (!var1.getClickedInventory().equals(var4.getInventory())) {
                  Party var5 = Party.getParty(var4);
                  if (var5 != null && var5.getOwner().equals(var4.getName())) {
                     if (var5.getMembersNames().size() != 2) {
                        this.gL.a(var4, "party-size", u.a("<number>", Integer.toString(2)));
                     } else {
                        List var6 = BattleKit.getKits(var2);
                        BattleKit var7 = null;
                        Iterator var8 = var6.iterator();

                        while(var8.hasNext()) {
                           BattleKit var9 = (BattleKit)var8.next();
                           if (var3 && var9.isElo() || !var3 && !var9.isElo()) {
                              var7 = var9;
                              break;
                           }
                        }

                        if (var7 == null && !var6.isEmpty()) {
                           var7 = (BattleKit)var6.get(0);
                        }

                        if ((var1.getClick() == ClickType.SHIFT_LEFT || var1.getClick() == ClickType.SHIFT_RIGHT) && var7 != null && this.gL.getConfig().getBoolean("preview.shift-click-preview")) {
                           ga.strikepractice.m.a.a(var4, var7, this.gL);
                        } else if (this.H(var4)) {
                           boolean var10 = this.gL.getConfig().getBoolean("leave-queue-item");
                           if (var10 && var2.getType().equals(Material.WOOL) && var2.getItemMeta().hasDisplayName() && var1.getSlot() == var1.getInventory().getSize() - 1) {
                              this.gL.a(var4, "left-queue");
                              a(var4, false);
                              StrikePractice.getInstance().L.bh(var4);
                           } else if (var2.getItemMeta().hasDisplayName() && var1.getSlot() == var1.getInventory().getSize() - (var10 ? 2 : 1) && this.gL.getConfig().getBoolean("kit-editor-in-kit-selector")) {
                              this.gL.Y().az(var4);
                           } else {
                              this.e(var4, var7);
                           }
                        }
                     }
                  } else {
                     this.gL.a(var4, "not-own-party");
                  }
               }
            }
         }
      }
   }

   public void e(Player var1, BattleKit var2) {
      int var3 = this.gL.ao().dH().ai(var1);
      if (var2 == null) {
         var1.sendMessage(ChatColor.RED + "Error: invalid kit... try another kit and contact admins!");
      } else if (!DefaultPlayerStats.getStats().containsKey(var1.getUniqueId())) {
         var1.sendMessage(ChatColor.RED + "Please try again!");
      } else {
         DefaultPlayerStats var4 = DefaultPlayerStats.getStats(var1.getUniqueId());
         if (var2.isElo() && this.gL.getConfig().getBoolean("limit-rankeds") && var4.getRankedsLeft() <= 0) {
            this.gL.a(var1, "no-rankeds-left");
         } else if (!var2.isElo() && this.gL.getConfig().getBoolean("limit-unrankeds") && var4.getUnrankedsLeft() <= 0) {
            this.gL.a(var1, "no-unrankeds-left");
         } else if (var2.isElo() && var3 > this.gL.getConfig().getInt("max-ranked-queue-ping")) {
            this.gL.a(var1, "queue-ping-limit", u.a("<ping>", Integer.toString(var3)));
         } else {
            if (var2.isElo()) {
               int var5 = DefaultPlayerStats.getStats(var1.getUniqueId()).getKills();
               int var6 = this.gL.getConfig().getInt("ranked.kills-required");
               if (var5 < var6) {
                  this.gL.a(var1, "ranked-kills-required", u.a("<kills>", var5, "<needed>", var6 - var5, "<required>", var6));
                  return;
               }
            }

            Party var7 = Party.getParty(var1);
            if (var7 != null && var7.getOwner().equals(var1.getName())) {
               if (var7.getMembersNames().size() != 2) {
                  this.gL.a(var1, "party-size", u.a("<number>", 2));
               } else {
                  this.a(var7, var2);
               }
            } else {
               this.gL.a(var1, "not-own-party");
            }
         }
      }
   }

   private boolean H(Player var1) {
      if (!AbstractFight.isInFight(var1) && !PvPEvent.isInEvent(var1)) {
         return true;
      } else {
         this.gL.a(var1, "you-can-not-duel-now");
         return false;
      }
   }

   private void a(Party var1, BattleKit var2) {
      a(var1.getOwnerPlayer(), false);
      Iterator var8;
      Player var10;
      if (var2.isElo()) {
         PartyQueueRunnable var3 = new PartyQueueRunnable(this.gL, var1, var2);
         Object var4;
         if (gF.containsKey(var2)) {
            var4 = (Collection)gF.get(var2);
         } else {
            var4 = Collections.newSetFromMap(new ConcurrentHashMap());
         }

         ((Collection)var4).add(var3);
         gF.put(var2, var4);
         Iterator var5 = var1.getPlayers().iterator();

         while(var5.hasNext()) {
            Player var6 = (Player)var5.next();
            this.gL.a(var6, "waiting-for-duel", u.a("<kit>", var2.getFancyName()));
            var6.closeInventory();
            var6.setMetadata("StrikePracticeWaiting2v2Queue", new FixedMetadataValue(this.gL, System.currentTimeMillis()));
            this.gL.L.bh(var6);
         }

         bo();
      } else if (gE.containsKey(var2) && gE.get(var2) != null) {
         Party var9 = (Party)gE.get(var2);
         Iterator var11 = var9.getPlayers().iterator();

         Player var12;
         while(var11.hasNext()) {
            var12 = (Player)var11.next();
            var12.removeMetadata("StrikePracticeWaiting2v2Queue", this.gL);
            this.gL.L.bh(var12);
         }

         var11 = var1.getPlayers().iterator();

         while(var11.hasNext()) {
            var12 = (Player)var11.next();
            this.gL.a(var12, "waiting-for-duel", u.a("<kit>", var2.getFancyName()));
            var12.removeMetadata("StrikePracticeWaiting2v2Queue", this.gL);
            this.gL.L.bh(var12);
            var12.closeInventory();
         }

         gE.remove(var2);
         bo();
         BattleKit var13 = ga.strikepractice.battlekit.e.a(var2, false, BattleKitType.PARTY_QUEUE, BattleKitType.ANY);
         PartyVsParty var14 = new PartyVsParty(this.gL, var9, var1, var13);
         if (var14.canStart()) {
            var14.setQueue(true);
            var14.start();
         } else {
            Iterator var15 = var9.getPlayers().iterator();

            Player var7;
            while(var15.hasNext()) {
               var7 = (Player)var15.next();
               c.e(var7);
            }

            var15 = var1.getPlayers().iterator();

            while(var15.hasNext()) {
               var7 = (Player)var15.next();
               c.e(var7);
            }
         }
      } else {
         gE.put(var2, var1);
         var8 = var1.getPlayers().iterator();

         while(var8.hasNext()) {
            var10 = (Player)var8.next();
            this.gL.a(var10, "waiting-for-duel", u.a("<kit>", var2.getFancyName()));
            var10.setMetadata("StrikePracticeWaiting2v2Queue", new FixedMetadataValue(this.gL, System.currentTimeMillis()));
            this.gL.L.bh(var10);
            var10.closeInventory();
         }

         bo();
      }

      var8 = var1.getPlayers().iterator();

      while(var8.hasNext()) {
         var10 = (Player)var8.next();
         g.i(var10.getUniqueId());
      }

   }

   public static void a(Player var0, boolean var1) {
      Party var2 = Party.getParty(var0);
      if (var2 != null && !var2.isInFight()) {
         boolean var3 = gE.entrySet().removeIf((var1x) -> {
            return var1x.getValue() == var2;
         });
         PartyQueueRunnable var4 = PartyQueueRunnable.getRanked(var0);
         Iterator var5;
         if (var4 != null) {
            var3 = true;
            var5 = StrikePractice.getInstance().kits.iterator();

            while(var5.hasNext()) {
               BattleKit var6 = (BattleKit)var5.next();
               if (gF.containsKey(var6)) {
                  Collection var7 = (Collection)gF.get(var6);
                  var7.remove(var4);
               }
            }
         }

         if (var1) {
            var0.closeInventory();
         }

         var0.removeMetadata("StrikePracticeWaiting2v2Queue", StrikePractice.getInstance());
         var0.removeMetadata("StrikePractice2v2RankedQueue", StrikePractice.getInstance());
         if (var3) {
            var5 = var2.getPlayers().iterator();

            while(var5.hasNext()) {
               Player var8 = (Player)var5.next();
               StrikePractice.getInstance().L.bh(var8);
            }

            g.i(var0.getUniqueId());
            bo();
         }

      }
   }

   public static boolean b(Party var0) {
      if (var0.getMembersNames().size() != 2) {
         Player var1 = var0.getOwnerPlayer();
         if (var1 != null && var1.hasMetadata("StrikePracticeWaiting2v2Queue")) {
            a(var1, true);
            return true;
         }
      }

      return false;
   }

   public static void bo() {
      StrikePractice var0 = StrikePractice.getInstance();
      String var1 = f.K(var0.getConfig().getString("in-queue"));
      String var2 = f.K(var0.getConfig().getString("in-match"));
      boolean var3 = var0.getConfig().getBoolean("change-icon-amount");
      boolean var4 = var0.getConfig().getBoolean("separate-queues");
      ArrayList var5 = new ArrayList();
      Iterator var6 = var0.kits.iterator();

      while(true) {
         BattleKit var7;
         do {
            if (!var6.hasNext()) {
               HashMap var28 = new HashMap();
               Iterator var29 = Bukkit.getOnlinePlayers().iterator();

               BattleKit var10;
               while(var29.hasNext()) {
                  Player var8 = (Player)var29.next();
                  Fight var9 = AbstractFight.getCurrentFight(var8);
                  if (var9 instanceof PartyVsParty && ((PartyVsParty)var9).isQueue()) {
                     var10 = var9.getKit();
                     if (var10 != null) {
                        int var11 = 1;
                        if (var28.containsKey(var10)) {
                           var11 += (Integer)var28.get(var10);
                        }

                        var28.put(var10, var11);
                     }
                  }
               }

               int var30 = 0;
               int var31 = 0;

               for(int var32 = 0; var32 < var5.size(); ++var32) {
                  try {
                     var10 = (BattleKit)var5.get(var32);
                     if (var10.getIcon() == null) {
                        Bukkit.getLogger().warning(var10.getName() + " kit does not have a valid icon.");
                     }

                     ItemStack var33 = var10.getIcon().clone();
                     ItemMeta var12 = var33.getItemMeta();
                     if (var12 == null) {
                        Bukkit.getLogger().warning(var10.getName() + " kit does not have a valid icon (meta).");
                     }

                     ArrayList var13 = new ArrayList(6);
                     int var14 = var10.isElo() ? a(var10, false) : (gE.get(var10) != null ? 1 : 0);
                     if (var3) {
                        var33.setAmount(var14 + 1);
                     }

                     int var15 = 0;
                     if (var10.isElo()) {
                        var15 = gF.containsKey(var10) ? ((Collection)gF.get(var10)).size() : 0;
                     } else if (gE.containsKey(var10) && gE.get(var10) != null) {
                        var15 = 1;
                     }

                     String[] var16 = var1.split("\\\\n");
                     int var17 = var16.length;

                     int var18;
                     String var19;
                     String[] var20;
                     int var21;
                     int var22;
                     String var23;
                     for(var18 = 0; var18 < var17; ++var18) {
                        var19 = var16[var18];
                        var20 = var19.split(".split");
                        var21 = var20.length;

                        for(var22 = 0; var22 < var21; ++var22) {
                           var23 = var20[var22];
                           var13.add(var23.replace("<players>", Integer.toString(var15)));
                        }
                     }

                     var15 = (Integer)var28.getOrDefault(var10, 0);
                     var16 = var2.split("\\\\n");
                     var17 = var16.length;

                     for(var18 = 0; var18 < var17; ++var18) {
                        var19 = var16[var18];
                        var20 = var19.split(".split");
                        var21 = var20.length;

                        for(var22 = 0; var22 < var21; ++var22) {
                           var23 = var20[var22];
                           if (!var23.contains("<wins_") && !var23.contains("<losses_")) {
                              var13.add(var23.replace("<players>", Integer.toString(var15)));
                           }
                        }
                     }

                     for(int var34 = 0; var34 < var13.size(); ++var34) {
                        var13.set(var34, var0.ah().a((Player)null, (String)((String)var13.get(var34)), (String)""));
                     }

                     var12.setLore((List)var13.stream().filter((var0x) -> {
                        return !var0x.contains("[display=false]");
                     }).collect(Collectors.toList()));
                     var33.setItemMeta(var12);
                     if (var10.getTypes().contains(BattleKitType.PARTY_QUEUE) || var10.getTypes().contains(BattleKitType.ANY)) {
                        if (var4) {
                           if (var10.isElo()) {
                              try {
                                 gG.setItem(var30, var33.clone());
                              } catch (Exception var26) {
                                 f(var0);
                                 return;
                              }

                              ++var30;
                           } else {
                              try {
                                 gH.setItem(var31, var33);
                              } catch (Exception var25) {
                                 f(var0);
                                 return;
                              }

                              ++var31;
                           }
                        } else {
                           try {
                              gH.setItem(var32, var33);
                           } catch (Exception var24) {
                              f(var0);
                              return;
                           }
                        }
                     }
                  } catch (Exception var27) {
                     Bukkit.getLogger().warning("Party queue loading failed, kit: " + ((BattleKit)var5.get(var32)).getName());
                     var27.printStackTrace();
                  }
               }

               return;
            }

            var7 = (BattleKit)var6.next();
         } while(!var7.getTypes().contains(BattleKitType.ANY) && !var7.getTypes().contains(BattleKitType.PARTY_QUEUE));

         if (var7.getIcon() != null && !var5.contains(var7)) {
            var5.add(var7);
         }
      }
   }

   private static int a(BattleKit var0, boolean var1) {
      int var2 = 0;
      if (gF.containsKey(var0)) {
         Collection var3 = (Collection)gF.get(var0);
         var2 = var3.size();
      }

      return var2;
   }

   public void d(Player var1, String var2) {
      bo();
      BattleKit var3 = StrikePractice.getAPI().getKit(var2);
      if (var3 != null) {
         if (var3.getKitTypes().contains(BattleKitType.PARTY_QUEUE) || var3.getKitTypes().contains(BattleKitType.ANY)) {
            if (!this.H(var1)) {
               return;
            } else {
               this.e(var1, var3);
               return;
            }
         }

         B.debug(var3.getName() + " does not have PARTY_QUEUE type, cannot queue with /2v2 <kit>");
      } else {
         B.debug("/2v2 " + var2 + ": no such kit " + var2);
      }

      if (var2.equalsIgnoreCase("ranked") && this.gL.getConfig().getBoolean("separate-queues")) {
         var1.openInventory(gG);
      } else {
         var1.openInventory(gH);
      }

   }

   public static void f(StrikePractice var0) {
      if (gI <= 50) {
         ++gI;
         Iterator var1;
         HumanEntity var2;
         if (gH != null) {
            var1 = gH.getViewers().iterator();

            while(var1.hasNext()) {
               var2 = (HumanEntity)var1.next();
               var2.closeInventory();
            }

            gH.clear();
         }

         if (gG != null) {
            var1 = gG.getViewers().iterator();

            while(var1.hasNext()) {
               var2 = (HumanEntity)var1.next();
               var2.closeInventory();
            }

            gG.clear();
         }

         boolean var6 = var0.getConfig().getBoolean("separate-queues");
         int var7 = 0;
         ItemStack var3 = null;
         if (var0.getConfig().getBoolean("kit-editor-in-kit-selector")) {
            ++var7;
            var3 = new ItemStack(Material.getMaterial(var0.getConfig().getString("kit-selector-editor-material")));
            ItemMeta var4 = var3.getItemMeta();
            var4.setDisplayName(f.K(var0.getConfig().getString("kit-selector-editor-name")));
            var3.setItemMeta(var4);
         }

         ItemStack var8 = null;
         if (var0.getConfig().getBoolean("leave-queue-item")) {
            ++var7;
            var8 = new ItemStack(Material.WOOL);
            var8.setDurability((short)14);
            ItemMeta var5 = var8.getItemMeta();
            var5.setDisplayName(f.K(var0.getConfig().getString("quit-item-name")));
            var8.setItemMeta(var5);
         }

         gK = f.K(var0.getConfig().getString("2v2-queue-inventory-title"));
         gH = Bukkit.createInventory((InventoryHolder)null, var0.L.a(false, !var6, BattleKitType.PARTY_QUEUE, var7), gK);
         if (var8 != null) {
            gH.setItem(gH.getSize() - 1, var8);
         }

         if (var3 != null) {
            if (var8 == null) {
               gH.setItem(gH.getSize() - 1, var3);
            } else {
               gH.setItem(gH.getSize() - 2, var3);
            }
         }

         if (var6) {
            gJ = f.K(var0.getConfig().getString("2v2-ranked-queue-inventory-title"));
            gG = Bukkit.createInventory((InventoryHolder)null, var0.L.a(false, true, true, BattleKitType.PARTY_QUEUE, var7), gJ);
            if (var3 != null) {
               if (var8 == null) {
                  gG.setItem(gG.getSize() - 1, var3);
               } else {
                  gG.setItem(gG.getSize() - 2, var3);
               }
            }

            if (var8 != null) {
               gG.setItem(gG.getSize() - 1, var8);
            }
         }

         bo();
      }
   }
}
