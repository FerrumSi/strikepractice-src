package ga.strikepractice.fights.party.partyfights;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.party.Party;

@APIClass
public interface PartyFight {
   Party[] getParties();
}
