package ga.strikepractice.fights.party.partyfights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.events.PartySplitEndEvent;
import ga.strikepractice.events.PartySplitStartEvent;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.u;
import ga.strikepractice.utils.y;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;

@APIClass
public class PartySplit extends AbstractFight implements PartyFight {
   private final StrikePractice plugin;
   private final Party party;
   private boolean cancelled;
   public final HashSet<String> alive;
   public final HashSet<String> alive2;
   private HashSet<String> team;
   private HashSet<String> team2;
   private boolean ended;

   public PartySplit(StrikePractice var1, Party var2, BattleKit var3) {
      this.plugin = var1;
      this.party = var2;
      this.kit = var3;
      int var4 = (int)Math.ceil((double)var2.getMembersNames().size() / 2.0D);
      this.alive = new HashSet(var4);
      this.alive2 = new HashSet(var4);
   }

   public boolean canStart() {
      if (this.arena == null) {
         if (this.kit.isBuild()) {
            this.arena = c.b(y.W(this.party.getOwner()), this.kit);
         } else {
            this.arena = c.d(y.W(this.party.getOwner()), this.kit);
         }
      }

      return this.arena != null && !this.arena.needsRollback() && !this.arena.isUsing() && this.arena.getLoc1() != null && this.arena.getLoc2() != null && this.arena.getLoc1().getWorld() != null && this.arena.getLoc1().getWorld().getName().equals(this.arena.getLoc2().getWorld().getName());
   }

   public void start() {
      super.start();
      PartySplitStartEvent var1 = new PartySplitStartEvent(this, this.party);
      Bukkit.getPluginManager().callEvent(var1);
      this.cancelled = var1.isCancelled();
      if (!this.cancelled) {
         this.setStartedAfterCountdown();
         this.arena.setUsing(true, this);
         this.party.setFight(this);
         ArrayList var2 = new ArrayList(this.party.getMembersNames());
         Collections.shuffle(var2);
         Iterator var3 = var2.iterator();

         String var4;
         while(var3.hasNext()) {
            var4 = (String)var3.next();
            if (this.alive2.size() > this.alive.size()) {
               this.alive.add(var4);
            } else {
               this.alive2.add(var4);
            }
         }

         var3 = this.alive.iterator();

         Player var5;
         while(var3.hasNext()) {
            var4 = (String)var3.next();
            var5 = y.W(var4);
            if (var5 != null) {
               this.initPlayer(var5, this.arena.getLoc1(), true);
            }
         }

         var3 = this.alive2.iterator();

         while(var3.hasNext()) {
            var4 = (String)var3.next();
            var5 = y.W(var4);
            if (var5 != null) {
               this.initPlayer(var5, this.arena.getLoc2(), false);
            }
         }

         this.team = new HashSet(this.alive);
         this.team2 = new HashSet(this.alive2);
         this.startCountdown();
         this.plugin.Z().a(this.kit);
      }

   }

   private void initPlayer(Player var1, Location var2, boolean var3) {
      try {
         if (var1.isDead()) {
            var1.spigot().respawn();
         }

         this.plugin.clear(var1, false, false);
         if (!N.e(var1, var2)) {
            this.forceEndDelayed(ChatColor.RED + "An error occurred in your fight and the fight was forced to end!");
            return;
         }

         AbstractFight.setCurrentFight(var1, this);
         this.kit.giveKit(var1);
         if (this.plugin.aa().vI) {
            if (var3) {
               this.plugin.aa().b(var1, "team1", this.alive);
               this.plugin.aa().b(var1, "team2", this.alive2);
            } else {
               this.plugin.aa().b(var1, "team1", this.alive2);
               this.plugin.aa().b(var1, "team2", this.alive);
            }
         }

         this.plugin.a(var1, "fight-start-message.party-split");
         this.kit.sendFightInfo(var1);
      } catch (Exception var5) {
         var5.printStackTrace();
         this.forceEndDelayed("Something went wrong...");
      }

   }

   private void startCountdown() {
      i.a(this.party.getMembersNames(), this.kit == null || this.kit.isStickSpawn());
   }

   public void handleDeath(Player var1) {
      Party var2 = Party.getParty(var1);
      HashSet var3;
      HashSet var4;
      HashSet var5;
      HashSet var6;
      if (this.alive.contains(var1.getName())) {
         var3 = this.alive;
         var4 = this.alive2;
         var5 = this.team;
         var6 = this.team2;
      } else {
         if (!this.alive2.contains(var1.getName())) {
            return;
         }

         var3 = this.alive2;
         var4 = this.alive;
         var5 = this.team2;
         var6 = this.team;
      }

      new FightInventory(var1, this.plugin);
      this.plugin.clear(var1, false, true);
      AbstractFight.setCurrentFight(var1, (Fight)null);
      var3.remove(var1.getName());
      int var7 = var3.size();
      Iterator var8 = var5.iterator();

      String var9;
      Player var10;
      while(var8.hasNext()) {
         var9 = (String)var8.next();
         var10 = y.W(var9);
         if (var10 != null) {
            this.plugin.a(var10, "your-member-died", u.a("<player>", var1.getName(), "<alive>", var7));
         }
      }

      var8 = var6.iterator();

      while(var8.hasNext()) {
         var9 = (String)var8.next();
         var10 = y.W(var9);
         if (var10 != null) {
            this.plugin.a(var10, "opponent-member-died", u.a("<player>", var1.getName(), "<alive>", var7));
         }
      }

      if (this.plugin.aa().vI) {
         this.plugin.aa().bk(var1);
      }

      if (var7 == 0) {
         Bukkit.getPluginManager().callEvent(new PartySplitEndEvent(this, var2, var4, var3));
         this.ended = true;
         super.ended = System.currentTimeMillis();
         var8 = var4.iterator();

         while(var8.hasNext()) {
            var9 = (String)var8.next();
            var10 = y.W(var9);
            if (var10 != null) {
               new FightInventory(var10, this.plugin);
               if (this.plugin.aa().vI) {
                  this.plugin.aa().bk(var10);
               }
            }
         }

         Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, () -> {
            boolean var3 = this.allowSpectating();
            Iterator var4x = var2.getMembersNames().iterator();

            String var5;
            Player var6;
            while(var4x.hasNext()) {
               var5 = (String)var4x.next();
               var6 = y.W(var5);
               if (var6 != null) {
                  if (var3 && this.plugin.ac().isSpectator(var6)) {
                     this.plugin.ac().removeSpectator(var6, true);
                  }

                  AbstractFight.setCurrentFight(var6, (Fight)null);
               }
            }

            var4x = var4.iterator();

            while(var4x.hasNext()) {
               var5 = (String)var4x.next();
               var6 = y.W(var5);
               if (var6 != null) {
                  this.plugin.clear(var6, true, true);
               }
            }

            if (var2 != null) {
               var2.setFight((Fight)null);
               var2.setOpponent((Party)null);
            }

            if (this.arena != null) {
               this.arena.setUsing(false, (Fight)null);
            }

         }, (long)(20 * this.plugin.getConfig().getInt("wait-before-teleport")));
         var8 = var5.iterator();

         while(var8.hasNext()) {
            var9 = (String)var8.next();
            var10 = Bukkit.getPlayer(var9);
            if (var10 != null) {
               this.plugin.a(var10, "your-team-did-not-win");
            }
         }

         var8 = var6.iterator();

         while(var8.hasNext()) {
            var9 = (String)var8.next();
            var10 = Bukkit.getPlayer(var9);
            if (var10 != null) {
               this.plugin.a(var10, "your-team-won");
            }
         }

         C.c(() -> {
            FightInventory.message(var5, var6);
            FightInventory.message(var6, var5);
            this.sendSpectatorMessages(var6, var5);
         });
      }

   }

   public Party[] getParties() {
      return new Party[]{this.party};
   }

   public boolean allowSpectating() {
      return this.plugin.getConfig().getBoolean("allow-spectating");
   }

   public List<String> getOpponents(Player var1) {
      String var2 = var1.getName();
      return this.getTeam1() != null && this.getTeam2() != null ? new ArrayList(this.getTeam1().contains(var2) ? this.getTeam2() : this.getTeam1()) : new ArrayList(0);
   }

   public List<String> getTeammates(Player var1) {
      String var2 = var1.getName();
      return this.getTeam1() != null && this.getTeam2() != null ? new ArrayList(this.getTeam1().contains(var2) ? this.getTeam1() : this.getTeam2()) : new ArrayList(0);
   }

   public HashSet<String> getAlive1() {
      return this.alive;
   }

   public HashSet<String> getAlive2() {
      return this.alive2;
   }

   public HashSet<String> getTeam1() {
      return this.team;
   }

   public HashSet<String> getTeam2() {
      return this.team2;
   }

   public boolean hasEnded() {
      return this.ended;
   }

   public void forceEnd(String var1) {
      Bukkit.getPluginManager().callEvent(new PartySplitEndEvent(this, this.party, new HashSet(), new HashSet()));
      Iterator var2 = this.party.getMembersNames().iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         Player var4 = Bukkit.getPlayer(var3);
         if (var4 != null) {
            if (var1 != null) {
               var4.sendMessage(var1);
            }

            AbstractFight.setCurrentFight(var4, (Fight)null);
            if (this.plugin.ac().isSpectator(var4)) {
               this.plugin.ac().removeSpectator(var4, true);
            }

            this.plugin.a(var4, true, true, true);
            this.party.setFight((Fight)null);
            if (this.plugin.aa().vI) {
               this.plugin.aa().bk(var4);
            }
         }
      }

      if (this.arena != null) {
         this.arena.setUsing(false, (Fight)null);
      }

      this.ended = true;
      super.ended = System.currentTimeMillis();
   }
}
