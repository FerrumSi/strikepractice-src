package ga.strikepractice.fights.party.partyfights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.events.PartyVsBotsEndEvent;
import ga.strikepractice.events.PartyVsBotsStartEvent;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.BotFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.npc.CitizensNPC;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.u;
import ga.strikepractice.utils.y;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.metadata.Metadatable;
import org.bukkit.scheduler.BukkitRunnable;

@APIClass
public class PartyVsBots extends AbstractFight implements BotFight, PartyFight {
   private final StrikePractice plugin;
   private final Party party;
   private final Map<CitizensNPC, Boolean> botsAlive = new HashMap();
   private final Set<String> playersAlive = new HashSet();
   private boolean cancelled;
   private boolean ended;
   private CitizensNPC.Difficulty difficulty;

   public PartyVsBots(StrikePractice var1, Party var2, BattleKit var3) {
      this.plugin = var1;
      this.party = var2;
      this.kit = var3;
   }

   public void start() {
      super.start();
      PartyVsBotsStartEvent var1 = new PartyVsBotsStartEvent(this, this.party);
      Bukkit.getPluginManager().callEvent(var1);
      this.cancelled = var1.isCancelled();
      if (!this.cancelled) {
         this.setStartedAfterCountdown();
         this.arena.setUsing(true, this);
         this.party.setFight(this);
         boolean var2 = this.plugin.getConfig().getBoolean("enable-colored-names");
         ArrayList var3 = new ArrayList();
         Iterator var4 = this.party.getMembers().iterator();

         while(var4.hasNext()) {
            String var5 = (String)var4.next();
            Player var6 = y.W(var5);
            if (var6 != null) {
               var3.add(var6.getUniqueId());
            }
         }

         String var9 = f.K(this.plugin.getConfig().getString("bot-name"));
         Iterator var10 = var3.iterator();

         while(var10.hasNext()) {
            UUID var11 = (UUID)var10.next();
            Player var7 = Bukkit.getPlayer(var11);
            if (var7 != null) {
               if (this.plugin.ac().isSpectator(var7)) {
                  this.plugin.ac().removeSpectator(var7, false);
               }

               if (var7.isDead()) {
                  var7.spigot().respawn();
               }

               this.plugin.clear(var7, false, false);
               if (!N.e(var7, this.arena.getLoc1())) {
                  this.forceEndDelayed(ChatColor.RED + "An error occurred in your fight and the fight was forced to end!");
                  return;
               }

               var7.setHealth(var7.getMaxHealth());
               var7.setFoodLevel(20);
               AbstractFight.setCurrentFight(var7, this);
               this.kit.giveKit(var7);
               if (var2) {
                  this.plugin.aa().a(var7, "team1", var3);
               }

               this.plugin.a(var7, "fight-start-message.party-bots");
               this.kit.sendFightInfo(var7);
               this.playersAlive.add(var7.getName());
               CitizensNPC var8 = new CitizensNPC(var9.replace("<player>", var7.getName()), var7.getName(), this.arena.getLoc2());
               var8.startCombatTask(var3, this, this.difficulty);
               this.botsAlive.put(var8, true);
            }
         }

         this.startCountdown();
         this.plugin.Z().a(this.kit);
         (new BukkitRunnable() {
            public void run() {
               if (PartyVsBots.this.hasEnded()) {
                  this.cancel();
               } else {
                  Iterator var1 = PartyVsBots.this.botsAlive.entrySet().iterator();

                  while(true) {
                     CitizensNPC var3;
                     do {
                        Entry var2;
                        do {
                           if (!var1.hasNext()) {
                              return;
                           }

                           var2 = (Entry)var1.next();
                        } while(!(Boolean)var2.getValue());

                        var3 = (CitizensNPC)var2.getKey();
                     } while(var3 != null && var3.getBukkitEntity() != null && var3.getNPC() != null && !var3.getBukkitEntity().isDead());

                     PartyVsBots.this.botsAlive.put(var3, false);
                     PartyVsBots.this.botDeathEndsFight(var3 != null && var3.getNPC() != null ? var3.getNPC().getName() : "*offline*");
                  }
               }
            }
         }).runTaskTimer(this.plugin, 400L, 100L);
      }

   }

   public Party[] getParties() {
      return new Party[]{this.party};
   }

   public boolean allowSpectating() {
      return this.plugin.getConfig().getBoolean("allow-spectating");
   }

   public boolean hasEnded() {
      return this.ended;
   }

   public boolean canStart() {
      if (this.arena == null) {
         if (this.kit.isBuild()) {
            this.arena = c.b(y.W(this.party.getOwner()), this.kit);
         } else {
            this.arena = c.d(y.W(this.party.getOwner()), this.kit);
         }
      }

      return this.arena != null && !this.arena.needsRollback() && !this.arena.isUsing() && this.arena.getLoc1() != null && this.arena.getLoc2() != null && this.arena.getLoc1().getWorld() != null && this.arena.getLoc1().getWorld().getName().equals(this.arena.getLoc2().getWorld().getName());
   }

   public void handleDeath(Player var1) {
      Party var2 = Party.getParty(var1);
      if (this.playersAlive.contains(var1.getName())) {
         new FightInventory(var1, this.plugin);
         this.plugin.clear(var1, false, true);
         AbstractFight.setCurrentFight(var1, (Fight)null);
         this.playersAlive.remove(var1.getName());
         int var3 = this.playersAlive.size();
         Iterator var4 = var2.getMembers().iterator();

         String var5;
         Player var6;
         while(var4.hasNext()) {
            var5 = (String)var4.next();
            var6 = y.W(var5);
            if (var6 != null) {
               this.plugin.a(var6, "your-member-died", u.a("<player>", var1.getName(), "<alive>", var3));
            }
         }

         if (this.plugin.aa().vI) {
            this.plugin.aa().bk(var1);
         }

         if (var3 == 0) {
            Bukkit.getPluginManager().callEvent(new PartyVsBotsEndEvent(this, var2, PartyVsBotsEndEvent.Winners.et));
            this.ended = true;
            super.ended = System.currentTimeMillis();
            var4 = this.botsAlive.entrySet().iterator();

            while(var4.hasNext()) {
               Entry var9 = (Entry)var4.next();
               if ((Boolean)var9.getValue()) {
                  try {
                     new FightInventory(((CitizensNPC)var9.getKey()).getBukkitEntity(), ((CitizensNPC)var9.getKey()).getNPC().getName(), ((CitizensNPC)var9.getKey()).getBukkitEntity().getInventory(), this.plugin);
                     AbstractFight.setCurrentFight(((CitizensNPC)var9.getKey()).getBukkitEntity(), this);
                  } catch (Exception var7) {
                  }
               }
            }

            Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, () -> {
               boolean var2x = this.allowSpectating();
               Iterator var3 = this.botsAlive.entrySet().iterator();

               while(var3.hasNext()) {
                  Entry var4 = (Entry)var3.next();
                  if ((Boolean)var4.getValue()) {
                     ((CitizensNPC)var4.getKey()).destroy();
                  }
               }

               var3 = var2.getMembers().iterator();

               while(var3.hasNext()) {
                  String var6 = (String)var3.next();
                  Player var5 = y.W(var6);
                  if (var5 != null) {
                     if (var2x && this.plugin.ac().isSpectator(var5)) {
                        this.plugin.ac().removeSpectator(var5, true);
                     }

                     AbstractFight.setCurrentFight(var5, (Fight)null);
                  }
               }

               if (var2 != null) {
                  var2.setFight((Fight)null);
                  var2.setOpponent((Party)null);
               }

               if (this.arena != null) {
                  this.arena.setUsing(false, (Fight)null);
               }

            }, (long)(20 * this.plugin.getConfig().getInt("wait-before-teleport")));
            var4 = var2.getMembers().iterator();

            while(var4.hasNext()) {
               var5 = (String)var4.next();
               var6 = y.W(var5);
               if (var6 != null) {
                  this.plugin.a(var6, "your-team-did-not-win");
               }
            }

            HashSet var8 = new HashSet();
            Iterator var10 = this.botsAlive.keySet().iterator();

            while(var10.hasNext()) {
               CitizensNPC var11 = (CitizensNPC)var10.next();
               if (var11 != null && var11.getNPC() != null) {
                  var8.add(var11.getNPC().getName());
               }
            }

            C.c(() -> {
               FightInventory.message(var2.getMembers(), var8);
               this.sendSpectatorMessages(var8, var2.getMembersNames());
            });
         }
      }

   }

   public void forceEnd(String var1) {
      Bukkit.getPluginManager().callEvent(new PartyVsBotsEndEvent(this, this.party, PartyVsBotsEndEvent.Winners.eu));
      Iterator var2 = this.party.getMembers().iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         Player var4 = y.W(var3);
         if (var4 != null) {
            if (var1 != null) {
               var4.sendMessage(var1);
            }

            AbstractFight.setCurrentFight(var4, (Fight)null);
            if (this.plugin.ac().isSpectator(var4)) {
               this.plugin.ac().removeSpectator(var4, true);
            }

            this.plugin.a(var4, true, true, true);
            this.party.setFight((Fight)null);
            if (this.plugin.aa().vI) {
               this.plugin.aa().bk(var4);
            }
         }
      }

      var2 = this.botsAlive.keySet().iterator();

      while(var2.hasNext()) {
         CitizensNPC var5 = (CitizensNPC)var2.next();
         var5.destroy(true);
      }

      if (this.arena != null) {
         this.arena.setUsing(false, (Fight)null);
      }

      this.ended = true;
      super.ended = System.currentTimeMillis();
   }

   private void startCountdown() {
      i.a(this.party.getMembersNames(), this.kit == null || this.kit.isStickSpawn());
   }

   private void botDeathEndsFight(String var1) {
      int var2 = 0;

      Iterator var3;
      Player var5;
      String var7;
      try {
         var3 = this.botsAlive.entrySet().iterator();

         while(var3.hasNext()) {
            Entry var4 = (Entry)var3.next();
            if ((Boolean)var4.getValue()) {
               ++var2;
            }
         }

         var3 = this.party.getMembers().iterator();

         while(var3.hasNext()) {
            var7 = (String)var3.next();
            var5 = y.W(var7);
            if (var5 != null) {
               this.plugin.a(var5, "opponent-member-died", u.a("<player>", var1, "<alive>", var2));
            }
         }
      } catch (Exception var6) {
      }

      if (var2 == 0) {
         Bukkit.getPluginManager().callEvent(new PartyVsBotsEndEvent(this, this.party, PartyVsBotsEndEvent.Winners.es));
         this.ended = true;
         super.ended = System.currentTimeMillis();
         var3 = this.playersAlive.iterator();

         while(var3.hasNext()) {
            var7 = (String)var3.next();
            var5 = y.W(var7);
            if (var5 != null) {
               new FightInventory(var5, this.plugin);
               if (this.plugin.aa().vI) {
                  this.plugin.aa().bk(var5);
               }
            }
         }

         Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, () -> {
            boolean var1 = this.allowSpectating();
            Iterator var2 = this.party.getMembers().iterator();

            String var3;
            Player var4;
            while(var2.hasNext()) {
               var3 = (String)var2.next();
               var4 = y.W(var3);
               if (var4 != null) {
                  if (var1 && this.plugin.ac().isSpectator(var4)) {
                     this.plugin.ac().removeSpectator(var4, true);
                  }

                  AbstractFight.setCurrentFight(var4, (Fight)null);
               }
            }

            var2 = this.playersAlive.iterator();

            while(var2.hasNext()) {
               var3 = (String)var2.next();
               var4 = y.W(var3);
               if (var4 != null) {
                  this.plugin.clear(var4, true, true);
               }
            }

            this.party.setFight((Fight)null);
            this.party.setOpponent((Party)null);
            if (this.arena != null) {
               this.arena.setUsing(false, (Fight)null);
            }

         }, 20L * (long)this.plugin.getConfig().getInt("wait-before-teleport"));
         var3 = this.party.getMembers().iterator();

         while(var3.hasNext()) {
            var7 = (String)var3.next();
            var5 = y.W(var7);
            if (var5 != null) {
               this.plugin.a(var5, "your-team-won");
            }
         }

         HashSet var8 = new HashSet(this.botsAlive.size());
         Iterator var9 = this.botsAlive.keySet().iterator();

         while(var9.hasNext()) {
            CitizensNPC var10 = (CitizensNPC)var9.next();
            if (var10.getNPC() != null) {
               var8.add(var10.getNPC().getName());
            }
         }

         C.c(() -> {
            FightInventory.message(this.party.getMembers(), var8);
            this.sendSpectatorMessages(this.party.getMembersNames(), var8);
         });
      }

   }

   /** @deprecated */
   @Deprecated
   public HashMap<CitizensNPC, Boolean> getBotsTeam() {
      return (HashMap)this.botsAlive;
   }

   /** @deprecated */
   @Deprecated
   public HashSet<String> getPlayersTeam() {
      return this.party.getMembers();
   }

   public Set<String> getPlayers() {
      return this.party.getMembers();
   }

   /** @deprecated */
   @Deprecated
   public HashSet<String> getPlayersAlive() {
      return (HashSet)this.playersAlive;
   }

   public Set<String> getAlivePlayers() {
      return this.playersAlive;
   }

   public HashSet<CitizensNPC> getBotsAlive() {
      HashSet var1 = new HashSet();
      Iterator var2 = this.botsAlive.entrySet().iterator();

      while(var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         if ((Boolean)var3.getValue()) {
            var1.add((CitizensNPC)var3.getKey());
         }
      }

      return var1;
   }

   public List<String> getTeammates(Player var1) {
      return new ArrayList(this.party.getMembersNames());
   }

   public List<String> getOpponents(Player var1) {
      return (List)this.botsAlive.keySet().stream().filter((var0) -> {
         return var0.getNPC() != null;
      }).map((var0) -> {
         return var0.getNPC().getName();
      }).collect(Collectors.toList());
   }

   public Set<CitizensNPC> getAliveBots() {
      return this.getBotsAlive();
   }

   public CitizensNPC.Difficulty getDifficulty() {
      return this.difficulty;
   }

   public void setDifficulty(CitizensNPC.Difficulty var1) {
      this.difficulty = var1;
   }

   public void handleBotDeath(Metadatable var1) {
      Iterator var2 = this.botsAlive.entrySet().iterator();

      while(var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         if (((CitizensNPC)var3.getKey()).getBukkitEntity() != null && ((CitizensNPC)var3.getKey()).getBukkitEntity().getUniqueId().equals(((Entity)var1).getUniqueId()) && (Boolean)var3.getValue()) {
            this.botsAlive.put((CitizensNPC)var3.getKey(), false);
            String var4 = ((CitizensNPC)var3.getKey()).getNPC().getFullName();

            try {
               new FightInventory(((CitizensNPC)var3.getKey()).getBukkitEntity(), ((CitizensNPC)var3.getKey()).getNPC().getName(), ((CitizensNPC)var3.getKey()).getBukkitEntity().getInventory(), this.plugin);
               ((CitizensNPC)var3.getKey()).destroy();
            } catch (Exception var6) {
            }

            this.botDeathEndsFight(var4);
         }
      }

   }

   public Collection<CitizensNPC> getBots() {
      return this.botsAlive.keySet();
   }
}
