package ga.strikepractice.fights.party.partyfights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.api.APIClass;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.events.PartyVsPartyEndEvent;
import ga.strikepractice.events.PartyVsPartyStartEvent;
import ga.strikepractice.fightinventory.FightInventory;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.requests.PartyVsPartyRequest;
import ga.strikepractice.party.Party;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.stats.Stats;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.u;
import ga.strikepractice.utils.y;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

@APIClass
public class PartyVsParty extends AbstractFight implements PartyFight {
   private final StrikePractice plugin;
   public Party p1;
   public Party p2;
   private final HashSet<String> partyAlive1;
   private final HashSet<String> partyAlive2;
   private boolean cancelled;
   private boolean ended;
   private boolean queue;
   public PartyVsPartyRequest request;

   public PartyVsParty(StrikePractice var1, Party var2, Party var3, BattleKit var4) {
      this.plugin = var1;
      this.p1 = var2;
      this.p2 = var3;
      this.kit = var4;
      this.partyAlive1 = new HashSet(var2.getMembersNames().size());
      this.partyAlive2 = new HashSet(var3.getMembersNames().size());
   }

   public boolean canStart() {
      if (this.arena == null) {
         if (this.kit.isBuild()) {
            this.arena = c.b(this.p1.getOwnerPlayer(), this.kit);
         } else {
            this.arena = c.d(this.p1.getOwnerPlayer(), this.kit);
         }
      }

      return this.arena != null && !this.arena.needsRollback() && !this.arena.isUsing() && this.arena.getLoc1() != null && this.arena.getLoc2() != null && this.arena.getLoc1().getWorld() != null && this.arena.getLoc1().getWorld().getName().equals(this.arena.getLoc2().getWorld().getName());
   }

   public Party[] getParties() {
      return new Party[]{this.p1, this.p2};
   }

   public void start() {
      super.start();
      PartyVsPartyStartEvent var1 = new PartyVsPartyStartEvent(this, this.p1, this.p2);
      Bukkit.getPluginManager().callEvent(var1);
      this.cancelled = var1.isCancelled();
      if (!this.cancelled) {
         this.setStartedAfterCountdown();
         this.arena.setUsing(true, this);
         this.p1.setFight(this);
         this.p2.setFight(this);
         this.p2.setOpponent(this.p1);
         this.p1.setOpponent(this.p2);
         String var2 = this.plugin.X();
         Iterator var3 = this.p1.getMembersNames().iterator();

         String var4;
         Player var5;
         while(var3.hasNext()) {
            var4 = (String)var3.next();
            var5 = y.W(var4);
            if (var5 != null) {
               this.initPlayer(var5, true);
            }
         }

         var3 = this.p2.getMembersNames().iterator();

         while(var3.hasNext()) {
            var4 = (String)var3.next();
            var5 = y.W(var4);
            if (var5 != null) {
               this.initPlayer(var5, false);
            }
         }

         this.startCountdown();
         this.plugin.Z().a(this.kit);
      }

   }

   private void startCountdown() {
      ArrayList var1 = new ArrayList();
      var1.addAll(this.p1.getMembersNames());
      var1.addAll(this.p2.getMembersNames());
      i.a(var1, this.kit == null || this.kit.isStickSpawn());
   }

   private void initPlayer(Player var1, boolean var2) {
      this.plugin.clear(var1, false, false);
      if (!N.e(var1, var2 ? this.arena.getLoc1() : this.arena.getLoc2())) {
         this.forceEndDelayed(ChatColor.RED + "An error occurred in your fight and the fight was forced to end!");
      } else {
         AbstractFight.setCurrentFight(var1, this);
         this.kit.giveKit(var1);
         if (var2) {
            this.partyAlive1.add(var1.getName());
         } else {
            this.partyAlive2.add(var1.getName());
         }

         if (this.plugin.aa().vI) {
            if (var2) {
               this.plugin.aa().b(var1, "team1", this.p1.getMembersNames());
               this.plugin.aa().b(var1, "team2", this.p2.getMembersNames());
            } else {
               this.plugin.aa().b(var1, "team2", this.p1.getMembersNames());
               this.plugin.aa().b(var1, "team1", this.p2.getMembersNames());
            }
         }

         this.plugin.a(var1, "fight-start-message.party-vs-party");
         this.kit.sendFightInfo(var1);
      }
   }

   public void handleDeath(Player var1) {
      Party var2 = Party.getParty(var1);
      HashSet var3;
      HashSet var4;
      if (this.partyAlive1.contains(var1.getName())) {
         var3 = this.partyAlive1;
         var4 = this.partyAlive2;
      } else {
         if (!this.partyAlive2.contains(var1.getName())) {
            return;
         }

         var3 = this.partyAlive2;
         var4 = this.partyAlive1;
      }

      new FightInventory(var1, this.plugin);
      this.plugin.clear(var1, false, true);
      AbstractFight.setCurrentFight(var1, (Fight)null);
      var3.remove(var1.getName());
      int var5 = var3.size();
      Iterator var6 = var2.getMembersNames().iterator();

      while(var6.hasNext()) {
         String var7 = (String)var6.next();
         Player var8 = y.W(var7);
         this.plugin.a(var8, "your-member-died", u.a("<player>", var1.getName(), "<alive>", var5));
      }

      Party var11 = var2.getOpponent();
      Iterator var12 = var11.getMembersNames().iterator();

      Player var9;
      String var13;
      while(var12.hasNext()) {
         var13 = (String)var12.next();
         var9 = y.W(var13);
         this.plugin.a(var9, "opponent-member-died", u.a("<player>", var1.getName(), "<alive>", var5));
      }

      if (this.plugin.aa().vI) {
         this.plugin.aa().bk(var1);
      }

      if (var5 == 0) {
         this.ended = true;
         super.ended = System.currentTimeMillis();
         Bukkit.getPluginManager().callEvent(new PartyVsPartyEndEvent(this, var11, var2));
         var12 = var4.iterator();

         while(var12.hasNext()) {
            var13 = (String)var12.next();
            var9 = y.W(var13);
            if (var9 != null) {
               new FightInventory(var9, this.plugin);
               if (this.plugin.aa().vI) {
                  this.plugin.aa().bk(var9);
               }
            }
         }

         Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, () -> {
            boolean var4x = this.allowSpectating();
            Iterator var5 = var2.getMembersNames().iterator();

            String var6;
            Player var7;
            while(var5.hasNext()) {
               var6 = (String)var5.next();
               var7 = y.W(var6);
               if (var7 != null) {
                  if (var4x && this.plugin.ac().isSpectator(var7)) {
                     this.plugin.ac().removeSpectator(var7, true);
                  }

                  AbstractFight.setCurrentFight(var7, (Fight)null);
               }
            }

            var5 = var11.getMembersNames().iterator();

            while(var5.hasNext()) {
               var6 = (String)var5.next();
               var7 = y.W(var6);
               if (var7 != null) {
                  if (var4x && this.plugin.ac().isSpectator(var7)) {
                     this.plugin.ac().removeSpectator(var7, true);
                  }

                  AbstractFight.setCurrentFight(var7, (Fight)null);
               }
            }

            var5 = var4.iterator();

            while(var5.hasNext()) {
               var6 = (String)var5.next();
               var7 = y.W(var6);
               if (var7 != null) {
                  this.plugin.clear(var7, true, true);
               }
            }

            if (var2 != null) {
               var2.setFight((Fight)null);
               var2.setOpponent((Party)null);
            }

            if (var11 != null) {
               var11.setFight((Fight)null);
               var11.setOpponent((Party)null);
            }

            if (this.arena != null) {
               this.arena.setUsing(false, (Fight)null);
            }

         }, (long)(20 * this.plugin.getConfig().getInt("wait-before-teleport")));
         var12 = var11.getMembersNames().iterator();

         while(var12.hasNext()) {
            var13 = (String)var12.next();
            var9 = y.W(var13);
            if (var9 != null) {
               UUID var10 = var9.getUniqueId();
               DefaultPlayerStats.getStats(var10).setPartyVsPartyWins(DefaultPlayerStats.getStats(var10).getPartyVsPartyWins() + 1);
            }
         }

         var12 = var2.getMembersNames().iterator();

         while(var12.hasNext()) {
            var13 = (String)var12.next();
            var9 = y.W(var13);
            if (var9 != null) {
               this.plugin.a(var9, "your-team-did-not-win");
            }
         }

         var12 = var11.getMembersNames().iterator();

         while(var12.hasNext()) {
            var13 = (String)var12.next();
            var9 = y.W(var13);
            if (var9 != null) {
               this.plugin.a(var9, "your-team-won");
            }
         }

         C.c(() -> {
            FightInventory.message(this.p1.getMembersNames(), this.p2.getMembersNames());
            FightInventory.message(this.p2.getMembersNames(), this.p1.getMembersNames());
            this.sendSpectatorMessages(var11.getMembersNames(), var2.getMembersNames());
            if (this.kit.isElo()) {
               int var3 = 0;

               Player var5;
               for(Iterator var4 = var11.getPlayers().iterator(); var4.hasNext(); var3 += DefaultPlayerStats.getStats(var5.getUniqueId()).getElo(this.kit)) {
                  var5 = (Player)var4.next();
               }

               var3 /= var11.getPlayers().size();
               int var7 = 0;

               Player var6;
               for(Iterator var8 = var2.getPlayers().iterator(); var8.hasNext(); var7 += DefaultPlayerStats.getStats(var6.getUniqueId()).getElo(this.kit)) {
                  var6 = (Player)var8.next();
               }

               var7 /= var2.getPlayers().size();
               this.doElo(var11, var3, var2, var7);
            }

         });
      }

   }

   public boolean allowSpectating() {
      return this.plugin.getConfig().getBoolean("allow-spectating");
   }

   public boolean hasEnded() {
      return this.ended;
   }

   public Party getParty1() {
      return this.p1;
   }

   public Party getParty2() {
      return this.p2;
   }

   public HashSet<String> getPartyAlive1() {
      return this.partyAlive1;
   }

   public boolean isQueue() {
      return this.queue;
   }

   public void setQueue(boolean var1) {
      this.queue = var1;
   }

   public HashSet<String> getPartyAlive2() {
      return this.partyAlive2;
   }

   public void forceEnd(Party var1) {
      Bukkit.getPluginManager().callEvent(new PartyVsPartyEndEvent(this, this.p2 == var1 ? this.p1 : this.p2, var1));
      Iterator var2 = this.p2.getMembersNames().iterator();

      String var3;
      Player var4;
      while(var2.hasNext()) {
         var3 = (String)var2.next();
         var4 = y.W(var3);
         if (var4 != null) {
            if (!var1.getOwner().equals(this.p2.getOwner())) {
               this.plugin.a(var4, "your-team-won-disband");
            }

            AbstractFight.setCurrentFight(var4, (Fight)null);
            if (this.plugin.ac().isSpectator(var4)) {
               this.plugin.ac().removeSpectator(var4, true);
            }

            this.plugin.clear(var4, true, true);
            if (this.plugin.aa().vI) {
               this.plugin.aa().bk(var4);
            }
         }
      }

      this.p2.setFight((Fight)null);
      this.p2.setOpponent((Party)null);
      var2 = this.p1.getMembersNames().iterator();

      while(var2.hasNext()) {
         var3 = (String)var2.next();
         var4 = y.W(var3);
         if (var4 != null) {
            if (!var1.getOwner().equals(this.p1.getOwner())) {
               this.plugin.a(var4, "your-team-won-disband");
            }

            AbstractFight.setCurrentFight(var4, (Fight)null);
            if (this.plugin.ac().isSpectator(var4)) {
               this.plugin.ac().removeSpectator(var4, true);
            }

            this.plugin.clear(var4, true, true);
            if (this.plugin.aa().vI) {
               this.plugin.aa().bk(var4);
            }
         }
      }

      this.p1.setFight((Fight)null);
      this.p1.setOpponent((Party)null);
      if (this.arena != null) {
         this.arena.setUsing(false, (Fight)null);
      }

   }

   public List<String> getTeammates(Player var1) {
      Party var2 = Party.getParty(var1);
      return (List)(var2 == null ? Collections.emptyList() : new ArrayList(var2.getMembersNames()));
   }

   public List<String> getOpponents(Player var1) {
      Party var2 = Party.getParty(var1);
      return new ArrayList(var2 == this.getParty1() ? this.getParty2().getMembersNames() : this.getParty1().getMembersNames());
   }

   public void forceEnd(String var1) {
      Bukkit.getPluginManager().callEvent(new PartyVsPartyEndEvent(this, (Party)null, (Party)null));
      Iterator var2 = this.p1.getMembersNames().iterator();

      String var3;
      Player var4;
      while(var2.hasNext()) {
         var3 = (String)var2.next();
         var4 = y.W(var3);
         if (var4 != null) {
            if (var1 != null) {
               var4.sendMessage(var1);
            }

            AbstractFight.setCurrentFight(var4, (Fight)null);
            if (this.plugin.ac().isSpectator(var4)) {
               this.plugin.ac().removeSpectator(var4, true);
            }

            this.plugin.a(var4, true, true, true);
            this.p1.setFight((Fight)null);
            this.p1.setOpponent((Party)null);
         }
      }

      var2 = this.p2.getMembersNames().iterator();

      while(var2.hasNext()) {
         var3 = (String)var2.next();
         var4 = y.W(var3);
         if (var4 != null) {
            if (var1 != null) {
               var4.sendMessage(var1);
            }

            AbstractFight.setCurrentFight(var4, (Fight)null);
            if (this.plugin.ac().isSpectator(var4)) {
               this.plugin.ac().removeSpectator(var4, true);
            }

            this.plugin.a(var4, true, true, true);
            this.p1.setFight((Fight)null);
            this.p1.setOpponent((Party)null);
         }
      }

      if (this.arena != null) {
         this.arena.setUsing(false, (Fight)null);
      }

      this.ended = true;
      super.ended = System.currentTimeMillis();
   }

   private void doElo(Party var1, int var2, Party var3, int var4) {
      int var7 = var2;
      int var8 = var4;
      int var9;
      if (var2 > var4) {
         var9 = var2 - var4;
         if (var9 > 100 && var9 <= 200) {
            var7 = var2 + 4;
            var8 = var4 - 4;
         }

         if (var9 > 200) {
            var7 = var2 + 3;
            var8 = var4 - 3;
         }

         if (var9 > 50 && var9 <= 100) {
            var7 = var2 + 6;
            var8 = var4 - 6;
         }

         if (var9 <= 50) {
            var7 = var2 + 7;
            var8 = var4 - 7;
         }
      }

      if (var2 == var4) {
         var7 = var2 + 8;
         var8 = var4 - 8;
      }

      if (var4 > var2) {
         var9 = var4 - var2;
         if (var9 > 100 && var9 <= 150) {
            var8 = var4 - 15;
            var7 = var2 + 15;
         }

         if (var9 > 150 && var9 <= 200) {
            var8 = var4 - 17;
            var7 = var2 + 17;
         }

         if (var9 > 200) {
            var8 = var4 - 21;
            var7 = var2 + 21;
         }

         if (var9 > 50 && var9 <= 100) {
            var8 = var4 - 13;
            var7 = var2 + 13;
         }

         if (var9 <= 50) {
            var8 = var4 - 10;
            var7 = var2 + 10;
         }
      }

      int var10 = var7 - var2;
      int var11 = var8 - var4;
      String var12 = var1.getOwner() + "'s party";
      String var13 = var3.getOwner() + "'s party";
      this.sendEloChangeMsg(var3, var2, var4, var7, var8, var10, var11, var12, var13, var8 + "");
      this.sendEloChangeMsg(var1, var2, var4, var7, var7, var10, var11, var12, var13, var8 + "");
   }

   private void sendEloChangeMsg(Party var1, int var2, int var3, int var4, int var5, int var6, int var7, String var8, String var9, String var10) {
      boolean var11 = this.plugin.getConfig().getBoolean("elo-is-global-elo");

      Player var13;
      for(Iterator var12 = var1.getPlayers().iterator(); var12.hasNext(); this.plugin.a(var13, "elo-fight", u.a("<player1>", var8, "<player2>", var9, "<elo1>", var4, "<elo2>", var10, "<old1>", var2, "<old2>", var3, "<diff1>", var6, "<diff2>", var7))) {
         var13 = (Player)var12.next();
         if (var11) {
            this.plugin.kits.forEach((var2x) -> {
               if (var2x.isElo()) {
                  DefaultPlayerStats.getStats(var13.getUniqueId()).getElos().put(Stats.eloColumn(var2x), var5);
               }

            });
         } else {
            DefaultPlayerStats.getStats(var13.getUniqueId()).getElos().put(Stats.eloColumn(this.kit), var5);
         }
      }

   }
}
