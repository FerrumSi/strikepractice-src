package ga.strikepractice.fights.party.a;

import ga.strikepractice.party.Party;
import org.bukkit.inventory.ItemStack;

public abstract class a {
   private final String ge;

   public a(String var1) {
      this.ge = var1;
   }

   public String getName() {
      return this.ge;
   }

   public abstract boolean a(Party var1);

   public abstract ItemStack getIcon();

   public abstract int bl();
}
