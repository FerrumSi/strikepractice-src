package ga.strikepractice.fights.party.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.fights.party.b.c;
import ga.strikepractice.matchrecorder.replay.d;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.r;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class b {
   private static final b gf = new b();
   private final HashSet<ga.strikepractice.fights.party.a.a> gg = new HashSet();

   public void e(final StrikePractice var1) {
      Material var2 = Material.getMaterial(var1.getConfig().getString("party.ffa-item"));
      final ItemStack var3 = new ItemStack(var2 == null ? Material.DIAMOND : var2);
      ItemMeta var4 = var3.getItemMeta();
      var4.setDisplayName(f.K(var1.getConfig().getString("party.ffa-item-name")));
      ArrayList var5 = new ArrayList();
      Iterator var6 = var1.getConfig().getStringList("party.ffa-item-lore").iterator();

      while(var6.hasNext()) {
         String var7 = (String)var6.next();
         var5.add(f.K(var7));
      }

      var4.setLore(var5);
      var3.setItemMeta(var4);
      final int var24 = var1.getConfig().getInt("party.ffa-item-slot");
      this.gg.add(new ga.strikepractice.fights.party.a.a("partyffa") {
         public boolean a(Party var1x) {
            Player var2 = Bukkit.getPlayer(var1x.getOwner());
            if (var2 != null) {
               if (var1x.getMembersNames().size() == 1) {
                  var1.a(var2, "not-enough-players");
                  return false;
               }

               var1.L.a(var2, new ga.strikepractice.fights.party.b.a(var1x), BattleKitType.PARTY_FFA);
            }

            return true;
         }

         public int bl() {
            return var24;
         }

         public ItemStack getIcon() {
            return var1.getConfig().getBoolean("party.party-ffa-enabled") ? var3 : new ItemStack(Material.AIR);
         }
      });
      Material var25 = Material.getMaterial(var1.getConfig().getString("party.split-item"));
      final ItemStack var8 = new ItemStack(var25 == null ? Material.DIAMOND : var25);
      ItemMeta var9 = var8.getItemMeta();
      var9.setDisplayName(f.K(var1.getConfig().getString("party.split-item-name")));
      ArrayList var10 = new ArrayList();
      Iterator var11 = var1.getConfig().getStringList("party.split-item-lore").iterator();

      while(var11.hasNext()) {
         String var12 = (String)var11.next();
         var10.add(f.K(var12));
      }

      var9.setLore(var10);
      var8.setItemMeta(var9);
      final int var26 = var1.getConfig().getInt("party.split-item-slot");
      this.gg.add(new ga.strikepractice.fights.party.a.a("partysplit") {
         public boolean a(Party var1x) {
            Player var2 = Bukkit.getPlayer(var1x.getOwner());
            if (var2 != null) {
               if (var1x.getMembersNames().size() == 1) {
                  var1.a(var2, "not-enough-players");
                  return false;
               }

               var1.L.a(var2, new ga.strikepractice.fights.party.b.b(var1x), BattleKitType.PARTY_SPLIT);
            }

            return true;
         }

         public int bl() {
            return var26;
         }

         public ItemStack getIcon() {
            return var1.getConfig().getBoolean("party.party-split-enabled") ? var8 : new ItemStack(Material.AIR);
         }
      });
      if (var1.I) {
         Material var27 = Material.getMaterial(var1.getConfig().getString("party.party-playback-item"));
         final ItemStack var13 = new ItemStack(var27 == null ? Material.DIAMOND : var27);
         ItemMeta var14 = var13.getItemMeta();
         var14.setDisplayName(f.K(var1.getConfig().getString("party.party-playback-item-name")));
         ArrayList var15 = new ArrayList();
         Iterator var16 = var1.getConfig().getStringList("party.party-playback-item-lore").iterator();

         while(var16.hasNext()) {
            String var17 = (String)var16.next();
            var15.add(f.K(var17));
         }

         var14.setLore(var15);
         var13.setItemMeta(var14);
         final int var28 = var1.getConfig().getInt("party.party-playback-item-slot");
         this.gg.add(new ga.strikepractice.fights.party.a.a("partyplayback") {
            public boolean a(Party var1x) {
               Player var2 = Bukkit.getPlayer(var1x.getOwner());
               if (var2 != null) {
                  if (!ga.strikepractice.k.b.a(var2, ga.strikepractice.k.a.pU)) {
                     var1.a(var2, "no-permission");
                     return true;
                  }

                  d.a(var2, 0);
               }

               return true;
            }

            public int bl() {
               return var28;
            }

            public ItemStack getIcon() {
               return var1.getConfig().getBoolean("party.party-playback-enabled") ? var13 : new ItemStack(Material.AIR);
            }
         });
         Material var29 = Material.getMaterial(var1.getConfig().getString("party.party-vs-bots-item"));
         final ItemStack var18 = new ItemStack(var29 == null ? Material.SKULL_ITEM : var29);
         ItemMeta var19 = var18.getItemMeta();
         var19.setDisplayName(f.K(var1.getConfig().getString("party.party-vs-bots-item-name")));
         ArrayList var20 = new ArrayList();
         Iterator var21 = var1.getConfig().getStringList("party.party-vs-bots-item-lore").iterator();

         while(var21.hasNext()) {
            String var22 = (String)var21.next();
            var20.add(f.K(var22));
         }

         var19.setLore(var20);
         var18.setItemMeta(var19);
         final int var23 = var1.getConfig().getInt("party.party-vs-bots-item-slot");
         this.gg.add(new ga.strikepractice.fights.party.a.a("partybots") {
            public boolean a(Party var1x) {
               Player var2 = Bukkit.getPlayer(var1x.getOwner());
               if (var2 != null) {
                  if (!ga.strikepractice.k.b.a(var2, ga.strikepractice.k.a.pV)) {
                     var1.a(var2, "no-permission");
                     return true;
                  }

                  var1.L.a(var2, new c(var1x), BattleKitType.BOT_FIGHT);
               } else {
                  Bukkit.getLogger().warning(var1x.getOwner() + " couldn't be found OwO send this message to Toppe");
               }

               return true;
            }

            public int bl() {
               return var23;
            }

            public ItemStack getIcon() {
               return var1.getConfig().getBoolean("party.party-vs-bots-enabled") ? var18 : new ItemStack(Material.AIR);
            }
         });
      }

   }

   public ga.strikepractice.fights.party.a.a k(String var1) {
      Iterator var2 = this.gg.iterator();

      ga.strikepractice.fights.party.a.a var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (ga.strikepractice.fights.party.a.a)var2.next();
      } while(!var3.getName().equalsIgnoreCase(var1));

      return var3;
   }

   public ga.strikepractice.fights.party.a.a a(ItemStack var1) {
      if (!r.h(var1)) {
         return null;
      } else {
         Iterator var2 = this.gg.iterator();

         ga.strikepractice.fights.party.a.a var3;
         do {
            if (!var2.hasNext()) {
               return null;
            }

            var3 = (ga.strikepractice.fights.party.a.a)var2.next();
         } while(!var3.getIcon().equals(var1));

         return var3;
      }
   }

   public Collection<ga.strikepractice.fights.party.a.a> bm() {
      return this.gg;
   }

   public static b bn() {
      return gf;
   }
}
