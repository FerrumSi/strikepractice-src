package ga.strikepractice.fights.party.b;

import ga.strikepractice.party.Party;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class a implements InventoryHolder {
   private final Party gx;

   public a(Party var1) {
      this.gx = var1;
   }

   public Inventory getInventory() {
      return null;
   }

   public Party getParty() {
      return this.gx;
   }
}
