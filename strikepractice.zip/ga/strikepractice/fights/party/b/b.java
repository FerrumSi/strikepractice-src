package ga.strikepractice.fights.party.b;

import ga.strikepractice.party.Party;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class b implements InventoryHolder {
   private final Party gy;

   public b(Party var1) {
      this.gy = var1;
   }

   public Inventory getInventory() {
      return null;
   }

   public Party getParty() {
      return this.gy;
   }
}
