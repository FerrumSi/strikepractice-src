package ga.strikepractice.fights.party.b;

import ga.strikepractice.party.Party;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class d implements InventoryHolder {
   private final Party gA;
   private final Party gB;

   public d(Party var1, Party var2) {
      this.gA = var1;
      this.gB = var2;
   }

   public Inventory getInventory() {
      return null;
   }

   public Party getParty() {
      return this.gA;
   }

   public Party getParty2() {
      return this.gB;
   }
}
