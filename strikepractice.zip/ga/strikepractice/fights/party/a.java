package ga.strikepractice.fights.party;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.battlekit.e;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.party.a.b;
import ga.strikepractice.fights.party.b.d;
import ga.strikepractice.fights.party.partyfights.PartyFFA;
import ga.strikepractice.fights.party.partyfights.PartySplit;
import ga.strikepractice.fights.party.partyfights.PartyVsBots;
import ga.strikepractice.fights.party.partyfights.PartyVsParty;
import ga.strikepractice.fights.requests.FightRequest;
import ga.strikepractice.fights.requests.PartyVsPartyRequest;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.r;
import ga.strikepractice.utils.u;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class a implements Listener {
   private final StrikePractice gd;

   public a(StrikePractice var1) {
      this.gd = var1;
   }

   public static void a(Player var0, String[] var1, StrikePractice var2) {
      Party var3 = Party.getParty(var0);
      if (var3 != null) {
         if (!var3.isInFight() && !PvPEvent.isInEvent(var0)) {
            if (var1.length > 0) {
               Iterator var4 = var3.getMembersNames().iterator();

               String var5;
               Player var6;
               label73:
               do {
                  while(var4.hasNext()) {
                     var5 = (String)var4.next();
                     var6 = Bukkit.getPlayer(var5);
                     if (var6 != null) {
                        continue label73;
                     }

                     var3.getMembersNames().remove(var5);
                  }

                  if (var1.length == 1) {
                     b(var0, var2);
                  } else {
                     Player var10 = Bukkit.getPlayer(var1[1]);
                     if (var10 != null) {
                        Party var11 = Party.getParty(var10);
                        if (var11 != null) {
                           if (!var3.isInFight() && !var11.isInFight()) {
                              Collection var12 = FightRequest.getPartyRequestsForPlayer(var0);
                              Iterator var7 = var12.iterator();

                              PartyVsPartyRequest var8;
                              PartyVsParty var9;
                              do {
                                 if (!var7.hasNext()) {
                                    var2.a(var0, "party-has-not-dueled");
                                    return;
                                 }

                                 var8 = (PartyVsPartyRequest)var7.next();
                                 var9 = (PartyVsParty)var8.getFight();
                              } while(!var9.p2.equals(var8.getDueled()) || !var9.p1.equals(var8.getDueler()) || var8.hasExpired());

                              if (var9.canStart()) {
                                 var9.start();
                              } else {
                                 c.e(var0);
                              }

                              return;
                           }

                           var2.a(var0, "in-fight");
                           return;
                        }

                        var0.sendMessage(ChatColor.RED + "Player not found or not in party.");
                     } else {
                        var0.sendMessage(ChatColor.RED + "Player not found or not in party.");
                     }

                     b(var0, var2);
                  }

                  return;
               } while(AbstractFight.getCurrentFight(var6) == null && !PvPEvent.isInEvent(var6));

               var0.sendMessage(ChatColor.RED + "Can't start! The player " + var5 + " is in a duel!");
            }
         } else {
            var2.a(var0, "can-not-do-party-commands");
         }
      }
   }

   private static void b(Player var0, StrikePractice var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, f.K(var1.getConfig().getString("party.inventory-title")));
      int var3 = 0;
      String var4 = f.K(var1.getConfig().getString("party.in-match-party"));
      String var5 = f.K(var1.getConfig().getString("party.not-in-match-party"));
      String var6 = var1.getConfig().getString("party.member");
      String var7 = var6 == null ? null : f.K(var6);
      int var8 = var1.getConfig().getInt("party.show-members-limit");
      Iterator var9 = Bukkit.getOnlinePlayers().iterator();

      while(var9.hasNext()) {
         Player var10 = (Player)var9.next();
         Party var11 = Party.getParty(var10);
         if (var11 != null && var11.getOwner().equals(var10.getName())) {
            Set var12 = var11.getMembersNames();
            ItemStack var13 = new ItemStack(Material.SKULL_ITEM);
            var13.setAmount(var12.size());
            ItemMeta var14 = var13.getItemMeta();
            ArrayList var15 = new ArrayList(var12.size());
            if (var7 != null) {
               int var16 = 0;
               Iterator var17 = var12.iterator();

               while(var17.hasNext()) {
                  String var18 = (String)var17.next();
                  Player var19 = Bukkit.getPlayer(var18);
                  if (var19 != null) {
                     ++var16;
                     var15.add(var7.replace("<name>", var19.getName()));
                     if (var16 == var8 && var12.size() - 1 > var16) {
                        String var20 = var1.getConfig().getString("party.show-members-limit-reached");
                        if (var20 != null) {
                           var15.add(f.K(var20.replace("<more_members>", var11.getMembersNames().size() - var16 + "")));
                        }
                        break;
                     }
                  }
               }
            }

            var14.setLore(var15);
            if (var10.getName().equals(var0.getName())) {
               var13.setDurability((short)1);
               var14.setDisplayName(f.K(var1.getConfig().getString("party.your-party")).replace("<player>", var10.getName()));
            } else if (var11.isInFight()) {
               var13.setDurability((short)0);
               var14.setDisplayName(var4.replace("<name>", var10.getName()));
            } else {
               var13.setDurability((short)3);
               var14.setDisplayName(var5.replace("<name>", var10.getName()));
            }

            var13.setItemMeta(var14);
            var2.addItem(new ItemStack[]{var13});
            ++var3;
            if (var3 == 44) {
               break;
            }
         }
      }

      var9 = b.bn().bm().iterator();

      while(var9.hasNext()) {
         ga.strikepractice.fights.party.a.a var21 = (ga.strikepractice.fights.party.a.a)var9.next();
         var2.setItem(var21.bl(), var21.getIcon());
      }

      var0.openInventory(var2);
   }

   @EventHandler
   public void a(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player && r.h(var1.getCurrentItem())) {
         Player var2 = (Player)var1.getWhoClicked();
         String var5;
         if (var1.getView().getTitle().equals(f.K(this.gd.getConfig().getString("party.inventory-title")))) {
            var1.setCancelled(true);
            Party var12 = Party.getParty(var2);
            if (var12 != null) {
               if (!var12.getOwner().equals(var2.getName())) {
                  this.gd.a(var2, "not-own-party");
                  return;
               }

               if (!var12.getMembersNames().isEmpty() && var1.getCurrentItem().getItemMeta().hasDisplayName()) {
                  ga.strikepractice.fights.party.a.a var15 = b.bn().a(var1.getCurrentItem());
                  if (var15 != null) {
                     var15.a(var12);
                     return;
                  }

                  if (var1.getCurrentItem().getType().equals(Material.SKULL_ITEM) && var1.getCurrentItem().getItemMeta().hasLore()) {
                     var5 = f.K(this.gd.getConfig().getString("party.member"));
                     String[] var19 = var5.split("<name>");
                     String var7 = (String)var1.getCurrentItem().getItemMeta().getLore().get(0);
                     if (var19.length > 0) {
                        var7 = var7.replace(var19[0], "");
                     }

                     if (var19.length > 1) {
                        var7 = var7.replace(var19[1], "");
                     }

                     Player var8 = Bukkit.getPlayer(var7);
                     if (var8 == null) {
                        var2.closeInventory();
                        return;
                     }

                     Party var9 = Party.getParty(var8);
                     if (var9 == var12 || var9 == null) {
                        var2.closeInventory();
                        return;
                     }

                     if (!var9.isInFight()) {
                        this.gd.L.a(var2, new d(var12, var9), BattleKitType.PARTY_VS_PARTY);
                     } else {
                        this.gd.a(var2, "can-not-duel-that-party");
                        var2.closeInventory();
                     }
                  }
               }
            }
         } else if (var1.getView().getTitle().equals(ChatColor.GREEN + "Open Parties")) {
            var1.setCancelled(true);
            if (Party.getParty(var2) != null) {
               this.gd.a(var2, "can-not-do-while-in-party");
               var2.closeInventory();
               return;
            }

            if (PvPEvent.isInEvent(var2) || AbstractFight.getCurrentFight(var2) != null) {
               this.gd.a(var2, "can-not-do-party-commands");
               return;
            }

            String var3 = f.K(this.gd.getConfig().getString("party.member"));
            String[] var4 = var3.split("<name>");
            var5 = (String)var1.getCurrentItem().getItemMeta().getLore().get(0);
            if (var4.length > 0) {
               var5 = var5.replace(var4[0], "");
            }

            Player var6 = Bukkit.getPlayer(var5);
            if (var6 == null || Party.getParty(var6) == null) {
               var2.closeInventory();
               return;
            }

            var2.chat("/party join " + var5);
         }

         if (var1.getInventory().getHolder() == null) {
            return;
         }

         if (var1.getView().getTitle().equals(f.K(this.gd.getConfig().getString("inventory-title")))) {
            var1.setCancelled(true);
            if (var1.getCurrentItem().getItemMeta().hasDisplayName() && var1.getSlot() == var1.getInventory().getSize() - 1 && this.gd.getConfig().getBoolean("kit-editor-in-kit-selector")) {
               this.gd.Y().az(var2);
               return;
            }

            BattleKit var17;
            BattleKit var20;
            Party var21;
            BattleKit var26;
            if (var1.getInventory().getHolder() instanceof ga.strikepractice.fights.party.b.a) {
               ga.strikepractice.fights.party.b.a var13 = (ga.strikepractice.fights.party.b.a)var1.getInventory().getHolder();
               if (var13.getParty().getOwner().equals(var2.getName())) {
                  var17 = BattleKit.getKit(var2, var1.getCurrentItem(), false);
                  var20 = this.gd.Y().getPlayerKits(var2).getCustomKit();
                  if (var20 != null && var1.getCurrentItem().equals(var20.getIcon())) {
                     var17 = var20;
                  } else if (var17 == null) {
                     var2.sendMessage(ChatColor.RED + "Error: invalid kit.. please try another kit and contact admins!");
                     return;
                  }

                  if ((var1.getClick() == ClickType.SHIFT_LEFT || var1.getClick() == ClickType.SHIFT_RIGHT) && this.gd.getConfig().getBoolean("preview.shift-click-preview")) {
                     ga.strikepractice.m.a.a(var2, var17, this.gd);
                     return;
                  }

                  var21 = Party.getParty(var2);
                  if (var21.getMembersNames().size() < 2) {
                     this.gd.a(var2, "not-enough-players");
                     var2.closeInventory();
                     return;
                  }

                  var26 = e.a(var17, false, BattleKitType.PARTY_FFA, BattleKitType.ANY);
                  PartyFFA var24 = new PartyFFA(this.gd, var21, var26);
                  new ga.strikepractice.fights.a.b(var2, var26, (var2x) -> {
                     var24.setArena(var2x);
                     if (var24.canStart()) {
                        var24.start();
                        var2.closeInventory();
                     } else {
                        c.e(var2);
                     }

                  });
               }
            } else if (var1.getInventory().getHolder() instanceof ga.strikepractice.fights.party.b.b) {
               ga.strikepractice.fights.party.b.b var14 = (ga.strikepractice.fights.party.b.b)var1.getInventory().getHolder();
               if (var14.getParty().getOwner().equals(var2.getName())) {
                  var17 = BattleKit.getKit(var2, var1.getCurrentItem(), false);
                  var20 = this.gd.Y().getPlayerKits(var2).getCustomKit();
                  if (var20 != null && var1.getCurrentItem().equals(var20.getIcon())) {
                     var17 = var20;
                  } else if (var17 == null) {
                     var2.sendMessage(ChatColor.RED + "Error: invalid kit.. please try another kit and contact admins!");
                     return;
                  }

                  if ((var1.getClick() == ClickType.SHIFT_LEFT || var1.getClick() == ClickType.SHIFT_RIGHT) && this.gd.getConfig().getBoolean("preview.shift-click-preview")) {
                     ga.strikepractice.m.a.a(var2, var17, this.gd);
                     return;
                  }

                  var21 = var14.getParty();
                  if (var21.getMembersNames().size() < 2) {
                     this.gd.a(var2, "not-enough-players");
                     var2.closeInventory();
                     return;
                  }

                  var26 = e.a(var17, false, BattleKitType.PARTY_SPLIT, BattleKitType.ANY);
                  new ga.strikepractice.fights.a.b(var2, var26, (var4x) -> {
                     PartySplit var5 = new PartySplit(this.gd, var21, var26);
                     var5.setArena(var4x);
                     if (var5.canStart()) {
                        var5.start();
                        var2.closeInventory();
                     } else {
                        c.e(var2);
                     }

                  });
               }
            } else if (var1.getInventory().getHolder() instanceof ga.strikepractice.fights.party.b.c) {
               var1.setCancelled(true);
               ga.strikepractice.fights.party.b.c var16 = (ga.strikepractice.fights.party.b.c)var1.getInventory().getHolder();
               if (!var16.getParty().getOwner().equals(var2.getName())) {
                  return;
               }

               var17 = BattleKit.getKit(var2, var1.getCurrentItem(), false);
               var20 = this.gd.Y().getPlayerKits(var2).getCustomKit();
               if (var20 != null && var1.getCurrentItem().equals(var20.getIcon())) {
                  var17 = var20;
               } else if (var17 == null) {
                  var2.sendMessage(ChatColor.RED + "Error: invalid kit.. please try another kit and contact admins!");
                  return;
               }

               if ((var1.getClick() == ClickType.SHIFT_LEFT || var1.getClick() == ClickType.SHIFT_RIGHT) && this.gd.getConfig().getBoolean("preview.shift-click-preview")) {
                  ga.strikepractice.m.a.a(var2, var17, this.gd);
                  return;
               }

               BattleKit var23 = e.a(var17, false, BattleKitType.BOT_FIGHT, BattleKitType.ANY);
               PartyVsBots var28 = new PartyVsBots(this.gd, var16.getParty(), var23);
               new ga.strikepractice.fights.a.b(var2, var17, (var3x) -> {
                  if (var16.getParty() != null) {
                     var28.setArena(var3x);
                     ga.strikepractice.npc.e.a(var2, var28);
                  }

               });
            } else if (var1.getInventory().getHolder() instanceof d) {
               var1.setCancelled(true);
               d var18 = (d)var1.getInventory().getHolder();
               if (!var18.getParty().getOwner().equals(var2.getName())) {
                  return;
               }

               Player var25 = Bukkit.getPlayer(var18.getParty2().getOwner());
               Party var22 = Party.getParty(var25);
               var21 = Party.getParty(var2);
               if (var22 != null && !var22.isInFight() && !var21.isInFight()) {
                  var26 = BattleKit.getKit(var2, var1.getCurrentItem(), false);
                  BattleKit var27 = this.gd.Y().getPlayerKits(var2).getCustomKit();
                  if (var27 != null && var1.getCurrentItem().equals(var27.getIcon())) {
                     var26 = var27;
                  }

                  if (var26 == null) {
                     var2.sendMessage(ChatColor.RED + "Error: invalid kit, please try other kits and contact admins!");
                     return;
                  }

                  if ((var1.getClick() == ClickType.SHIFT_LEFT || var1.getClick() == ClickType.SHIFT_RIGHT) && this.gd.getConfig().getBoolean("preview.shift-click-preview")) {
                     ga.strikepractice.m.a.a(var2, var27, this.gd);
                     return;
                  }

                  BattleKit var29 = e.a(var26, false, BattleKitType.PARTY_VS_PARTY, BattleKitType.ANY);
                  PartyVsParty var10 = new PartyVsParty(this.gd, var21, var22, var29);
                  new ga.strikepractice.fights.a.b(var2, var29, (var8x) -> {
                     if (var22 != null && var21 != null) {
                        var10.setArena(var8x);
                        FightRequest.addPartyRequest(var25, new PartyVsPartyRequest(var21, var22, var10));
                        String var10x;
                        if (var10.getKit().equals(var27)) {
                           if (this.gd.getConfig().getBoolean("clickable-messages")) {
                              UUID var9 = UUID.randomUUID();
                              ga.strikepractice.m.a.rm.put(var9, var27);
                              var10x = f.K(this.gd.getConfig().getString("preview-custom-kit"));
                              Iterator var11 = var22.getMembersNames().iterator();

                              String var12;
                              Player var13;
                              while(var11.hasNext()) {
                                 var12 = (String)var11.next();
                                 var13 = Bukkit.getPlayer(var12);
                                 if (var13 != null) {
                                    ga.strikepractice.utils.d.b(var13, var10x, "/previewkit " + var9);
                                 }
                              }

                              var11 = var22.getMembersNames().iterator();

                              while(var11.hasNext()) {
                                 var12 = (String)var11.next();
                                 var13 = Bukkit.getPlayer(var12);
                                 if (var13 != null) {
                                    this.gd.a(var13, "party-wants-duel-with-custom-kit", u.a("<player>", var2.getName(), "<sender>", var2.getName(), "<target>", var25.getName(), "<kit>", var27.getFancyName(), "<arena>", var8x == null ? "random" : var8x.getDisplayName(), "<combo>", var27.isCombo(), "<horse>", var27.isHorse(), "<bow>", var27.isOnlyBow()));
                                 }
                              }
                           }
                        } else {
                           Iterator var14 = var22.getMembersNames().iterator();

                           while(var14.hasNext()) {
                              var10x = (String)var14.next();
                              Player var15 = Bukkit.getPlayer(var10x);
                              if (var15 != null) {
                                 this.gd.a(var15, "party-wants-duel", u.a("<player>", var2.getName(), "<sender>", var2.getName(), "<target>", var25.getName(), "<kit>", var26.getFancyName(), "<arena>", var8x == null ? "random" : var8x.getDisplayName(), "<combo>", var26.isRandomKit() ? "random" : var26.isCombo(), "<horse>", var26.isRandomKit() ? "random" : var26.isHorse(), "<bow>", var26.isRandomKit() ? "random" : var26.isOnlyBow()));
                              }
                           }
                        }

                        var2.closeInventory();
                        this.gd.a(var2, "request-sent", u.a("<player>", var2.getName(), "<target>", var25.getName(), "<sender>", var2.getName(), "<kit>", var26.getFancyName(), "<arena>", var8x != null ? var8x.getDisplayName() : "random"));
                        if (this.gd.getConfig().getBoolean("clickable-messages")) {
                           ga.strikepractice.utils.d.b(var25, f.K(this.gd.getConfig().getString("clickable-message")), "/party match " + var2.getName());
                        }

                     } else {
                        if (var2 != null) {
                           var2.sendMessage(ChatColor.RED + "Invalid opponent party!");
                        }

                     }
                  });
               } else {
                  this.gd.a(var2, "in-fight");
               }
            }
         }
      }

   }
}
