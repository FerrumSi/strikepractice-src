package ga.strikepractice.fights.b;

import ga.strikepractice.StrikePractice;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class d implements CommandExecutor {
   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 0) {
         Player var5 = Bukkit.getPlayer(var4[0]);
         if (var5 != null) {
            var1.sendMessage(var5.getName() + "'s rank is " + StrikePractice.getInstance().aj().K(var5).getName());
            return true;
         }
      }

      var1.sendMessage(StrikePractice.getInstance().X() + ChatColor.GREEN + "All ranks:");
      var1.sendMessage("");
      ga.strikepractice.fights.b.a var8 = var1 instanceof Player ? StrikePractice.getInstance().aj().K((Player)var1) : null;
      Iterator var6 = StrikePractice.getInstance().aj().bM().iterator();

      while(var6.hasNext()) {
         ga.strikepractice.fights.b.a var7 = (ga.strikepractice.fights.b.a)var6.next();
         if (var8 == var7) {
            var1.sendMessage(ChatColor.BOLD + var7.getName() + ChatColor.GRAY + ChatColor.BOLD + " (" + var7.bJ() + "-" + var7.bI() + ")");
         } else {
            var1.sendMessage(var7.getName() + ChatColor.GRAY + " (" + var7.bJ() + "-" + var7.bI() + ")");
         }
      }

      if (var1 instanceof Player) {
         var1.sendMessage("");
         StrikePractice.getInstance().aj().J((Player)var1);
      }

      return true;
   }
}
