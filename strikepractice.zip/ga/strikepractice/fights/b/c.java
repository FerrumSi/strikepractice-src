package ga.strikepractice.fights.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.u;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class c {
   private final List<ga.strikepractice.fights.b.a> hq = new ArrayList();
   private final StrikePractice hr;

   public c(StrikePractice var1) {
      this.hr = var1;
   }

   public void bK() {
      try {
         Iterator var1 = this.hr.getConfig().getConfigurationSection("elo-ranks.ranks").getKeys(false).iterator();

         while(var1.hasNext()) {
            String var2 = (String)var1.next();
            String var3 = f.K(this.hr.getConfig().getString("elo-ranks.ranks." + var2 + ".name"));
            String var4 = this.hr.getConfig().getString("elo-ranks.ranks." + var2 + ".elo-range");
            String[] var5 = var4.replace(" ", "").split("-");
            if (var5.length == 2) {
               int var6 = Integer.parseInt(var5[0]);
               int var7 = Integer.parseInt(var5[1]);
               this.hq.add(new ga.strikepractice.fights.b.a(var3, var2, var6, var7));
            }
         }
      } catch (Exception var8) {
         var8.printStackTrace();
         Bukkit.getLogger().warning("----------------------------------------");
         Bukkit.getLogger().warning("");
         Bukkit.getLogger().warning("Failed to load elo ranks. Check your config.yml");
         Bukkit.getLogger().warning("");
         Bukkit.getLogger().warning("----------------------------------------");
      }

      (new BukkitRunnable() {
         public void run() {
            for(int var1 = ga.strikepractice.b.a.cM + 1000; var1 < ga.strikepractice.b.a.cM + 1000; ++var1) {
               int var2 = 0;
               Iterator var3 = c.this.hq.iterator();

               while(var3.hasNext()) {
                  ga.strikepractice.fights.b.a var4 = (ga.strikepractice.fights.b.a)var3.next();
                  if (var1 <= var4.bI() && var1 >= var4.bJ()) {
                     ++var2;
                     if (var2 > 1) {
                        Bukkit.getLogger().warning("StrikePractice >> Elo rank " + var4.getIdentifier() + " overlaps with other elo ranks!");
                     }
                  }
               }
            }

         }
      }).runTaskAsynchronously(this.hr);
   }

   public boolean bL() {
      return this.hr.getConfig().getBoolean("elo-ranks.send-everytime");
   }

   public void J(Player var1) {
      this.a(var1, this.K(var1));
   }

   public void a(Player var1, ga.strikepractice.fights.b.a var2) {
      this.hr.a(var1, "rank-message", u.a("<rank>", var2 == null ? "<rank>" : var2.getName()));
   }

   public List<ga.strikepractice.fights.b.a> bM() {
      return this.hq;
   }

   public ga.strikepractice.fights.b.a K(Player var1) {
      if (var1 == null) {
         return null;
      } else {
         DefaultPlayerStats var2 = DefaultPlayerStats.getStats(var1.getUniqueId());
         return var2 == null ? null : this.h(var2.getGlobalElo());
      }
   }

   public ga.strikepractice.fights.b.a h(int var1) {
      Iterator var2 = this.hq.iterator();

      ga.strikepractice.fights.b.a var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (ga.strikepractice.fights.b.a)var2.next();
      } while(var1 > var3.bI() || var1 < var3.bJ());

      return var3;
   }
}
