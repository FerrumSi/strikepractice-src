package ga.strikepractice.fights.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.events.DuelEndEvent;
import ga.strikepractice.utils.C;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;

public class b implements Listener {
   private final StrikePractice hj;

   public b(StrikePractice var1) {
      this.hj = var1;
   }

   @EventHandler
   public void b(DuelEndEvent var1) {
      C.c(() -> {
         if (var1.getFight().getKit() != null && var1.getFight().getKit().isElo()) {
            final Player var2 = var1.getWinner();
            final Player var3 = var1.getLoser();
            final c var4 = this.hj.aj();
            if (var4.bL()) {
               var4.J(var2);
               var4.J(var3);
            } else {
               final ga.strikepractice.fights.b.a var5 = var4.K(var2);
               final ga.strikepractice.fights.b.a var6 = var4.K(var3);
               (new BukkitRunnable() {
                  public void run() {
                     ga.strikepractice.fights.b.a var1;
                     if (var2 != null) {
                        var1 = var4.K(var2);
                        if (var5 != var1) {
                           var4.a(var2, var1);
                        }
                     }

                     if (var3 != null) {
                        var1 = var4.K(var3);
                        if (var6 != var1) {
                           var4.a(var3, var1);
                        }
                     }

                  }
               }).runTaskLaterAsynchronously(this.hj, 5L);
            }
         }

      });
   }
}
