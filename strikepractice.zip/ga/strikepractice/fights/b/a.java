package ga.strikepractice.fights.b;

public class a {
   private int hg;
   private int hh;
   private String name;
   private String hi;

   public a(String var1, String var2, int var3, int var4) {
      this.name = var1;
      this.hi = var2;
      this.hg = var3;
      this.hh = var4;
   }

   public String getIdentifier() {
      return this.hi;
   }

   public int bI() {
      return this.hh;
   }

   public int bJ() {
      return this.hg;
   }

   public String getName() {
      return this.name;
   }

   public void m(String var1) {
      this.hi = var1;
   }

   public void f(int var1) {
      this.hg = var1;
   }

   public void g(int var1) {
      this.hh = var1;
   }

   public void setName(String var1) {
      this.name = var1;
   }
}
