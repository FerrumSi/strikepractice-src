package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.P;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007¨\u0006\u0007"},
   d2 = {"Lga/strikepractice/fights/TeleportDebug;", "Lorg/bukkit/event/Listener;", "()V", "onTeleport", "", "e", "Lorg/bukkit/event/player/PlayerTeleportEvent;", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nTeleportListener.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TeleportListener.kt\nga/strikepractice/fights/TeleportDebug\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,40:1\n1#2:41\n*E\n"})
public final class e implements Listener {
   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public final void b(@NotNull PlayerTeleportEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (var1.getFrom().getWorld() == var1.getTo().getWorld()) {
         Location var2 = var1.getFrom().clone();
         boolean var4 = false;
         var2.setY(0.0D);
         Location var10000 = var2;
         var2 = var1.getTo().clone();
         Location var5 = var10000;
         var4 = false;
         var2.setY(0.0D);
         if (!(var5.distanceSquared(var2) > 40000.0D)) {
            return;
         }
      }

      if (B.vj.fV() || StrikePractice.getInstance().getConfig().getBoolean("teleport-debug")) {
         Player var6 = var1.getPlayer();
         Fight var3 = AbstractFight.getCurrentFight(var6);
         if (var3 != null && !var3.hasEnded()) {
            Bukkit.broadcast(ChatColor.RED.toString() + "Something tried to teleported the player " + var6.getName() + " while in fight. Time: " + P.gy() + ". Check logs and report this to staff and the developer of StrikePractice", ga.strikepractice.k.a.py.toString());
            Bukkit.getLogger().warning("Attempted to teleport player " + var6.getName() + " to another world");
            Bukkit.getLogger().info(var3.toString());
            Bukkit.getLogger().info("From " + (new D(var1.getFrom())).gb());
            Bukkit.getLogger().info("To " + (new D(var1.getTo())).gb());
            throw new RuntimeException("This error is just to debug the issue");
         }
      }

   }
}
