package ga.strikepractice.fights;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.u;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class DefaultMatchDurationLimit implements MatchDurationLimit {
   private final StrikePractice plugin;
   private final Fight fight;
   private int minutes = 0;
   private final int limit;
   private boolean endingSoon;

   public DefaultMatchDurationLimit(Fight var1, StrikePractice var2) {
      this.fight = var1;
      this.plugin = var2;
      this.limit = var2.getConfig().getInt("fight-duration-limit");
   }

   public void onFightStart() {
      if (this.limit < 600) {
         (new BukkitRunnable() {
            public void run() {
               if (DefaultMatchDurationLimit.this.fight.hasEnded()) {
                  this.cancel();
               } else {
                  DefaultMatchDurationLimit.this.minutes++;
                  double var1 = (double)DefaultMatchDurationLimit.this.minutes / (double)DefaultMatchDurationLimit.this.limit;
                  Iterator var3;
                  Player var4;
                  if (DefaultMatchDurationLimit.this.minutes >= DefaultMatchDurationLimit.this.limit) {
                     var3 = Bukkit.getOnlinePlayers().iterator();

                     while(true) {
                        do {
                           if (!var3.hasNext()) {
                              (new BukkitRunnable() {
                                 public void run() {
                                    DefaultMatchDurationLimit.this.fight.forceEnd((String)null);
                                 }
                              }).runTask(DefaultMatchDurationLimit.this.plugin);
                              this.cancel();
                              return;
                           }

                           var4 = (Player)var3.next();
                        } while(AbstractFight.getCurrentFight(var4) != DefaultMatchDurationLimit.this.fight && DefaultMatchDurationLimit.this.plugin.ac().eG().get(var4.getUniqueId()) != DefaultMatchDurationLimit.this.fight);

                        DefaultMatchDurationLimit.this.plugin.a(var4, "fight-duration-force-end");
                     }
                  } else if (var1 >= 0.8D) {
                     DefaultMatchDurationLimit.this.endingSoon = true;
                     var3 = Bukkit.getOnlinePlayers().iterator();

                     while(true) {
                        do {
                           if (!var3.hasNext()) {
                              return;
                           }

                           var4 = (Player)var3.next();
                        } while(AbstractFight.getCurrentFight(var4) != DefaultMatchDurationLimit.this.fight && DefaultMatchDurationLimit.this.plugin.ac().eG().get(var4.getUniqueId()) != DefaultMatchDurationLimit.this.fight);

                        DefaultMatchDurationLimit.this.plugin.a(var4, "fight-duration-limit", u.a("<limit>", DefaultMatchDurationLimit.this.limit, "<left>", DefaultMatchDurationLimit.this.limit - DefaultMatchDurationLimit.this.minutes));
                     }
                  }
               }
            }
         }).runTaskTimerAsynchronously(this.plugin, 1200L, 1200L);
      }

   }

   public boolean isEndingSoon() {
      return this.endingSoon;
   }
}
