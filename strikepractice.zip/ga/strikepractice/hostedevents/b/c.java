package ga.strikepractice.hostedevents.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.events.PvPEventEndEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.u;
import java.util.Iterator;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class c implements Listener {
   private final StrikePractice iW;

   public c(StrikePractice var1) {
      this.iW = var1;
   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      if (b.iR != null) {
         if (b.iR.cz().containsKey(var1.getPlayer().getName())) {
            var1.getPlayer().setHealth(0.0D);
            ga.strikepractice.hostedevents.b.a var2 = b.iR;
            if (var2 != null && (var2.getP1() == null || var2.getP2() == null)) {
               return;
            }

            if (!var2.getP1().equals(var1.getPlayer().getName()) && !var2.getP2().equals(var1.getPlayer().getName())) {
               b.iR.cz().remove(var1.getPlayer().getName());
               this.iW.clear(var1.getPlayer(), true, true);
            }
         }

      }
   }

   @EventHandler
   public void a(EntityDamageEvent var1) {
      if (b.iR != null && var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         if (b.iR.cz().containsKey(var2.getName()) && !AbstractFight.isInFight(var2)) {
            var1.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void a(PlayerDeathEvent var1) {
      if (b.iR != null) {
         Player var2 = var1.getEntity();
         String var3 = var2.getName();
         if (var3 != null) {
            if (b.iR.cz().containsKey(var3)) {
               b.iR.cz().remove(var3);
               if (b.iR.getP1() == null || b.iR.getP2() == null) {
                  return;
               }

               String var4 = null;
               if (b.iR.getP1().equals(var3)) {
                  var4 = b.iR.getP2();
               } else if (b.iR.getP2().equals(var3)) {
                  var4 = b.iR.getP1();
               }

               if (var4 == null) {
                  return;
               }

               Iterator var5 = b.iR.cz().keySet().iterator();

               String var6;
               Player var7;
               while(var5.hasNext()) {
                  var6 = (String)var5.next();
                  var7 = Bukkit.getPlayer(var6);
                  if (var7 != null) {
                     this.iW.a(var7, "brackets-slays", u.a("<player1>", var4, "<player2>", var3));
                  }
               }

               Player var11 = Bukkit.getPlayer(var4);
               if (var11 != null) {
                  this.iW.clear(var11, false, true);
                  b.iR.cz().put(var11.getName(), true);
               }

               if (b.iR.ct()) {
                  if (this.iW.getConfig().getBoolean("brackets.allow-spectating")) {
                     b.iR.spectators.add(var2.getUniqueId());
                  } else {
                     this.iW.clear(var2, true, true);
                  }

                  b.iR.cw();
                  if (var11 != null) {
                     b.iR.L(var11);
                  }
               } else {
                  this.iW.clear(var2, true, true);
                  if (var11 != null) {
                     this.iW.clear(var11, false, true);
                  }

                  var6 = null;

                  String var8;
                  Iterator var12;
                  for(var12 = b.iR.cz().keySet().iterator(); var12.hasNext(); var6 = var8) {
                     var8 = (String)var12.next();
                  }

                  var12 = Bukkit.getOnlinePlayers().iterator();

                  while(var12.hasNext()) {
                     Player var13 = (Player)var12.next();
                     this.iW.a(var13, "brackets-winner", u.a("<player>", var6));
                  }

                  var7 = Bukkit.getPlayer(var6);
                  PvPEventEndEvent var14 = new PvPEventEndEvent(b.iR, var7);
                  Bukkit.getPluginManager().callEvent(var14);
                  b.iR.stop();
                  UUID var9 = var7.getUniqueId();
                  DefaultPlayerStats var10 = DefaultPlayerStats.getStats(var9);
                  var10.setBracketsWins(var10.getBracketsWins() + 1);
                  if (var6 != null) {
                     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), this.iW.getConfig().getString("brackets.winner-cmd").replace("<player>", var6));
                  }
               }
            }

         }
      }
   }
}
