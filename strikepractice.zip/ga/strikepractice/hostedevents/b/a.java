package ga.strikepractice.hostedevents.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.battlekit.e;
import ga.strikepractice.events.PvPEventEndEvent;
import ga.strikepractice.events.PvPEventStartEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.u;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class a implements PvPEvent {
   protected Map<String, Boolean> players = new HashMap();
   public final Set<UUID> spectators = Collections.newSetFromMap(new ConcurrentHashMap());
   protected BattleKit kit;
   protected StrikePractice plugin;
   protected String p1;
   protected String p2;
   protected boolean iu;
   protected Duel fL;
   protected Arena arena;
   protected long startTime;
   protected boolean iI;
   public int iJ;
   protected long iK;

   public a(StrikePractice var1) {
      this.plugin = var1;
      this.iI = var1.getConfig().getBoolean("allow-brackets-spectating");
   }

   public void start() {
      PvPEventStartEvent var1 = new PvPEventStartEvent(this);
      Bukkit.getPluginManager().callEvent(var1);
      if (!var1.isCancelled()) {
         this.cs();
      }
   }

   public void cs() {
      this.startTime = System.currentTimeMillis();
      this.iu = true;
      this.cy();
      this.iJ = this.players.size();
      if (this.arena != null) {
         this.arena.setBuild(this.kit.isBuild());
      }

      Iterator var1 = this.players.keySet().iterator();

      while(true) {
         while(true) {
            Player var3;
            do {
               if (!var1.hasNext()) {
                  this.cw();
                  return;
               }

               String var2 = (String)var1.next();
               var3 = Bukkit.getPlayer(var2);
            } while(var3 == null);

            if (this.iI && this.arena != null) {
               N.e(var3, this.arena.getCenter());
               this.plugin.ac().addSpectator(var3);
            } else {
               this.L(var3);
            }
         }
      }
   }

   public boolean ct() {
      int var1 = 0;
      Iterator var2 = this.players.keySet().iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         if (Bukkit.getPlayer(var3) != null) {
            ++var1;
         }
      }

      return var1 >= 2;
   }

   public void stop() {
      PvPEventEndEvent var1 = new PvPEventEndEvent(this, (Player)null);
      Bukkit.getPluginManager().callEvent(var1);
      this.iJ = 0;
      this.iu = false;
      (new BukkitRunnable() {
         public void run() {
            Iterator var1 = a.this.players.keySet().iterator();

            while(var1.hasNext()) {
               String var2 = (String)var1.next();
               final Player var3 = Bukkit.getPlayer(var2);
               if (var3 != null) {
                  a.this.plugin.a(var3, "event-stopped");
                  if (a.this.plugin.ac().isSpectator(var3)) {
                     a.this.plugin.ac().removeSpectator(var3, true);
                  }

                  a.this.plugin.clear(var3, true, true);
                  (new BukkitRunnable() {
                     public void run() {
                        if (var3 != null) {
                           a.this.plugin.clear(var3, true, true);
                        }

                     }
                  }).runTaskLater(a.this.plugin, 40L);
               }
            }

            a.this.players.clear();
         }
      }).runTaskLater(this.plugin, (long)(20 * this.plugin.getConfig().getInt("wait-before-teleport")));
      this.p1 = null;
      this.p2 = null;
      this.cu();
      b.iR = null;
      b.iU = false;
   }

   protected void cu() {
      Iterator var1 = this.spectators.iterator();

      while(var1.hasNext()) {
         UUID var2 = (UUID)var1.next();
         final Player var3 = Bukkit.getPlayer(var2);
         if (var3 != null) {
            this.plugin.a(var3, "event-stopped");
            if (StrikePractice.u) {
               if (this.plugin.ac().isSpectator(var3)) {
                  this.plugin.ac().removeSpectator(var3, true);
               }

               this.plugin.clear(var3, true, true);
            } else {
               (new BukkitRunnable() {
                  public void run() {
                     if (a.this.plugin.ac().isSpectator(var3)) {
                        a.this.plugin.ac().removeSpectator(var3, true);
                     }

                  }
               }).runTaskLater(this.plugin, 20L);
            }
         }
      }

   }

   public String cv() {
      if (!this.iu) {
         return "--:--";
      } else {
         int var1 = this.players.size() - 1;
         int var2 = this.iJ - this.players.size();
         long var3 = System.currentTimeMillis() - this.startTime;
         long var5 = System.currentTimeMillis() - this.iK;
         long var7;
         if (var2 > 0) {
            var7 = var3 / (long)var2;
         } else if (var5 > 30L) {
            var7 = var5;
         } else {
            var7 = 30L;
         }

         long var9 = var7 * (long)var1 - var5;
         if (var9 < 5000L) {
            var9 = 5000L;
         }

         return (new SimpleDateFormat("mm:ss")).format(new Date(var9 + StrikePractice.B));
      }
   }

   public void cw() {
      (new BukkitRunnable() {
         public void run() {
            if (!a.this.ct()) {
               this.cancel();
            } else if (a.this.arena == null || !a.this.arena.needsRollback() && !a.this.arena.isUsing()) {
               int var1 = 0;
               String var2 = null;
               Iterator var3 = a.this.players.entrySet().iterator();

               Entry var4;
               while(var3.hasNext()) {
                  var4 = (Entry)var3.next();
                  if (!(Boolean)var4.getValue()) {
                     ++var1;
                     var2 = (String)var4.getKey();
                  }
               }

               String var5;
               Iterator var9;
               if (var1 < 2) {
                  HashSet var7 = new HashSet();
                  var9 = a.this.players.keySet().iterator();

                  while(var9.hasNext()) {
                     var5 = (String)var9.next();
                     if (var5 != null && Bukkit.getPlayer(var5) != null) {
                        var7.add(var5);
                     }
                  }

                  a.this.players.clear();
                  var9 = var7.iterator();

                  while(var9.hasNext()) {
                     var5 = (String)var9.next();
                     a.this.players.put(var5, false);
                  }
               }

               if (var2 == null) {
                  var3 = a.this.players.entrySet().iterator();

                  while(var3.hasNext()) {
                     var4 = (Entry)var3.next();
                     if (!(Boolean)var4.getValue()) {
                        var2 = (String)var4.getKey();
                        if (StrikePractice.t.nextInt(a.this.players.size()) == 0) {
                           break;
                        }
                     }
                  }
               }

               a.this.players.put(var2, true);
               String var8 = null;
               var9 = a.this.players.entrySet().iterator();

               while(var9.hasNext()) {
                  Entry var10 = (Entry)var9.next();
                  if (!(Boolean)var10.getValue()) {
                     var8 = (String)var10.getKey();
                     if (StrikePractice.t.nextInt(a.this.players.size()) == 0) {
                        break;
                     }
                  }
               }

               a.this.players.put(var8, true);
               if (var2 != null && var8 != null && Bukkit.getPlayer(var2) != null && Bukkit.getPlayer(var8) != null) {
                  a.this.p1 = var2;
                  a.this.p2 = var8;
                  var9 = a.this.players.keySet().iterator();

                  while(var9.hasNext()) {
                     var5 = (String)var9.next();
                     Player var6 = Bukkit.getPlayer(var5);
                     if (var6 != null) {
                        a.this.plugin.a(var6, "brackets-next-fight", u.a("<player1>", var2, "<player2>", var8));
                     }
                  }

                  if (a.this.arena == null) {
                     a.this.cy();
                  }

                  if (a.this.arena == null) {
                     Bukkit.broadcastMessage(ChatColor.RED + "Brackets cannot be started... the arena is invalid or it can not be used.");
                     a.this.stop();
                     this.cancel();
                  } else {
                     a.this.arena.removeItems();
                     BattleKit var11 = e.a(a.this.kit, false, BattleKitType.BRACKETS);
                     a.this.fL = new Duel(a.this.plugin, var2, var8, var11);
                     a.this.fL.setDoNotTeleport(true);
                     a.this.fL.setArena(a.this.arena);
                     a.this.fL.start();
                     a.this.iK = System.currentTimeMillis();
                     this.cancel();
                     a.this.cx();
                  }
               } else {
                  Bukkit.broadcastMessage(ChatColor.RED + "Error: brackets player is invalid!");
                  a.this.stop();
                  this.cancel();
               }
            }
         }
      }).runTaskTimer(this.plugin, 20L, 20L);
   }

   protected void cx() {
      Iterator var1 = Collections.unmodifiableSet(this.spectators).iterator();

      while(true) {
         while(var1.hasNext()) {
            UUID var2 = (UUID)var1.next();
            Player var3 = Bukkit.getPlayer(var2);
            if (var3 != null && !AbstractFight.isInFight(var3) && !StrikePractice.getAPI().isInQueue(var3)) {
               Location var4 = var3.getLocation();
               if (var4.getWorld() != this.arena.getCenter().getWorld() || !this.plugin.ac().isSpectator(var3) || var4.distanceSquared(this.arena.getCenter()) > 5625.0D) {
                  N.e(var3, this.arena.getCenter());
               }

               this.plugin.ac().l(var3, this.fL);
            } else {
               this.spectators.remove(var2);
            }
         }

         return;
      }
   }

   public void L(Player var1) {
      Location var2 = t("brackets");
      if (var2 != null) {
         this.plugin.clear(var1, false, false);
         if (this.iI && this.arena != null) {
            N.e(var1, this.arena.getCenter());
            this.plugin.ac().addSpectator(var1);
         } else {
            N.e(var1, var2);
         }
      } else if (this.iI && this.arena != null) {
         N.e(var1, this.arena.getCenter());
         this.plugin.ac().addSpectator(var1);
      }

   }

   public void cy() {
      Iterator var1 = this.plugin.M.iterator();

      Arena var2;
      while(var1.hasNext()) {
         var2 = (Arena)var1.next();
         if (var2.getName().toLowerCase().contains("brackets") && var2.getKits().contains(this.kit.getName().toLowerCase())) {
            this.arena = var2;
            this.arena.setCustomMaxChangesPerTick(20);
         }
      }

      if (this.arena == null) {
         var1 = this.plugin.M.iterator();

         while(var1.hasNext()) {
            var2 = (Arena)var1.next();
            if (var2.getName().equalsIgnoreCase("brackets")) {
               this.arena = var2;
               this.arena.setCustomMaxChangesPerTick(20);
            }
         }
      }

      if (this.arena != null) {
         this.arena.setUsing(false);
      }

   }

   public static Location t(String var0) {
      Object var1 = StrikePractice.getInstance().getConfig().get(var0 + ".lobby");
      if (var1 == null) {
         Bukkit.getLogger().warning(ChatColor.RED + "Brackets lobby is not valid!");
         return null;
      } else {
         return ((D)var1).ga();
      }
   }

   public String getP1() {
      return this.p1;
   }

   public Duel bh() {
      return this.fL;
   }

   public String getP2() {
      return this.p2;
   }

   public BattleKit getKit() {
      return this.kit;
   }

   /** @deprecated */
   @Deprecated
   public HashMap<String, Boolean> cz() {
      return (HashMap)this.players;
   }

   public Map<String, Boolean> cA() {
      return this.players;
   }

   public long getStartTime() {
      return this.startTime;
   }

   public Arena getArena() {
      return this.arena;
   }

   public boolean hasStarted() {
      return this.iu;
   }

   public void setKit(BattleKit var1) {
      this.kit = var1;
   }

   public void u(String var1) {
      this.p1 = var1;
   }

   public void v(String var1) {
      this.p2 = var1;
   }

   /** @deprecated */
   @Deprecated
   public void a(HashMap<String, Boolean> var1) {
      this.players = var1;
   }

   public void setPlayers(Map<String, Boolean> var1) {
      this.players = var1;
   }

   public void f(boolean var1) {
      this.iu = var1;
   }

   public long getPhaseDuration() {
      return this.bh() != null ? this.bh().getDuration() : 0L;
   }

   public int getTotalPlayers() {
      return this.iJ;
   }

   public int getPlayersLeft() {
      return this.players.size();
   }

   public PvPEvent.a getType() {
      return PvPEvent.a.ij;
   }
}
