package ga.strikepractice.hostedevents.b;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.e;
import ga.strikepractice.utils.u;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

@e(
   fj = {"join", "leave", "setlobby"}
)
public class b implements CommandExecutor {
   public static ga.strikepractice.hostedevents.b.a iR;
   private static BukkitTask iS;
   private final StrikePractice iT;
   public static boolean iU;

   public b(StrikePractice var1) {
      this.iT = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 0 && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pB) && var4[0].equalsIgnoreCase("start")) {
         if (var4.length > 1) {
            c(var1, var4[1]);
            return true;
         }

         var1.sendMessage(ChatColor.GRAY + "/Brackets start <kit>");
      }

      if (var4.length > 0 && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pB) && var4[0].equalsIgnoreCase("open")) {
         if (ga.strikepractice.hostedevents.b.a.t("brackets") == null) {
            var1.sendMessage(ChatColor.RED + "The brackets lobby is invalid!");
         } else if (iR == null) {
            var1.sendMessage(ChatColor.BLUE + "The event is now open!");
            iR = new ga.strikepractice.hostedevents.b.a(this.iT);
         } else {
            var1.sendMessage(ChatColor.RED + "The event is already open!");
         }
      } else if (var4.length > 0 && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pB) && var4[0].equalsIgnoreCase("stop")) {
         if (iR != null) {
            iR.stop();
            var1.sendMessage(ChatColor.RED + "Stopped!");
         }

         iU = false;
      } else if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         if (var4.length == 0) {
            if (ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pB)) {
               var5.sendMessage(ChatColor.GOLD + "/Brackets open");
               var5.sendMessage(ChatColor.GOLD + "/Brackets start <kit>");
               var5.sendMessage(ChatColor.GOLD + "/Brackets stop");
               var5.sendMessage(ChatColor.GOLD + "/Brackets setlobby");
            }

            var5.sendMessage(ChatColor.YELLOW + "/Brackets join");
            var5.sendMessage(ChatColor.YELLOW + "/Brackets leave");
            return true;
         }

         Iterator var6;
         String var7;
         Player var8;
         if (var4[0].equalsIgnoreCase("leave")) {
            if (iR != null && iR.cz().containsKey(var5.getName())) {
               if (iR.getP1() != null && iR.getP2() != null && (iR.getP1().equals(var5.getName()) || iR.getP2().equals(var5.getName()))) {
                  var5.setHealth(0.0D);
                  return true;
               }

               var6 = iR.cz().keySet().iterator();

               while(var6.hasNext()) {
                  var7 = (String)var6.next();
                  var8 = Bukkit.getPlayer(var7);
                  if (var8 != null) {
                     this.iT.a(var8, "brackets-left", u.a("<player>", var5.getName()));
                  }
               }

               this.iT.ac().removeSpectator(var5, true);
               iR.cz().remove(var5.getName());
               if (!iR.hasStarted()) {
                  iR.iJ = iR.cz().size();
               }

               if (iS != null && !ct()) {
                  var6 = Bukkit.getOnlinePlayers().iterator();

                  while(var6.hasNext()) {
                     Player var12 = (Player)var6.next();
                     if (ga.strikepractice.k.b.a(var12, ga.strikepractice.k.a.py)) {
                        var12.sendMessage(ChatColor.RED + "Brackets does not have has enough players to start automatically. Cancelling the brackets.");
                     }
                  }

                  iS.cancel();
               }
            }

            return true;
         }

         if (Party.getParty(var5) != null) {
            this.iT.a(var5, "can-not-do-while-in-party");
            return true;
         }

         if (AbstractFight.isInFight(var5) || var5.hasMetadata("StrikePracticeWaitingQueue") || PvPEvent.isInEvent(var5)) {
            this.iT.a(var5, "can-not-do-while-in-match");
            return true;
         }

         if (var4[0].equalsIgnoreCase("join")) {
            if (iR == null) {
               this.iT.a(var5, "brackets-not-started");
               return true;
            }

            if (ga.strikepractice.hostedevents.b.a.t("brackets") == null) {
               var5.sendMessage(ChatColor.RED + "Invalid brackets lobby!");
               return true;
            }

            if (iR.hasStarted()) {
               this.iT.a(var5, "brackets-already-started");
            } else if (!iR.cz().containsKey(var5.getName())) {
               if (this.iT.ac().isSpectator(var5)) {
                  this.iT.ac().removeSpectator(var5, false);
               }

               iR.cz().put(var5.getName(), false);
               if (!iR.hasStarted()) {
                  iR.iJ = iR.cz().size();
               }

               iR.L(var5);
               var6 = iR.cz().keySet().iterator();

               while(var6.hasNext()) {
                  var7 = (String)var6.next();
                  var8 = Bukkit.getPlayer(var7);
                  if (var8 != null) {
                     this.iT.a(var8, "brackets-joined", u.a("<player>", var5.getName()));
                  }
               }

               int var10 = this.iT.getConfig().getInt("brackets.auto-start");
               if (!iU && iS == null && var10 == iR.cz().size() && ga.strikepractice.hostedevents.a.b.iA.keySet().stream().noneMatch((var0) -> {
                  return var0.cm() == ga.strikepractice.hostedevents.a.c.iC;
               })) {
                  int var11 = this.iT.getConfig().getInt("brackets.auto-start-after-seconds");
                  Iterator var13 = Bukkit.getOnlinePlayers().iterator();

                  while(var13.hasNext()) {
                     Player var9 = (Player)var13.next();
                     if (ga.strikepractice.k.b.a(var9, ga.strikepractice.k.a.py)) {
                        var9.sendMessage(ChatColor.RED + "Brackets has " + var10 + " players, starting it automatically in " + var11 + " seconds.");
                     }
                  }

                  iS = (new BukkitRunnable() {
                     public void run() {
                        Iterator var1 = Bukkit.getOnlinePlayers().iterator();

                        while(var1.hasNext()) {
                           Player var2 = (Player)var1.next();
                           if (ga.strikepractice.k.b.a(var2, ga.strikepractice.k.a.py)) {
                              var2.sendMessage(ChatColor.RED + "Starting brackets automatically!");
                           }
                        }

                        b.c(Bukkit.getConsoleSender(), b.this.iT.getConfig().getString("automatic-events.brackets-kit"));
                     }
                  }).runTaskLater(this.iT, (long)(20 * var11));
               }
            }
         } else if (var4[0].equalsIgnoreCase("setlobby") && ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pz)) {
            this.iT.getConfig().set("brackets.lobby", new D(var5.getLocation()));
            this.iT.saveConfig();
            var5.sendMessage(ChatColor.BLUE + "Brackets lobby set!");
         }
      }

      return true;
   }

   public static boolean ct() {
      if (iR != null && iR.cz() != null) {
         return iR.ct() && iR.cz().size() >= StrikePractice.getInstance().getConfig().getInt("brackets.auto-start");
      } else {
         return false;
      }
   }

   public static boolean c(CommandSender var0, String var1) {
      if (iR == null) {
         var0.sendMessage(ChatColor.RED + "Can't start the brackets! The game is not open.");
      } else if (iR.hasStarted()) {
         var0.sendMessage(ChatColor.RED + "The event has already started.");
      } else {
         if (iR.ct()) {
            if (iS != null) {
               iS.cancel();
               iS = null;
            }

            BattleKit var2 = BattleKit.getKit(var1);
            if (var2 == null) {
               var0.sendMessage(ChatColor.RED + "Invanlid kit!");
               return false;
            }

            iR.setKit(var2);
            iR.start();
            return true;
         }

         var0.sendMessage(ChatColor.RED + "There are under 2 players in the brackets!");
         iR.stop();
      }

      return false;
   }
}
