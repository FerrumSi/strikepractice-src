package ga.strikepractice.hostedevents.koth;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.d;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.u;
import java.util.Iterator;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class c implements Listener {
   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerDeathEvent var1) {
      ga.strikepractice.hostedevents.koth.a var2 = b.jE;
      final Player var3 = var1.getEntity();
      if (var2 != null && (var2.cK().getMembers().contains(var3.getUniqueId()) || var2.cL().getMembers().contains(var3.getUniqueId()))) {
         var1.getDrops().clear();
         StrikePractice var4 = StrikePractice.getInstance();
         var4.clear(var3, true, true);
         var2.cK().getMembers().remove(var3.getUniqueId());
         var2.cL().getMembers().remove(var3.getUniqueId());
         if (var4.aa().vI) {
            var4.aa().bk(var3);
         }

         if (var4.getConfig().getBoolean("koth.anytime-join")) {
            if (var4.getConfig().getBoolean("koth.auto-respawn")) {
               (new BukkitRunnable() {
                  public void run() {
                     if (var3 != null) {
                        var3.chat("/koth join");
                     }

                  }
               }).runTaskLater(var4, 10L);
            } else {
               var4.a(var3, "koth-join-back");
               if (var4.getConfig().getBoolean("clickable-messages")) {
                  d.b(var3, f.K(var4.getConfig().getString("clickable-message")), "/koth join");
               }
            }
         }
      }

   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      Player var2 = var1.getPlayer();
      StrikePractice var3 = StrikePractice.getInstance();
      if (b.jE != null && (b.jE.cK().getMembers().contains(var2.getUniqueId()) || b.jE.cL().getMembers().contains(var2.getUniqueId()))) {
         b.jE.cK().getMembers().remove(var2.getUniqueId());
         b.jE.cL().getMembers().remove(var2.getUniqueId());
         var3.clear(var2, true, true);
         Iterator var4 = b.jG.iterator();

         while(var4.hasNext()) {
            UUID var5 = (UUID)var4.next();
            Player var6 = Bukkit.getPlayer(var5);
            if (var6 != null) {
               var3.a(var6, "koth-left", u.a("<player>", var2.getName()));
            }
         }
      } else if (b.jG.contains(var2.getUniqueId())) {
         var3.a(var2, "koth-left");
      }

      b.jG.remove(var2.getUniqueId());
   }

   @EventHandler
   public void a(EntityDamageByEntityEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2;
         Player var3;
         if (var1.getDamager() instanceof Player) {
            var2 = (Player)var1.getDamager();
            var3 = (Player)var1.getEntity();
            if (this.b(var2, var3)) {
               var1.setCancelled(true);
               return;
            }
         }

         if (var1.getDamager() instanceof Projectile && ((Projectile)var1.getDamager()).getShooter() instanceof Player) {
            var2 = (Player)((Projectile)var1.getDamager()).getShooter();
            var3 = (Player)var1.getEntity();
            if (this.b(var2, var3)) {
               var1.setCancelled(true);
            }
         }
      }

   }

   private boolean b(Player var1, Player var2) {
      if (b.jE == null) {
         return false;
      } else {
         return b.jE.cK().getMembers().contains(var1.getUniqueId()) && b.jE.cK().getMembers().contains(var2.getUniqueId()) || b.jE.cL().getMembers().contains(var1.getUniqueId()) && b.jE.cL().getMembers().contains(var2.getUniqueId());
      }
   }
}
