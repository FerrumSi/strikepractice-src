package ga.strikepractice.hostedevents.koth;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.queue.d;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.e;
import ga.strikepractice.utils.u;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

@e(
   fj = {"join", "leave", "spawn1", "spawn2", "corner1", "corner2"}
)
public class b implements CommandExecutor {
   public static ga.strikepractice.hostedevents.koth.a jE;
   private final StrikePractice jF;
   public static boolean jl;
   public static List<UUID> jG = new ArrayList();

   public b(StrikePractice var1) {
      this.jF = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 1 && var4[0].equalsIgnoreCase("start") && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pJ)) {
         a(var1, new String[]{var4[1]}, this.jF);
         return true;
      } else if (var4.length > 0 && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pJ) && var4[0].equalsIgnoreCase("stop")) {
         if (jE != null) {
            jE.stop();
            jG.clear();
            var1.sendMessage(ChatColor.RED + "Stopped!");
         }

         jl = false;
         return true;
      } else if (var4.length > 0 && var4[0].equalsIgnoreCase("open") && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pJ)) {
         if (j(this.jF) == null) {
            var1.sendMessage(ChatColor.RED + "The spawn1 location is invalid!");
         }

         if (k(this.jF) == null) {
            var1.sendMessage(ChatColor.RED + "The spawn2 location is invalid!");
         }

         if (l(this.jF) == null) {
            var1.sendMessage(ChatColor.RED + "The corner1 location is invalid!");
         }

         if (m(this.jF) == null) {
            var1.sendMessage(ChatColor.RED + "The corner2 location is invalid!");
         } else if (!jl) {
            var1.sendMessage(ChatColor.BLUE + "The event is now open!");
            jl = true;
         } else {
            var1.sendMessage(ChatColor.RED + "The event is already open!");
         }

         return true;
      } else {
         if (var1 instanceof Player) {
            Player var5 = (Player)var1;
            if ((AbstractFight.isInFight(var5) || var5.hasMetadata("StrikePracticeWaitingQueue") || PvPEvent.isInEvent(var5)) && var4.length > 0 && !var4[0].equalsIgnoreCase("leave")) {
               this.jF.a(var5, "can-not-do-while-in-match");
               return true;
            }

            Iterator var6;
            UUID var7;
            Player var8;
            if (var4.length > 0 && var4[0].equalsIgnoreCase("leave")) {
               if (jE != null && (jE.cK().getMembers().contains(var5.getUniqueId()) || jE.cL().getMembers().contains(var5.getUniqueId()))) {
                  jE.cK().getMembers().remove(var5.getUniqueId());
                  jE.cL().getMembers().remove(var5.getUniqueId());
                  this.jF.clear(var5, true, true);
                  var6 = jG.iterator();

                  while(var6.hasNext()) {
                     var7 = (UUID)var6.next();
                     var8 = Bukkit.getPlayer(var7);
                     if (var8 != null) {
                        this.jF.a(var8, "koth-left", u.a("<player>", var5.getName()));
                     }
                  }

                  if (this.jF.aa().vI) {
                     this.jF.aa().bk(var5);
                  }
               } else {
                  var6 = jG.iterator();

                  while(var6.hasNext()) {
                     var7 = (UUID)var6.next();
                     var8 = Bukkit.getPlayer(var7);
                     if (var8 != null) {
                        this.jF.a(var8, "koth-left", u.a("<player>", var5.getName()));
                     }
                  }
               }

               if (!jG.contains(var5.getUniqueId())) {
                  this.jF.a(var5, "koth-left", u.a("<player>", var5.getName()));
               }

               jG.remove(var5.getUniqueId());
               return true;
            }

            if (Party.getParty(var5) != null) {
               this.jF.a(var5, "can-not-do-while-in-party");
               return true;
            }

            if (var4.length > 0 && var4[0].equalsIgnoreCase("join")) {
               if (AbstractFight.isInFight(var5) || PvPEvent.isInEvent(var5)) {
                  this.jF.a(var5, "can-not-do-while-in-match");
                  return true;
               }

               if (!jl) {
                  this.jF.a(var5, "koth-has-not-started");
                  return true;
               }

               if (jE != null && jE.hasStarted()) {
                  if (StrikePractice.getInstance().getConfig().getBoolean("koth.anytime-join")) {
                     if (jE != null) {
                        if (jE.hasStarted()) {
                           jE.P(var5);
                        } else {
                           this.jF.a(var5, "koth-has-not-started");
                        }
                     }
                  } else {
                     this.jF.a(var5, "koth-already-started");
                  }
               } else if (!jG.contains(var5.getUniqueId())) {
                  d.b(var5, true);
                  if (this.jF.ac().isSpectator(var5)) {
                     this.jF.ac().removeSpectator(var5, false);
                  }

                  jG.add(var5.getUniqueId());
                  var6 = jG.iterator();

                  while(var6.hasNext()) {
                     var7 = (UUID)var6.next();
                     var8 = Bukkit.getPlayer(var7);
                     if (var8 != null) {
                        this.jF.a(var8, "koth-joined", u.a("<player>", var5.getName()));
                     }
                  }
               }
            } else if (var4.length > 0 && var4[0].equalsIgnoreCase("spawn1") && ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pz)) {
               this.jF.getConfig().set("koth.spawn1", new D(var5.getLocation()));
               this.jF.saveConfig();
               var5.sendMessage(ChatColor.RED + "You have set the spawn1.");
            } else if (var4.length > 0 && var4[0].equalsIgnoreCase("spawn2") && ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pz)) {
               this.jF.getConfig().set("koth.spawn2", new D(var5.getLocation()));
               this.jF.saveConfig();
               var5.sendMessage(ChatColor.RED + "You have set the spawn2.");
            } else if (var4.length > 0 && var4[0].equalsIgnoreCase("corner1") && ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pz)) {
               this.jF.getConfig().set("koth.corner1", new D(var5.getLocation()));
               this.jF.saveConfig();
               var5.sendMessage(ChatColor.RED + "You have set the corner1.");
               var5.sendMessage(ChatColor.GRAY + "Note: the corners mean the capping area, not the arena corners! Set one a block below and one a few blocks above the ground.");
            } else if (var4.length > 0 && var4[0].equalsIgnoreCase("corner2") && ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pz)) {
               this.jF.getConfig().set("koth.corner2", new D(var5.getLocation()));
               this.jF.saveConfig();
               var5.sendMessage(ChatColor.RED + "You have set the corner2.");
               var5.sendMessage(ChatColor.GRAY + "Note: the corners mean the capping area, not the arena corners! Set one a block below and one a few blocks above the ground.");
            } else {
               if (ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pJ)) {
                  var5.sendMessage(ChatColor.GOLD + "/koth open");
                  var5.sendMessage(ChatColor.GOLD + "/koth start <kit>");
                  var5.sendMessage(ChatColor.GOLD + "/koth spawn1");
                  var5.sendMessage(ChatColor.GOLD + "/koth spawn2");
                  var5.sendMessage(ChatColor.GOLD + "/koth corner1");
                  var5.sendMessage(ChatColor.GOLD + "/koth corner2");
                  var5.sendMessage(ChatColor.GOLD + "/koth stop");
               }

               var5.sendMessage(ChatColor.YELLOW + "/koth join");
               var5.sendMessage(ChatColor.YELLOW + "/koth leave");
            }
         }

         return false;
      }
   }

   public static boolean a(CommandSender var0, String[] var1, StrikePractice var2) {
      if (jE != null && jE.hasStarted()) {
         var0.sendMessage("KOTH event has already started!");
         return false;
      } else {
         BattleKit var3 = BattleKit.getKit(var1[0]);
         if (var3 == null) {
            var0.sendMessage(ChatColor.RED + "Invanlid kit!");
            return false;
         } else {
            Location var4 = null;
            Location var5 = null;
            Location var6 = null;
            Location var7 = null;

            try {
               var4 = j(var2);
               var5 = k(var2);
               var6 = l(var2);
               var7 = m(var2);
            } catch (Exception var9) {
               var0.sendMessage(ChatColor.RED + "Invalid locations! Be sure that spawn, corner1 and corner2 are set before starting the event.");
               return false;
            }

            jE = new ga.strikepractice.hostedevents.koth.a(var3, var4, var5, var6, var7, i(var2), var2);
            jE.start();
            var0.sendMessage(ChatColor.YELLOW + "Starting KoTH...");
            return true;
         }
      }
   }

   private static int i(StrikePractice var0) {
      return var0.getConfig().getInt("koth.timer");
   }

   private static Location j(StrikePractice var0) {
      return a(var0, "koth.spawn1");
   }

   private static Location k(StrikePractice var0) {
      return a(var0, "koth.spawn2");
   }

   private static Location l(StrikePractice var0) {
      return a(var0, "koth.corner1");
   }

   private static Location m(StrikePractice var0) {
      return a(var0, "koth.corner2");
   }

   private static Location a(StrikePractice var0, String var1) {
      Object var2 = var0.getConfig().get(var1);
      return var2 != null && var2 instanceof D ? ((D)var2).ga() : null;
   }
}
