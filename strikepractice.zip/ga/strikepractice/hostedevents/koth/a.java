package ga.strikepractice.hostedevents.koth;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.events.PvPEventEndEvent;
import ga.strikepractice.events.PvPEventStartEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.t;
import ga.strikepractice.utils.u;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.Nullable;

public class a implements PvPEvent {
   private final ga.strikepractice.hostedevents.koth.a.a jo = new ga.strikepractice.hostedevents.koth.a.a();
   private final ga.strikepractice.hostedevents.koth.a.a jp = new ga.strikepractice.hostedevents.koth.a.a();
   public ga.strikepractice.hostedevents.koth.a.a jq;
   public BattleKit kit;
   private boolean iu;
   private final Location jr;
   private final Location js;
   private final Location jt;
   private final Location ju;
   public final int jv;
   public int counter;
   public UUID jw;
   private BukkitTask jx;
   public long jy;
   public Fight jz;
   private Arena arena;
   private final StrikePractice jA;

   public a(BattleKit var1, Location var2, Location var3, Location var4, Location var5, int var6, StrikePractice var7) {
      this.jA = var7;
      this.jr = var2;
      this.js = var3;
      this.kit = var1;
      this.jv = var6;
      if (var6 < 1) {
         var6 = 1;
      }

      this.jt = var4;
      this.ju = var5;
      this.counter = var6;
      Iterator var8 = StrikePractice.getInstance().M.iterator();

      while(var8.hasNext()) {
         Arena var9 = (Arena)var8.next();
         if (var9.getName().equalsIgnoreCase("koth")) {
            this.arena = var9;
         }
      }

      if (this.arena == null) {
         this.arena = new ga.strikepractice.arena.c("tmp_koth");
      }

   }

   public BattleKit getKit() {
      return this.kit;
   }

   public long getStartTime() {
      return this.jy;
   }

   public int getPlayersLeft() {
      return this.jo.jD.size() + this.jp.jD.size();
   }

   public int getTotalPlayers() {
      return this.jo.jD.size() + this.jp.jD.size();
   }

   public void start() {
      PvPEventStartEvent var1 = new PvPEventStartEvent(this);
      Bukkit.getPluginManager().callEvent(var1);
      if (!var1.isCancelled()) {
         this.iu = true;
         this.jz = new AbstractFight() {
            public void start() {
            }

            public boolean hasEnded() {
               return !a.this.hasStarted();
            }

            public void handleDeath(Player var1) {
            }

            public void forceEnd(String var1) {
            }

            public Arena getArena() {
               return a.this.arena;
            }

            public boolean canStart() {
               return false;
            }

            public boolean allowSpectating() {
               return false;
            }

            public BattleKit getKit() {
               return a.this.kit;
            }

            public List<String> getOpponents(Player var1) {
               ga.strikepractice.hostedevents.koth.a.a var2 = a.this.Q(var1);
               if (var2 == null) {
                  return Collections.emptyList();
               } else {
                  Collection var3 = var2 == a.this.jo ? a.this.jp.getMembers() : a.this.jo.getMembers();
                  return (List)var3.stream().map((var0) -> {
                     return Bukkit.getPlayer(var0).getName();
                  }).collect(Collectors.toList());
               }
            }

            public List<String> getTeammates(Player var1) {
               ga.strikepractice.hostedevents.koth.a.a var2 = a.this.Q(var1);
               return var2 == null ? Collections.emptyList() : (List)var2.getMembers().stream().map((var0) -> {
                  return Bukkit.getPlayer(var0).getName();
               }).collect(Collectors.toList());
            }

            public boolean playersAreOpponents(Player var1, Player var2) {
               ga.strikepractice.hostedevents.koth.a.a var3 = a.this.Q(var1);
               ga.strikepractice.hostedevents.koth.a.a var4 = a.this.Q(var2);
               return var3 != null && var4 != null && var3 != var4;
            }

            public boolean playersAreTeammates(Player var1, Player var2) {
               ga.strikepractice.hostedevents.koth.a.a var3 = a.this.Q(var1);
               return var3 != null && var3.jD.contains(var2.getUniqueId());
            }
         };
         this.arena.setUsing(true, this.jz);
         this.jy = System.currentTimeMillis();
         Iterator var2 = b.jG.iterator();

         while(var2.hasNext()) {
            UUID var3 = (UUID)var2.next();
            Player var4 = Bukkit.getPlayer(var3);
            if (var4 != null && Party.getParty(var4) == null && AbstractFight.getCurrentFight(var4) == null) {
               this.P(var4);
            }
         }

         b.jG.clear();

         try {
            this.jx = (new BukkitRunnable() {
               public void run() {
                  if (a.this.jw == null) {
                     a.this.cJ();
                  }

                  Player var1 = a.this.jw == null ? null : Bukkit.getPlayer(a.this.jw);
                  if (a.this.jw != null && var1 != null) {
                     if (a.this.O(var1)) {
                        --a.this.counter;
                        if (a.this.counter == 0) {
                           Iterator var2 = Bukkit.getOnlinePlayers().iterator();

                           while(var2.hasNext()) {
                              Player var3 = (Player)var2.next();
                              StrikePractice.getInstance().a(var3, "koth-winner", u.a("<team>", a.this.a(a.this.jq)));
                           }

                           PvPEventEndEvent var4 = new PvPEventEndEvent(a.this, var1);
                           Bukkit.getPluginManager().callEvent(var4);
                           a.this.stop();
                        }
                     } else {
                        a.this.counter = a.this.jv;
                        a.this.jw = null;
                        a.this.jq = null;
                        a.this.cJ();
                     }
                  }

               }
            }).runTaskTimer(StrikePractice.getInstance(), 20L, 20L);
         } catch (Exception var5) {
            var5.printStackTrace();
            Bukkit.broadcastMessage(ChatColor.RED + "An error occurred in the KOTH event...");
            this.stop();
         }

      }
   }

   private boolean O(Player var1) {
      return var1 != null && !var1.isDead() && t.a(var1.getLocation(), this.jt, this.ju);
   }

   private void cJ() {
      ArrayList var1 = new ArrayList();
      Iterator var2 = this.jo.getMembers().iterator();

      UUID var3;
      Player var4;
      while(var2.hasNext()) {
         var3 = (UUID)var2.next();
         var4 = Bukkit.getPlayer(var3);
         if (var4 != null && this.O(var4)) {
            var1.add(var4);
         }
      }

      var2 = this.jp.getMembers().iterator();

      while(var2.hasNext()) {
         var3 = (UUID)var2.next();
         var4 = Bukkit.getPlayer(var3);
         if (var4 != null && this.O(var4)) {
            var1.add(var4);
         }
      }

      if (!var1.isEmpty()) {
         int var5 = 0;
         if (var1.size() > 1) {
            var5 = StrikePractice.t.nextInt(var1.size());
         }

         for(Iterator var6 = var1.iterator(); var6.hasNext(); --var5) {
            var4 = (Player)var6.next();
            if (var5 == 0) {
               this.jw = var4.getUniqueId();
               if (this.jo.getMembers().contains(var4.getUniqueId())) {
                  this.jq = this.jo;
               } else if (this.jp.getMembers().contains(var4.getUniqueId())) {
                  this.jq = this.jp;
               }

               return;
            }
         }
      }

   }

   public void stop() {
      this.iu = false;
      if (this.arena != null) {
         this.arena.setUsing(false, (Fight)null);
      }

      b.jl = false;
      Iterator var1 = this.jo.getMembers().iterator();

      UUID var2;
      Player var3;
      while(var1.hasNext()) {
         var2 = (UUID)var1.next();
         var3 = Bukkit.getPlayer(var2);
         if (var3 != null) {
            this.jA.clear(var3, false, true);

            try {
               Bukkit.getScheduler().scheduleSyncDelayedTask(this.jA, () -> {
                  this.jA.clear(var3, true, true);
                  if (this.jA.ac().isSpectator(var3)) {
                     this.jA.ac().removeSpectator(var3, true);
                  }

               }, (long)(20 * this.jA.getConfig().getInt("wait-before-teleport")));
            } catch (Exception var5) {
               this.jA.clear(var3, true, true);
               if (this.jA.ac().isSpectator(var3)) {
                  this.jA.ac().removeSpectator(var3, true);
               }
            }

            if (this.jA.aa().vI) {
               this.jA.aa().bk(var3);
            }
         }
      }

      var1 = this.jp.getMembers().iterator();

      while(var1.hasNext()) {
         var2 = (UUID)var1.next();
         var3 = Bukkit.getPlayer(var2);
         if (var3 != null) {
            this.jA.clear(var3, false, true);
            Bukkit.getScheduler().scheduleSyncDelayedTask(this.jA, () -> {
               this.jA.clear(var3, true, true);
               if (this.jA.ac().isSpectator(var3)) {
                  this.jA.ac().removeSpectator(var3, true);
               }

            }, (long)(20 * this.jA.getConfig().getInt("wait-before-teleport")));
            if (this.jA.aa().vI) {
               this.jA.aa().bk(var3);
            }
         }
      }

      var1 = Bukkit.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player var6 = (Player)var1.next();
         this.jA.a(var6, "event-stopped");
      }

      if (this.jx != null) {
         this.jx.cancel();
      }

      b.jE = null;
   }

   public boolean hasStarted() {
      return this.iu;
   }

   public void P(Player var1) {
      if (this.jA.ac().isSpectator(var1)) {
         this.jA.ac().removeSpectator(var1, false);
      }

      this.jA.clear(var1, false, true);
      boolean var2 = this.jA.getConfig().getBoolean("enable-colored-names");
      if (this.jo.getMembers().contains(var1.getUniqueId())) {
         N.e(var1, this.jr);
         i.a(Collections.singletonList(var1.getName()), this.kit.isStickSpawn());
         this.kit.giveKit(var1);
         if (var2) {
            this.jA.aa().n(var1, "team1");
         }
      } else if (this.jp.getMembers().contains(var1.getUniqueId())) {
         N.e(var1, this.jr);
         i.a(Collections.singletonList(var1.getName()), this.kit.isStickSpawn());
         this.kit.giveKit(var1);
         if (var2) {
            this.jA.aa().n(var1, "team2");
         }
      } else {
         if (this.jo.getMembers().size() > this.jp.getMembers().size()) {
            this.jp.getMembers().add(var1.getUniqueId());
            N.e(var1, this.js);
            if (var2) {
               this.jA.aa().n(var1, "team2");
            }
         } else {
            this.jo.getMembers().add(var1.getUniqueId());
            N.e(var1, this.jr);
            if (var2) {
               this.jA.aa().n(var1, "team1");
            }
         }

         i.a(Collections.singletonList(var1.getName()), this.kit.isStickSpawn());
         this.kit.giveKit(var1);
      }

   }

   public ga.strikepractice.hostedevents.koth.a.a cK() {
      return this.jo;
   }

   public ga.strikepractice.hostedevents.koth.a.a cL() {
      return this.jp;
   }

   @Nullable
   private ga.strikepractice.hostedevents.koth.a.a Q(Player var1) {
      if (this.cK().getMembers().contains(var1.getUniqueId())) {
         return this.cK();
      } else {
         return this.cL().getMembers().contains(var1.getUniqueId()) ? this.cL() : null;
      }
   }

   public String a(ga.strikepractice.hostedevents.koth.a.a var1) {
      return f.K(var1 == this.jo ? StrikePractice.getInstance().getConfig().getString("koth.team1") : StrikePractice.getInstance().getConfig().getString("koth.team2"));
   }

   public PvPEvent.a getType() {
      return PvPEvent.a.il;
   }

   public static class a {
      private final Set<UUID> jD = new HashSet();

      public Collection<UUID> getMembers() {
         Iterator var1 = this.jD.iterator();
         if (var1.hasNext()) {
            UUID var2 = (UUID)var1.next();
            if (Bukkit.getPlayer(var2) == null) {
               var1.remove();
            }
         }

         return this.jD;
      }
   }
}
