package ga.strikepractice.hostedevents.d;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.d;
import ga.strikepractice.utils.f;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class c implements Listener {
   private final StrikePractice jn;

   public c(StrikePractice var1) {
      this.jn = var1;
   }

   @EventHandler
   public void a(EntityDamageByEntityEvent var1) {
      if (var1.getEntity() instanceof Player && var1.getDamager() instanceof Player) {
         if (var1.getEntity().hasMetadata("StrikePracticeJuggernaut") && var1.getDamager().hasMetadata("StrikePracticeJuggernaut") && b.jk != null && !b.jk.cH().equals(var1.getEntity().getName()) && !b.jk.cH().equals(var1.getDamager().getName())) {
            var1.setCancelled(true);
         }
      } else if (var1.getEntity() instanceof Player && var1.getDamager() instanceof Projectile) {
         Projectile var2 = (Projectile)var1.getDamager();
         if (var2.getShooter() != null && var2.getShooter() instanceof Player && ((Player)var2.getShooter()).hasMetadata("StrikePracticeJuggernaut") && b.jk != null && !b.jk.cH().equals(var1.getEntity().getName()) && !b.jk.cH().equals(((Player)var2.getShooter()).getName())) {
            var1.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      if (b.jk != null) {
         if (b.jk.cH().equalsIgnoreCase(var1.getPlayer().getName())) {
            b.jk.cF();
         }

         if (var1.getPlayer().hasMetadata("StrikePracticeJuggernaut")) {
            var1.getPlayer().removeMetadata("StrikePracticeJuggernaut", this.jn);
            this.jn.clear(var1.getPlayer(), true, true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerDeathEvent var1) {
      if (b.jk != null) {
         Player var2 = var1.getEntity();
         if (b.jk.cH() != null && b.jk.cH().equalsIgnoreCase(var2.getName())) {
            var1.getDrops().clear();
            if (var2.getKiller() != null && var2.getKiller() instanceof Player) {
               Player var3 = var2.getKiller();
               b.jk.x(var3.getName());
            } else {
               b.jk.x("*unknown*");
            }
         } else if (var2.hasMetadata("StrikePracticeJuggernaut")) {
            var2.removeMetadata("StrikePracticeJuggernaut", this.jn);
            var1.getDrops().clear();
            this.jn.clear(var2, true, true);
            StrikePractice.getInstance().a(var1.getEntity(), "juggernaut-join-back");
            if (StrikePractice.getInstance().getConfig().getBoolean("clickable-messages")) {
               d.b(var1.getEntity(), f.K(StrikePractice.getInstance().getConfig().getString("clickable-message")), "/juggernaut join");
            }
         }

      }
   }
}
