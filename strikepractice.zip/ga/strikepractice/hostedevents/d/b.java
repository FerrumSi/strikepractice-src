package ga.strikepractice.hostedevents.d;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.e;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

@e(
   fj = {"join", "leave", "setspawn"}
)
public class b implements CommandExecutor {
   public static List<String> jj = new ArrayList();
   public static ga.strikepractice.hostedevents.d.a jk;
   public static boolean jl;
   private final StrikePractice jm;

   public b(StrikePractice var1) {
      this.jm = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 3 && var4[0].equalsIgnoreCase("start") && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pF)) {
         a(var1, var4, this.jm);
      } else if (var4.length == 0) {
         if (ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pF)) {
            var1.sendMessage(ChatColor.GOLD + "/juggernaut open");
            var1.sendMessage(ChatColor.GOLD + "/juggernaut start <player|-random> <juggernautkit> <otherskit>");
            var1.sendMessage(ChatColor.GOLD + "/juggernaut setspawn");
            var1.sendMessage(ChatColor.GOLD + "/juggernaut stop");
         }

         var1.sendMessage(ChatColor.YELLOW + "/juggernaut join");
         var1.sendMessage(ChatColor.YELLOW + "/juggernaut leave");
      } else if (var4.length > 0 && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pF) && var4[0].equalsIgnoreCase("stop")) {
         if (jk != null) {
            jk.stop();
            jj.clear();
            var1.sendMessage(ChatColor.RED + "Stopped!");
         }

         jl = false;
      } else if (var4[0].equalsIgnoreCase("open") && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pF)) {
         if (!jl) {
            var1.sendMessage(ChatColor.BLUE + "The event is now open!");
            jl = true;
         } else {
            var1.sendMessage(ChatColor.RED + "The event is already open!");
         }
      } else if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         if (var4[0].equalsIgnoreCase("leave")) {
            if (jk != null && jk.cH().equals(var5.getName())) {
               jk.x(var5.getName());
               return true;
            } else {
               if (var5.hasMetadata("StrikePracticeJuggernaut")) {
                  this.jm.clear(var5, true, true);
                  var5.removeMetadata("StrikePracticeJuggernaut", this.jm);
               }

               if (jj.contains(var5.getName())) {
                  var5.sendMessage(ChatColor.GOLD + "You won't become the juggernaut.");
                  jj.remove(var5.getName());
               }

               return true;
            }
         }

         if (Party.getParty(var5) != null) {
            this.jm.a(var5, "can-not-do-while-in-party");
            return true;
         }

         if (AbstractFight.isInFight(var5) || var5.hasMetadata("StrikePracticeWaitingQueue") || PvPEvent.isInEvent(var5)) {
            this.jm.a(var5, "can-not-do-while-in-match");
            return true;
         }

         if (var4[0].equalsIgnoreCase("join")) {
            if (AbstractFight.getCurrentFight(var5) != null || PvPEvent.isInEvent(var5)) {
               this.jm.a(var5, "can-not-do-while-in-match");
               return true;
            }

            if (!jl) {
               this.jm.a(var5, "juggernaut-not-open");
               return true;
            }

            if (jk == null || !jk.hasStarted()) {
               this.jm.a(var5, "juggernaut-not-started");
               if (!jj.contains(var5.getName())) {
                  jj.add(var5.getName());
               }

               this.jm.a(var5, "juggernaut-chance");
               return true;
            }

            jk.N(var5);
         } else if (var4[0].equalsIgnoreCase("setspawn") && ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pz)) {
            this.jm.getConfig().set("juggernaut.spawn", new D(var5.getLocation()));
            this.jm.saveConfig();
            var5.sendMessage(ChatColor.RED + "Juggernaut spawn set!");
         } else {
            if (ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pF)) {
               var5.sendMessage(ChatColor.GOLD + "/juggernaut open");
               var5.sendMessage(ChatColor.GOLD + "/juggernaut start <player|-random> <juggernautkit> <otherskit>");
               var5.sendMessage(ChatColor.GOLD + "/juggernaut setspawn");
               var5.sendMessage(ChatColor.GOLD + "/juggernaut stop");
            }

            var5.sendMessage(ChatColor.YELLOW + "/juggernaut join");
            var5.sendMessage(ChatColor.YELLOW + "/juggernaut leave");
         }
      }

      return false;
   }

   public static boolean a(CommandSender var0, String[] var1, StrikePractice var2) {
      if (jk != null && jk.hasStarted()) {
         var0.sendMessage("Juggernaut event has already started!");
         return false;
      } else {
         BattleKit var3 = BattleKit.getKit(var1[2]);
         BattleKit var4 = BattleKit.getKit(var1[3]);
         if (var3 != null && var4 != null) {
            String var5 = var1[1];
            if (var1[1].equalsIgnoreCase("-random")) {
               var5 = cI();
            }

            if (var5 == null) {
               var0.sendMessage(ChatColor.RED + "That player is not online!");
               return false;
            } else {
               Player var6 = Bukkit.getPlayer(var5);
               if (var6 == null) {
                  var0.sendMessage(ChatColor.RED + "That player is not online!");
                  return false;
               } else {
                  if (var6 != null && Party.getParty(var6) == null && AbstractFight.getCurrentFight(var6) == null && !PvPEvent.isInEvent(var6)) {
                     Location var7 = h(var2);
                     if (var7 != null && Bukkit.getWorld(var7.getWorld().getName()) != null) {
                        var0.sendMessage(ChatColor.GREEN + "Starting juggernaut...");
                        jk = new ga.strikepractice.hostedevents.d.a(var6.getName(), var3, var4, var7, var2);
                        jk.start();
                        Iterator var8 = jj.iterator();

                        while(var8.hasNext()) {
                           String var9 = (String)var8.next();
                           Player var10 = Bukkit.getPlayer(var9);
                           if (var10 != null && Party.getParty(var10) == null && AbstractFight.getCurrentFight(var10) == null && !PvPEvent.isInEvent(var10)) {
                              jk.N(var10);
                           }
                        }

                        jj.clear();
                        return true;
                     }

                     var0.sendMessage("The juggernaut spawn is invalid!");
                  } else {
                     var0.sendMessage(ChatColor.RED + "The player is an event, party or fight.");
                  }

                  return false;
               }
            }
         } else {
            var0.sendMessage(ChatColor.RED + "Invanlid kit!");
            return false;
         }
      }
   }

   private static Location h(StrikePractice var0) {
      Object var1 = var0.getConfig().get("juggernaut.spawn");
      if (!(var1 instanceof D)) {
         String var2 = "juggernaut.spawn is missing. Set it with /juggernaut setspawn";
         Bukkit.getLogger().warning(var2);
         Bukkit.broadcast(var0.X() + " [admin] " + var2, ga.strikepractice.k.a.pz.dY());
         return null;
      } else {
         return ((D)var1).ga();
      }
   }

   public static String cI() {
      ArrayList var0 = new ArrayList();
      Iterator var1 = jj.iterator();

      while(var1.hasNext()) {
         String var2 = (String)var1.next();
         Player var3 = Bukkit.getPlayer(var2);
         if (var3 != null && Party.getParty(var3) == null && AbstractFight.getCurrentFight(var3) == null && !PvPEvent.isInEvent(var3)) {
            var0.add(var2);
         }
      }

      if (var0.size() == 1) {
         return (String)var0.get(0);
      } else if (var0.isEmpty()) {
         return null;
      } else {
         return (String)var0.get(StrikePractice.t.nextInt(var0.size()));
      }
   }
}
