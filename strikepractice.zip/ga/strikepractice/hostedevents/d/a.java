package ga.strikepractice.hostedevents.d;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.events.PvPEventEndEvent;
import ga.strikepractice.events.PvPEventStartEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.u;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;

public class a implements PvPEvent {
   private final StrikePractice jd;
   private boolean iu;
   private final BattleKit je;
   public static final String jf = "StrikePracticeJuggernaut";
   private final BattleKit jg;
   private final Location jh;
   private String it;
   private long startTime;
   private int ji;

   public a(String var1, BattleKit var2, BattleKit var3, Location var4, StrikePractice var5) {
      this.jd = var5;
      this.jg = var2;
      this.je = var3;
      this.it = var1;
      this.jh = var4;
   }

   public void start() {
      PvPEventStartEvent var1 = new PvPEventStartEvent(this);
      Bukkit.getPluginManager().callEvent(var1);
      if (!var1.isCancelled()) {
         this.startTime = System.currentTimeMillis();
         this.f(true);
         Player var2 = Bukkit.getPlayer(this.it);
         if (var2 == null) {
            this.cF();
         } else {
            N.e(var2, this.jh);
            this.jg.giveKit(var2);
            Player var5;
            if (StrikePractice.getInstance().getConfig().getBoolean("enable-colored-names")) {
               List var3 = this.cD();
               this.jd.aa().a(var2, "team2", var3);
               Iterator var4 = Bukkit.getOnlinePlayers().iterator();

               while(var4.hasNext()) {
                  var5 = (Player)var4.next();
                  if (var3.contains(var5.getUniqueId())) {
                     this.jd.aa().a(var5, "team1", var3);
                  }
               }
            }

            i.a(Collections.singletonList(var2.getName()), this.jg.isStickSpawn());
            Iterator var6 = Bukkit.getOnlinePlayers().iterator();

            while(var6.hasNext()) {
               Player var7 = (Player)var6.next();
               this.jd.a(var7, "player-is-juggernaut", u.a("<player>", var2.getName()));
            }

            var6 = b.jj.iterator();

            while(var6.hasNext()) {
               String var8 = (String)var6.next();
               var5 = Bukkit.getPlayer(var8);
               if (var5 != null && Party.getParty(var5) == null && AbstractFight.getCurrentFight(var5) == null && !PvPEvent.isInEvent(var5)) {
                  this.N(var5);
               }
            }

         }
      }
   }

   private List<UUID> cD() {
      ArrayList var1 = new ArrayList();
      Iterator var2 = Bukkit.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         Player var3 = (Player)var2.next();
         if (var3.hasMetadata("StrikePracticeJuggernaut")) {
            var1.add(var3.getUniqueId());
         }
      }

      return var1;
   }

   private List<Player> cE() {
      ArrayList var1 = new ArrayList();
      Iterator var2 = Bukkit.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         Player var3 = (Player)var2.next();
         if (var3.hasMetadata("StrikePracticeJuggernaut")) {
            var1.add(var3);
         }
      }

      return var1;
   }

   public void stop() {
      PvPEventEndEvent var1 = new PvPEventEndEvent(this, (Player)null);
      Bukkit.getPluginManager().callEvent(var1);
      Iterator var2 = Bukkit.getOnlinePlayers().iterator();

      Player var3;
      while(var2.hasNext()) {
         var3 = (Player)var2.next();
         if (var3.hasMetadata("StrikePracticeJuggernaut")) {
            this.jd.clear(var3, true, true);
            var3.removeMetadata("StrikePracticeJuggernaut", this.jd);
         }
      }

      var2 = Bukkit.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         var3 = (Player)var2.next();
         this.jd.a(var3, "event-stopped");
      }

      if (this.it != null) {
         Player var4 = Bukkit.getPlayer(this.it);
         this.it = "";
         if (var4 != null) {
            this.jd.clear(var4, true, true);
            if (StrikePractice.getInstance().getConfig().getBoolean("enable-colored-names")) {
               this.jd.aa().bk(var4);
            }
         }
      }

      b.jl = false;
      b.jk = null;
   }

   public void N(Player var1) {
      if (this.jd.ac().isSpectator(var1)) {
         this.jd.ac().removeSpectator(var1, false);
      }

      this.jd.clear(var1, false, true);
      N.e(var1, this.jh);
      var1.setMetadata("StrikePracticeJuggernaut", new FixedMetadataValue(this.jd, true));
      Player var2 = Bukkit.getPlayer(this.it);
      if (var2 == null) {
         this.cF();
      } else {
         if (StrikePractice.getInstance().getConfig().getBoolean("enable-colored-names")) {
            this.jd.aa().a(var2, "team2", this.cD());
            Iterator var3 = this.cE().iterator();

            while(var3.hasNext()) {
               Player var4 = (Player)var3.next();
               this.jd.aa().a(var4, "team1", this.cD());
            }
         }

         i.a(Collections.singletonList(var1.getName()), this.je.isStickSpawn());
         this.je.giveKit(var1);
         if (this.getPlayersLeft() > this.ji) {
            this.ji = this.getPlayersLeft();
         }

      }
   }

   public void x(String var1) {
      Player var2 = Bukkit.getPlayer(this.it);
      if (var2 != null) {
         this.jd.clear(var2, true, true);
         if (StrikePractice.getInstance().getConfig().getBoolean("enable-colored-names")) {
            this.jd.aa().bk(var2);
         }
      }

      Iterator var3 = Bukkit.getOnlinePlayers().iterator();

      Player var4;
      while(var3.hasNext()) {
         var4 = (Player)var3.next();
         if (var4.hasMetadata("StrikePracticeJuggernaut")) {
            this.jd.clear(var4, true, true);
            var4.removeMetadata("StrikePracticeJuggernaut", this.jd);
         }
      }

      var3 = Bukkit.getOnlinePlayers().iterator();

      while(var3.hasNext()) {
         var4 = (Player)var3.next();
         this.jd.a(var4, "juggernaut-eliminated", u.a("<player>", this.it, "<killer>", var1));
      }

      b.jk = null;
      this.it = null;
      this.stop();
      Player var5 = Bukkit.getPlayer(var1);
      if (var5 != null) {
         DefaultPlayerStats var6 = DefaultPlayerStats.getStats(var5.getUniqueId());
         var6.setJuggernautWins(var6.getJuggernautWins() + 1);
      }

   }

   public void cF() {
      Player var1 = Bukkit.getPlayer(this.it);
      if (var1 != null) {
         this.jd.clear(var1, true, true);
         if (StrikePractice.getInstance().getConfig().getBoolean("enable-colored-names")) {
            this.jd.aa().bk(var1);
         }
      }

      Iterator var2 = Bukkit.getOnlinePlayers().iterator();

      Player var3;
      while(var2.hasNext()) {
         var3 = (Player)var2.next();
         if (var3.hasMetadata("StrikePracticeJuggernaut")) {
            this.jd.clear(var3, true, true);
            var3.removeMetadata("StrikePracticeJuggernaut", this.jd);
         }
      }

      var2 = Bukkit.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         var3 = (Player)var2.next();
         this.jd.a(var3, "juggernaut-eliminated-logging-out");
      }

      this.stop();
      b.jk = null;
      this.it = null;
   }

   public BattleKit getKit() {
      return this.je;
   }

   public BattleKit cG() {
      return this.jg;
   }

   public boolean hasStarted() {
      return this.iu;
   }

   public long getStartTime() {
      return this.startTime;
   }

   public int getPlayersLeft() {
      return this.cE().size();
   }

   public int getTotalPlayers() {
      return this.ji;
   }

   public void f(boolean var1) {
      this.iu = var1;
   }

   public String cH() {
      return this.it;
   }

   public PvPEvent.a getType() {
      return PvPEvent.a.in;
   }
}
