package ga.strikepractice.hostedevents;

import ga.strikepractice.api.APIClass;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.hostedevents.d.b;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;

@APIClass
public interface PvPEvent {
   void start();

   void stop();

   boolean hasStarted();

   BattleKit getKit();

   static boolean isInEvent(Player var0) {
      if (ga.strikepractice.hostedevents.lms.a.jW != null && ga.strikepractice.hostedevents.lms.a.jW.cM().contains(var0.getName())) {
         return true;
      } else if (var0.hasMetadata("ToppeBattlesLmsWaiting")) {
         return true;
      } else if (var0.hasMetadata("StrikePracticeJuggernaut")) {
         return true;
      } else if (b.jk != null && b.jk.cH() != null && b.jk.cH().equalsIgnoreCase(var0.getName())) {
         return true;
      } else if (ga.strikepractice.hostedevents.b.b.iR != null && ga.strikepractice.hostedevents.b.b.iR.cz().containsKey(var0.getName())) {
         return true;
      } else if (ga.strikepractice.hostedevents.e.b.kk != null && ga.strikepractice.hostedevents.e.b.kk.cz().containsKey(var0.getName())) {
         return true;
      } else if (ga.strikepractice.hostedevents.koth.b.jG.contains(var0.getUniqueId())) {
         return true;
      } else {
         return ga.strikepractice.hostedevents.koth.b.jE != null && (ga.strikepractice.hostedevents.koth.b.jE.cK().getMembers().contains(var0.getUniqueId()) || ga.strikepractice.hostedevents.koth.b.jE.cL().getMembers().contains(var0.getUniqueId()));
      }
   }

   static String getEventString(Player var0) {
      if (ga.strikepractice.hostedevents.lms.a.jW != null && ga.strikepractice.hostedevents.lms.a.jW.cM().contains(var0.getName())) {
         return "lms (alive)";
      } else if (var0.hasMetadata("ToppeBattlesLmsWaiting")) {
         return "lms (waiting)";
      } else if (var0.hasMetadata("StrikePracticeJuggernaut")) {
         return "juggernaut (joined)";
      } else if (b.jk != null && b.jk.cH() != null && b.jk.cH().equalsIgnoreCase(var0.getName())) {
         return "juggernaut (the juggernaut)";
      } else if (ga.strikepractice.hostedevents.b.b.iR != null && ga.strikepractice.hostedevents.b.b.iR.cz().containsKey(var0.getName())) {
         return "brackets";
      } else if (ga.strikepractice.hostedevents.e.b.kk != null && ga.strikepractice.hostedevents.e.b.kk.cz().containsKey(var0.getName())) {
         return "sumo";
      } else if (ga.strikepractice.hostedevents.koth.b.jG.contains(var0.getUniqueId())) {
         return "koth (waiting)";
      } else {
         return ga.strikepractice.hostedevents.koth.b.jE == null || !ga.strikepractice.hostedevents.koth.b.jE.cK().getMembers().contains(var0.getUniqueId()) && !ga.strikepractice.hostedevents.koth.b.jE.cL().getMembers().contains(var0.getUniqueId()) ? "not in event" : "koth";
      }
   }

   static PvPEvent getEvent(Player var0) {
      if (ga.strikepractice.hostedevents.lms.a.jW != null && ga.strikepractice.hostedevents.lms.a.jW.cM().contains(var0.getName())) {
         return ga.strikepractice.hostedevents.lms.a.jW;
      } else if (b.jk != null && var0.hasMetadata("StrikePracticeJuggernaut")) {
         return b.jk;
      } else if (b.jk != null && b.jk.cH() != null && b.jk.cH().equals(var0.getName())) {
         return b.jk;
      } else if (ga.strikepractice.hostedevents.b.b.iR != null && ga.strikepractice.hostedevents.b.b.iR.cz().containsKey(var0.getName())) {
         return ga.strikepractice.hostedevents.b.b.iR;
      } else if (ga.strikepractice.hostedevents.e.b.kk != null && ga.strikepractice.hostedevents.e.b.kk.cz().containsKey(var0.getName())) {
         return ga.strikepractice.hostedevents.e.b.kk;
      } else if (ga.strikepractice.hostedevents.koth.b.jG.contains(var0.getUniqueId())) {
         return ga.strikepractice.hostedevents.koth.b.jE;
      } else {
         return ga.strikepractice.hostedevents.koth.b.jE == null || !ga.strikepractice.hostedevents.koth.b.jE.cK().getMembers().contains(var0.getUniqueId()) && !ga.strikepractice.hostedevents.koth.b.jE.cL().getMembers().contains(var0.getUniqueId()) ? null : ga.strikepractice.hostedevents.koth.b.jE;
      }
   }

   static List<PvPEvent> getCurrentPvPEvents() {
      ArrayList var0 = new ArrayList();
      if (ga.strikepractice.hostedevents.lms.a.jW != null && ga.strikepractice.hostedevents.lms.a.jW.hasStarted()) {
         var0.add(ga.strikepractice.hostedevents.lms.a.jW);
      }

      if (b.jk != null && b.jk.hasStarted()) {
         var0.add(b.jk);
      }

      if (ga.strikepractice.hostedevents.b.b.iR != null && ga.strikepractice.hostedevents.b.b.iR.hasStarted()) {
         var0.add(ga.strikepractice.hostedevents.b.b.iR);
      }

      if (ga.strikepractice.hostedevents.koth.b.jE != null && ga.strikepractice.hostedevents.koth.b.jE.hasStarted()) {
         var0.add(ga.strikepractice.hostedevents.koth.b.jE);
      }

      if (ga.strikepractice.hostedevents.e.b.kk != null && ga.strikepractice.hostedevents.e.b.kk.hasStarted()) {
         var0.add(ga.strikepractice.hostedevents.e.b.kk);
      }

      return var0;
   }

   long getStartTime();

   default long getPhaseDuration() {
      return System.currentTimeMillis() - this.getStartTime();
   }

   int getPlayersLeft();

   int getTotalPlayers();

   PvPEvent.a getType();

   public static enum a {
      ij("Brackets"),
      ik("Sumo"),
      il("KOTH"),
      im("LMS"),
      in("Juggernaut");

      private final String io;

      private a(String var3) {
         this.io = var3;
      }

      public String getDisplayName() {
         return this.io;
      }

      // $FF: synthetic method
      private static PvPEvent.a[] ck() {
         return new PvPEvent.a[]{ij, ik, il, im, in};
      }
   }
}
