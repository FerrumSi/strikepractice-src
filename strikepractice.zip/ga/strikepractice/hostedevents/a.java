package ga.strikepractice.hostedevents;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.events.PlayerHostEvent;
import ga.strikepractice.k.b;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.G;
import ga.strikepractice.utils.c;
import ga.strikepractice.utils.h;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class a implements CommandExecutor, TabCompleter {
   private final StrikePractice ii;

   public a(StrikePractice var1) {
      this.ii = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      boolean var5 = b.a(var1, ga.strikepractice.k.a.pX);
      if (var4.length > 0) {
         if (this.a(var1, var4[0])) {
            return true;
         }

         Player var6;
         BattleKit var9;
         if (var4[0].equalsIgnoreCase("brackets")) {
            if (b.a(var1, ga.strikepractice.k.a.pC)) {
               if (ga.strikepractice.hostedevents.b.b.iR != null) {
                  if (var1 instanceof Player) {
                     this.ii.a((Player)var1, "brackets-already-started");
                  } else {
                     this.ii.a("brackets-already-started", false);
                  }
               } else if (var1 instanceof Player && var4.length < 2) {
                  var6 = (Player)var1;
                  G.a(var6, BattleKitType.BRACKETS, (var3x) -> {
                     this.a(var1, var3x);
                     var6.chat("/brackets join");
                  });
               } else {
                  var9 = var5 && var4.length > 1 ? BattleKit.getKit(var4[1]) : null;
                  if (var4.length > 1 && var9 == null) {
                     var1.sendMessage(ChatColor.RED + "Invalid kit!");
                     return true;
                  }

                  this.a(var1, var9);
                  if (var1 instanceof Player) {
                     ((Player)var1).chat("/brackets join");
                  }
               }
            } else if (var1 instanceof Player) {
               this.ii.a((Player)var1, "no-permission");
            } else {
               var1.sendMessage("No permissions!");
            }

            return true;
         }

         PlayerHostEvent var10;
         if (var4[0].equalsIgnoreCase("sumo")) {
            if (b.a(var1, ga.strikepractice.k.a.pE)) {
               if (ga.strikepractice.hostedevents.e.b.kk != null) {
                  if (var1 instanceof Player) {
                     this.ii.a((Player)var1, "sumo-already-started");
                  } else {
                     this.ii.a("sumo-already-started", false);
                  }
               } else {
                  var10 = new PlayerHostEvent(var4[0], var1);
                  Bukkit.getPluginManager().callEvent(var10);
                  if (var10.isCancelled()) {
                     return true;
                  }

                  var1.sendMessage(ChatColor.YELLOW + "Trying to start a sumo event...");
                  ga.strikepractice.hostedevents.a.a var12 = new ga.strikepractice.hostedevents.a.a(this.ii, var4[0]);
                  var12.r(var1.getName());
                  var12.c(this.b(var1, var4[0]));
                  if (var1 instanceof Player) {
                     ((Player)var1).chat("/sumo join");
                  }
               }
            } else if (var1 instanceof Player) {
               this.ii.a((Player)var1, "no-permission");
            } else {
               var1.sendMessage("No permissions!");
            }

            return true;
         }

         ga.strikepractice.hostedevents.a.a var8;
         if (var4[0].equalsIgnoreCase("koth")) {
            if (b.a(var1, ga.strikepractice.k.a.pK)) {
               if (ga.strikepractice.hostedevents.koth.b.jl || ga.strikepractice.hostedevents.koth.b.jE != null && ga.strikepractice.hostedevents.koth.b.jE.hasStarted()) {
                  if (var1 instanceof Player) {
                     this.ii.a((Player)var1, "koth-already-started");
                  } else {
                     this.ii.a("koth-already-started", false);
                  }
               } else {
                  var10 = new PlayerHostEvent(var4[0], var1);
                  Bukkit.getPluginManager().callEvent(var10);
                  if (var10.isCancelled()) {
                     return true;
                  }

                  var1.sendMessage(ChatColor.YELLOW + "Trying to start a king of the hill event...");
                  BattleKit var11 = var5 && var4.length > 1 ? BattleKit.getKit(var4[1]) : null;
                  if (var4.length > 1 && var11 == null) {
                     var1.sendMessage(ChatColor.RED + "Invalid kit!");
                     return true;
                  }

                  var8 = new ga.strikepractice.hostedevents.a.a(this.ii, var4[0].toLowerCase(), var11);
                  var8.r(var1.getName());
                  var8.c(this.b(var1, var4[0]));
                  if (var1 instanceof Player) {
                     ((Player)var1).chat("/koth join");
                  }
               }
            } else if (var1 instanceof Player) {
               this.ii.a((Player)var1, "no-permission");
            } else {
               var1.sendMessage("No permissions!");
            }

            return true;
         }

         if (var4[0].equalsIgnoreCase("lms")) {
            if (b.a(var1, ga.strikepractice.k.a.pI)) {
               if (!ga.strikepractice.hostedevents.lms.a.jl && (ga.strikepractice.hostedevents.lms.a.jW == null || !ga.strikepractice.hostedevents.lms.a.jW.hasStarted())) {
                  if (var1 instanceof Player && var4.length < 2) {
                     var6 = (Player)var1;
                     G.a(var6, BattleKitType.LMS, (var2x) -> {
                        this.b(var1, var2x);
                     });
                  } else {
                     var9 = var5 && var4.length > 1 ? BattleKit.getKit(var4[1]) : null;
                     if (var4.length > 1 && var9 == null) {
                        var1.sendMessage(ChatColor.RED + "Invalid kit!");
                        return true;
                     }

                     this.b(var1, var9);
                     if (var1 instanceof Player) {
                        ((Player)var1).chat("/lms join");
                     }
                  }
               } else if (var1 instanceof Player) {
                  this.ii.a((Player)var1, "lms-already-started");
               } else {
                  this.ii.a("lms-already-started", false);
               }
            } else if (var1 instanceof Player) {
               this.ii.a((Player)var1, "no-permission");
            } else {
               var1.sendMessage("No permissions!");
            }

            return true;
         }

         if (var4[0].equalsIgnoreCase("juggernaut")) {
            if (!b.a(var1, ga.strikepractice.k.a.pG)) {
               if (var1 instanceof Player) {
                  this.ii.a((Player)var1, "no-permission");
               } else {
                  var1.sendMessage("No permissions!");
               }

               return true;
            }

            if (var4.length > 1) {
               if (ga.strikepractice.hostedevents.d.b.jl) {
                  if (var1 instanceof Player) {
                     this.ii.a((Player)var1, "juggernaut-already-started");
                  } else {
                     this.ii.a("juggernaut-already-started", false);
                  }
               } else {
                  var6 = Bukkit.getPlayer(var4[1]);
                  if (var6 == null && !var4[1].equalsIgnoreCase("-random")) {
                     if (var1 instanceof Player) {
                        this.ii.a((Player)var1, "not-online");
                     } else {
                        var1.sendMessage("Player not found");
                     }
                  } else {
                     PlayerHostEvent var7 = new PlayerHostEvent(var4[0], var1);
                     Bukkit.getPluginManager().callEvent(var7);
                     if (var7.isCancelled()) {
                        return true;
                     }

                     var1.sendMessage(ChatColor.YELLOW + "Trying to start a juggernaut event...");
                     var8 = new ga.strikepractice.hostedevents.a.a(this.ii, var4[0], var4[1]);
                     var8.r(var1.getName());
                     var8.c(this.b(var1, var4[0]));
                     if (var1 instanceof Player) {
                        ((Player)var1).chat("/juggernaut join");
                     }
                  }
               }
            } else {
               var1.sendMessage(ChatColor.GOLD + "/hostevent juggernaut <juggernaut player or -random>");
            }

            return true;
         }
      }

      if (var5) {
         var1.sendMessage(ChatColor.GOLD + "/hostevent brackets [kit]");
         var1.sendMessage(ChatColor.GOLD + "/hostevent sumo");
         var1.sendMessage(ChatColor.GOLD + "/hostevent lms [kit]");
         var1.sendMessage(ChatColor.GOLD + "/hostevent koth [kit]");
         var1.sendMessage(ChatColor.GOLD + "/hostevent juggernaut <juggernaut player or -random>");
      } else {
         var1.sendMessage(ChatColor.GOLD + "/hostevent brackets");
         var1.sendMessage(ChatColor.GOLD + "/hostevent sumo");
         var1.sendMessage(ChatColor.GOLD + "/hostevent lms");
         var1.sendMessage(ChatColor.GOLD + "/hostevent koth");
         var1.sendMessage(ChatColor.GOLD + "/hostevent juggernaut <juggernaut player or -random>");
      }

      return true;
   }

   private void a(CommandSender var1, BattleKit var2) {
      PlayerHostEvent var3 = new PlayerHostEvent("brackets", var1);
      Bukkit.getPluginManager().callEvent(var3);
      if (!var3.isCancelled()) {
         var1.sendMessage(ChatColor.YELLOW + "Trying to start a brackets event...");
         ga.strikepractice.hostedevents.a.a var4 = new ga.strikepractice.hostedevents.a.a(this.ii, "brackets", var2);
         var4.r(var1.getName());
         var4.c(this.b(var1, "brackets"));
      }
   }

   private void b(CommandSender var1, BattleKit var2) {
      PlayerHostEvent var3 = new PlayerHostEvent("lms", var1);
      Bukkit.getPluginManager().callEvent(var3);
      if (!var3.isCancelled()) {
         var1.sendMessage(ChatColor.YELLOW + "Trying to start a last man standing event...");
         ga.strikepractice.hostedevents.a.a var4 = new ga.strikepractice.hostedevents.a.a(this.ii, "lms", var2);
         var4.r(var1.getName());
         var4.c(this.b(var1, "lms"));
         if (var1 instanceof Player) {
            ((Player)var1).chat("/lms join");
         }

      }
   }

   private boolean a(CommandSender var1, String var2) {
      if (var1 instanceof Player && !b.a(var1, ga.strikepractice.k.a.pA)) {
         Player var3 = (Player)var1;
         DefaultPlayerStats var4 = DefaultPlayerStats.getStats(var3.getUniqueId());
         if (var4 != null) {
            return var4.isOnCooldown(var2.toLowerCase(), true);
         }
      }

      return false;
   }

   private c<Integer> b(CommandSender var1, String var2) {
      var2 = var2.toLowerCase();
      UUID var3 = var1 instanceof Player ? ((Player)var1).getUniqueId() : null;
      return (var3x) -> {
         if (var3x == 1 && var3 != null) {
            Player var4 = Bukkit.getPlayer(var3);
            if (var4 != null) {
               DefaultPlayerStats var5 = DefaultPlayerStats.getStats(var3);
               long var6 = (long)(this.ii.getConfig().getInt("cooldowns.hostevent." + var2) * 60 * 1000);
               var5.putOnCooldown(var2, System.currentTimeMillis() + var6);
            } else {
               C.c(() -> {
                  DefaultPlayerStats var3x = DefaultPlayerStats.getStats(var3, true, true);
                  long var4 = (long)(this.ii.getConfig().getInt("cooldowns.hostevent." + var2) * 60 * 1000);
                  var3x.putOnCooldown(var2, System.currentTimeMillis() + var4);
                  var3x.save();
               });
            }
         }

      };
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length == 2 && Arrays.asList("brackets", "koth").contains(var4[1])) {
         List var6 = (List)this.ii.kits.stream().map(BattleKit::getName).collect(Collectors.toList());
         var6.removeIf((var1x) -> {
            return !var1x.toLowerCase().contains(var4[1].toLowerCase());
         });
         var6.sort(new h(var4[1]));
         return var6;
      } else if (var4.length == 1) {
         ArrayList var5 = new ArrayList(Arrays.asList("brackets", "sumo", "koth", "juggernaut"));
         var5.removeIf((var1x) -> {
            return !var1x.toLowerCase().contains(var4[0].toLowerCase());
         });
         var5.sort(new h(var4[0]));
         return var5;
      } else {
         return null;
      }
   }
}
