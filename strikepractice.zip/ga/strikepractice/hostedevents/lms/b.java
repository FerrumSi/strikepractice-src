package ga.strikepractice.hostedevents.lms;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.events.PvPEventEndEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.i.j;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.t;
import ga.strikepractice.utils.u;
import java.util.Iterator;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class b implements Listener {
   private final StrikePractice jZ;

   public b(StrikePractice var1) {
      this.jZ = var1;
   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      var1.getPlayer().removeMetadata("ToppeBattlesLmsWaiting", this.jZ);
      if (ga.strikepractice.hostedevents.lms.a.jW != null && ga.strikepractice.hostedevents.lms.a.jW.cM() != null) {
         if (ga.strikepractice.hostedevents.lms.a.jW.hasStarted() && ga.strikepractice.hostedevents.lms.a.jW.cM().contains(var1.getPlayer().getName())) {
            var1.getPlayer().setHealth(0.0D);
         }

         if (ga.strikepractice.hostedevents.lms.a.jX.contains(var1.getPlayer().getName())) {
            if (ga.strikepractice.hostedevents.lms.a.jW != null && ga.strikepractice.hostedevents.lms.a.jW.hasStarted()) {
               var1.getPlayer().setHealth(0.0D);
            }

            Iterator var2 = ga.strikepractice.hostedevents.lms.a.jX.iterator();

            while(var2.hasNext()) {
               String var3 = (String)var2.next();
               Player var4 = Bukkit.getPlayer(var3);
               if (var4 != null) {
                  this.jZ.a(var4, "lms-left", u.a("<player>", var1.getPlayer().getName()));
               }
            }

            ga.strikepractice.hostedevents.lms.a.jX.remove(var1.getPlayer().getName());
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerDeathEvent var1) {
      if (ga.strikepractice.hostedevents.lms.a.jW != null && ga.strikepractice.hostedevents.lms.a.jW.cM() != null) {
         final Player var2 = var1.getEntity();
         if (ga.strikepractice.hostedevents.lms.a.jW.hasStarted() && ga.strikepractice.hostedevents.lms.a.jW.cM().contains(var2.getName())) {
            Iterator var3 = ga.strikepractice.hostedevents.lms.a.jW.cM().iterator();

            final String var4;
            final Player var5;
            while(var3.hasNext()) {
               var4 = (String)var3.next();
               var5 = Bukkit.getPlayer(var4);
               if (var5 != null) {
                  this.jZ.a(var5, "lms-death-message", u.a("<player>", var2.getName(), "<alive>", ga.strikepractice.hostedevents.lms.a.jW.cM().size() - 1));
               }
            }

            j.Z(var2);
            ga.strikepractice.hostedevents.lms.a.jX.remove(var2.getName());
            ga.strikepractice.hostedevents.lms.a.jW.cM().remove(var2.getName());
            AbstractFight.setCurrentFight(var2, (Fight)null);
            var2.removeMetadata("ToppeBattlesLmsWaiting", this.jZ);
            if (this.jZ.getConfig().getBoolean("allow-spectating")) {
               final Location var10 = var2.getLocation().add(0.0D, 1.0D, 0.0D);
               this.jZ.clear(var2, false, true);
               (new BukkitRunnable() {
                  public void run() {
                     if (var2 != null) {
                        var2.teleport(var10);
                        b.this.jZ.ac().addSpectator(var2);
                        ga.strikepractice.hostedevents.lms.a.jW.jO.add(var2.getUniqueId());
                        var2.teleport(var10);
                     }

                  }
               }).runTaskLater(this.jZ, 5L);
            } else {
               this.jZ.clear(var2, true, true);
            }

            if (ga.strikepractice.hostedevents.lms.a.jW.cM().size() == 1) {
               var3 = ga.strikepractice.hostedevents.lms.a.jW.cM().iterator();
               if (var3.hasNext()) {
                  var4 = (String)var3.next();
                  var5 = Bukkit.getPlayer(var4);
                  var5.removeMetadata("ToppeBattlesLmsWaiting", this.jZ);
                  PvPEventEndEvent var6 = new PvPEventEndEvent(ga.strikepractice.hostedevents.lms.a.jW, var5);
                  Bukkit.getPluginManager().callEvent(var6);
                  (new BukkitRunnable() {
                     public void run() {
                        if (var5 != null) {
                           AbstractFight.setCurrentFight(var5, (Fight)null);
                           b.this.jZ.clear(var5, true, true);
                        }

                        if (ga.strikepractice.hostedevents.lms.a.jW != null) {
                           ga.strikepractice.hostedevents.lms.a.jW.f(false);
                           ga.strikepractice.hostedevents.lms.a.jW.stop();
                        }

                        ga.strikepractice.hostedevents.lms.a.jX.remove(var4);
                     }
                  }).runTaskLater(this.jZ, (long)(20 * this.jZ.getConfig().getInt("wait-before-teleport")));
                  Iterator var7 = Bukkit.getOnlinePlayers().iterator();

                  while(var7.hasNext()) {
                     Player var8 = (Player)var7.next();
                     this.jZ.a(var8, "lms-winner", u.a("<player>", var4));
                  }

                  UUID var11 = var5.getUniqueId();
                  DefaultPlayerStats.getStats(var11).setLmsWins(DefaultPlayerStats.getStats(var11).getLMSWins() + 1);
                  Iterator var12 = t.a(var5.getLocation(), 5.0F, 32).iterator();

                  while(var12.hasNext()) {
                     Location var9 = (Location)var12.next();
                     var9.getWorld().spawnEntity(var9, EntityType.FIREWORK);
                  }
               }

               ga.strikepractice.hostedevents.lms.a.jW.cM().clear();
            }
         }

      }
   }
}
