package ga.strikepractice.hostedevents.lms;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.queue.d;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.e;
import ga.strikepractice.utils.u;
import java.util.HashSet;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;

@e(
   fj = {"join", "leave", "setspawn"}
)
public class a implements CommandExecutor {
   public static final String jV = "ToppeBattlesLmsWaiting";
   public static LMS jW;
   public static boolean jl;
   public static HashSet<String> jX = new HashSet();
   private final StrikePractice jY;

   public a(StrikePractice var1) {
      this.jY = var1;
   }

   private static Location h(StrikePractice var0) {
      D var1 = (D)var0.getConfig().get("lms.spawn");
      return var1 != null ? var1.ga() : null;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 1 && var4[0].equalsIgnoreCase("start") && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pH)) {
         a(var1, var4, this.jY);
      } else if (var4.length == 0) {
         if (ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pH)) {
            var1.sendMessage(ChatColor.GOLD + "/lms open");
            var1.sendMessage(ChatColor.GOLD + "/lms stop");
            var1.sendMessage(ChatColor.GOLD + "/lms start <kit>");
            var1.sendMessage(ChatColor.GOLD + "/lms setspawn");
         }

         var1.sendMessage(ChatColor.YELLOW + "/lms join");
         var1.sendMessage(ChatColor.YELLOW + "/lms leave");
      } else if (var4[0].equalsIgnoreCase("stop") && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pH)) {
         if (jW != null) {
            jW.stop();
            jX.clear();
            var1.sendMessage(ChatColor.RED + "Stopped!");
         }

         jl = false;
      } else if (var4[0].equalsIgnoreCase("open") && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pH)) {
         if (h(this.jY) == null) {
            var1.sendMessage(ChatColor.RED + "The LMS spawn is invalid!");
         } else if (!jl) {
            var1.sendMessage(ChatColor.BLUE + "The event is now open!");
            jl = true;
         } else {
            var1.sendMessage(ChatColor.RED + "The event is already open!");
         }
      } else if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         if (Party.getParty(var5) != null) {
            this.jY.a(var5, "can-not-do-while-in-party");
            return true;
         }

         Iterator var6;
         String var7;
         Player var8;
         if (var4[0].equalsIgnoreCase("leave")) {
            var5.removeMetadata("ToppeBattlesLmsWaiting", this.jY);
            if (jX.contains(var5.getName())) {
               if (jW != null && jW.hasStarted()) {
                  var5.setHealth(0.0D);
               }

               var6 = jX.iterator();

               while(var6.hasNext()) {
                  var7 = (String)var6.next();
                  var8 = Bukkit.getPlayer(var7);
                  if (var8 != null) {
                     this.jY.a(var8, "lms-left", u.a("<player>", var5.getName()));
                  }
               }

               jX.remove(var5.getName());
               return true;
            }

            if (jW != null && !jW.hasStarted()) {
               jW.getPlayers().remove(var5.getName());
            }

            return true;
         }

         if (AbstractFight.isInFight(var5) || var5.hasMetadata("StrikePracticeWaitingQueue") || PvPEvent.isInEvent(var5)) {
            this.jY.a(var5, "can-not-do-while-in-match");
            return true;
         }

         if (var4[0].equalsIgnoreCase("join")) {
            if (!jl) {
               this.jY.a(var5, "lms-has-not-started");
               return true;
            }

            if (!jX.contains(var5.getName())) {
               if (jW != null && jW.hasStarted()) {
                  this.jY.a(var5, "lms-already-started");
                  return true;
               }

               if (this.jY.ac().isSpectator(var5)) {
                  this.jY.ac().removeSpectator(var5, false);
               }

               d.b(var5, true);
               jX.add(var5.getName());
               var5.setMetadata("ToppeBattlesLmsWaiting", new FixedMetadataValue(this.jY, true));
               var6 = jX.iterator();

               while(var6.hasNext()) {
                  var7 = (String)var6.next();
                  var8 = Bukkit.getPlayer(var7);
                  if (var8 != null) {
                     this.jY.a(var8, "lms-joined", u.a("<player>", var5.getName()));
                  }
               }
            }
         } else if (var4[0].equalsIgnoreCase("setspawn") && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pz)) {
            this.jY.getConfig().set("lms.spawn", new D(var5.getLocation()));
            this.jY.saveConfig();
            var5.sendMessage(ChatColor.RED + "LMS spawn set!");
         }
      }

      return false;
   }

   public static boolean a(CommandSender var0, String[] var1, StrikePractice var2) {
      if (jW != null && jW.hasStarted()) {
         if (var0 instanceof Player) {
            var2.a((Player)var0, "lms-already-started");
         } else {
            var0.sendMessage("LMS event has already started!");
         }

         return false;
      } else if (h(var2) == null) {
         var0.sendMessage(ChatColor.RED + "Invalid lms spawn!");
         return false;
      } else if (jX.size() >= 2) {
         BattleKit var7 = BattleKit.getKit(var1[1]);
         if (var7 == null) {
            var0.sendMessage(ChatColor.RED + "Invanlid kit!");
            return false;
         } else {
            Location var8 = h(var2);
            if (var8 != null && Bukkit.getWorld(var8.getWorld().getName()) != null) {
               jW = new LMS(jX, var7, var8, var2);
               jW.start();
               var0.sendMessage("Starting lms...");
               return true;
            } else {
               var0.sendMessage("The lms spawn is invalid!");
               return false;
            }
         }
      } else {
         String var3 = "Can't start, there are under 2 players in the lms.";
         var0.sendMessage(var3);
         if (var0 instanceof ConsoleCommandSender) {
            Iterator var4 = jX.iterator();

            while(var4.hasNext()) {
               String var5 = (String)var4.next();
               Player var6 = Bukkit.getPlayer(var5);
               if (var6 != null) {
                  var6.sendMessage(var3);
                  var6.chat("/lms leave");
               }
            }
         }

         return false;
      }
   }
}
