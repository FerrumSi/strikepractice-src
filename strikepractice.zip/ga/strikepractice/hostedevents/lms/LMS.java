package ga.strikepractice.hostedevents.lms;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.arena.c;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.battlekit.BattleKitType;
import ga.strikepractice.battlekit.e;
import ga.strikepractice.events.PvPEventEndEvent;
import ga.strikepractice.events.PvPEventStartEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.SimpleFight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.i.j;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.i;
import ga.strikepractice.utils.t;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class LMS implements PvPEvent {
   private final StrikePractice jJ;
   private boolean iu;
   private final BattleKit jK;
   private long startTime;
   private final Location jL;
   private final Collection<String> jM;
   private final Collection<String> jN = new HashSet();
   public Collection<UUID> jO = new HashSet();
   private final Fight jP = new LMS.LMSFight();
   private final int jQ;
   private final Arena jR;

   public LMS(Collection<String> var1, BattleKit var2, Location var3, StrikePractice var4) {
      this.jM = new HashSet(var1);
      this.jQ = var1.size();
      this.jJ = var4;
      this.jK = e.a(var2, false, BattleKitType.LMS);
      this.jL = var3;
      this.jR = new c("temp_lms");
      this.jR.setBuild(true);
      this.jR.setCenter(var3);
      this.jR.setLoc1(var3);
      this.jR.setLoc2(var3);
      this.jR.setDisplayName("LMS");
   }

   public void start() {
      ga.strikepractice.hostedevents.lms.a.jl = false;
      PvPEventStartEvent var1 = new PvPEventStartEvent(this);
      Bukkit.getPluginManager().callEvent(var1);
      if (!var1.isCancelled()) {
         this.startTime = System.currentTimeMillis();
         this.f(true);
         ArrayList var2 = new ArrayList();
         this.jP.setKit(this.jK);
         this.jP.setArena(this.jR);
         this.jP.setStartedAfterCountdown();
         this.jR.setCurrentFight(this.jP);
         List var3 = t.a(this.jL, (float)this.jJ.getConfig().getInt("circle-radius"), this.jM.size());
         Iterator var4 = this.jM.iterator();

         while(var4.hasNext()) {
            String var5 = (String)var4.next();
            final Player var6 = Bukkit.getPlayer(var5);
            if (var6 != null) {
               if (this.jJ.ac().isSpectator(var6)) {
                  this.jJ.ac().removeSpectator(var6, true);
               }

               this.jJ.clear(var6, false, false);
               Location var7 = this.jL.clone();
               Location var8 = (Location)var3.get(0);
               Location var9 = var8.setDirection(var7.subtract(var8).toVector());
               if (N.e(var6, var9)) {
                  var6.removeMetadata("ToppeBattlesLmsWaiting", this.jJ);
                  AbstractFight.setCurrentFight(var6, this.jP);
                  var3.remove(0);
                  (new BukkitRunnable() {
                     public void run() {
                        if (var6 != null) {
                           LMS.this.jK.giveKit(var6);
                           j.Y(var6);
                           if (LMS.this.jJ.ae() != null) {
                              LMS.this.jJ.ae().ad(var6);
                           }
                        }

                     }
                  }).runTaskLater(this.jJ, 20L);
                  var2.add(var6.getName());
               }
            }
         }

         this.jN.addAll(var2);
         i.a(var2, 10, false);
      }
   }

   public BattleKit getKit() {
      return this.jK;
   }

   public void stop() {
      try {
         PvPEventEndEvent var1 = new PvPEventEndEvent(this, (Player)null);
         Bukkit.getPluginManager().callEvent(var1);
         this.jR.rollbackArena(this.jP);
      } catch (Exception var4) {
         Bukkit.getLogger().warning("Failed to reset lms arenas");
         var4.printStackTrace();
      }

      Iterator var5 = Bukkit.getOnlinePlayers().iterator();

      Player var2;
      while(var5.hasNext()) {
         var2 = (Player)var5.next();
         if (this.jO.contains(var2.getUniqueId()) && this.jJ.ac().isSpectator(var2)) {
            this.jJ.ac().removeSpectator(var2, true);
         }
      }

      var5 = this.cM().iterator();

      while(var5.hasNext()) {
         String var6 = (String)var5.next();
         Player var3 = Bukkit.getPlayer(var6);
         if (var3 != null) {
            this.jJ.clear(var3, true, true);
            AbstractFight.setCurrentFight(var3, (Fight)null);
            var3.removeMetadata("ToppeBattlesLmsWaiting", this.jJ);
            ga.strikepractice.hostedevents.lms.a.jX.remove(var3.getName());
         }
      }

      var5 = Bukkit.getOnlinePlayers().iterator();

      while(var5.hasNext()) {
         var2 = (Player)var5.next();
         this.jJ.a(var2, "event-stopped");
         var2.removeMetadata("ToppeBattlesLmsWaiting", this.jJ);
      }

      ga.strikepractice.hostedevents.lms.a.jW = null;
      this.cM().clear();
   }

   public boolean hasStarted() {
      return this.iu;
   }

   public long getStartTime() {
      return this.startTime;
   }

   public int getPlayersLeft() {
      return this.jN.size();
   }

   public int getTotalPlayers() {
      return this.jQ;
   }

   public void f(boolean var1) {
      this.iu = var1;
   }

   public Collection<String> cM() {
      return this.jN;
   }

   public Collection<String> getPlayers() {
      return this.jM;
   }

   public PvPEvent.a getType() {
      return PvPEvent.a.im;
   }

   public class LMSFight extends SimpleFight {
   }
}
