package ga.strikepractice.hostedevents.c;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

@SerializableAs("GUIItem")
public class b implements ConfigurationSerializable {
   private ItemStack ja;
   private String jb;
   private int jc;

   public b(ItemStack var1, String var2, int var3) {
      this.ja = var1;
      this.jb = var2;
      this.jc = var3;
   }

   public b(Map<String, Object> var1) {
      if (var1 != null) {
         if (!var1.isEmpty()) {
            if (var1.containsKey("slot") && var1.get("slot") instanceof Integer) {
               this.jc = (Integer)var1.get("slot");
            }

            if (var1.containsKey("item") && var1.get("item") instanceof ItemStack) {
               this.ja = (ItemStack)var1.get("item");
            }

            if (var1.containsKey("command") && var1.get("command") instanceof String) {
               this.jb = (String)var1.get("command");
            }

         }
      }
   }

   public Map<String, Object> serialize() {
      HashMap var1 = new HashMap();
      var1.put("item", this.ja);
      var1.put("slot", this.jc);
      var1.put("command", this.jb);
      return var1;
   }

   public void M(Player var1) {
      if (!this.jb.startsWith("/")) {
         this.jb = "/" + this.jb;
      }

      var1.chat(this.jb);
   }

   public String cB() {
      return this.jb;
   }

   public ItemStack cC() {
      return this.ja;
   }

   public int bl() {
      return this.jc;
   }

   public void w(String var1) {
      this.jb = var1;
   }

   public void b(ItemStack var1) {
      this.ja = var1;
   }

   public void i(int var1) {
      this.jc = var1;
   }
}
