package ga.strikepractice.hostedevents.c;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.utils.g;
import ga.strikepractice.utils.q;
import ga.strikepractice.utils.r;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0002\u0018\u00002\u00020\u00012\u00020\u0002B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0007J3\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\n2\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\n0\u0017H\u0016¢\u0006\u0002\u0010\u0018R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0019"},
   d2 = {"Lga/strikepractice/hostedevents/eventsgui/EventGUI;", "Lorg/bukkit/command/CommandExecutor;", "Lorg/bukkit/event/Listener;", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "items", "", "Lga/strikepractice/hostedevents/eventsgui/EventGUIItem;", "title", "", "onClick", "", "e", "Lorg/bukkit/event/inventory/InventoryClickEvent;", "onCommand", "", "sender", "Lorg/bukkit/command/CommandSender;", "cmd", "Lorg/bukkit/command/Command;", "label", "args", "", "(Lorg/bukkit/command/CommandSender;Lorg/bukkit/command/Command;Ljava/lang/String;[Ljava/lang/String;)Z", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nEventGUI.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EventGUI.kt\nga/strikepractice/hostedevents/eventsgui/EventGUI\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,68:1\n1603#2,9:69\n1855#2:78\n1856#2:80\n1612#2:81\n1549#2:82\n1620#2,3:83\n766#2:86\n857#2,2:87\n1549#2:89\n1620#2,3:90\n1855#2,2:93\n1#3:79\n*S KotlinDebug\n*F\n+ 1 EventGUI.kt\nga/strikepractice/hostedevents/eventsgui/EventGUI\n*L\n18#1:69,9\n18#1:78\n18#1:80\n18#1:81\n39#1:82\n39#1:83,3\n40#1:86\n40#1:87,2\n41#1:89\n41#1:90,3\n57#1:93,2\n18#1:79\n*E\n"})
public final class a implements CommandExecutor, Listener {
   @NotNull
   private final StrikePractice iX;
   @NotNull
   private final List<b> iY;
   @NotNull
   private final String iZ;

   public a(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.iX = var1;
      List var10001 = this.iX.getConfig().getList("events-gui.items");
      Intrinsics.checkNotNullExpressionValue(var10001, "plugin.config.getList(\"events-gui.items\")");
      Iterable var2 = (Iterable)var10001;
      boolean var3 = false;
      Collection var5 = (Collection)(new ArrayList());
      boolean var6 = false;
      boolean var8 = false;
      Iterator var9 = var2.iterator();

      while(var9.hasNext()) {
         Object var10 = var9.next();
         boolean var12 = false;
         boolean var14 = false;
         b var10000;
         if (var10 instanceof b) {
            b var16 = (b)var10;
            boolean var17 = false;
            q.f(((b)var10).cC());
            var10000 = (b)var10;
         } else {
            var10000 = null;
         }

         if (var10000 != null) {
            b var18 = var10000;
            boolean var19 = false;
            var5.add(var18);
         }
      }

      this.iY = (List)var5;
      String var21 = this.iX.getConfig().getString("events-gui.title");
      Intrinsics.checkNotNullExpressionValue(var21, "plugin.config.getString(\"events-gui.title\")");
      this.iZ = g.P(var21);
   }

   public boolean onCommand(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      Intrinsics.checkNotNullParameter(var1, "sender");
      Intrinsics.checkNotNullParameter(var2, "cmd");
      Intrinsics.checkNotNullParameter(var3, "label");
      Intrinsics.checkNotNullParameter(var4, "args");
      if (var1 instanceof Player) {
         CommandSender var5 = var1;
         Inventory var6 = Bukkit.createInventory((InventoryHolder)null, this.iX.getConfig().getInt("events-gui.size"), this.iZ);
         Iterator var7 = this.iY.iterator();

         while(true) {
            b var8;
            ItemStack var9;
            do {
               if (!var7.hasNext()) {
                  ((Player)var5).openInventory(var6);
                  return true;
               }

               var8 = (b)var7.next();
               ItemStack var10000 = var8.cC().clone();
               Intrinsics.checkNotNullExpressionValue(var10000, "eventItem.item.clone()");
               var9 = var10000;
            } while(!r.h(var9));

            ItemMeta var10 = var9.getItemMeta();
            var10.setDisplayName(this.iX.ah().a((Player)var5, var10.getDisplayName(), "", true));
            if (var10.hasLore()) {
               List var10001 = var10.getLore();
               Intrinsics.checkNotNullExpressionValue(var10001, "meta.lore");
               Iterable var11 = (Iterable)var10001;
               boolean var12 = false;
               Collection var14 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var11, 10)));
               boolean var15 = false;
               Iterator var16 = var11.iterator();

               Object var17;
               String var18;
               boolean var19;
               while(var16.hasNext()) {
                  var17 = var16.next();
                  var18 = (String)var17;
                  var19 = false;
                  var14.add(this.iX.ah().a((Player)var5, var18, "", true));
               }

               var11 = (Iterable)((List)var14);
               var12 = false;
               var14 = (Collection)(new ArrayList());
               var15 = false;
               var16 = var11.iterator();

               while(true) {
                  if (!var16.hasNext()) {
                     var11 = (Iterable)((List)var14);
                     var12 = false;
                     var14 = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var11, 10)));
                     var15 = false;
                     var16 = var11.iterator();

                     while(var16.hasNext()) {
                        var17 = var16.next();
                        var18 = (String)var17;
                        var19 = false;
                        Intrinsics.checkNotNullExpressionValue(var18, "it");
                        var14.add(StringsKt.replace$default(StringsKt.replace$default(var18, "[display=true]", "", false, 4, (Object)null), "[display=!false]", "", false, 4, (Object)null));
                     }

                     var10.setLore((List)var14);
                     break;
                  }

                  var17 = var16.next();
                  var18 = (String)var17;
                  var19 = false;
                  Intrinsics.checkNotNullExpressionValue(var18, "it");
                  if (!StringsKt.contains$default((CharSequence)var18, (CharSequence)"[display=false]", false, 2, (Object)null) && !StringsKt.contains$default((CharSequence)var18, (CharSequence)"[display=!true]", false, 2, (Object)null)) {
                     var14.add(var17);
                  }
               }
            }

            var9.setItemMeta(var10);
            var6.setItem(var8.bl(), var9);
         }
      } else {
         return true;
      }
   }

   @EventHandler
   public final void e(@NotNull InventoryClickEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (var1.getWhoClicked() instanceof Player) {
         ItemStack var10000;
         ItemMeta var8;
         String var9;
         label42: {
            var10000 = var1.getCurrentItem();
            if (var10000 != null) {
               var8 = var10000.getItemMeta();
               if (var8 != null) {
                  var9 = var8.getDisplayName();
                  break label42;
               }
            }

            var9 = null;
         }

         if (var9 != null && var1.getInventory() != null && Intrinsics.areEqual((Object)var1.getView().getTitle(), (Object)this.iZ)) {
            var1.setCancelled(true);
            Iterable var2 = (Iterable)this.iY;
            boolean var3 = false;
            Iterator var4 = var2.iterator();

            while(var4.hasNext()) {
               b var6;
               label30: {
                  Object var5 = var4.next();
                  var6 = (b)var5;
                  boolean var7 = false;
                  var10000 = var6.cC();
                  if (var10000 != null) {
                     var8 = var10000.getItemMeta();
                     if (var8 != null) {
                        var9 = var8.getDisplayName();
                        break label30;
                     }
                  }

                  var9 = null;
               }

               if (Intrinsics.areEqual((Object)var9, (Object)var1.getCurrentItem().getItemMeta().getDisplayName())) {
                  var1.getWhoClicked().closeInventory();
                  HumanEntity var10001 = var1.getWhoClicked();
                  Intrinsics.checkNotNull(var10001, "null cannot be cast to non-null type org.bukkit.entity.Player");
                  var6.M((Player)var10001);
                  return;
               }
            }
         }
      }

   }
}
