package ga.strikepractice.hostedevents.e;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.events.PvPEventEndEvent;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.stats.DefaultPlayerStats;
import ga.strikepractice.utils.u;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class c implements Listener {
   private final StrikePractice kn;

   public c(StrikePractice var1) {
      this.kn = var1;
   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      if (b.kk != null) {
         if (b.kk.cA().containsKey(var1.getPlayer().getName())) {
            var1.getPlayer().setHealth(0.0D);
            ga.strikepractice.hostedevents.e.a var2 = b.kk;
            if (var2 == null || var2.getP1() == null || var2.getP2() == null) {
               return;
            }

            if (!var2.getP1().equals(var1.getPlayer().getName()) && !var2.getP2().equals(var1.getPlayer().getName())) {
               b.kk.cA().remove(var1.getPlayer().getName());
               this.kn.clear(var1.getPlayer(), true, true);
            }
         }

      }
   }

   @EventHandler
   public void a(EntityDamageEvent var1) {
      if (b.kk != null && var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         if (b.kk.cA().containsKey(var2.getName()) && !AbstractFight.isInFight(var2)) {
            var1.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void a(PlayerDeathEvent var1) {
      if (b.kk != null) {
         Player var2 = var1.getEntity();
         String var3 = var2.getName();
         if (var3 != null) {
            if (b.kk.cA().containsKey(var3)) {
               b.kk.cA().remove(var3);
               if (b.kk.getP1() == null || b.kk.getP2() == null) {
                  return;
               }

               String var4 = null;
               if (b.kk.getP1().equals(var3)) {
                  var4 = b.kk.getP2();
               } else if (b.kk.getP2().equals(var3)) {
                  var4 = b.kk.getP1();
               }

               if (var4 == null) {
                  return;
               }

               Iterator var5 = b.kk.cA().keySet().iterator();

               String var6;
               while(var5.hasNext()) {
                  var6 = (String)var5.next();
                  Player var7 = Bukkit.getPlayer(var6);
                  if (var7 != null) {
                     this.kn.a(var7, "sumo-slays", u.a("<player1>", var4, "<player2>", var3));
                  }
               }

               Player var9 = Bukkit.getPlayer(var4);
               this.kn.clear(var9, false, true);
               b.kk.cA().put(var9.getName(), true);
               if (b.kk.ct()) {
                  b.kk.cw();
                  b.kk.L(var9);
                  if (this.kn.getConfig().getBoolean("sumo.allow-spectating")) {
                     b.kk.spectators.add(var2.getUniqueId());
                  } else {
                     this.kn.clear(var2, true, true);
                  }
               } else {
                  this.kn.clear(var2, true, true);
                  this.kn.clear(var9, false, true);
                  var6 = null;

                  String var8;
                  Iterator var10;
                  for(var10 = b.kk.cA().keySet().iterator(); var10.hasNext(); var6 = var8) {
                     var8 = (String)var10.next();
                  }

                  var10 = Bukkit.getOnlinePlayers().iterator();

                  while(var10.hasNext()) {
                     Player var12 = (Player)var10.next();
                     this.kn.a(var12, "sumo-winner", u.a("<player>", var6));
                  }

                  PvPEventEndEvent var11 = new PvPEventEndEvent(b.kk, var9);
                  Bukkit.getPluginManager().callEvent(var11);
                  b.kk.stop();
                  DefaultPlayerStats var13 = DefaultPlayerStats.getStats(var9.getUniqueId());
                  var13.setSumoWins(var13.getSumoWins() + 1);
                  if (var6 != null) {
                     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), this.kn.getConfig().getString("sumo.winner-cmd").replace("<player>", var6));
                  }
               }
            }

         }
      }
   }
}
