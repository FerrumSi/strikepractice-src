package ga.strikepractice.hostedevents.e;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import ga.strikepractice.events.PvPEventEndEvent;
import ga.strikepractice.events.PvPEventStartEvent;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.utils.N;
import ga.strikepractice.utils.u;
import java.util.HashSet;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class a extends ga.strikepractice.hostedevents.b.a {
   public a(StrikePractice var1) {
      super(var1);
   }

   public void start() {
      PvPEventStartEvent var1 = new PvPEventStartEvent(this);
      Bukkit.getPluginManager().callEvent(var1);
      if (!var1.isCancelled()) {
         super.cs();
      }
   }

   public void stop() {
      PvPEventEndEvent var1 = new PvPEventEndEvent(this, (Player)null);
      Bukkit.getPluginManager().callEvent(var1);
      this.iJ = 0;
      this.iu = false;
      (new BukkitRunnable() {
         public void run() {
            Iterator var1 = a.this.players.keySet().iterator();

            while(var1.hasNext()) {
               String var2 = (String)var1.next();
               final Player var3 = Bukkit.getPlayer(var2);
               if (var3 != null) {
                  a.this.plugin.a(var3, "event-stopped");
                  if (a.this.plugin.ac().isSpectator(var3)) {
                     a.this.plugin.ac().removeSpectator(var3, true);
                  }

                  a.this.plugin.clear(var3, true, true);
                  (new BukkitRunnable() {
                     public void run() {
                        if (var3 != null) {
                           a.this.plugin.clear(var3, true, true);
                        }

                     }
                  }).runTaskLater(a.this.plugin, 40L);
               }
            }

            a.this.players.clear();
         }
      }).runTaskLater(this.plugin, (long)(20 * this.plugin.getConfig().getInt("wait-before-teleport")));
      this.p1 = null;
      this.p2 = null;
      this.cu();
      b.kk = null;
      b.iU = false;
   }

   public void cw() {
      (new BukkitRunnable() {
         public void run() {
            if (!a.this.ct()) {
               this.cancel();
            } else if (a.this.arena == null || !a.this.arena.needsRollback() && !a.this.arena.isUsing()) {
               int var1 = 0;
               String var2 = null;
               Iterator var3 = a.this.players.keySet().iterator();

               String var4;
               while(var3.hasNext()) {
                  var4 = (String)var3.next();
                  if (!(Boolean)a.this.players.get(var4)) {
                     ++var1;
                     var2 = var4;
                  }
               }

               String var5;
               Iterator var9;
               if (var1 < 2) {
                  HashSet var7 = new HashSet();
                  var9 = a.this.players.keySet().iterator();

                  while(var9.hasNext()) {
                     var5 = (String)var9.next();
                     if (var5 != null && Bukkit.getPlayer(var5) != null) {
                        var7.add(var5);
                     }
                  }

                  a.this.players.clear();
                  var9 = var7.iterator();

                  while(var9.hasNext()) {
                     var5 = (String)var9.next();
                     a.this.players.put(var5, false);
                  }
               }

               if (var2 == null) {
                  var3 = a.this.players.keySet().iterator();

                  while(var3.hasNext()) {
                     var4 = (String)var3.next();
                     if (!(Boolean)a.this.players.get(var4)) {
                        var2 = var4;
                        if (StrikePractice.t.nextInt(a.this.players.size()) == 0) {
                           break;
                        }
                     }
                  }
               }

               a.this.players.put(var2, true);
               String var8 = null;
               var9 = a.this.players.keySet().iterator();

               while(var9.hasNext()) {
                  var5 = (String)var9.next();
                  if (!(Boolean)a.this.players.get(var5)) {
                     var8 = var5;
                     if (StrikePractice.t.nextInt(a.this.players.size()) == 0) {
                        break;
                     }
                  }
               }

               a.this.players.put(var8, true);
               if (var2 != null && var8 != null && Bukkit.getPlayer(var2) != null && Bukkit.getPlayer(var8) != null) {
                  a.this.p1 = var2;
                  a.this.p2 = var8;
                  var9 = a.this.cz().keySet().iterator();

                  while(var9.hasNext()) {
                     var5 = (String)var9.next();
                     Player var6 = Bukkit.getPlayer(var5);
                     if (var6 != null) {
                        a.this.plugin.a(var6, "sumo-next-fight", u.a("<player1>", var2, "<player2>", var8));
                     }
                  }

                  if (a.this.arena == null) {
                     a.this.cy();
                  }

                  if (a.this.arena == null) {
                     Bukkit.broadcastMessage(ChatColor.RED + "Sumo cannot be started... the arena is invalid or it can not be used.");
                     a.this.stop();
                     this.cancel();
                  } else {
                     a.this.arena.removeItems();
                     a.this.fL = new Duel(a.this.plugin, var2, var8, a.this.kit);
                     a.this.fL.setDoNotTeleport(true);
                     a.this.fL.setArena(a.this.arena);
                     a.this.fL.start();
                     a.this.iK = System.currentTimeMillis();
                     this.cancel();
                     a.this.cx();
                  }
               } else {
                  Bukkit.broadcastMessage(ChatColor.RED + "Error: sumo player is invalid!");
                  a.this.stop();
                  this.cancel();
               }
            }
         }
      }).runTaskTimer(this.plugin, 20L, 20L);
   }

   public void cy() {
      Iterator var1 = this.plugin.M.iterator();

      Arena var2;
      while(var1.hasNext()) {
         var2 = (Arena)var1.next();
         if (var2.getName().toLowerCase().contains("sumoevent") && var2.getKits().contains(this.kit.getName().toLowerCase())) {
            this.arena = var2;
         }
      }

      if (this.arena == null) {
         var1 = this.plugin.M.iterator();

         while(var1.hasNext()) {
            var2 = (Arena)var1.next();
            if (var2.getName().equalsIgnoreCase("sumoevent")) {
               this.arena = var2;
            }
         }
      }

      if (this.arena != null) {
         this.arena.setUsing(false);
      }

   }

   public void L(Player var1) {
      Location var2 = ga.strikepractice.hostedevents.b.a.t("sumo");
      if (var2 != null) {
         this.plugin.clear(var1, false, false);
         if (this.iI && this.arena != null) {
            N.e(var1, this.arena.getCenter());
            this.plugin.ac().addSpectator(var1);
         } else {
            N.e(var1, var2);
         }
      } else if (this.iI && this.arena != null) {
         N.e(var1, this.arena.getCenter());
         this.plugin.ac().addSpectator(var1);
      }

   }

   public PvPEvent.a getType() {
      return PvPEvent.a.ik;
   }
}
