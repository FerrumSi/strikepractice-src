package ga.strikepractice.hostedevents.e;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.utils.D;
import ga.strikepractice.utils.e;
import ga.strikepractice.utils.u;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

@e(
   fj = {"join", "leave", "setlobby"}
)
public class b implements CommandExecutor {
   public static ga.strikepractice.hostedevents.e.a kk;
   private static BukkitTask iS;
   private final StrikePractice kl;
   public static boolean iU;

   public b(StrikePractice var1) {
      this.kl = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 0 && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pD) && var4[0].equalsIgnoreCase("start")) {
         if (var4.length > 1) {
            c(var1, var4[1]);
            return true;
         }

         var1.sendMessage(ChatColor.GRAY + "/sumo start <kit>");
      }

      if (var4.length > 0 && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pD) && var4[0].equalsIgnoreCase("open")) {
         if (ga.strikepractice.hostedevents.b.a.t("sumo") == null) {
            var1.sendMessage(ChatColor.RED + "The sumo lobby is invalid!");
         } else if (kk == null) {
            var1.sendMessage(ChatColor.BLUE + "The event is now open!");
            kk = new ga.strikepractice.hostedevents.e.a(this.kl);
         } else {
            var1.sendMessage(ChatColor.RED + "The event is already open!");
         }
      } else if (var4.length > 0 && ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pD) && var4[0].equalsIgnoreCase("stop")) {
         if (kk != null) {
            kk.stop();
            var1.sendMessage(ChatColor.RED + "Stopped!");
         }

         iU = false;
      } else if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         if (var4.length == 0) {
            if (ga.strikepractice.k.b.a(var1, ga.strikepractice.k.a.pD)) {
               var5.sendMessage(ChatColor.GOLD + "/sumo open");
               var5.sendMessage(ChatColor.GOLD + "/sumo start <kit>");
               var5.sendMessage(ChatColor.GOLD + "/sumo stop");
               var5.sendMessage(ChatColor.GOLD + "/sumo setlobby");
            }

            var5.sendMessage(ChatColor.YELLOW + "/sumo join");
            var5.sendMessage(ChatColor.YELLOW + "/sumo leave");
            return true;
         }

         Iterator var6;
         String var7;
         Player var8;
         if (var4[0].equalsIgnoreCase("leave")) {
            if (kk != null && kk.cz().containsKey(var5.getName())) {
               if (kk.getP1() != null && kk.getP2() != null && (kk.getP1().equals(var5.getName()) || kk.getP2().equals(var5.getName()))) {
                  var5.setHealth(0.0D);
                  return true;
               }

               var6 = kk.cz().keySet().iterator();

               while(var6.hasNext()) {
                  var7 = (String)var6.next();
                  var8 = Bukkit.getPlayer(var7);
                  if (var8 != null) {
                     this.kl.a(var8, "sumo-left", u.a("<player>", var5.getName()));
                  }
               }

               this.kl.clear(var5, true, true);
               kk.cz().remove(var5.getName());
               if (!kk.hasStarted()) {
                  kk.iJ = kk.cz().size();
               }

               if (iS != null && !ct()) {
                  var6 = Bukkit.getOnlinePlayers().iterator();

                  while(var6.hasNext()) {
                     Player var12 = (Player)var6.next();
                     if (ga.strikepractice.k.b.a(var12, ga.strikepractice.k.a.py)) {
                        var12.sendMessage(ChatColor.RED + "sumo does not have has enough players to start automatically. Cancelling the sumo.");
                     }
                  }

                  iS.cancel();
               }
            }

            return true;
         }

         if (Party.getParty(var5) != null) {
            this.kl.a(var5, "can-not-do-while-in-party");
            return true;
         }

         if (AbstractFight.isInFight(var5) || var5.hasMetadata("StrikePracticeWaitingQueue") || PvPEvent.isInEvent(var5)) {
            this.kl.a(var5, "can-not-do-while-in-match");
            return true;
         }

         if (var4[0].equalsIgnoreCase("join")) {
            if (kk == null) {
               this.kl.a(var5, "sumo-not-started");
               return true;
            }

            if (ga.strikepractice.hostedevents.b.a.t("sumo") == null) {
               var5.sendMessage(ChatColor.RED + "Invalid sumo lobby!");
               return true;
            }

            if (kk.hasStarted()) {
               this.kl.a(var5, "sumo-already-started");
            } else if (!kk.cz().containsKey(var5.getName())) {
               if (this.kl.ac().isSpectator(var5)) {
                  this.kl.ac().removeSpectator(var5, false);
               }

               kk.cz().put(var5.getName(), false);
               if (!kk.hasStarted()) {
                  kk.iJ = kk.cz().size();
               }

               kk.L(var5);
               var6 = kk.cz().keySet().iterator();

               while(var6.hasNext()) {
                  var7 = (String)var6.next();
                  var8 = Bukkit.getPlayer(var7);
                  if (var8 != null) {
                     this.kl.a(var8, "sumo-joined", u.a("<player>", var5.getName()));
                  }
               }

               int var10 = this.kl.getConfig().getInt("sumo.auto-start");
               if (!iU && iS == null && var10 == kk.cz().size()) {
                  int var11 = this.kl.getConfig().getInt("sumo.auto-start-after-seconds");
                  Iterator var13 = Bukkit.getOnlinePlayers().iterator();

                  while(var13.hasNext()) {
                     Player var9 = (Player)var13.next();
                     if (ga.strikepractice.k.b.a(var9, ga.strikepractice.k.a.py)) {
                        var9.sendMessage(ChatColor.RED + "Sumo has now " + var10 + " players, starting it automatically in " + var11 + " seconds.");
                     }
                  }

                  iS = (new BukkitRunnable() {
                     public void run() {
                        Iterator var1 = Bukkit.getOnlinePlayers().iterator();

                        while(var1.hasNext()) {
                           Player var2 = (Player)var1.next();
                           if (ga.strikepractice.k.b.a(var2, ga.strikepractice.k.a.py)) {
                              var2.sendMessage(ChatColor.RED + "Starting sumo automatically!");
                           }
                        }

                        b.c(Bukkit.getConsoleSender(), b.this.kl.getConfig().getString("automatic-events.sumo-kit"));
                     }
                  }).runTaskLater(this.kl, (long)(20 * var11));
               }
            }
         } else if (var4[0].equalsIgnoreCase("setlobby") && ga.strikepractice.k.b.a(var5, ga.strikepractice.k.a.pz)) {
            this.kl.getConfig().set("sumo.lobby", new D(var5.getLocation()));
            this.kl.saveConfig();
            var5.sendMessage(ChatColor.BLUE + "Sumo lobby set!");
         }
      }

      return true;
   }

   public static boolean ct() {
      if (kk != null && kk.cz() != null) {
         return kk.ct() && kk.cz().size() >= StrikePractice.getInstance().getConfig().getInt("sumo.auto-start");
      } else {
         return false;
      }
   }

   public static boolean c(CommandSender var0, String var1) {
      if (kk == null) {
         var0.sendMessage(ChatColor.RED + "Can't start the sumo! The game is not open.");
      } else if (kk.hasStarted()) {
         var0.sendMessage(ChatColor.RED + "The event has already started.");
      } else {
         if (kk.ct()) {
            if (iS != null) {
               iS.cancel();
            }

            BattleKit var2 = BattleKit.getKit(var1);
            if (var2 == null) {
               var0.sendMessage(ChatColor.RED + "Invanlid kit!");
               return false;
            }

            kk.setKit(var2);
            kk.start();
            return true;
         }

         var0.sendMessage(ChatColor.RED + "There are under 2 players in the sumo!");
         kk.stop();
      }

      return false;
   }
}
