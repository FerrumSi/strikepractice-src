package ga.strikepractice.hostedevents.a;

public enum c {
   iC,
   iD,
   iE,
   iF,
   iG;

   public static c s(String var0) {
      String var1 = var0.toLowerCase().replace(" ", "").replace("_", "").replace("-", "");
      if (!var1.equals("lms") && !var1.equals("lastmanstanding")) {
         if (!var1.equals("koth") && !var1.equals("kingofthehill")) {
            if (var1.equals("juggernaut")) {
               return iF;
            } else if (!var1.equals("brackets") && !var1.equals("1v1tournament")) {
               return !var1.equals("sumo") && !var1.equals("sumoevent") ? null : iG;
            } else {
               return iC;
            }
         } else {
            return iD;
         }
      } else {
         return iE;
      }
   }

   public String toString() {
      if (!this.equals(iD) && !this.equals(iE)) {
         String var1 = super.toString().toLowerCase();
         return Character.toUpperCase(var1.charAt(0)) + var1.substring(1);
      } else {
         return super.toString();
      }
   }

   // $FF: synthetic method
   private static c[] cr() {
      return new c[]{iC, iD, iE, iF, iG};
   }
}
