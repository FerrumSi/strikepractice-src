package ga.strikepractice.hostedevents.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.P;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

public class b extends BukkitRunnable {
   public static final Map<ga.strikepractice.hostedevents.a.a, String> iA = Collections.synchronizedMap(new HashMap());
   private final StrikePractice iB;

   public b(StrikePractice var1) {
      this.iB = var1;
   }

   public void run() {
      Calendar var1 = P.gA();
      int var2 = var1.get(11);
      int var3 = var1.get(12);
      Iterator var4 = cq().entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         String[] var6 = ((String)var5.getKey()).split(":");

         try {
            int var7 = Integer.parseInt(var6[0]);
            int var8 = Integer.parseInt(var6[1]);
            if (var7 == var2 && var8 == var3) {
               if (iA.containsValue(((c)var5.getValue()).toString())) {
                  return;
               }

               iA.put(new ga.strikepractice.hostedevents.a.a(this.iB, ((c)var5.getValue()).toString()), ((c)var5.getValue()).toString());
            }
         } catch (IndexOutOfBoundsException | NumberFormatException var9) {
            Bukkit.getLogger().warning("Could not start automatic event! The format:" + var5 + " is invalid! Format should be: hours:minutes:event(for example: 15:30:lms)");
         }
      }

   }

   public static Map<String, c> cq() {
      HashMap var0 = new HashMap();
      Iterator var1 = StrikePractice.getInstance().getConfig().getStringList("automatic-events.times").iterator();

      while(var1.hasNext()) {
         String var2 = (String)var1.next();
         String[] var3 = var2.split(":");

         try {
            int var4 = Integer.parseInt(var3[0]);
            int var5 = Integer.parseInt(var3[1]);
            c var6 = c.s(var3[2]);
            if (var6 != null) {
               var0.put((var4 == 0 ? "00" : var4) + ":" + (var5 == 0 ? "00" : var5), var6);
            }
         } catch (IndexOutOfBoundsException | NumberFormatException var7) {
            Bukkit.getLogger().warning("Could not start automatic event! The format:" + var2 + " is invalid! Format should be: hours:minutes:event(for example: 15:30:lms)");
         }
      }

      return var0;
   }

   public static void g(StrikePractice var0) {
      (new b(var0)).runTaskTimerAsynchronously(var0, 600L, StrikePractice.C ? 900L : 400L);
   }
}
