package ga.strikepractice.hostedevents.a;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.hostedevents.lms.LMS;
import ga.strikepractice.utils.d;
import ga.strikepractice.utils.f;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class a {
   private final StrikePractice iq;
   private c ir;
   private final BattleKit is;
   private String it;
   private boolean iu;
   private String cW;
   private ga.strikepractice.utils.c<Integer> iv;

   public a(StrikePractice var1, String var2, BattleKit var3) {
      this.iq = var1;
      this.is = var3;
      String var4 = var2.toLowerCase();
      if (var4.equals("lms")) {
         this.ir = c.iE;
      } else if (var4.equals("brackets")) {
         this.ir = c.iC;
      } else if (var4.equals("juggernaut")) {
         this.ir = c.iF;
      } else if (var4.equals("koth")) {
         this.ir = c.iD;
      } else if (var4.equals("sumo")) {
         this.ir = c.iG;
      }

      if (this.cl()) {
         this.cn();
      }

   }

   public a(StrikePractice var1, String var2) {
      this(var1, var2, (BattleKit)null);
   }

   public a(StrikePractice var1, String var2, String var3) {
      this(var1, var2, (BattleKit)null);
      this.it = var3;
   }

   private boolean cl() {
      return this.ir != null && !b.iA.containsValue(this.ir.toString().toLowerCase());
   }

   private BattleKit getKit() {
      return this.is;
   }

   public c cm() {
      return this.ir;
   }

   public void r(String var1) {
      this.cW = var1;
   }

   private void cn() {
      if (this.ir == c.iE) {
         if (ga.strikepractice.hostedevents.lms.a.jl) {
            return;
         }

         ga.strikepractice.hostedevents.lms.a.jl = true;
      } else if (this.ir == c.iC) {
         if (ga.strikepractice.hostedevents.b.b.iR != null) {
            return;
         }

         ga.strikepractice.hostedevents.b.b.iR = new ga.strikepractice.hostedevents.b.a(this.iq);
      } else if (this.ir == c.iG) {
         if (ga.strikepractice.hostedevents.e.b.kk != null) {
            return;
         }

         ga.strikepractice.hostedevents.e.b.kk = new ga.strikepractice.hostedevents.e.a(this.iq);
      } else if (this.ir == c.iF) {
         if (ga.strikepractice.hostedevents.d.b.jl) {
            return;
         }

         ga.strikepractice.hostedevents.d.b.jl = true;
      } else if (this.ir == c.iD) {
         if (ga.strikepractice.hostedevents.koth.b.jl) {
            return;
         }

         ga.strikepractice.hostedevents.koth.b.jl = true;
      }

      (new BukkitRunnable() {
         int counter;

         {
            this.counter = a.this.iq.getConfig().getInt("automatic-events.broadcast.times");
         }

         public void run() {
            String var1 = a.this.cW == null ? "Server" : a.this.cW;
            String var2 = a.this.iq.getConfig().getString("automatic-events.broadcast." + a.this.ir.toString().toLowerCase());
            BattleKit var3 = a.this.is != null ? a.this.is : StrikePractice.getAPI().getKit(a.this.cp());
            if (var3 == null) {
               Bukkit.getLogger().warning("Invalid kit in " + a.this.ir + " event: " + a.this.cp());
               Bukkit.broadcast("Invalid kit in " + a.this.ir + " event: " + a.this.cp(), ga.strikepractice.k.a.py.dY());
               this.cancel();
               if (ga.strikepractice.hostedevents.koth.b.jE != null) {
                  ga.strikepractice.hostedevents.koth.b.jE.stop();
               }

            } else {
               String var4 = a.this.iq.X() + f.K(var2.replace("<player>", var1).replace("<host>", var1).replace("<kit>", var3.getFancyName()));
               if (this.counter <= 0) {
                  try {
                     (new BukkitRunnable() {
                        public void run() {
                           a.this.start();
                        }
                     }).runTask(a.this.iq);
                  } catch (Exception var7) {
                     Bukkit.broadcastMessage(ChatColor.RED + "The " + a.this.ir.toString().toLowerCase() + " event could not be started...");
                  }

                  this.cancel();
               } else if (!a.this.co()) {
                  if (!var2.isEmpty()) {
                     Iterator var5 = Bukkit.getOnlinePlayers().iterator();

                     while(var5.hasNext()) {
                        Player var6 = (Player)var5.next();
                        d.b(var6, var4, "/" + a.this.ir.toString().toLowerCase() + " join");
                     }
                  }
               } else {
                  this.cancel();
               }

               --this.counter;
            }
         }
      }).runTaskTimerAsynchronously(this.iq, 2L, (long)(20 * this.iq.getConfig().getInt("automatic-events.broadcast.delay")));
   }

   private boolean co() {
      Iterator var1 = PvPEvent.getCurrentPvPEvents().iterator();

      PvPEvent var2;
      do {
         if (!var1.hasNext()) {
            return false;
         }

         var2 = (PvPEvent)var1.next();
         if (this.ir == c.iE && var2 instanceof LMS) {
            return true;
         }

         if (this.ir == c.iC && var2 instanceof ga.strikepractice.hostedevents.b.a) {
            return true;
         }

         if (this.ir == c.iF && var2 instanceof ga.strikepractice.hostedevents.d.a) {
            return true;
         }

         if (this.ir == c.iD && var2 instanceof ga.strikepractice.hostedevents.koth.a) {
            return true;
         }
      } while(this.ir != c.iG || !(var2 instanceof ga.strikepractice.hostedevents.e.a));

      return true;
   }

   private void start() {
      String var1 = this.cp();
      if (this.ir == c.iE) {
         this.iu = ga.strikepractice.hostedevents.lms.a.a(Bukkit.getConsoleSender(), new String[]{"start", var1}, this.iq);
         b.iA.remove(this);
         ga.strikepractice.hostedevents.lms.a.jl = false;
      } else if (this.ir == c.iC) {
         this.iu = ga.strikepractice.hostedevents.b.b.c(Bukkit.getConsoleSender(), var1);
         b.iA.remove(this);
      } else if (this.ir == c.iG) {
         this.iu = ga.strikepractice.hostedevents.e.b.c(Bukkit.getConsoleSender(), var1);
         b.iA.remove(this);
      } else if (this.ir == c.iF) {
         this.iu = ga.strikepractice.hostedevents.d.b.a(Bukkit.getConsoleSender(), new String[]{"start", this.it != null ? this.it : "-random", this.iq.getConfig().getString("automatic-events.juggernaut-kit"), var1}, this.iq);
         b.iA.remove(this);
      } else if (this.ir == c.iD) {
         this.iu = ga.strikepractice.hostedevents.koth.b.a(Bukkit.getConsoleSender(), new String[]{var1}, this.iq);
         b.iA.remove(this);
         ga.strikepractice.hostedevents.koth.b.jl = StrikePractice.getInstance().getConfig().getBoolean("koth.anytime-join");
      } else {
         (new BukkitRunnable() {
            public void run() {
               b.iA.remove(a.this);
            }
         }).runTaskLaterAsynchronously(this.iq, 1200L);
      }

      if (this.iv != null) {
         this.iv.run(this.iu ? 1 : -1);
         this.iv = null;
      }

   }

   private String cp() {
      if (this.is != null) {
         return this.is.getName();
      } else {
         switch(this.ir) {
         case iE:
            return this.iq.getConfig().getString("automatic-events.lms-kit");
         case iC:
            return this.iq.getConfig().getString("automatic-events.brackets-kit");
         case iG:
            return this.iq.getConfig().getString("automatic-events.sumo-kit");
         case iF:
            return this.iq.getConfig().getString("automatic-events.juggernaut-player-kit");
         case iD:
            return this.iq.getConfig().getString("automatic-events.koth-kit");
         default:
            Bukkit.getLogger().warning("Invalid kit in " + this.ir + " event! Check configured default kit");
            return null;
         }
      }
   }

   public void c(ga.strikepractice.utils.c<Integer> var1) {
      this.iv = var1;
   }
}
