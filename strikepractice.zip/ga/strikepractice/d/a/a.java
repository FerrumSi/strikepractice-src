package ga.strikepractice.d.a;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import ga.strikepractice.StrikePractice;
import ga.strikepractice.events.BotDuelEndEvent;
import ga.strikepractice.events.DuelEndEvent;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.botduel.BotDuel;
import ga.strikepractice.fights.duel.Duel;
import ga.strikepractice.i.v;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.TuplesKt;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.collections.MapsKt;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.Ref;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.Charsets;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.g;
import ga.strikepractice.utils.o;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0007\u001a\u00020\bH\u0002J\n\u0010\t\u001a\u0004\u0018\u00010\nH\u0002J\u0012\u0010\u000b\u001a\u0004\u0018\u00010\n2\u0006\u0010\f\u001a\u00020\nH\u0002J\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0007J=\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\n2\u0006\u0010\u0015\u001a\u00020\n2\u0006\u0010\u0016\u001a\u00020\n2\b\u0010\u0017\u001a\u0004\u0018\u00010\u00182\u0006\u0010\u0019\u001a\u00020\u001a¢\u0006\u0002\u0010\u001bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u001c"},
   d2 = {"Lga/strikepractice/discord/webhook/FightWebhook;", "Lorg/bukkit/event/Listener;", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "getPlugin", "()Lga/strikepractice/StrikePractice;", "getFile", "Ljava/io/File;", "getWebhookUrl", "", "loadJsonMessage", "message", "onFightEnd", "", "e", "Lga/strikepractice/events/DuelEndEvent;", "postFight", "placeholderPlayer", "Lorg/bukkit/entity/Player;", "messageType", "winner", "loser", "eloChange", "", "fight", "Lga/strikepractice/fights/Fight;", "(Lorg/bukkit/entity/Player;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Lga/strikepractice/fights/Fight;)V", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nFightWebhook.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FightWebhook.kt\nga/strikepractice/discord/webhook/FightWebhook\n+ 2 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n*L\n1#1,126:1\n81#2,4:127\n81#2,4:131\n81#2,4:135\n81#2,4:139\n81#2,4:143\n81#2,4:147\n81#2,4:151\n*S KotlinDebug\n*F\n+ 1 FightWebhook.kt\nga/strikepractice/discord/webhook/FightWebhook\n*L\n50#1:127,4\n52#1:131,4\n82#1:135,4\n84#1:139,4\n91#1:143,4\n93#1:147,4\n98#1:151,4\n*E\n"})
public final class a implements Listener {
   @NotNull
   private final StrikePractice dU;

   public a(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.dU = var1;
      this.aT();
      PluginManager var2 = Bukkit.getPluginManager();
      var2.registerEvents((Listener)(new v()), (Plugin)this.dU);
      if (var2.getPlugin("Citizens") != null) {
         Plugin var10000 = var2.getPlugin("Citizens");
         if (var10000 != null ? var10000.isEnabled() : false) {
            try {
               var2.registerEvents((Listener)(new Listener() {
                  @EventHandler
                  public final void a(@NotNull BotDuelEndEvent var1) {
                     Intrinsics.checkNotNullParameter(var1, "e");
                     if (var1.getWinner() != null && var1.getPlayer() != null) {
                        ga.strikepractice.d.a.a var10000 = a.this;
                        Player var10001 = var1.getPlayer();
                        Intrinsics.checkNotNullExpressionValue(var10001, "e.player");
                        String var10003 = var1.getWinner();
                        Intrinsics.checkNotNullExpressionValue(var10003, "e.winner");
                        String var10004 = var1.getLoser();
                        Intrinsics.checkNotNullExpressionValue(var10004, "e.loser");
                        BotDuel var10006 = var1.getFight();
                        Intrinsics.checkNotNullExpressionValue(var10006, "e.fight");
                        var10000.a(var10001, "botduel", var10003, var10004, (Integer)null, (Fight)var10006);
                     }

                  }
               }), (Plugin)this.dU);
            } catch (Exception var4) {
               Bukkit.getLogger().warning("Failed to enable discord webhooks for bot duels.");
               if (B.vj.fV()) {
                  var4.printStackTrace();
               }
            }
         }
      }

   }

   @NotNull
   public final StrikePractice aS() {
      return this.dU;
   }

   private final File aT() {
      File var1 = new File(this.dU.getDataFolder(), "discord-webhooks.json");
      boolean var3 = false;
      Logger var10000;
      B.a var4;
      boolean var5;
      StringBuilder var6;
      Logger var7;
      boolean var8;
      String var9;
      if (!var1.exists()) {
         this.dU.saveResource("discord-webhooks.json", false);
         var4 = B.vj;
         var5 = false;
         if (var4.fV()) {
            var10000 = Bukkit.getLogger();
            var6 = (new StringBuilder()).append("[SP DEBUG] ");
            var7 = var10000;
            var8 = false;
            var9 = "initialized webhook file " + var1.getAbsolutePath();
            var7.info(var6.append(var9).toString());
         }
      } else {
         var4 = B.vj;
         var5 = false;
         if (var4.fV()) {
            var10000 = Bukkit.getLogger();
            var6 = (new StringBuilder()).append("[SP DEBUG] ");
            var7 = var10000;
            var8 = false;
            var9 = "loaded webhook file from " + var1.getAbsolutePath();
            var7.info(var6.append(var9).toString());
         }
      }

      return var1;
   }

   private final String h(String var1) {
      File var2 = this.aT();
      Gson var10000 = new Gson();
      Charset var5 = Charsets.UTF_8;
      short var6 = 8192;
      Reader var7 = (Reader)(new InputStreamReader((InputStream)(new FileInputStream(var2)), var5));
      Map var3 = (Map)var10000.fromJson((Reader)(var7 instanceof BufferedReader ? (BufferedReader)var7 : new BufferedReader(var7, var6)), g.fp());
      if (var3 != null) {
         Object var8 = var3.get(var1);
         if (var8 != null) {
            Object var4 = var8;
            return (new GsonBuilder()).disableHtmlEscaping().create().toJson(var4);
         }
      }

      return null;
   }

   private final String aU() {
      return this.dU.getConfig().getString("discord.fight-webhook-url");
   }

   @EventHandler
   public final void a(@NotNull DuelEndEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (var1.getWinner() != null && var1.getLoser() != null) {
         String var2 = var1.getFight().getKit().isElo() ? "ranked" : (var1.getFight().isQueue() ? "unranked" : "duel");
         C.a(ga.strikepractice.d.a.a::a, 10L);
      }
   }

   public final void a(@NotNull Player var1, @NotNull String var2, @NotNull String var3, @NotNull String var4, @Nullable Integer var5, @NotNull Fight var6) {
      Intrinsics.checkNotNullParameter(var1, "placeholderPlayer");
      Intrinsics.checkNotNullParameter(var2, "messageType");
      Intrinsics.checkNotNullParameter(var3, "winner");
      Intrinsics.checkNotNullParameter(var4, "loser");
      Intrinsics.checkNotNullParameter(var6, "fight");

      try {
         B.a var7;
         boolean var8;
         boolean var9;
         Logger var11;
         StringBuilder var12;
         String var13;
         Logger var10000;
         if (!this.dU.getConfig().getBoolean("discord.enable-webhooks")) {
            var7 = B.vj;
            var8 = false;
            if (var7.fV()) {
               var10000 = Bukkit.getLogger();
               var12 = (new StringBuilder()).append("[SP DEBUG] ");
               var11 = var10000;
               var9 = false;
               var13 = "discord.enable-webhooks is disabled";
               var11.info(var12.append(var13).toString());
            }
         } else if (!this.dU.getConfig().getStringList("discord.webhook-types").contains(var2)) {
            var7 = B.vj;
            var8 = false;
            if (var7.fV()) {
               var10000 = Bukkit.getLogger();
               var12 = (new StringBuilder()).append("[SP DEBUG] ");
               var11 = var10000;
               var9 = false;
               StringBuilder var17 = (new StringBuilder()).append("discord.webhook-types does not contain ").append(var2).append(" but contains:");
               List var10001 = this.dU.getConfig().getStringList("discord.webhook-types");
               Intrinsics.checkNotNullExpressionValue(var10001, "plugin.config.getStringL…(\"discord.webhook-types\")");
               var13 = var17.append(CollectionsKt.joinToString$default((Iterable)var10001, (CharSequence)null, (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 63, (Object)null)).toString();
               var11.info(var12.append(var13).toString());
            }
         } else {
            String var15 = this.aU();
            boolean var10;
            B.a var16;
            if (var15 != null && StringsKt.startsWith$default(var15, "https://", false, 2, (Object)null)) {
               var16 = B.vj;
               var9 = false;
               if (var16.fV()) {
                  var10000 = Bukkit.getLogger();
                  var12 = (new StringBuilder()).append("[SP DEBUG] ");
                  var11 = var10000;
                  var10 = false;
                  var13 = "posting " + var2 + " fight (discord webhook)";
                  var11.info(var12.append(var13).toString());
               }

               C.c(ga.strikepractice.d.a.a::a);
            } else {
               var16 = B.vj;
               var9 = false;
               if (var16.fV()) {
                  var10000 = Bukkit.getLogger();
                  var12 = (new StringBuilder()).append("[SP DEBUG] ");
                  var11 = var10000;
                  var10 = false;
                  var13 = "invalid webhook url: " + var15;
                  var11.info(var12.append(var13).toString());
               }
            }
         }
      } catch (Exception var14) {
         Bukkit.getLogger().warning("Failed to send discord webhook message (fight=" + var14 + ".fight)");
         var14.printStackTrace();
      }

   }

   private static final void a(ga.strikepractice.d.a.a var0, DuelEndEvent var1, String var2) {
      Intrinsics.checkNotNullParameter(var0, "this$0");
      Intrinsics.checkNotNullParameter(var1, "$e");
      Intrinsics.checkNotNullParameter(var2, "$messageType");
      Player var10001 = var1.getWinner();
      Intrinsics.checkNotNullExpressionValue(var10001, "e.winner");
      String var10003 = var1.getWinner().getName();
      Intrinsics.checkNotNullExpressionValue(var10003, "e.winner.name");
      String var10004 = var1.getLoser().getName();
      Intrinsics.checkNotNullExpressionValue(var10004, "e.loser.name");
      Integer var10005 = var1.getFight().winnerEloChange;
      Duel var10006 = var1.getFight();
      Intrinsics.checkNotNullExpressionValue(var10006, "e.fight");
      var0.a(var10001, var2, var10003, var10004, var10005, (Fight)var10006);
   }

   private static final void a(String var0, Ref.ObjectRef var1) {
      Intrinsics.checkNotNullParameter(var1, "$message");
      Object var10001 = var1.element;
      Intrinsics.checkNotNull(var10001);
      o.c(var0, (String)var10001);
   }

   private static final void a(Ref.ObjectRef var0, ga.strikepractice.d.a.a var1, String var2, String var3, Integer var4, Fight var5, Player var6, String var7) {
      Intrinsics.checkNotNullParameter(var0, "$message");
      Intrinsics.checkNotNullParameter(var1, "this$0");
      Intrinsics.checkNotNullParameter(var2, "$winner");
      Intrinsics.checkNotNullParameter(var3, "$loser");
      Intrinsics.checkNotNullParameter(var5, "$fight");
      Intrinsics.checkNotNullParameter(var6, "$placeholderPlayer");
      if (var0.element == null) {
         B.a var8 = B.vj;
         boolean var9 = false;
         if (var8.fV()) {
            Logger var10000 = Bukkit.getLogger();
            StringBuilder var12 = (new StringBuilder()).append("[SP DEBUG] ");
            Logger var11 = var10000;
            boolean var10 = false;
            String var13 = "invalid webhook message " + (String)var0.element;
            var11.info(var12.append(var13).toString());
         }
      } else {
         StrikePractice var10001 = var1.dU;
         String var10002 = (String)var0.element;
         Pair[] var14 = new Pair[]{TuplesKt.to("<winner>", var2), TuplesKt.to("<loser>", var3), TuplesKt.to("<elo_changes>", var4 != null ? var4 : 0), TuplesKt.to("<fight_id>", var5.getStarted())};
         var0.element = var10001.a(var10002, MapsKt.mapOf(var14));
         var0.element = var1.dU.ab.a(var6, (String)var0.element, "", true);
         if (!var1.dU.getConfig().getBoolean("keep-webhook-colors")) {
            var0.element = ChatColor.stripColor((String)var0.element);
         }

         C.c(ga.strikepractice.d.a.a::a);
      }

   }

   private static final void a(ga.strikepractice.d.a.a var0, String var1, String var2, String var3, Integer var4, Fight var5, Player var6, String var7) {
      Intrinsics.checkNotNullParameter(var0, "this$0");
      Intrinsics.checkNotNullParameter(var1, "$messageType");
      Intrinsics.checkNotNullParameter(var2, "$winner");
      Intrinsics.checkNotNullParameter(var3, "$loser");
      Intrinsics.checkNotNullParameter(var5, "$fight");
      Intrinsics.checkNotNullParameter(var6, "$placeholderPlayer");
      Ref.ObjectRef var8 = new Ref.ObjectRef();
      var8.element = var0.h(var1);
      C.d(ga.strikepractice.d.a.a::a);
   }
}
