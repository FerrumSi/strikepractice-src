package ga.strikepractice.h;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.inventory.ItemStack;

@SerializableAs("LanguageItem")
public class b implements ConfigurationSerializable {
   private int jc;
   private ItemStack ja;
   private String language;

   public b(ItemStack var1, String var2, int var3) {
      this.ja = var1;
      this.language = var2;
      this.jc = var3;
   }

   public b(Map<String, Object> var1) {
      if (var1.containsKey("language") && var1.containsKey("item") && var1.containsKey("slot")) {
         Object var2 = var1.get("language");
         if (var2 instanceof String) {
            this.language = (String)var2;
         }

         Object var3 = var1.get("item");
         if (var3 instanceof ItemStack) {
            this.ja = (ItemStack)var3;
         }

         Object var4 = var1.get("slot");
         if (var4 instanceof Integer) {
            this.jc = (Integer)var4;
         }
      }

   }

   public void setLanguage(String var1) {
      this.language = var1;
   }

   public void b(ItemStack var1) {
      this.ja = var1;
   }

   public void i(int var1) {
      this.jc = var1;
   }

   public String getLanguage() {
      return this.language;
   }

   public ItemStack cC() {
      return this.ja;
   }

   public int bl() {
      return this.jc;
   }

   public Map<String, Object> serialize() {
      HashMap var1 = new HashMap();
      var1.put("language", this.language);
      var1.put("slot", this.jc);
      var1.put("item", this.ja);
      return var1;
   }

   public static b g(Map<String, Object> var0) {
      return new b(var0);
   }

   public static b h(Map<String, Object> var0) {
      return new b(var0);
   }
}
