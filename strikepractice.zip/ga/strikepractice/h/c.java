package ga.strikepractice.h;

import ga.strikepractice.StrikePractice;
import java.util.Iterator;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class c implements CommandExecutor {
   private final StrikePractice kF;

   public c(StrikePractice var1) {
      this.kF = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         if (var4.length < 2) {
            var5.sendMessage(ChatColor.GRAY + "/langitem create <language> <slot>");
            var5.sendMessage(ChatColor.GRAY + "/langitem delete <slot>");
         } else {
            int var6;
            if (var4.length == 3) {
               if (var4[0].equalsIgnoreCase("create")) {
                  if (var5.getItemInHand() != null && var5.getItemInHand().getType() != Material.AIR) {
                     try {
                        var6 = Integer.parseInt(var4[2]);
                     } catch (NumberFormatException var10) {
                        var5.sendMessage(ChatColor.RED + "That's not a number!");
                        return true;
                     }

                     if (var6 > 54 || var6 < 1) {
                        var5.sendMessage(ChatColor.RED + "The slot must be between 1 and 54");
                        return true;
                     }

                     b var11 = new b(var5.getItemInHand(), var4[1].replace("_", " "), var6 - 1);
                     this.kF.K.add(var11);
                     var5.sendMessage(ChatColor.BLUE + "Created a new language item.");
                  } else {
                     var5.sendMessage(ChatColor.RED + "Hold something in your hand.");
                  }
               }
            } else if (var4.length == 2 && var4[0].equalsIgnoreCase("delete")) {
               try {
                  var6 = Integer.parseInt(var4[1]) - 1;
               } catch (NumberFormatException var9) {
                  var5.sendMessage(ChatColor.RED + "That's not a number!");
                  return true;
               }

               Iterator var7 = this.kF.K.iterator();

               while(var7.hasNext()) {
                  b var8 = (b)var7.next();
                  if (var8.bl() == var6) {
                     this.kF.K.remove(var8);
                     var5.sendMessage(ChatColor.BLUE + "Deleted an old language item. (slot " + var4[1] + ")");
                     break;
                  }
               }
            }
         }
      }

      return true;
   }
}
