package ga.strikepractice.h;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.playersettings.PlayerSettings;
import ga.strikepractice.utils.f;
import ga.strikepractice.utils.s;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class e {
   public static void b(Player var0, StrikePractice var1) {
      int var2 = var1.getConfig().getInt("language.inv-size");
      Inventory var3 = Bukkit.createInventory((InventoryHolder)null, var2, f.K(var1.getConfig().getString("language.title")));

      for(int var4 = 0; var4 < 9; ++var4) {
         var3.setItem(var4, s.a(Material.STAINED_GLASS_PANE, " "));
      }

      Iterator var6 = var1.K.iterator();

      while(var6.hasNext()) {
         b var5 = (b)var6.next();
         var3.setItem(var5.bl(), var5.cC());
      }

      var3.setItem(4, s.a(Material.getMaterial(var1.getConfig().getString("language.your-language-item")), f.K(var1.getConfig().getString("language.your-language")).replace("<language>", PlayerSettings.getPlayerSettings(var0).getLanguage())));
      var3.setItem(var3.getSize() - 1, ga.strikepractice.m.a.aJ(var0));
      var0.openInventory(var3);
   }

   public static void a(StrikePractice var0, Player var1, String var2) {
      int var3 = var0.getConfig().getInt("language.inv-size");
      Inventory var4 = Bukkit.createInventory((InventoryHolder)null, var3, f.K(var0.getConfig().getString("language.title")));

      for(int var5 = 0; var5 < 9; ++var5) {
         var4.setItem(var5, s.a(Material.STAINED_GLASS_PANE, " "));
      }

      var4.setItem(4, s.a(Material.getMaterial(var0.getConfig().getString("language.your-language-item")), f.K(var0.getConfig().getString("language.your-language")).replace("<language>", PlayerSettings.getPlayerSettings(var1).getLanguage())));
      Iterator var7 = var0.K.iterator();

      while(var7.hasNext()) {
         b var6 = (b)var7.next();
         if (var6.getLanguage().toLowerCase().contains(var2.toLowerCase())) {
            var4.addItem(new ItemStack[]{var6.cC()});
         }
      }

      var4.setItem(var4.getSize() - 1, ga.strikepractice.m.a.aJ(var1));
      var1.openInventory(var4);
   }

   public static String T(Player var0) {
      StrikePractice var1 = StrikePractice.getInstance();
      if (var0 != null && var1.getConfig().getBoolean("language.automatic-language")) {
         String var2 = var1.ao().dH().getLanguage(var0);
         if (var2 != null) {
            if (var2.equals("fi_FI")) {
               Bukkit.getLogger().info(var0.getName() + "'s language was automatically detected and set to 'suomi' (Finnish)");
               return "suomi";
            }

            if (var2.equals("en_CA") || var2.equals("en_GB") || var2.equals("en_AU") || var2.equals("en_US")) {
               Bukkit.getLogger().info(var0.getName() + "'s language was automatically detected and set to 'english'. Disable with language.automatic-language: false");
               return "english";
            }
         }
      }

      return var1.getConfig().getString("default-language");
   }
}
