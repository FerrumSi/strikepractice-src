package ga.strikepractice.h;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.playersettings.PlayerSettings;
import ga.strikepractice.utils.g;
import ga.strikepractice.utils.r;
import java.util.Iterator;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\t"},
   d2 = {"Lga/strikepractice/language/LanguageListener;", "Lorg/bukkit/event/Listener;", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "onClick", "", "e", "Lorg/bukkit/event/inventory/InventoryClickEvent;", "strikepractice-core"}
)
public final class d implements Listener {
   @NotNull
   private final StrikePractice kG;

   public d(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.kG = var1;
   }

   @EventHandler
   public final void f(@NotNull InventoryClickEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      if (var1.getWhoClicked() instanceof Player && r.h(var1.getCurrentItem())) {
         HumanEntity var10000 = var1.getWhoClicked();
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.bukkit.entity.Player");
         Player var2 = (Player)var10000;
         ItemStack var3 = var1.getCurrentItem();
         String var6 = var1.getView().getTitle();
         String var10001 = this.kG.getConfig().getString("language.title");
         Intrinsics.checkNotNullExpressionValue(var10001, "plugin.config.getString(\"language.title\")");
         if (Intrinsics.areEqual((Object)var6, (Object)g.P(var10001))) {
            var1.setCancelled(true);
            Iterator var4 = this.kG.K.iterator();

            while(var4.hasNext()) {
               b var5;
               label28: {
                  var5 = (b)var4.next();
                  ItemStack var7 = var5.cC();
                  if (var7 != null) {
                     ItemMeta var8 = var7.getItemMeta();
                     if (var8 != null) {
                        var6 = var8.getDisplayName();
                        break label28;
                     }
                  }

                  var6 = null;
               }

               ItemMeta var9 = var3.getItemMeta();
               if (Intrinsics.areEqual((Object)var6, (Object)(var9 != null ? var9.getDisplayName() : null))) {
                  PlayerSettings.getPlayerSettings(var2.getUniqueId()).setLanguage(var5.getLanguage(), this.kG, true);
                  var2.closeInventory();
                  break;
               }
            }
         }

      }
   }
}
