package ga.strikepractice.h;

import ga.strikepractice.StrikePractice;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class a implements CommandExecutor {
   private final StrikePractice kE;

   public a(StrikePractice var1) {
      this.kE = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player) {
         Player var5 = (Player)var1;
         if (var4.length == 0) {
            e.b(var5, this.kE);
         } else {
            e.a(this.kE, var5, var4[0]);
         }
      }

      return true;
   }
}
