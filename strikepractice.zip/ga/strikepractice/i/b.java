package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.C;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;

public class b implements Listener {
   private final StrikePractice lT;

   public b(StrikePractice var1) {
      this.lT = var1;
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void a(PlayerItemConsumeEvent var1) {
      if (var1.getItem().getType() == Material.POTION) {
         Player var2 = var1.getPlayer();
         C.a(() -> {
            var2.getInventory().remove(Material.GLASS_BOTTLE);
         }, 2L);
      }

   }
}
