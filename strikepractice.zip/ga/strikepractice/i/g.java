package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class g implements Listener {
   public static final String me = "StrikePracticeDoNotRespawn";
   private final StrikePractice mf;
   private final boolean mg;
   private final boolean mh;
   private final Collection<String> mi = new HashSet();
   private boolean mj;

   public g(StrikePractice var1) {
      this.mf = var1;
      this.mg = var1.getConfig().getBoolean("death.disable-message");
      this.mh = var1.getConfig().getBoolean("death.lightning");
      this.mj = var1.getConfig().getBoolean("death.disable-keep-inventory");
      var1.getConfig().getStringList("disabled-worlds").forEach((var1x) -> {
         this.mi.add(var1x.toLowerCase());
      });
   }

   @EventHandler(
      priority = EventPriority.LOW
   )
   public void a(PlayerDeathEvent var1) {
      Player var2 = var1.getEntity();
      if (!this.mi.contains(var2.getWorld().getName().toLowerCase())) {
         if (Bukkit.getPlayer(var2.getUniqueId()) != null && !var2.hasMetadata("StrikePracticeDoNotRespawn") && this.mf.getConfig().getBoolean("death.respawn")) {
            C.a(() -> {
               if (var2.isDead()) {
                  var2.spigot().respawn();
               }

               this.mf.L.L(var2);
            }, 1L);
         }

         if (this.mg) {
            var1.setDeathMessage((String)null);
         }

         if (this.mh) {
            Iterator var3 = var2.getWorld().getPlayers().iterator();

            while(var3.hasNext()) {
               Player var4 = (Player)var3.next();
               if (var4.getWorld() == var2.getWorld() && var4.getLocation().distanceSquared(var2.getLocation()) < 40000.0D) {
                  this.mf.ao().dH().c(var4, var2.getLocation());
               }
            }
         }

         if (this.mj) {
            try {
               var1.setKeepInventory(false);
            } catch (Exception var5) {
               this.mj = false;
               if (B.fQ()) {
                  var5.printStackTrace();
               }
            }
         }

      }
   }
}
