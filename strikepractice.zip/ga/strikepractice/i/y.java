package ga.strikepractice.i;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;

public class y implements Listener {
   @EventHandler(
      ignoreCancelled = true
   )
   public void a(PlayerChangedWorldEvent var1) {
      var1.getPlayer().setSprinting(true);
   }
}
