package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.WeatherType;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;

public class r implements CommandExecutor {
   private static final String[] mA = new String[]{"night", "day", "sun", "report", "ping", "practicecommands"};
   private final StrikePractice mB;

   public r(StrikePractice var1) {
      this.mB = var1;
      StringBuilder var2 = new StringBuilder("Player practice commands registered: ");
      String var3 = "";
      String[] var4 = mA;
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String var7 = var4[var6];
         PluginCommand var8 = var1.getCommand(var7);
         if (var8 != null) {
            var8.setExecutor(this);
            var2.append(var3).append(var7);
            var3 = ", ";
         }
      }

      Bukkit.getLogger().info(var2.toString());
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!(var1 instanceof Player)) {
         var1.sendMessage("Only players may use these commands.");
         return false;
      } else {
         Player var5 = (Player)var1;
         String var6 = var2.getName();
         byte var7 = -1;
         switch(var6.hashCode()) {
         case -934521548:
            if (var6.equals("report")) {
               var7 = 5;
            }
            break;
         case -419159869:
            if (var6.equals("practicecommands")) {
               var7 = 0;
            }
            break;
         case 99228:
            if (var6.equals("day")) {
               var7 = 2;
            }
            break;
         case 114252:
            if (var6.equals("sun")) {
               var7 = 3;
            }
            break;
         case 3441010:
            if (var6.equals("ping")) {
               var7 = 4;
            }
            break;
         case 104817688:
            if (var6.equals("night")) {
               var7 = 1;
            }
         }

         StringBuilder var8;
         String[] var10;
         int var11;
         int var12;
         String var13;
         switch(var7) {
         case 0:
            var5.sendMessage(this.mB.X() + "Practice Player Commands:");
            var8 = new StringBuilder();
            String var9 = "";
            var10 = mA;
            var11 = var10.length;

            for(var12 = 0; var12 < var11; ++var12) {
               var13 = var10[var12];
               var8.append(var9 + "/" + var13);
               var9 = ", ";
            }

            var5.sendMessage(this.mB.X() + var8);
            break;
         case 1:
            var5.setPlayerTime(18000L, false);
            break;
         case 2:
            var5.setPlayerTime(6000L, false);
            break;
         case 3:
            var5.setPlayerWeather(WeatherType.CLEAR);
            var5.setPlayerTime(6000L, false);
            break;
         case 4:
            if (var4.length > 0) {
               Player var15 = Bukkit.getPlayer(var4[0]);
               if (var15 == null) {
                  this.mB.a(var5, "not-online");
               } else {
                  var5.sendMessage(String.format(String.format("%s%s's ping is %%s ms.", this.mB.X(), var15.getName()), this.mB.ao().dH().ai(var15)));
               }
            } else {
               var5.sendMessage(String.format(String.format("%sYour ping is %%s ms.", this.mB.X()), this.mB.ao().dH().ai(var5)));
            }
            break;
         case 5:
            if (var4.length == 0) {
               var5.sendMessage(ChatColor.RED + "/report <player/reason>");
               return true;
            }

            var8 = new StringBuilder();
            var10 = var4;
            var11 = var4.length;

            for(var12 = 0; var12 < var11; ++var12) {
               var13 = var10[var12];
               var8.append(var13).append(" ");
            }

            String var14 = var8.toString();
            Iterator var16 = Bukkit.getOnlinePlayers().iterator();

            while(var16.hasNext()) {
               Player var17 = (Player)var16.next();
               if (ga.strikepractice.k.b.a(var17, ga.strikepractice.k.a.py)) {
                  var17.sendMessage(this.mB.X() + ChatColor.RED + var5.getName() + " reported: " + var14);
               }
            }

            var5.sendMessage(this.mB.X() + "Reported: " + var14);
         }

         return true;
      }
   }
}
