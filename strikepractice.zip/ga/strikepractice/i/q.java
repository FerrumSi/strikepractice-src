package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.hostedevents.PvPEvent;
import ga.strikepractice.party.Party;
import ga.strikepractice.playersettings.PlayerSettings;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.D;
import java.util.Iterator;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class q implements Listener {
   private final StrikePractice mz = StrikePractice.getInstance();
   private Location be;
   private Location bf;

   public q(StrikePractice var1) {
      String var2 = var1.getConfig().getString("player-spawn-hider.spawn-corner1");
      String var3 = var1.getConfig().getString("player-spawn-hider.spawn-corner2");
      if (var2 != null && var3 != null) {
         try {
            this.be = D.Z(var2).ga();
            this.bf = D.Z(var3).ga();
         } catch (Exception var6) {
            Bukkit.getLogger().warning("Failed to parse player-spawn-hider.spawn-corner1/corner2 from the config");
         }

         Iterator var4 = Bukkit.getOnlinePlayers().iterator();

         while(var4.hasNext()) {
            Player var5 = (Player)var4.next();
            this.ad(var5);
         }
      }

   }

   @EventHandler
   public void a(PlayerJoinEvent var1) {
      C.a(() -> {
         this.af(var1.getPlayer());
      }, 20L);
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void a(PlayerTeleportEvent var1) {
      Player var2 = var1.getPlayer();
      if (Bukkit.getPlayer(var2.getUniqueId()) != null) {
         C.a(() -> {
            if (var1.getFrom().getWorld() == var1.getTo().getWorld() && var1.getFrom().distanceSquared(var1.getTo()) < 25.0D) {
               B.debug("PlayerHider: " + var2.getName() + " teleported less than 5 blocks");
            } else {
               this.ad(var2);
            }
         }, 8L);
      }
   }

   public void ad(Player var1) {
      boolean var2 = ga.strikepractice.utils.t.a(var1.getLocation(), this.be, this.bf);
      if (var2) {
         this.af(var1);
      } else {
         this.ae(var1);
      }

   }

   private void ae(Player var1) {
      B.debug("PlayerHider#handlePlayerOutsideSpawn " + var1.getName());
      Map var2 = this.mz.ac().eG();
      Fight var3 = AbstractFight.getCurrentFight(var1);
      boolean var4 = this.mz.ac().isSpectator(var1);
      Fight var5 = var4 ? (Fight)var2.get(var1.getUniqueId()) : null;
      Iterator var6 = Bukkit.getOnlinePlayers().iterator();

      while(true) {
         Player var7;
         Fight var8;
         boolean var9;
         do {
            if (!var6.hasNext()) {
               return;
            }

            var7 = (Player)var6.next();
            var8 = AbstractFight.getCurrentFight(var7);
            var9 = var4 == this.mz.ac().isSpectator(var7) && var5 == var2.get(var7.getUniqueId());
         } while(var8 != var3 && !this.c(var1, var7) && !var9);

         var1.showPlayer(var7);
      }
   }

   private void af(Player var1) {
      B.debug("PlayerHider#handlePlayerAtSpawn " + var1.getName() + "");
      boolean var2 = PlayerSettings.isStatsLoaded(var1) && PlayerSettings.getPlayerSettings(var1).isHideOtherPlayers();
      Party var3 = Party.getParty(var1);
      Iterator var4 = Bukkit.getOnlinePlayers().iterator();

      while(true) {
         while(var4.hasNext()) {
            Player var5 = (Player)var4.next();
            if (var3 != null && var3 == Party.getParty(var5)) {
               var5.showPlayer(var1);
               var1.showPlayer(var5);
            } else {
               if (var2) {
                  var1.hidePlayer(var5);
               }

               if (PlayerSettings.isStatsLoaded(var5) && PlayerSettings.getPlayerSettings(var5).isHideOtherPlayers()) {
                  var5.hidePlayer(var1);
               }
            }
         }

         return;
      }
   }

   private boolean c(Player var1, Player var2) {
      PvPEvent var3 = PvPEvent.getEvent(var1);
      PvPEvent var4 = PvPEvent.getEvent(var2);
      if (var3 == null && var4 == null) {
         return false;
      } else {
         return var3 == var4;
      }
   }
}
