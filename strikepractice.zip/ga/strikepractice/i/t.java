package ga.strikepractice.i;

import org.bukkit.entity.Arrow;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;

public class t implements Listener {
   @EventHandler
   public void a(ProjectileHitEvent var1) {
      if (var1.getEntity() instanceof Arrow) {
         var1.getEntity().remove();
      }

   }
}
