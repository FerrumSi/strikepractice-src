package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.events.BotDuelEndEvent;
import ga.strikepractice.events.DuelEndEvent;
import ga.strikepractice.events.PartyFFAEndEvent;
import ga.strikepractice.events.PartySplitEndEvent;
import ga.strikepractice.events.PartyVsBotsEndEvent;
import ga.strikepractice.events.PartyVsPartyEndEvent;
import ga.strikepractice.fights.Fight;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class A implements Listener {
   private static StrikePractice plugin;

   public A(StrikePractice var1) {
      plugin = var1;
   }

   @EventHandler
   public void b(DuelEndEvent var1) {
      if (var1.getWinner() != null && var1.getLoser() != null) {
         a(var1.getFight().getKit().isElo() ? "ranked" : "unranked", var1.getWinner(), var1.getFight(), var1.getLoser().getName());
      }

   }

   @EventHandler
   public void b(PartyFFAEndEvent var1) {
      a("party-ffa", var1.getWinner(), var1.getFight(), "");
   }

   @EventHandler
   public void a(PartyVsPartyEndEvent var1) {
      if (var1.getWinner() != null) {
         Iterator var2 = var1.getWinner().getPlayers().iterator();

         while(var2.hasNext()) {
            Player var3 = (Player)var2.next();
            a("party-vs-party", var3, var1.getFight(), "");
         }
      }

   }

   @EventHandler
   public void a(PartySplitEndEvent var1) {
      Iterator var2 = var1.getWinners().iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         Player var4 = Bukkit.getPlayer(var3);
         if (var4 != null) {
            a("party-split", var4, var1.getFight(), "");
         }
      }

   }

   private static void a(String var0, Player var1, Fight var2, String var3) {
      Iterator var4 = plugin.getConfig().getStringList("winner-commands." + var0).iterator();

      while(var4.hasNext()) {
         String var5 = (String)var4.next();
         Bukkit.dispatchCommand(Bukkit.getConsoleSender(), plugin.ah().a(var1, var5, "", true).replace("<player>", var1.getName()).replace("<winner>", var1.getName()).replace("<opponent>", var3).replace("<loser>", var3).replace("<kit>", var2.getKit().getFancyName()).replace("<raw_kit>", var2.getKit().getName()));
      }

   }

   public static class a implements Listener {
      @EventHandler
      public void c(BotDuelEndEvent var1) {
         if (var1.getWinnerType() == BotDuelEndEvent.WinnerType.PLAYER) {
            A.a("bot-duel", var1.getPlayer(), var1.getFight(), var1.getBot() != null ? var1.getBot().getName() : "");
         }

      }

      @EventHandler
      public void b(PartyVsBotsEndEvent var1) {
         if (var1.getWinners() == PartyVsBotsEndEvent.Winners.es) {
            Iterator var2 = var1.getParty().getPlayers().iterator();

            while(var2.hasNext()) {
               Player var3 = (Player)var2.next();
               A.a("party-bots", var3, var1.getFight(), "");
            }
         }

      }
   }
}
