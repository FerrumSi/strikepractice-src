package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import java.lang.reflect.Method;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class w implements Listener {
   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void f(PlayerInteractEvent var1) {
      if (var1.getItem() != null && var1.getItem().getType() == Material.MUSHROOM_SOUP && (var1.getAction() == Action.RIGHT_CLICK_AIR || var1.getAction() == Action.RIGHT_CLICK_BLOCK || this.h(var1))) {
         var1.setCancelled(true);
         Player var2 = var1.getPlayer();
         Player var3 = var1.getPlayer();
         if (var3.getHealth() < var3.getMaxHealth() - 7.0D) {
            var3.setHealth(var3.getHealth() + 7.0D);
            this.g(var1);
         } else if (var3.getHealth() < var3.getMaxHealth()) {
            var3.setHealth(var3.getMaxHealth());
            this.g(var1);
         } else if (var2.getFoodLevel() < 13) {
            var2.setFoodLevel(var2.getFoodLevel() + 7);
            this.g(var1);
            if (var2.getSaturation() < 13.0F) {
               var2.setSaturation(var2.getSaturation() + 7.0F);
            } else {
               var2.setSaturation(20.0F);
            }
         } else if (var2.getFoodLevel() < 20) {
            var2.setFoodLevel(20);
            this.g(var1);
            if (var2.getSaturation() < 13.0F) {
               var2.setSaturation(var2.getSaturation() + 7.0F);
            } else {
               var2.setSaturation(20.0F);
            }
         }
      }

   }

   private void g(PlayerInteractEvent var1) {
      var1.getItem().setType(Material.BOWL);
      var1.getPlayer().updateInventory();
   }

   private boolean h(PlayerInteractEvent var1) {
      if (StrikePractice.getInstance().ao().mU && (var1.getAction() == Action.LEFT_CLICK_AIR || var1.getAction() == Action.LEFT_CLICK_BLOCK)) {
         try {
            Method var2 = var1.getClass().getMethod("getHand");
            Object var3 = var2.invoke(var1);
            return var3.toString().equals("OFF_HAND");
         } catch (Exception var4) {
         }
      }

      return false;
   }
}
