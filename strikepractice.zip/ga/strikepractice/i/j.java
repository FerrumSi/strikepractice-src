package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.events.BotDuelEndEvent;
import ga.strikepractice.events.BotDuelStartEvent;
import ga.strikepractice.events.DuelEndEvent;
import ga.strikepractice.events.DuelStartEvent;
import ga.strikepractice.events.PartyFFAEndEvent;
import ga.strikepractice.events.PartyFFAStartEvent;
import ga.strikepractice.events.PartySplitEndEvent;
import ga.strikepractice.events.PartySplitStartEvent;
import ga.strikepractice.events.PartyVsBotsEndEvent;
import ga.strikepractice.events.PartyVsBotsStartEvent;
import ga.strikepractice.events.PartyVsPartyEndEvent;
import ga.strikepractice.events.PartyVsPartyStartEvent;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.JvmStatic;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.Regex;
import ga.strikepractice.kotlin.text.StringsKt;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u00162\u00020\u0001:\u0002\u0015\u0016B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0010\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\bH\u0007J\u0010\u0010\t\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\nH\u0007J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\fH\u0007J\u0010\u0010\r\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u000eH\u0007J\u0010\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0010H\u0007J\u0010\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0012H\u0007J\u0010\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0014H\u0007¨\u0006\u0017"},
   d2 = {"Lga/strikepractice/misc/FightStartEndCommands;", "Lorg/bukkit/event/Listener;", "()V", "onDuelEnd", "", "e", "Lga/strikepractice/events/DuelEndEvent;", "onDuelStart", "Lga/strikepractice/events/DuelStartEvent;", "onPartyFFAEnd", "Lga/strikepractice/events/PartyFFAEndEvent;", "onPartyFFAStart", "Lga/strikepractice/events/PartyFFAStartEvent;", "onPartySplitEnd", "Lga/strikepractice/events/PartySplitEndEvent;", "onPartySplitStart", "Lga/strikepractice/events/PartySplitStartEvent;", "onPartyVsPartyEnd", "Lga/strikepractice/events/PartyVsPartyEndEvent;", "onPartyVsPartyStart", "Lga/strikepractice/events/PartyVsPartyStartEvent;", "BotEvents", "Companion", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nFightStartEndCommands.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FightStartEndCommands.kt\nga/strikepractice/misc/FightStartEndCommands\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,150:1\n1855#2,2:151\n1855#2,2:153\n1855#2,2:155\n1855#2,2:157\n1855#2,2:159\n1855#2,2:161\n1855#2,2:163\n1855#2,2:165\n*S KotlinDebug\n*F\n+ 1 FightStartEndCommands.kt\nga/strikepractice/misc/FightStartEndCommands\n*L\n24#1:151,2\n29#1:153,2\n34#1:155,2\n35#1:157,2\n47#1:159,2\n52#1:161,2\n57#1:163,2\n58#1:165,2\n*E\n"})
public final class j implements Listener {
   @NotNull
   public static final j.b mo = new j.b((DefaultConstructorMarker)null);
   private static final StrikePractice mp = StrikePractice.getInstance();
   @Nullable
   private static List<String> mq;
   @Nullable
   private static List<String> mr;

   @EventHandler
   public final void a(@NotNull DuelStartEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      j.b var10000 = mo;
      Player var10001 = var1.getPlayer1();
      Intrinsics.checkNotNullExpressionValue(var10001, "e.player1");
      var10000.aa(var10001);
      var10000 = mo;
      var10001 = var1.getPlayer2();
      Intrinsics.checkNotNullExpressionValue(var10001, "e.player2");
      var10000.aa(var10001);
   }

   @EventHandler
   public final void a(@NotNull PartyFFAStartEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      List var10000 = var1.getParty().getPlayers();
      Intrinsics.checkNotNullExpressionValue(var10000, "e.party.players");
      Iterable var2 = (Iterable)var10000;
      boolean var3 = false;
      Iterator var4 = var2.iterator();

      while(var4.hasNext()) {
         Object var5 = var4.next();
         Player var6 = (Player)var5;
         boolean var7 = false;
         j.b var8 = mo;
         Intrinsics.checkNotNullExpressionValue(var6, "it");
         var8.aa(var6);
      }

   }

   @EventHandler
   public final void a(@NotNull PartySplitStartEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      List var10000 = var1.getParty().getPlayers();
      Intrinsics.checkNotNullExpressionValue(var10000, "e.party.players");
      Iterable var2 = (Iterable)var10000;
      boolean var3 = false;
      Iterator var4 = var2.iterator();

      while(var4.hasNext()) {
         Object var5 = var4.next();
         Player var6 = (Player)var5;
         boolean var7 = false;
         j.b var8 = mo;
         Intrinsics.checkNotNullExpressionValue(var6, "it");
         var8.aa(var6);
      }

   }

   @EventHandler
   public final void a(@NotNull PartyVsPartyStartEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      List var10000 = var1.getChallangerParty().getPlayers();
      Intrinsics.checkNotNullExpressionValue(var10000, "e.challangerParty.players");
      Iterable var2 = (Iterable)var10000;
      boolean var3 = false;
      Iterator var4 = var2.iterator();

      Object var5;
      Player var6;
      boolean var7;
      j.b var8;
      while(var4.hasNext()) {
         var5 = var4.next();
         var6 = (Player)var5;
         var7 = false;
         var8 = mo;
         Intrinsics.checkNotNullExpressionValue(var6, "it");
         var8.aa(var6);
      }

      var10000 = var1.getEnemyParty().getPlayers();
      Intrinsics.checkNotNullExpressionValue(var10000, "e.enemyParty.players");
      var2 = (Iterable)var10000;
      var3 = false;
      var4 = var2.iterator();

      while(var4.hasNext()) {
         var5 = var4.next();
         var6 = (Player)var5;
         var7 = false;
         var8 = mo;
         Intrinsics.checkNotNullExpressionValue(var6, "it");
         var8.aa(var6);
      }

   }

   @EventHandler
   public final void d(@NotNull DuelEndEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      j.b var10000 = mo;
      Player var10001 = ga.strikepractice.utils.y.W(var1.getFight().getP1());
      Intrinsics.checkNotNullExpressionValue(var10001, "getPlayer(e.fight.p1)");
      var10000.ab(var10001);
      var10000 = mo;
      var10001 = ga.strikepractice.utils.y.W(var1.getFight().getP2());
      Intrinsics.checkNotNullExpressionValue(var10001, "getPlayer(e.fight.p2)");
      var10000.ab(var10001);
   }

   @EventHandler
   public final void a(@NotNull PartyFFAEndEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      List var10000 = var1.getParty().getPlayers();
      Intrinsics.checkNotNullExpressionValue(var10000, "e.party.players");
      Iterable var2 = (Iterable)var10000;
      boolean var3 = false;
      Iterator var4 = var2.iterator();

      while(var4.hasNext()) {
         Object var5 = var4.next();
         Player var6 = (Player)var5;
         boolean var7 = false;
         j.b var8 = mo;
         Intrinsics.checkNotNullExpressionValue(var6, "it");
         var8.ab(var6);
      }

   }

   @EventHandler
   public final void a(@NotNull PartySplitEndEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      List var10000 = var1.getParty().getPlayers();
      Intrinsics.checkNotNullExpressionValue(var10000, "e.party.players");
      Iterable var2 = (Iterable)var10000;
      boolean var3 = false;
      Iterator var4 = var2.iterator();

      while(var4.hasNext()) {
         Object var5 = var4.next();
         Player var6 = (Player)var5;
         boolean var7 = false;
         j.b var8 = mo;
         Intrinsics.checkNotNullExpressionValue(var6, "it");
         var8.ab(var6);
      }

   }

   @EventHandler
   public final void a(@NotNull PartyVsPartyEndEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      List var10000 = var1.getFight().p1.getPlayers();
      Intrinsics.checkNotNullExpressionValue(var10000, "e.fight.p1.players");
      Iterable var2 = (Iterable)var10000;
      boolean var3 = false;
      Iterator var4 = var2.iterator();

      Object var5;
      Player var6;
      boolean var7;
      j.b var8;
      while(var4.hasNext()) {
         var5 = var4.next();
         var6 = (Player)var5;
         var7 = false;
         var8 = mo;
         Intrinsics.checkNotNullExpressionValue(var6, "it");
         var8.ab(var6);
      }

      var10000 = var1.getFight().p2.getPlayers();
      Intrinsics.checkNotNullExpressionValue(var10000, "e.fight.p2.players");
      var2 = (Iterable)var10000;
      var3 = false;
      var4 = var2.iterator();

      while(var4.hasNext()) {
         var5 = var4.next();
         var6 = (Player)var5;
         var7 = false;
         var8 = mo;
         Intrinsics.checkNotNullExpressionValue(var6, "it");
         var8.ab(var6);
      }

   }

   @JvmStatic
   public static final void Y(@NotNull Player var0) {
      mo.aa(var0);
   }

   @JvmStatic
   public static final void Z(@NotNull Player var0) {
      mo.ab(var0);
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0010\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\bH\u0007J\u0010\u0010\t\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\nH\u0007J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\fH\u0007¨\u0006\r"},
      d2 = {"Lga/strikepractice/misc/FightStartEndCommands$BotEvents;", "Lorg/bukkit/event/Listener;", "()V", "onBotDuelEnd", "", "e", "Lga/strikepractice/events/BotDuelEndEvent;", "onBotDuelStart", "Lga/strikepractice/events/BotDuelStartEvent;", "onPartyVsBotsEnd", "Lga/strikepractice/events/PartyVsBotsEndEvent;", "onPartyVsBotsStart", "Lga/strikepractice/events/PartyVsBotsStartEvent;", "strikepractice-core"}
   )
   @SourceDebugExtension({"SMAP\nFightStartEndCommands.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FightStartEndCommands.kt\nga/strikepractice/misc/FightStartEndCommands$BotEvents\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,150:1\n1855#2,2:151\n1855#2,2:153\n*S KotlinDebug\n*F\n+ 1 FightStartEndCommands.kt\nga/strikepractice/misc/FightStartEndCommands$BotEvents\n*L\n64#1:151,2\n74#1:153,2\n*E\n"})
   public static final class a implements Listener {
      @EventHandler
      public final void a(@NotNull PartyVsBotsEndEvent var1) {
         Intrinsics.checkNotNullParameter(var1, "e");
         List var10000 = var1.getParty().getPlayers();
         Intrinsics.checkNotNullExpressionValue(var10000, "e.party.players");
         Iterable var2 = (Iterable)var10000;
         boolean var3 = false;
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            Object var5 = var4.next();
            Player var6 = (Player)var5;
            boolean var7 = false;
            j.b var8 = j.mo;
            Intrinsics.checkNotNullExpressionValue(var6, "it");
            var8.ab(var6);
         }

      }

      @EventHandler
      public final void b(@NotNull BotDuelEndEvent var1) {
         Intrinsics.checkNotNullParameter(var1, "e");
         j.b var10000 = j.mo;
         Player var10001 = var1.getPlayer();
         Intrinsics.checkNotNullExpressionValue(var10001, "e.player");
         var10000.ab(var10001);
      }

      @EventHandler
      public final void a(@NotNull PartyVsBotsStartEvent var1) {
         Intrinsics.checkNotNullParameter(var1, "e");
         List var10000 = var1.getParty().getPlayers();
         Intrinsics.checkNotNullExpressionValue(var10000, "e.party.players");
         Iterable var2 = (Iterable)var10000;
         boolean var3 = false;
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            Object var5 = var4.next();
            Player var6 = (Player)var5;
            boolean var7 = false;
            j.b var8 = j.mo;
            Intrinsics.checkNotNullExpressionValue(var6, "it");
            var8.aa(var6);
         }

      }

      @EventHandler
      public final void a(@NotNull BotDuelStartEvent var1) {
         Intrinsics.checkNotNullParameter(var1, "e");
         j.b var10000 = j.mo;
         Player var10001 = var1.getPlayer();
         Intrinsics.checkNotNullExpressionValue(var10001, "e.player");
         var10000.aa(var10001);
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J#\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u00052\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\u000eH\u0002¢\u0006\u0002\u0010\u000fJ#\u0010\u0010\u001a\u00020\u00052\u0006\u0010\f\u001a\u00020\u00052\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\u000eH\u0002¢\u0006\u0002\u0010\u0011J\u0018\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0010\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u0016H\u0007J\u0010\u0010\u0018\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u0016H\u0007R\u0016\u0010\u0003\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n \b*\u0004\u0018\u00010\u00070\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0019"},
      d2 = {"Lga/strikepractice/misc/FightStartEndCommands$Companion;", "", "()V", "endCommands", "", "", "plugin", "Lga/strikepractice/StrikePractice;", "ga.strikepractice.kotlin.jvm.PlatformType", "startCommands", "contains", "", "string", "s", "", "(Ljava/lang/String;[Ljava/lang/String;)Z", "delete", "(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;", "executeCommands", "", "cmd", "p", "Lorg/bukkit/entity/Player;", "onFightEnd", "onFightStart", "strikepractice-core"}
   )
   @SourceDebugExtension({"SMAP\nFightStartEndCommands.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FightStartEndCommands.kt\nga/strikepractice/misc/FightStartEndCommands$Companion\n+ 2 Strings.kt\nkotlin/text/StringsKt__StringsKt\n*L\n1#1,150:1\n107#2:151\n79#2,22:152\n*S KotlinDebug\n*F\n+ 1 FightStartEndCommands.kt\nga/strikepractice/misc/FightStartEndCommands$Companion\n*L\n118#1:151\n118#1:152,22\n*E\n"})
   public static final class b {
      private b() {
      }

      @JvmStatic
      public final void aa(@NotNull final Player var1) {
         Intrinsics.checkNotNullParameter(var1, "p");
         (new BukkitRunnable() {
            public void run() {
               if (j.mq == null) {
                  j.b var10000 = j.mo;
                  j.mq = (List)j.mp.getConfig().getStringList("fight-start-commands").stream().collect(Collectors.toList());
               }

               List var3 = j.mq;
               Intrinsics.checkNotNull(var3);
               Iterator var1x = var3.iterator();

               while(var1x.hasNext()) {
                  String var2 = (String)var1x.next();
                  j.mo.b(var2, var1);
               }

            }
         }).runTaskLater((Plugin)j.mp, 4L);
      }

      @JvmStatic
      public final void ab(@NotNull Player var1) {
         Intrinsics.checkNotNullParameter(var1, "p");
         if (j.mr == null) {
            j.mr = (List)j.mp.getConfig().getStringList("fight-end-commands").stream().collect(Collectors.toList());
         }

         List var10000 = j.mr;
         Intrinsics.checkNotNull(var10000);
         Iterator var2 = var10000.iterator();

         while(var2.hasNext()) {
            String var3 = (String)var2.next();
            this.b(var3, var1);
         }

      }

      private final void b(String var1, Player var2) {
         String[] var5;
         boolean var10000;
         label55: {
            var5 = new String[]{"console command:", "console cmd:"};
            if (!this.a(var1, var5)) {
               var5 = new String[]{"player command:", "player cmd:"};
               if (this.a(var1, var5)) {
                  var10000 = false;
                  break label55;
               }
            }

            var10000 = true;
         }

         boolean var4 = var10000;
         var5 = new String[]{"console command:", "console cmd:", "player command:", "player cmd:"};
         String var3 = this.b(var1, var5);
         String var17 = j.mp.ah().a(var2, var3, "", true);
         Intrinsics.checkNotNullExpressionValue(var17, "plugin.getPlaceholders()…holders(p, cmd, \"\", true)");
         String var15 = var17;
         boolean var6 = false;
         CharSequence var7 = (CharSequence)var15;
         boolean var8 = false;
         int var9 = 0;
         int var10 = var7.length() - 1;
         boolean var11 = false;

         while(var9 <= var10) {
            int var12 = !var11 ? var9 : var10;
            char var13 = var7.charAt(var12);
            boolean var14 = false;
            boolean var16 = Intrinsics.compare(var13, 32) <= 0;
            if (!var11) {
               if (!var16) {
                  var11 = true;
               } else {
                  ++var9;
               }
            } else {
               if (!var16) {
                  break;
               }

               --var10;
            }
         }

         var3 = var7.subSequence(var9, var10 + 1).toString();
         if (var4) {
            if (StringsKt.startsWith$default(var3, "/", false, 2, (Object)null)) {
               var17 = var3.substring(1);
               Intrinsics.checkNotNullExpressionValue(var17, "this as java.lang.String).substring(startIndex)");
               var3 = var17;
            }

            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), var3);
         } else {
            if (!StringsKt.startsWith$default(var3, "/", false, 2, (Object)null)) {
               var3 = '/' + var3;
            }

            var2.chat(var3);
         }

      }

      private final boolean a(String var1, String[] var2) {
         int var3 = 0;

         for(int var4 = var2.length; var3 < var4; ++var3) {
            String var5 = var2[var3];
            if (StringsKt.contains$default((CharSequence)var1, (CharSequence)var5, false, 2, (Object)null)) {
               return true;
            }
         }

         return false;
      }

      private final String b(String var1, String[] var2) {
         String var3 = var1;
         int var4 = 0;

         for(int var5 = var2.length; var4 < var5; ++var4) {
            String var6 = var2[var4];
            StringBuilder var10001 = (new StringBuilder()).append("(?i)");
            String var10002 = Pattern.quote(var6);
            Intrinsics.checkNotNullExpressionValue(var10002, "quote(str)");
            String var7 = var10002;
            var3 = StringsKt.replace$default(var3, var10001.append(new Regex(var7)).toString(), "", false, 4, (Object)null);
         }

         return var3;
      }

      // $FF: synthetic method
      public b(DefaultConstructorMarker var1) {
         this();
      }
   }
}
