package ga.strikepractice.i;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class i implements CommandExecutor {
   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      var1.sendMessage(ChatColor.GREEN + "" + ChatColor.BOLD + "How to setup ffa arenas?");
      var1.sendMessage(ChatColor.GREEN + "1. Create a new arena with /arena create and set pos1, pos2 and center.");
      var1.sendMessage(ChatColor.GREEN + "2. Add a kit with /arena kits <arena> <kit>");
      var1.sendMessage(ChatColor.GREEN + "3. Do /arena ffa <arena>");
      var1.sendMessage(ChatColor.GREEN + "4. Restart the server");
      var1.sendMessage(ChatColor.GREEN + "5. Players can now use /<arena> to join the ffa arena.");
      var1.sendMessage(ChatColor.GREEN + "For example if you did '/arena create builduhcffa' players can now do '/builduhcffa'");
      return true;
   }
}
