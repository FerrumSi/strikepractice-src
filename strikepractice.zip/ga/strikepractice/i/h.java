package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.events.DuelEndEvent;
import ga.strikepractice.stats.DefaultPlayerStats;
import java.util.ArrayList;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;

public class h implements Listener {
   private final StrikePractice mk;

   public h(StrikePractice var1) {
      this.mk = var1;
   }

   @EventHandler
   public void a(DuelEndEvent var1) {
      final Player var2 = var1.getWinner();
      if (var2 != null && var1.getFight() != null && var1.getFight().getKit() != null && var1.getFight().getKit().isElo()) {
         DefaultPlayerStats var3 = DefaultPlayerStats.getStats(var2.getUniqueId());
         final int var4 = var3.getGlobalElo();
         (new BukkitRunnable() {
            public void run() {
               if (var2 != null) {
                  DefaultPlayerStats var1 = DefaultPlayerStats.getStats(var2.getUniqueId());
                  int var2x = var1.getGlobalElo();
                  ArrayList var3 = new ArrayList();
                  int var4x = var2x;
                  Iterator var5 = h.this.mk.getConfig().getConfigurationSection("elo-rewards").getKeys(false).iterator();

                  while(true) {
                     String var6;
                     int var7;
                     do {
                        if (!var5.hasNext()) {
                           if (var4 < var4x && !var3.isEmpty()) {
                              var5 = var3.iterator();

                              while(var5.hasNext()) {
                                 var6 = (String)var5.next();
                                 Bukkit.dispatchCommand(Bukkit.getConsoleSender(), var6.replace("<player>", var2.getName()).replace("<player_elo>", var2x + "").replace("<required_elo>", var4x + ""));
                              }
                           }

                           return;
                        }

                        var6 = (String)var5.next();
                        var7 = h.this.mk.getConfig().getInt("elo-rewards." + var6 + ".elo");
                     } while(var4x < var7);

                     var3.clear();
                     Iterator var8 = h.this.mk.getConfig().getStringList("elo-rewards." + var6 + ".commands").iterator();

                     while(var8.hasNext()) {
                        String var9 = (String)var8.next();
                        var3.add(var9.replace("<level>", var6));
                     }
                  }
               }
            }
         }).runTaskLater(this.mk, 5L);
      }
   }
}
