package ga.strikepractice.i;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class u implements Listener {
   public static String mC;
   private static final Collection<String> mD = new HashSet();
   public static final Set<Consumer<Player>> mE = new HashSet();

   public u() {
      mD.add("report");
      if (Bukkit.getCommandAliases().containsKey("report")) {
         String[] var1 = (String[])Bukkit.getCommandAliases().get("report");
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            String var4 = var1[var3];
            mD.add(var4.toLowerCase());
         }
      }

   }

   @EventHandler
   public void a(PlayerCommandPreprocessEvent var1) {
      String var2 = var1.getMessage().toLowerCase();
      Iterator var3 = mD.iterator();

      String var4;
      do {
         if (!var3.hasNext()) {
            return;
         }

         var4 = (String)var3.next();
      } while(!var2.startsWith("/" + var4));

      String[] var5 = var1.getMessage().split(" ");
      if (var5.length > 1) {
         Player var6 = Bukkit.getPlayer(var5[1]);
         if (var6 != null) {
            mC = var6.getName();
            mE.forEach((var1x) -> {
               var1x.accept(var6);
            });
         }
      }

   }
}
