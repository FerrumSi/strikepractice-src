package ga.strikepractice.i;

import ga.strikepractice.utils.I;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class k implements Listener {
   private static boolean enabled = false;

   public k() {
      enabled = true;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void e(EntityDamageByEntityEvent var1) {
      try {
         if (var1.isCancelled() && var1.getDamager() instanceof Player && var1.getEntity() instanceof Player) {
            Player var2 = (Player)var1.getDamager();
            Location var3 = var1.getEntity().getLocation().add(0.0D, 1.0D, 0.0D);
            var2.getWorld().playEffect(var3, Effect.HEART, 0);
            I.a(var3, "CHICKEN_EGG_POP", 1.0F, 0.65F);
         }
      } catch (Error var4) {
      }

   }

   public static void a(NPC var0) {
      if (enabled) {
         try {
            var0.data().set("player-skin-name", "Chicken");
         } catch (Exception var2) {
         }
      }

   }
}
