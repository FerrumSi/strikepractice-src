package ga.strikepractice.i;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class x {
   private static final int mG = 3;
   private static final int mH = 5;

   public static x.a ah(Player var0) {
      double var1 = 0.0D;
      double var3 = 0.0D;
      Iterator var5 = Bukkit.getOnlinePlayers().iterator();

      while(var5.hasNext()) {
         Player var6 = (Player)var5.next();
         if (var1 >= 5.0D) {
            break;
         }

         if (!ga.strikepractice.k.b.a(var6, ga.strikepractice.k.a.py)) {
            ++var1;
            if (!var6.canSee(var0)) {
               ++var3;
            }
         }
      }

      if (var1 < 3.0D) {
         return x.a.mK;
      } else {
         if (var1 > 0.0D) {
            double var7 = var3 / var1;
            if (var7 > 0.6D) {
               return x.a.mI;
            }

            if (var7 < 0.4D) {
               return x.a.mJ;
            }
         }

         return x.a.mK;
      }
   }

   public static enum a {
      mI,
      mJ,
      mK;

      // $FF: synthetic method
      private static x.a[] dC() {
         return new x.a[]{mI, mJ, mK};
      }
   }
}
