package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.arena.Arena;
import java.util.HashSet;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkUnloadEvent;

public class d implements Listener {
   private static final HashSet<f> lX = new HashSet();
   private static StrikePractice plugin;

   public d(StrikePractice var1) {
      plugin = var1;
   }

   public static void ds() {
      int var0 = Bukkit.getViewDistance();
      Iterator var1 = plugin.M.iterator();

      while(true) {
         Arena var2;
         do {
            do {
               do {
                  do {
                     if (!var1.hasNext()) {
                        return;
                     }

                     var2 = (Arena)var1.next();
                  } while(var2.isUsing());
               } while(var2.getCenter() == null);
            } while(var2.getLoc1() == null);
         } while(var2.getLoc2() == null);

         Location var3 = var2.getCenter();

         int var4;
         int var5;
         Chunk var6;
         for(var4 = 0; var4 < var0 + var0; ++var4) {
            for(var5 = 0; var5 < var0 + var0; ++var5) {
               var6 = var3.getWorld().getChunkAt(var3.getChunk().getX() - var0 + var4, var3.getChunk().getZ() - var0 + var5);
               if (var6 != null) {
                  lX.add(new f(var6));
                  var6.load();
               }
            }
         }

         var3 = var2.getLoc1();

         for(var4 = 0; var4 < var0 + var0; ++var4) {
            for(var5 = 0; var5 < var0 + var0; ++var5) {
               var6 = var3.getWorld().getChunkAt(var3.getChunk().getX() - var0 + var4, var3.getChunk().getZ() - var0 + var5);
               if (var6 != null) {
                  lX.add(new f(var6));
                  var6.load();
               }
            }
         }

         var3 = var2.getLoc2();

         for(var4 = 0; var4 < var0 + var0; ++var4) {
            for(var5 = 0; var5 < var0 + var0; ++var5) {
               var6 = var3.getWorld().getChunkAt(var3.getChunk().getX() - var0 + var4, var3.getChunk().getZ() - var0 + var5);
               if (var6 != null) {
                  lX.add(new f(var6));
                  var6.load();
               }
            }
         }
      }
   }

   @EventHandler
   public void a(ChunkUnloadEvent var1) {
      f var2 = new f(var1.getChunk());
      Iterator var3 = lX.iterator();

      while(var3.hasNext()) {
         f var4 = (f)var3.next();
         if (var2.equals(var4)) {
            var1.setCancelled(true);
         }
      }

   }
}
