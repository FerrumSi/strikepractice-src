package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.AbstractFight;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.FoodLevelChangeEvent;

public class m implements Listener {
   private final StrikePractice mw;

   public m(StrikePractice var1) {
      this.mw = var1;
   }

   @EventHandler
   public void b(FoodLevelChangeEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         if (!AbstractFight.isInFight(var2)) {
            var1.setFoodLevel(20);
         }
      }

   }
}
