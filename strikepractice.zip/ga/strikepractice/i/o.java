package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class o implements Listener {
   private static final Map<UUID, Long> my = new ConcurrentHashMap();

   @EventHandler
   public void a(PlayerItemConsumeEvent var1) {
      my.put(var1.getPlayer().getUniqueId(), System.currentTimeMillis());
   }

   @EventHandler
   public void a(PlayerInteractEvent var1) {
      if (var1.getAction() == Action.RIGHT_CLICK_AIR) {
         my.put(var1.getPlayer().getUniqueId(), System.currentTimeMillis());
      }

   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      my.remove(var1.getPlayer().getUniqueId());
   }

   public static boolean a(UUID var0, long var1) {
      if (my.containsKey(var0)) {
         return (Long)my.get(var0) + var1 > System.currentTimeMillis();
      } else {
         return StrikePractice.C;
      }
   }
}
