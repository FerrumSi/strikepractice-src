package ga.strikepractice.i;

import ga.strikepractice.battlekit.BattleKit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason;

public class s implements Listener {
   @EventHandler
   public void a(EntityRegainHealthEvent var1) {
      if (var1.getEntity() instanceof Player && var1.getRegainReason() == RegainReason.SATIATED) {
         Player var2 = (Player)var1.getEntity();
         BattleKit var3 = BattleKit.getCurrentKit(var2);
         if (var3 != null && var3.getName() != null && var3.getName().toLowerCase().contains("uhc")) {
            var1.setCancelled(true);
         }
      }

   }
}
