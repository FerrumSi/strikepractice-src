package ga.strikepractice.i;

import org.bukkit.Chunk;

class f {
   private final int mc;
   private final int md;

   public f(Chunk var1) {
      this.mc = var1.getX();
      this.md = var1.getZ();
   }

   public int getX() {
      return this.mc;
   }

   public int getZ() {
      return this.md;
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof f)) {
         return super.equals(var1);
      } else {
         return ((f)var1).getX() == this.getX() && ((f)var1).getZ() == this.getZ();
      }
   }
}
