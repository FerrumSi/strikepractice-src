package ga.strikepractice.i;

import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public class p implements Listener {
   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void c(PlayerTeleportEvent var1) {
      if (var1.getCause().equals(TeleportCause.ENDER_PEARL)) {
         Location var2 = var1.getTo();
         var2.setX((double)var2.getBlockX() + 0.5D);
         var2.setZ((double)var2.getBlockZ() + 0.5D);
         var1.setTo(var2);
      }

   }
}
