package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.JvmStatic;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.text.StringsKt;
import ga.strikepractice.utils.B;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.Metadatable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \f2\u00020\u0001:\u0001\fB\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0007R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"},
   d2 = {"Lga/strikepractice/misc/GoldenHeads;", "Lorg/bukkit/event/Listener;", "plugin", "Lga/strikepractice/StrikePractice;", "(Lga/strikepractice/StrikePractice;)V", "effects", "", "Lorg/bukkit/potion/PotionEffect;", "onConsume", "", "e", "Lorg/bukkit/event/player/PlayerItemConsumeEvent;", "Companion", "strikepractice-core"}
)
@SourceDebugExtension({"SMAP\nGoldenHeads.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GoldenHeads.kt\nga/strikepractice/misc/GoldenHeads\n+ 2 CommonUtil.kt\nga/strikepractice/utils/SPDebugger$Companion\n*L\n1#1,66:1\n81#2,4:67\n81#2,4:71\n81#2,4:75\n*S KotlinDebug\n*F\n+ 1 GoldenHeads.kt\nga/strikepractice/misc/GoldenHeads\n*L\n40#1:67,4\n44#1:71,4\n50#1:75,4\n*E\n"})
public final class l implements Listener {
   @NotNull
   public static final l.a mt = new l.a((DefaultConstructorMarker)null);
   @NotNull
   private final StrikePractice mu;
   @NotNull
   private final List<PotionEffect> mv;

   public l(@NotNull StrikePractice var1) {
      Intrinsics.checkNotNullParameter(var1, "plugin");
      super();
      this.mu = var1;
      this.mv = (List)(new ArrayList());
      List var2 = this.mu.getConfig().getList("golden-head-effects");
      if (var2.isEmpty()) {
         this.mv.add(new PotionEffect(PotionEffectType.ABSORPTION, 1800, 0));
         this.mv.add(new PotionEffect(PotionEffectType.REGENERATION, 180, 1));
         this.mu.getConfig().set("golden-head-effects", this.mv);
         this.mu.saveConfig();
      } else {
         Iterator var3 = var2.iterator();

         while(var3.hasNext()) {
            Object var4 = var3.next();
            if (var4 instanceof PotionEffect) {
               this.mv.add(var4);
            }
         }
      }

   }

   @EventHandler
   public final void b(@NotNull PlayerItemConsumeEvent var1) {
      Intrinsics.checkNotNullParameter(var1, "e");
      Player var2 = var1.getPlayer();
      ItemStack var10000 = var1.getItem();
      if ((var10000 != null ? var10000.getType() : null) == Material.GOLDEN_APPLE) {
         B.a var3 = B.vj;
         boolean var4 = false;
         boolean var5;
         Logger var7;
         StringBuilder var8;
         String var9;
         Logger var14;
         if (var3.fV()) {
            var14 = Bukkit.getLogger();
            var8 = (new StringBuilder()).append("[SP DEBUG] ");
            var7 = var14;
            var5 = false;
            var9 = "apple eat detected: " + var2.getName();
            var7.info(var8.append(var9).toString());
         }

         if (this.mu.getConfig().getBoolean("bridges-instant-golden-apples")) {
            BattleKit var10 = BattleKit.getCurrentKit((Metadatable)var2);
            if (var10 != null ? var10.isBridges() : false) {
               B.a var13 = B.vj;
               var5 = false;
               if (var13.fV()) {
                  var14 = Bukkit.getLogger();
                  var8 = (new StringBuilder()).append("[SP DEBUG] ");
                  var7 = var14;
                  boolean var6 = false;
                  var9 = var2.getName() + " ate a \"the bridges\" apple";
                  var7.info(var8.append(var9).toString());
               }

               var2.setHealth(var2.getMaxHealth());
               return;
            }
         }

         boolean var17;
         label59: {
            var10000 = var1.getItem();
            if (var10000 != null) {
               ItemMeta var15 = var10000.getItemMeta();
               if (var15 != null) {
                  String var16 = var15.getDisplayName();
                  if (var16 != null) {
                     var16 = var16.toLowerCase();
                     Intrinsics.checkNotNullExpressionValue(var16, "this as java.lang.String).toLowerCase()");
                     if (var16 != null) {
                        var16 = StringsKt.replace$default(var16, " ", "", false, 4, (Object)null);
                        if (var16 != null) {
                           var17 = StringsKt.contains$default((CharSequence)var16, (CharSequence)"goldenhead", false, 2, (Object)null);
                           break label59;
                        }
                     }
                  }
               }
            }

            var17 = false;
         }

         if (var17) {
            var3 = B.vj;
            var4 = false;
            if (var3.fV()) {
               var14 = Bukkit.getLogger();
               var8 = (new StringBuilder()).append("[SP DEBUG] ");
               var7 = var14;
               var5 = false;
               var9 = var2.getName() + " ate a \"golden head\" apple. Adding/overriding effects: " + this.mv;
               var7.info(var8.append(var9).toString());
            }

            Iterator var11 = this.mv.iterator();

            while(var11.hasNext()) {
               PotionEffect var12 = (PotionEffect)var11.next();
               var2.addPotionEffect(var12, true);
            }
         }
      }

   }

   @JvmStatic
   @NotNull
   public static final ItemStack dz() {
      return mt.dA();
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007¨\u0006\u0005"},
      d2 = {"Lga/strikepractice/misc/GoldenHeads$Companion;", "", "()V", "goldenHeadItem", "Lorg/bukkit/inventory/ItemStack;", "strikepractice-core"}
   )
   public static final class a {
      private a() {
      }

      @JvmStatic
      @NotNull
      public final ItemStack dA() {
         return ga.strikepractice.utils.r.a(Material.GOLDEN_APPLE, ChatColor.GOLD.toString() + "Golden Head");
      }

      // $FF: synthetic method
      public a(DefaultConstructorMarker var1) {
         this();
      }
   }
}
