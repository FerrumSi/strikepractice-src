package ga.strikepractice.i;

import ga.strikepractice.events.BotDuelEndEvent;
import ga.strikepractice.events.DuelEndEvent;
import ga.strikepractice.matchrecorder.RecordedMatch;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class v implements Listener {
   private static final Set<UUID> mF = new HashSet();

   public v() {
      u.mE.add((var0) -> {
         mF.add(var0.getUniqueId());
      });
   }

   @EventHandler
   public void b(DuelEndEvent var1) {
      if (var1.getFight().getRecorder() != null) {
         RecordedMatch var2 = var1.getFight().getRecorder().getRecordedMatch();
         if (var2 != null) {
            if (var1.getWinner() != null) {
               a(var1.getWinner(), var2);
            }

            if (var1.getLoser() != null) {
               a(var1.getLoser(), var2);
            }

         }
      }
   }

   private static void a(Player var0, RecordedMatch var1) {
      UUID var2 = var0.getUniqueId();
      if (mF.contains(var2)) {
         mF.remove(var2);
         CompletableFuture.runAsync(() -> {
            Iterator var2 = Bukkit.getOnlinePlayers().iterator();

            while(var2.hasNext()) {
               Player var3 = (Player)var2.next();
               if (ga.strikepractice.k.b.a(var3, ga.strikepractice.k.a.py)) {
                  var3.sendMessage(ChatColor.RED + var0.getName() + " was reported in their previous recorded fight.");
                  ga.strikepractice.utils.d.b(var3, ChatColor.GOLD + "Click here to replay the fight.", "/replay " + var1.getUUID() + " killcam 0");
                  var3.sendMessage(ChatColor.GRAY + "Consider that replays are not accurate before punishing players!");
               }
            }

         });
      }

   }

   public static class a implements Listener {
      @EventHandler
      public void a(BotDuelEndEvent var1) {
         if (var1.getFight().getRecorder() != null) {
            RecordedMatch var2 = var1.getFight().getRecorder().getRecordedMatch();
            if (var2 != null) {
               v.a(var1.getPlayer(), var2);
            }
         }
      }
   }
}
