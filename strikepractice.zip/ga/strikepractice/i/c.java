package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.battlekit.BattleKit;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class c implements Listener {
   private boolean lU;
   private final StrikePractice lV;
   private final List<String> lW = new ArrayList();

   public c(StrikePractice var1) {
      this.lV = var1;
      String var2 = var1.getConfig().getString("bow-health-kits").replace(" ", "");
      String[] var3 = var2.split(",");
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String var6 = var3[var5];
         if (var6.equals("*")) {
            this.lU = true;
            this.lW.clear();
            return;
         }

         this.lW.add(var6.toLowerCase());
      }

   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void d(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Arrow) {
         Arrow var2 = (Arrow)var1.getDamager();
         if (var2.getShooter() instanceof Player && var1.getEntity() instanceof Damageable) {
            var2.getShooter();
            Player var3 = (Player)var2.getShooter();
            Damageable var4 = (Damageable)var1.getEntity();
            if (var4 instanceof Player) {
               Player var5 = (Player)var4;
               double var6 = var4.getHealth();
               double var8 = var1.getFinalDamage();
               int var10 = (int)(var6 - var8);
               long var11 = Math.round((double)var10 / 2.0D);
               if (var10 > 0 && var3 != var5 && this.V(var3)) {
                  this.lV.a(var3, "bow-health-message", ga.strikepractice.utils.u.a("<player>", var5.getName(), "<hp>", var10, "<hearts>", var11));
               }
            }
         }
      }

   }

   private boolean V(Player var1) {
      if (this.lU) {
         return true;
      } else {
         BattleKit var2 = BattleKit.getCurrentKit(var1);
         return var2 != null && (this.lW.contains(var2.getName()) || var2.getMergedEditor() != null && this.lW.contains(var2.getMergedEditor()));
      }
   }
}
