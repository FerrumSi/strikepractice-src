package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class e implements Listener {
   private static final Map<UUID, Integer> lY = new ConcurrentHashMap();
   private static final Map<UUID, Long> lZ = new ConcurrentHashMap();
   private static final Map<UUID, Integer> ma = new ConcurrentHashMap();

   public e(StrikePractice var1) {
      (new BukkitRunnable() {
         public void run() {
            long var1 = System.currentTimeMillis();
            Iterator var3 = Bukkit.getOnlinePlayers().iterator();

            while(var3.hasNext()) {
               Player var4 = (Player)var3.next();
               UUID var5 = var4.getUniqueId();
               long var6 = (Long)e.lZ.getOrDefault(var5, 0L);
               if (var6 < var1 - 1000L) {
                  int var8 = (Integer)e.ma.getOrDefault(var5, 0);
                  e.lY.put(var4.getUniqueId(), var8);
                  e.lZ.put(var5, var1);
                  e.ma.put(var5, 0);
               }
            }

         }
      }).runTaskTimerAsynchronously(var1, 10L, 10L);
   }

   @EventHandler
   public void e(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      if (var1.getAction().equals(Action.LEFT_CLICK_AIR)) {
         if (var2.getItemInHand() != null && var2.getItemInHand().getType() == Material.FISHING_ROD) {
            return;
         }

         UUID var3 = var2.getUniqueId();
         int var4 = (Integer)ma.getOrDefault(var3, 0);
         long var5 = System.currentTimeMillis();
         if ((Long)lZ.getOrDefault(var3, 0L) < var5 - 1000L) {
            lY.put(var2.getUniqueId(), var4);
            lZ.put(var3, var5);
            ma.put(var3, 0);
         } else {
            ma.put(var3, var4 + 1);
         }
      }

   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      UUID var2 = var1.getPlayer().getUniqueId();
      ma.remove(var2);
      lY.remove(var2);
      lZ.remove(var2);
   }

   public static int W(Player var0) {
      return (Integer)lY.getOrDefault(var0.getUniqueId(), 0);
   }
}
