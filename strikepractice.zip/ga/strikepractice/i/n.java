package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.fights.Fight;
import ga.strikepractice.fights.duel.BestOf;
import ga.strikepractice.fights.duel.BestOfFight;
import ga.strikepractice.utils.B;
import ga.strikepractice.utils.C;
import ga.strikepractice.utils.N;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class n extends BukkitRunnable {
   private final StrikePractice mx;

   public n(StrikePractice var1) {
      this(var1, var1.getConfig().getBoolean("insta-void-async") && StrikePractice.F && !var1.getConfig().getBoolean("insta-void-sync"));
   }

   private n(StrikePractice var1, boolean var2) {
      byte var3 = 5;
      this.mx = var1;
      if (var2) {
         this.runTaskTimerAsynchronously(var1, (long)var3, (long)var3);
      } else {
         this.runTaskTimer(var1, (long)var3, (long)var3);
      }

   }

   public void run() {
      try {
         this.dB();
      } catch (IllegalStateException var2) {
         this.cancel();
         new n(this.mx, false);
      }

   }

   private boolean ac(Player var1) {
      Material var2 = var1.getLocation().getBlock().getType();
      return var2 != null && var2.toString().contains("WATER");
   }

   private void dB() {
      Iterator var1 = Bukkit.getOnlinePlayers().iterator();

      while(true) {
         Player var2;
         Fight var3;
         boolean var4;
         do {
            do {
               do {
                  do {
                     do {
                        if (!var1.hasNext()) {
                           return;
                        }

                        var2 = (Player)var1.next();
                        var3 = AbstractFight.getCurrentFight(var2);
                     } while(var3 == null);
                  } while(var3.hasEnded());
               } while(!var3.hasStarted());

               var4 = false;
            } while(var2.isDead());
         } while(var2.getLocation().getBlockY() >= 0 && !(var4 = this.ac(var2)));

         if (var4 && var3.getKit() != null) {
            if (var3.getKit().isParkour()) {
               B.debug("Player " + var2.getName() + " considered dead due to insta-void in parkour");
               Location var8 = ga.strikepractice.fights.duel.a.c(var2, var3);
               if (var8 != null) {
                  N.e(var2, var8);
               }

               return;
            }

            String var5 = var3.getKit().getName();
            if (!var5.contains("sumo") && !var5.contains("spleef")) {
               return;
            }
         }

         BestOf var7 = null;
         if (var3 instanceof BestOfFight) {
            BestOfFight var6 = (BestOfFight)var3;
            var7 = var6.getBestOf();
            if (var6.isBreakTime()) {
               return;
            }
         }

         if (var7 != null && !var7.endsNow(var2.getUniqueId())) {
            C.e(() -> {
               B.debug("Player " + var2.getName() + " considered dead in best of fight due to insta-void");
               if (var3.getKit() != null) {
                  if (var3.getKit().isBedwars()) {
                     ga.strikepractice.fights.duel.a.v(var2);
                  } else if (var3.getKit().isBridges()) {
                     ga.strikepractice.fights.duel.a.w(var2);
                  } else {
                     var3.handleDeath(var2);
                  }
               } else {
                  var3.handleDeath(var2);
               }

            });
            return;
         }

         C.e(() -> {
            B.debug("Player " + var2.getName() + " considered dead due to insta-void");
            if (var3.getKit() != null) {
               if (var3.getKit().isBedwars()) {
                  ga.strikepractice.fights.duel.a.v(var2);
               } else if (var3.getKit().isBridges()) {
                  ga.strikepractice.fights.duel.a.w(var2);
               } else {
                  var2.setHealth(0.0D);
               }
            } else {
               var2.setHealth(0.0D);
            }

         });
      }
   }
}
