package ga.strikepractice.i;

import ga.strikepractice.StrikePractice;
import ga.strikepractice.fights.AbstractFight;
import ga.strikepractice.hostedevents.PvPEvent;
import java.util.Iterator;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class z extends BukkitRunnable {
   private final StrikePractice mM;
   private final boolean mN;

   public z(StrikePractice var1) {
      this.mM = var1;
      if (StrikePractice.F) {
         this.runTaskTimerAsynchronously(var1, 40L, 40L);
         this.mN = true;
      } else {
         this.runTaskTimer(var1, 20L, 20L);
         this.mN = false;
      }

   }

   public void run() {
      List var1 = this.mM.L.fN().getWorld().getPlayers();
      synchronized(var1) {
         Iterator var3 = var1.iterator();

         while(var3.hasNext()) {
            final Player var4 = (Player)var3.next();
            if (var4.getLocation().getY() < -5.0D && !var4.isDead() && !AbstractFight.isInFight(var4) && !PvPEvent.isInEvent(var4) && !this.mM.ac().isSpectator(var4)) {
               if (this.mN) {
                  (new BukkitRunnable() {
                     public void run() {
                        z.this.mM.L.L(var4);
                     }
                  }).runTask(this.mM);
               } else {
                  this.mM.L.L(var4);
               }
            }
         }

      }
   }
}
