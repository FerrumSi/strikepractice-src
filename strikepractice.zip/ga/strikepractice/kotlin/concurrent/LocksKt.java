package ga.strikepractice.kotlin.concurrent;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.JvmName;
import ga.strikepractice.kotlin.jvm.functions.Function0;
import ga.strikepractice.kotlin.jvm.internal.InlineMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a6\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\u00020\u00022\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00010\u0004H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\u0005\u001a6\u0010\u0006\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\u00020\u00072\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00010\u0004H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\b\u001a6\u0010\t\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\u00020\u00022\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00010\u0004H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\u0005\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\n"},
   d2 = {"read", "T", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;", "action", "Lga/strikepractice/kotlin/Function0;", "(Ljava/util/concurrent/locks/ReentrantReadWriteLock;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "withLock", "Ljava/util/concurrent/locks/Lock;", "(Ljava/util/concurrent/locks/Lock;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "write", "ga.strikepractice.kotlin-stdlib"}
)
@JvmName(
   name = "LocksKt"
)
@SourceDebugExtension({"SMAP\nLocks.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Locks.kt\nkotlin/concurrent/LocksKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,74:1\n1#2:75\n*E\n"})
public final class LocksKt {
   @InlineOnly
   private static final <T> T withLock(Lock var0, Function0<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "action");
      var0.lock();

      Object var2;
      try {
         var2 = var1.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         var0.unlock();
         InlineMarker.finallyEnd(1);
      }

      return var2;
   }

   @InlineOnly
   private static final <T> T read(ReentrantReadWriteLock var0, Function0<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "action");
      ReadLock var2 = var0.readLock();
      var2.lock();

      Object var3;
      try {
         var3 = var1.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         var2.unlock();
         InlineMarker.finallyEnd(1);
      }

      return var3;
   }

   @InlineOnly
   private static final <T> T write(ReentrantReadWriteLock var0, Function0<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "action");
      ReadLock var2 = var0.readLock();
      int var3 = var0.getWriteHoldCount() == 0 ? var0.getReadHoldCount() : 0;

      for(int var4 = 0; var4 < var3; ++var4) {
         boolean var6 = false;
         var2.unlock();
      }

      WriteLock var11 = var0.writeLock();
      var11.lock();

      Object var5;
      try {
         var5 = var1.invoke();
      } finally {
         InlineMarker.finallyStart(1);

         for(int var12 = 0; var12 < var3; ++var12) {
            boolean var8 = false;
            var2.lock();
         }

         var11.unlock();
         InlineMarker.finallyEnd(1);
      }

      return var5;
   }
}
