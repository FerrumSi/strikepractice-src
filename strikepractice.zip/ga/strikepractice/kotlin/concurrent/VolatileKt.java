package ga.strikepractice.kotlin.concurrent;

import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000*\u001e\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004B\u0002\b\u0005¨\u0006\u0006"},
   d2 = {"Volatile", "Lga/strikepractice/kotlin/jvm/Volatile;", "Lga/strikepractice/kotlin/SinceKotlin;", "version", "1.9", "Lga/strikepractice/kotlin/ExperimentalStdlibApi;", "ga.strikepractice.kotlin-stdlib"}
)
public final class VolatileKt {
   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.9"
   )
   @ExperimentalStdlibApi
   public static void Volatile$annotations() {
   }
}
