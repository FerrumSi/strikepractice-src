package ga.strikepractice.kotlin.enums;

import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.PublishedApi;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.jvm.functions.Function0;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0010\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\b\u0003\u001a2\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u000e\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\u0012\u0010\u0004\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u00060\u0005H\u0001\u001a1\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u000e\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0006H\u0001¢\u0006\u0002\u0010\b¨\u0006\t"},
   d2 = {"enumEntries", "Lga/strikepractice/kotlin/enums/EnumEntries;", "E", "", "entriesProvider", "Lga/strikepractice/kotlin/Function0;", "", "entries", "([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;", "ga.strikepractice.kotlin-stdlib"}
)
public final class EnumEntriesKt {
   @PublishedApi
   @ExperimentalStdlibApi
   @SinceKotlin(
      version = "1.8"
   )
   @NotNull
   public static final <E extends Enum<E>> EnumEntries<E> enumEntries(@NotNull Function0<E[]> var0) {
      Intrinsics.checkNotNullParameter(var0, "entriesProvider");
      return (EnumEntries)(new EnumEntriesList(var0));
   }

   @PublishedApi
   @ExperimentalStdlibApi
   @SinceKotlin(
      version = "1.8"
   )
   @NotNull
   public static final <E extends Enum<E>> EnumEntries<E> enumEntries(@NotNull final E[] var0) {
      Intrinsics.checkNotNullParameter(var0, "entries");
      EnumEntriesList var1 = new EnumEntriesList((Function0)(new Function0<E[]>() {
         @NotNull
         public final E[] invoke() {
            return var0;
         }
      }));
      boolean var3 = false;
      var1.size();
      return (EnumEntries)var1;
   }
}
