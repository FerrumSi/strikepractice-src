package ga.strikepractice.kotlin.enums;

import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.collections.AbstractList;
import ga.strikepractice.kotlin.collections.ArraysKt;
import ga.strikepractice.kotlin.jvm.functions.Function0;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.io.Serializable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010\u0000\n\u0000\b\u0003\u0018\u0000*\u000e\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u00032\b\u0012\u0004\u0012\u0002H\u00010\u00042\u00060\u0005j\u0002`\u0006B\u0019\u0012\u0012\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\t0\b¢\u0006\u0002\u0010\nJ\u0016\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00028\u0000H\u0096\u0002¢\u0006\u0002\u0010\u0017J\u0016\u0010\u0018\u001a\u00028\u00002\u0006\u0010\u0019\u001a\u00020\u0011H\u0096\u0002¢\u0006\u0002\u0010\u001aJ\u0015\u0010\u001b\u001a\u00020\u00112\u0006\u0010\u0016\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u001cJ\u0015\u0010\u001d\u001a\u00020\u00112\u0006\u0010\u0016\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u001cJ\b\u0010\u001e\u001a\u00020\u001fH\u0002R\u0018\u0010\u000b\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\tX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\fR\u001a\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00000\t8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\u00020\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013¨\u0006 "},
   d2 = {"Lga/strikepractice/kotlin/enums/EnumEntriesList;", "T", "", "Lga/strikepractice/kotlin/enums/EnumEntries;", "Lga/strikepractice/kotlin/collections/AbstractList;", "Ljava/io/Serializable;", "Lga/strikepractice/kotlin/io/Serializable;", "entriesProvider", "Lga/strikepractice/kotlin/Function0;", "", "(Lkotlin/jvm/functions/Function0;)V", "_entries", "[Ljava/lang/Enum;", "entries", "getEntries", "()[Ljava/lang/Enum;", "size", "", "getSize", "()I", "contains", "", "element", "(Ljava/lang/Enum;)Z", "get", "index", "(I)Ljava/lang/Enum;", "indexOf", "(Ljava/lang/Enum;)I", "lastIndexOf", "writeReplace", "", "ga.strikepractice.kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.8"
)
@ExperimentalStdlibApi
final class EnumEntriesList<T extends Enum<T>> extends AbstractList<T> implements EnumEntries<T>, Serializable {
   @NotNull
   private final Function0<T[]> entriesProvider;
   @Nullable
   private volatile T[] _entries;

   public EnumEntriesList(@NotNull Function0<T[]> var1) {
      Intrinsics.checkNotNullParameter(var1, "entriesProvider");
      super();
      this.entriesProvider = var1;
   }

   private final T[] getEntries() {
      Enum[] var1 = this._entries;
      if (var1 != null) {
         return var1;
      } else {
         var1 = (Enum[])this.entriesProvider.invoke();
         this._entries = var1;
         return var1;
      }
   }

   public int getSize() {
      return this.getEntries().length;
   }

   @NotNull
   public T get(int var1) {
      Enum[] var2 = this.getEntries();
      AbstractList.Companion.checkElementIndex$kotlin_stdlib(var1, var2.length);
      return var2[var1];
   }

   public boolean contains(@NotNull T var1) {
      Intrinsics.checkNotNullParameter(var1, "element");
      Enum var2 = (Enum)ArraysKt.getOrNull(this.getEntries(), var1.ordinal());
      return var2 == var1;
   }

   public int indexOf(@NotNull T var1) {
      Intrinsics.checkNotNullParameter(var1, "element");
      int var2 = var1.ordinal();
      Enum var3 = (Enum)ArraysKt.getOrNull(this.getEntries(), var2);
      return var3 == var1 ? var2 : -1;
   }

   public int lastIndexOf(@NotNull T var1) {
      Intrinsics.checkNotNullParameter(var1, "element");
      return this.indexOf((Object)var1);
   }

   private final Object writeReplace() {
      return new EnumEntriesSerializationProxy(this.getEntries());
   }
}
