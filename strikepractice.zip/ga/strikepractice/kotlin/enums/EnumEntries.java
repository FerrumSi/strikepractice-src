package ga.strikepractice.kotlin.enums;

import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.jvm.internal.markers.KMappedMarker;
import java.util.List;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0010\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\bw\u0018\u0000*\u000e\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003\u0082\u0001\u0001\u0004¨\u0006\u0005"},
   d2 = {"Lga/strikepractice/kotlin/enums/EnumEntries;", "E", "", "", "Lga/strikepractice/kotlin/enums/EnumEntriesList;", "ga.strikepractice.kotlin-stdlib"}
)
@ExperimentalStdlibApi
@SinceKotlin(
   version = "1.8"
)
public interface EnumEntries<E extends Enum<E>> extends KMappedMarker, List<E> {
}
