package ga.strikepractice.kotlin.enums;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.io.Serializable;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\b\u0000\u0018\u0000 \f*\u000e\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u00022\u00060\u0003j\u0002`\u0004:\u0001\fB\u0013\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0006¢\u0006\u0002\u0010\u0007J\b\u0010\n\u001a\u00020\u000bH\u0002R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"},
   d2 = {"Lga/strikepractice/kotlin/enums/EnumEntriesSerializationProxy;", "E", "", "Ljava/io/Serializable;", "Lga/strikepractice/kotlin/io/Serializable;", "entries", "", "([Ljava/lang/Enum;)V", "c", "Ljava/lang/Class;", "readResolve", "", "Companion", "ga.strikepractice.kotlin-stdlib"}
)
public final class EnumEntriesSerializationProxy<E extends Enum<E>> implements Serializable {
   @NotNull
   private static final EnumEntriesSerializationProxy.Companion Companion = new EnumEntriesSerializationProxy.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final Class<E> c;
   private static final long serialVersionUID = 0L;

   public EnumEntriesSerializationProxy(@NotNull E[] var1) {
      Intrinsics.checkNotNullParameter(var1, "entries");
      super();
      Class var10001 = var1.getClass().getComponentType();
      Intrinsics.checkNotNull(var10001);
      this.c = var10001;
   }

   private final Object readResolve() {
      Object[] var10000 = this.c.getEnumConstants();
      Intrinsics.checkNotNullExpressionValue(var10000, "c.enumConstants");
      return EnumEntriesKt.enumEntries((Enum[])var10000);
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\b\u0082\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0005"},
      d2 = {"Lga/strikepractice/kotlin/enums/EnumEntriesSerializationProxy$Companion;", "", "()V", "serialVersionUID", "", "ga.strikepractice.kotlin-stdlib"}
   )
   private static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker var1) {
         this();
      }
   }
}
