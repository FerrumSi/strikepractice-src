package ga.strikepractice.kotlin.experimental;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.RequiresOptIn;
import ga.strikepractice.kotlin.annotation.AnnotationRetention;
import ga.strikepractice.kotlin.annotation.AnnotationTarget;
import ga.strikepractice.kotlin.annotation.MustBeDocumented;
import ga.strikepractice.kotlin.annotation.Retention;
import ga.strikepractice.kotlin.annotation.Target;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;

@Target(
   allowedTargets = {AnnotationTarget.ANNOTATION_CLASS}
)
@Retention(AnnotationRetention.BINARY)
@MustBeDocumented
@Documented
@java.lang.annotation.Retention(RetentionPolicy.CLASS)
@java.lang.annotation.Target({ElementType.ANNOTATION_TYPE})
@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\b\u0087\u0002\u0018\u00002\u00020\u0001B\u0000¨\u0006\u0002"},
   d2 = {"Lga/strikepractice/kotlin/experimental/ExperimentalObjCName;", "", "ga.strikepractice.kotlin-stdlib"}
)
@RequiresOptIn
public @interface ExperimentalObjCName {
}
