package ga.strikepractice.kotlin;

import ga.strikepractice.kotlin.coroutines.Continuation;
import ga.strikepractice.kotlin.coroutines.CoroutineContext;
import ga.strikepractice.kotlin.coroutines.EmptyCoroutineContext;
import ga.strikepractice.kotlin.coroutines.intrinsics.IntrinsicsKt;
import ga.strikepractice.kotlin.coroutines.jvm.internal.DebugProbesKt;
import ga.strikepractice.kotlin.jvm.functions.Function3;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.TypeIntrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u0001*\u0004\b\u0001\u0010\u00022\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u00032\b\u0012\u0004\u0012\u0002H\u00020\u0004BK\u00129\u0010\u0005\u001a5\b\u0001\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010\u0003\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006¢\u0006\u0002\b\b\u0012\u0006\u0010\t\u001a\u00028\u0000ø\u0001\u0000¢\u0006\u0002\u0010\nJ\u0019\u0010\u0015\u001a\u00028\u00012\u0006\u0010\t\u001a\u00028\u0000H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0016Jc\u0010\u0017\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u000429\u0010\u0018\u001a5\b\u0001\u0012\f\u0012\n\u0012\u0002\b\u0003\u0012\u0002\b\u00030\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u0007\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006¢\u0006\u0002\b\b2\u000e\u0010\u000b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0004H\u0002ø\u0001\u0000¢\u0006\u0002\u0010\u0019J\u001e\u0010\u001a\u001a\u00020\u001b2\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00010\u0013H\u0016ø\u0001\u0000¢\u0006\u0002\u0010\u001cJ\u000b\u0010\u001d\u001a\u00028\u0001¢\u0006\u0002\u0010\u001eJ5\u0010\u0015\u001a\u0002H\u001f\"\u0004\b\u0002\u0010 \"\u0004\b\u0003\u0010\u001f*\u000e\u0012\u0004\u0012\u0002H \u0012\u0004\u0012\u0002H\u001f0!2\u0006\u0010\t\u001a\u0002H H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\"R\u0018\u0010\u000b\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0007\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fRF\u0010\u0010\u001a5\b\u0001\u0012\f\u0012\n\u0012\u0002\b\u0003\u0012\u0002\b\u00030\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u0007\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006¢\u0006\u0002\b\bX\u0082\u000eø\u0001\u0000¢\u0006\u0004\n\u0002\u0010\u0011R\u001e\u0010\u0012\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0013X\u0082\u000eø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\n\u0002\u0010\u0014R\u0010\u0010\t\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000\u0082\u0002\b\n\u0002\b\u0019\n\u0002\b!¨\u0006#"},
   d2 = {"Lga/strikepractice/kotlin/DeepRecursiveScopeImpl;", "T", "R", "Lga/strikepractice/kotlin/DeepRecursiveScope;", "Lga/strikepractice/kotlin/coroutines/Continuation;", "block", "Lga/strikepractice/kotlin/Function3;", "", "Lga/strikepractice/kotlin/ExtensionFunctionType;", "value", "(Lkotlin/jvm/functions/Function3;Ljava/lang/Object;)V", "cont", "context", "Lga/strikepractice/kotlin/coroutines/CoroutineContext;", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "function", "Lga/strikepractice/kotlin/jvm/functions/Function3;", "result", "Lga/strikepractice/kotlin/Result;", "Ljava/lang/Object;", "callRecursive", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "crossFunctionCompletion", "currentFunction", "(Lkotlin/jvm/functions/Function3;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;", "resumeWith", "", "(Ljava/lang/Object;)V", "runCallLoop", "()Ljava/lang/Object;", "S", "U", "Lga/strikepractice/kotlin/DeepRecursiveFunction;", "(Lkotlin/DeepRecursiveFunction;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "ga.strikepractice.kotlin-stdlib"}
)
final class DeepRecursiveScopeImpl<T, R> extends DeepRecursiveScope<T, R> implements Continuation<R> {
   @NotNull
   private Function3<? super DeepRecursiveScope<?, ?>, Object, ? super Continuation<Object>, ? extends Object> function;
   @Nullable
   private Object value;
   @Nullable
   private Continuation<Object> cont;
   @NotNull
   private Object result;

   public DeepRecursiveScopeImpl(@NotNull Function3<? super DeepRecursiveScope<T, R>, ? super T, ? super Continuation<? super R>, ? extends Object> var1, T var2) {
      Intrinsics.checkNotNullParameter(var1, "block");
      super((DefaultConstructorMarker)null);
      this.function = var1;
      this.value = var2;
      Intrinsics.checkNotNull(this, "null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
      this.cont = (Continuation)this;
      this.result = DeepRecursiveKt.access$getUNDEFINED_RESULT$p();
   }

   @NotNull
   public CoroutineContext getContext() {
      return (CoroutineContext)EmptyCoroutineContext.INSTANCE;
   }

   public void resumeWith(@NotNull Object var1) {
      this.cont = null;
      this.result = var1;
   }

   @Nullable
   public Object callRecursive(T var1, @NotNull Continuation<? super R> var2) {
      boolean var4 = false;
      Intrinsics.checkNotNull(var2, "null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
      this.cont = var2;
      this.value = var1;
      Object var10000 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(var2);
      }

      return var10000;
   }

   @Nullable
   public <U, S> Object callRecursive(@NotNull DeepRecursiveFunction<U, S> var1, U var2, @NotNull Continuation<? super S> var3) {
      boolean var5 = false;
      Function3 var10000 = var1.getBlock$kotlin_stdlib();
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type @[ExtensionFunctionType] kotlin.coroutines.SuspendFunction2<kotlin.DeepRecursiveScope<*, *>, kotlin.Any?, kotlin.Any?>{ kotlin.DeepRecursiveKt.DeepRecursiveFunctionBlock }");
      Function3 var6 = var10000;
      DeepRecursiveScopeImpl var7 = (DeepRecursiveScopeImpl)this;
      boolean var8 = false;
      Function3 var9 = var7.function;
      if (var6 != var9) {
         var7.function = var6;
         Intrinsics.checkNotNull(var3, "null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
         var7.cont = var7.crossFunctionCompletion(var9, var3);
      } else {
         Intrinsics.checkNotNull(var3, "null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
         var7.cont = var3;
      }

      var7.value = var2;
      Object var10 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      if (var10 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(var3);
      }

      return var10;
   }

   private final Continuation<Object> crossFunctionCompletion(Function3<? super DeepRecursiveScope<?, ?>, Object, ? super Continuation<Object>, ? extends Object> var1, Continuation<Object> var2) {
      CoroutineContext var3 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      return (Continuation)(new DeepRecursiveScopeImpl$crossFunctionCompletion$$inlined$Continuation$1(var3, this, var1, var2));
   }

   public final R runCallLoop() {
      while(true) {
         Object var1 = this.result;
         Continuation var10000 = this.cont;
         if (var10000 == null) {
            ResultKt.throwOnFailure(var1);
            return var1;
         }

         Continuation var2 = var10000;
         if (Result.equals-impl0(DeepRecursiveKt.access$getUNDEFINED_RESULT$p(), var1)) {
            Result.Companion var10001;
            Object var7;
            try {
               Function3 var4 = this.function;
               Object var5 = this.value;
               Intrinsics.checkNotNull(var4, "null cannot be cast to non-null type kotlin.Function3<R of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.startCoroutineUninterceptedOrReturn, P of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.startCoroutineUninterceptedOrReturn, kotlin.coroutines.Continuation<T of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.startCoroutineUninterceptedOrReturn>, kotlin.Any?>");
               var7 = ((Function3)TypeIntrinsics.beforeCheckcastToFunctionOfArity(var4, 3)).invoke(this, var5, var2);
            } catch (Throwable var6) {
               var10001 = Result.Companion;
               var2.resumeWith(Result.constructor-impl(ResultKt.createFailure(var6)));
               continue;
            }

            if (var7 != IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
               var10001 = Result.Companion;
               var2.resumeWith(Result.constructor-impl(var7));
            }
         } else {
            this.result = DeepRecursiveKt.access$getUNDEFINED_RESULT$p();
            var2.resumeWith(var1);
         }
      }
   }

   // $FF: synthetic method
   public static final void access$setFunction$p(DeepRecursiveScopeImpl var0, Function3 var1) {
      var0.function = var1;
   }

   // $FF: synthetic method
   public static final void access$setCont$p(DeepRecursiveScopeImpl var0, Continuation var1) {
      var0.cont = var1;
   }

   // $FF: synthetic method
   public static final void access$setResult$p(DeepRecursiveScopeImpl var0, Object var1) {
      var0.result = var1;
   }
}
