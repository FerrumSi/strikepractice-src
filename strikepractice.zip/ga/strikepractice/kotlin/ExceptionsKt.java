package ga.strikepractice.kotlin;

@Metadata(
   mv = {1, 8, 0},
   k = 4,
   xi = 49,
   d1 = {"ga/strikepractice/kotlin/ExceptionsKt__ExceptionsKt"}
)
public final class ExceptionsKt extends ExceptionsKt__ExceptionsKt {
   private ExceptionsKt() {
   }
}
