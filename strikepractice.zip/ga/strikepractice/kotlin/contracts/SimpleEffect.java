package ga.strikepractice.kotlin.contracts;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.internal.ContractsDsl;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\bg\u0018\u00002\u00020\u0001J\u0011\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H§\u0004¨\u0006\u0006"},
   d2 = {"Lga/strikepractice/kotlin/contracts/SimpleEffect;", "Lga/strikepractice/kotlin/contracts/Effect;", "implies", "Lga/strikepractice/kotlin/contracts/ConditionalEffect;", "booleanExpression", "", "ga.strikepractice.kotlin-stdlib"}
)
@ContractsDsl
@ExperimentalContracts
@SinceKotlin(
   version = "1.3"
)
public interface SimpleEffect extends Effect {
   @ContractsDsl
   @ExperimentalContracts
   @NotNull
   ConditionalEffect implies(boolean var1);
}
