package ga.strikepractice.kotlin.contracts;

import ga.strikepractice.kotlin.Function;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.internal.ContractsDsl;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001J&\u0010\u0002\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u00042\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00040\u00062\b\b\u0002\u0010\u0007\u001a\u00020\bH'J\b\u0010\t\u001a\u00020\nH'J\u0012\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\u0001H'J\b\u0010\f\u001a\u00020\rH'¨\u0006\u000e"},
   d2 = {"Lga/strikepractice/kotlin/contracts/ContractBuilder;", "", "callsInPlace", "Lga/strikepractice/kotlin/contracts/CallsInPlace;", "R", "lambda", "Lga/strikepractice/kotlin/Function;", "kind", "Lga/strikepractice/kotlin/contracts/InvocationKind;", "returns", "Lga/strikepractice/kotlin/contracts/Returns;", "value", "returnsNotNull", "Lga/strikepractice/kotlin/contracts/ReturnsNotNull;", "ga.strikepractice.kotlin-stdlib"}
)
@ContractsDsl
@ExperimentalContracts
@SinceKotlin(
   version = "1.3"
)
public interface ContractBuilder {
   @ContractsDsl
   @NotNull
   Returns returns();

   @ContractsDsl
   @NotNull
   Returns returns(@Nullable Object var1);

   @ContractsDsl
   @NotNull
   ReturnsNotNull returnsNotNull();

   @ContractsDsl
   @NotNull
   <R> CallsInPlace callsInPlace(@NotNull Function<? extends R> var1, @NotNull InvocationKind var2);

   @Metadata(
      mv = {1, 8, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      // $FF: synthetic method
      public static CallsInPlace callsInPlace$default(ContractBuilder var0, Function var1, InvocationKind var2, int var3, Object var4) {
         if (var4 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: callsInPlace");
         } else {
            if ((var3 & 2) != 0) {
               var2 = InvocationKind.UNKNOWN;
            }

            return var0.callsInPlace(var1, var2);
         }
      }
   }
}
