package ga.strikepractice.kotlin.internal;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.annotation.AnnotationRetention;
import ga.strikepractice.kotlin.annotation.AnnotationTarget;
import ga.strikepractice.kotlin.annotation.Retention;
import ga.strikepractice.kotlin.annotation.Target;
import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;

@Target(
   allowedTargets = {AnnotationTarget.FUNCTION, AnnotationTarget.PROPERTY, AnnotationTarget.CONSTRUCTOR}
)
@Retention(AnnotationRetention.BINARY)
@java.lang.annotation.Retention(RetentionPolicy.CLASS)
@java.lang.annotation.Target({ElementType.METHOD, ElementType.CONSTRUCTOR})
@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\b\u0081\u0002\u0018\u00002\u00020\u0001B\u0000¨\u0006\u0002"},
   d2 = {"Lga/strikepractice/kotlin/internal/LowPriorityInOverloadResolution;", "", "ga.strikepractice.kotlin-stdlib"}
)
public @interface LowPriorityInOverloadResolution {
}
