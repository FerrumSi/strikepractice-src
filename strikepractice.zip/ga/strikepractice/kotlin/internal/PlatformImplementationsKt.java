package ga.strikepractice.kotlin.internal;

import ga.strikepractice.kotlin.KotlinVersion;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.PublishedApi;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.jvm.JvmField;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b\u0003\u001a \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u0005H\u0001\u001a\"\u0010\b\u001a\u0002H\t\"\n\b\u0000\u0010\t\u0018\u0001*\u00020\n2\u0006\u0010\u000b\u001a\u00020\nH\u0083\b¢\u0006\u0002\u0010\f\"\u0010\u0010\u0000\u001a\u00020\u00018\u0000X\u0081\u0004¢\u0006\u0002\n\u0000¨\u0006\r"},
   d2 = {"IMPLEMENTATIONS", "Lga/strikepractice/kotlin/internal/PlatformImplementations;", "apiVersionIsAtLeast", "", "major", "", "minor", "patch", "castToBaseType", "T", "", "instance", "(Ljava/lang/Object;)Ljava/lang/Object;", "ga.strikepractice.kotlin-stdlib"}
)
public final class PlatformImplementationsKt {
   @JvmField
   @NotNull
   public static final PlatformImplementations IMPLEMENTATIONS;

   // $FF: synthetic method
   @InlineOnly
   private static final <T> T castToBaseType(Object var0) {
      try {
         Intrinsics.reifiedOperationMarker(1, "T");
         return (Object)var0;
      } catch (ClassCastException var4) {
         ClassLoader var2 = var0.getClass().getClassLoader();
         Intrinsics.reifiedOperationMarker(4, "T");
         ClassLoader var3 = ((Class)Object.class).getClassLoader();
         if (!Intrinsics.areEqual((Object)var2, (Object)var3)) {
            throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var2 + ", base type classloader: " + var3, (Throwable)var4);
         } else {
            throw var4;
         }
      }
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.2"
   )
   public static final boolean apiVersionIsAtLeast(int var0, int var1, int var2) {
      return KotlinVersion.CURRENT.isAtLeast(var0, var1, var2);
   }

   static {
      boolean var0 = false;

      PlatformImplementations var10000;
      Object var1;
      ClassLoader var3;
      ClassLoader var4;
      Object var13;
      try {
         var13 = Class.forName("ga.strikepractice.kotlin.internal.jdk8.JDK8PlatformImplementations").newInstance();
         Intrinsics.checkNotNullExpressionValue(var13, "forName(\"kotlin.internal…entations\").newInstance()");
         var1 = var13;

         try {
            if (var1 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
            }

            var10000 = (PlatformImplementations)var1;
         } catch (ClassCastException var11) {
            var3 = var1.getClass().getClassLoader();
            var4 = PlatformImplementations.class.getClassLoader();
            if (!Intrinsics.areEqual((Object)var3, (Object)var4)) {
               throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var3 + ", base type classloader: " + var4, (Throwable)var11);
            }

            throw var11;
         }
      } catch (ClassNotFoundException var12) {
         try {
            var13 = Class.forName("ga.strikepractice.kotlin.internal.JRE8PlatformImplementations").newInstance();
            Intrinsics.checkNotNullExpressionValue(var13, "forName(\"kotlin.internal…entations\").newInstance()");
            var1 = var13;

            try {
               if (var1 == null) {
                  throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
               }

               var10000 = (PlatformImplementations)var1;
            } catch (ClassCastException var9) {
               var3 = var1.getClass().getClassLoader();
               var4 = PlatformImplementations.class.getClassLoader();
               if (!Intrinsics.areEqual((Object)var3, (Object)var4)) {
                  throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var3 + ", base type classloader: " + var4, (Throwable)var9);
               }

               throw var9;
            }
         } catch (ClassNotFoundException var10) {
            try {
               var13 = Class.forName("ga.strikepractice.kotlin.internal.jdk7.JDK7PlatformImplementations").newInstance();
               Intrinsics.checkNotNullExpressionValue(var13, "forName(\"kotlin.internal…entations\").newInstance()");
               var1 = var13;

               try {
                  if (var1 == null) {
                     throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                  }

                  var10000 = (PlatformImplementations)var1;
               } catch (ClassCastException var7) {
                  var3 = var1.getClass().getClassLoader();
                  var4 = PlatformImplementations.class.getClassLoader();
                  if (!Intrinsics.areEqual((Object)var3, (Object)var4)) {
                     throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var3 + ", base type classloader: " + var4, (Throwable)var7);
                  }

                  throw var7;
               }
            } catch (ClassNotFoundException var8) {
               try {
                  var13 = Class.forName("ga.strikepractice.kotlin.internal.JRE7PlatformImplementations").newInstance();
                  Intrinsics.checkNotNullExpressionValue(var13, "forName(\"kotlin.internal…entations\").newInstance()");
                  var1 = var13;

                  try {
                     if (var1 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                     }

                     var10000 = (PlatformImplementations)var1;
                  } catch (ClassCastException var5) {
                     var3 = var1.getClass().getClassLoader();
                     var4 = PlatformImplementations.class.getClassLoader();
                     if (!Intrinsics.areEqual((Object)var3, (Object)var4)) {
                        throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var3 + ", base type classloader: " + var4, (Throwable)var5);
                     }

                     throw var5;
                  }
               } catch (ClassNotFoundException var6) {
                  var10000 = new PlatformImplementations();
               }
            }
         }
      }

      IMPLEMENTATIONS = var10000;
   }
}
