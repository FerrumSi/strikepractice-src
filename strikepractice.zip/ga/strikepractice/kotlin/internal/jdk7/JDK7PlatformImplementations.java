package ga.strikepractice.kotlin.internal.jdk7;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.collections.ArraysKt;
import ga.strikepractice.kotlin.internal.PlatformImplementations;
import ga.strikepractice.kotlin.jvm.JvmField;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0010\u0018\u00002\u00020\u0001:\u0001\u000eB\u0005¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006H\u0016J\u0016\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00060\t2\u0006\u0010\u0007\u001a\u00020\u0006H\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0002¨\u0006\u000f"},
   d2 = {"Lga/strikepractice/kotlin/internal/jdk7/JDK7PlatformImplementations;", "Lga/strikepractice/kotlin/internal/PlatformImplementations;", "()V", "addSuppressed", "", "cause", "", "exception", "getSuppressed", "", "sdkIsNullOrAtLeast", "", "version", "", "ReflectSdkVersion", "ga.strikepractice.kotlin-stdlib-jdk7"}
)
public class JDK7PlatformImplementations extends PlatformImplementations {
   private final boolean sdkIsNullOrAtLeast(int var1) {
      return JDK7PlatformImplementations.ReflectSdkVersion.sdkVersion == null || JDK7PlatformImplementations.ReflectSdkVersion.sdkVersion >= var1;
   }

   public void addSuppressed(@NotNull Throwable var1, @NotNull Throwable var2) {
      Intrinsics.checkNotNullParameter(var1, "cause");
      Intrinsics.checkNotNullParameter(var2, "exception");
      if (this.sdkIsNullOrAtLeast(19)) {
         var1.addSuppressed(var2);
      } else {
         super.addSuppressed(var1, var2);
      }

   }

   @NotNull
   public List<Throwable> getSuppressed(@NotNull Throwable var1) {
      Intrinsics.checkNotNullParameter(var1, "exception");
      List var2;
      if (this.sdkIsNullOrAtLeast(19)) {
         Throwable[] var10000 = var1.getSuppressed();
         Intrinsics.checkNotNullExpressionValue(var10000, "exception.suppressed");
         var2 = ArraysKt.asList((Object[])var10000);
      } else {
         var2 = super.getSuppressed(var1);
      }

      return var2;
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0014\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0004\n\u0002\u0010\u0005¨\u0006\u0006"},
      d2 = {"Lga/strikepractice/kotlin/internal/jdk7/JDK7PlatformImplementations$ReflectSdkVersion;", "", "()V", "sdkVersion", "", "Ljava/lang/Integer;", "ga.strikepractice.kotlin-stdlib-jdk7"}
   )
   @SourceDebugExtension({"SMAP\nJDK7PlatformImplementations.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JDK7PlatformImplementations.kt\nkotlin/internal/jdk7/JDK7PlatformImplementations$ReflectSdkVersion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,38:1\n1#2:39\n*E\n"})
   private static final class ReflectSdkVersion {
      @NotNull
      public static final JDK7PlatformImplementations.ReflectSdkVersion INSTANCE = new JDK7PlatformImplementations.ReflectSdkVersion();
      @JvmField
      @Nullable
      public static final Integer sdkVersion;

      static {
         Integer var1;
         try {
            Object var5 = Class.forName("android.os.Build$VERSION").getField("SDK_INT").get((Object)null);
            var1 = var5 instanceof Integer ? (Integer)var5 : null;
         } catch (Throwable var4) {
            var1 = null;
         }

         Integer var10000;
         if (var1 != null) {
            int var2 = ((Number)var1).intValue();
            boolean var3 = false;
            var10000 = var2 > 0 ? var1 : null;
         } else {
            var10000 = null;
         }

         sdkVersion = var10000;
      }
   }
}
