package ga.strikepractice.kotlin.internal.jdk8;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.internal.jdk7.JDK7PlatformImplementations;
import ga.strikepractice.kotlin.jvm.JvmField;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.random.Random;
import ga.strikepractice.kotlin.random.jdk8.PlatformThreadLocalRandom;
import ga.strikepractice.kotlin.ranges.IntRange;
import ga.strikepractice.kotlin.text.MatchGroup;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0010\u0018\u00002\u00020\u0001:\u0001\u000fB\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016J\u001a\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0002¨\u0006\u0010"},
   d2 = {"Lga/strikepractice/kotlin/internal/jdk8/JDK8PlatformImplementations;", "Lga/strikepractice/kotlin/internal/jdk7/JDK7PlatformImplementations;", "()V", "defaultPlatformRandom", "Lga/strikepractice/kotlin/random/Random;", "getMatchResultNamedGroup", "Lga/strikepractice/kotlin/text/MatchGroup;", "matchResult", "Ljava/util/regex/MatchResult;", "name", "", "sdkIsNullOrAtLeast", "", "version", "", "ReflectSdkVersion", "ga.strikepractice.kotlin-stdlib-jdk8"}
)
public class JDK8PlatformImplementations extends JDK7PlatformImplementations {
   private final boolean sdkIsNullOrAtLeast(int var1) {
      return JDK8PlatformImplementations.ReflectSdkVersion.sdkVersion == null || JDK8PlatformImplementations.ReflectSdkVersion.sdkVersion >= var1;
   }

   @Nullable
   public MatchGroup getMatchResultNamedGroup(@NotNull MatchResult var1, @NotNull String var2) {
      Intrinsics.checkNotNullParameter(var1, "matchResult");
      Intrinsics.checkNotNullParameter(var2, "name");
      Matcher var10000 = var1 instanceof Matcher ? (Matcher)var1 : null;
      if ((var1 instanceof Matcher ? (Matcher)var1 : null) == null) {
         throw new UnsupportedOperationException("Retrieving groups by name is not supported on this platform.");
      } else {
         Matcher var3 = var10000;
         IntRange var4 = new IntRange(var3.start(var2), var3.end(var2) - 1);
         MatchGroup var5;
         if (var4.getStart() >= 0) {
            String var10002 = var3.group(var2);
            Intrinsics.checkNotNullExpressionValue(var10002, "matcher.group(name)");
            var5 = new MatchGroup(var10002, var4);
         } else {
            var5 = null;
         }

         return var5;
      }
   }

   @NotNull
   public Random defaultPlatformRandom() {
      return this.sdkIsNullOrAtLeast(34) ? (Random)(new PlatformThreadLocalRandom()) : super.defaultPlatformRandom();
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0014\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0004\n\u0002\u0010\u0005¨\u0006\u0006"},
      d2 = {"Lga/strikepractice/kotlin/internal/jdk8/JDK8PlatformImplementations$ReflectSdkVersion;", "", "()V", "sdkVersion", "", "Ljava/lang/Integer;", "ga.strikepractice.kotlin-stdlib-jdk8"}
   )
   @SourceDebugExtension({"SMAP\nJDK8PlatformImplementations.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JDK8PlatformImplementations.kt\nkotlin/internal/jdk8/JDK8PlatformImplementations$ReflectSdkVersion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,61:1\n1#2:62\n*E\n"})
   private static final class ReflectSdkVersion {
      @NotNull
      public static final JDK8PlatformImplementations.ReflectSdkVersion INSTANCE = new JDK8PlatformImplementations.ReflectSdkVersion();
      @JvmField
      @Nullable
      public static final Integer sdkVersion;

      static {
         Integer var1;
         try {
            Object var5 = Class.forName("android.os.Build$VERSION").getField("SDK_INT").get((Object)null);
            var1 = var5 instanceof Integer ? (Integer)var5 : null;
         } catch (Throwable var4) {
            var1 = null;
         }

         Integer var10000;
         if (var1 != null) {
            int var2 = ((Number)var1).intValue();
            boolean var3 = false;
            var10000 = var2 > 0 ? var1 : null;
         } else {
            var10000 = null;
         }

         sdkVersion = var10000;
      }
   }
}
