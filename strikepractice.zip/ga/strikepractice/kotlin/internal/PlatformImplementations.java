package ga.strikepractice.kotlin.internal;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.collections.ArraysKt;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.jvm.JvmField;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.random.FallbackThreadLocalRandom;
import ga.strikepractice.kotlin.random.Random;
import ga.strikepractice.kotlin.text.MatchGroup;
import java.lang.reflect.Method;
import java.util.List;
import java.util.regex.MatchResult;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\b\u0010\u0018\u00002\u00020\u0001:\u0001\u0012B\u0005¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006H\u0016J\b\u0010\b\u001a\u00020\tH\u0016J\u001a\u0010\n\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J\u0016\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00060\u00112\u0006\u0010\u0007\u001a\u00020\u0006H\u0016¨\u0006\u0013"},
   d2 = {"Lga/strikepractice/kotlin/internal/PlatformImplementations;", "", "()V", "addSuppressed", "", "cause", "", "exception", "defaultPlatformRandom", "Lga/strikepractice/kotlin/random/Random;", "getMatchResultNamedGroup", "Lga/strikepractice/kotlin/text/MatchGroup;", "matchResult", "Ljava/util/regex/MatchResult;", "name", "", "getSuppressed", "", "ReflectThrowable", "ga.strikepractice.kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nPlatformImplementations.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlatformImplementations.kt\nkotlin/internal/PlatformImplementations\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,93:1\n1#2:94\n*E\n"})
public class PlatformImplementations {
   public void addSuppressed(@NotNull Throwable var1, @NotNull Throwable var2) {
      Intrinsics.checkNotNullParameter(var1, "cause");
      Intrinsics.checkNotNullParameter(var2, "exception");
      Method var10000 = PlatformImplementations.ReflectThrowable.addSuppressed;
      if (var10000 != null) {
         Object[] var3 = new Object[]{var2};
         var10000.invoke(var1, var3);
      }

   }

   @NotNull
   public List<Throwable> getSuppressed(@NotNull Throwable var1) {
      Intrinsics.checkNotNullParameter(var1, "exception");
      Method var10000 = PlatformImplementations.ReflectThrowable.getSuppressed;
      List var6;
      if (var10000 != null) {
         Object var5 = var10000.invoke(var1);
         if (var5 != null) {
            Object var2 = var5;
            boolean var4 = false;
            var6 = ArraysKt.asList((Throwable[])var2);
            if (var6 != null) {
               return var6;
            }
         }
      }

      var6 = CollectionsKt.emptyList();
      return var6;
   }

   @Nullable
   public MatchGroup getMatchResultNamedGroup(@NotNull MatchResult var1, @NotNull String var2) {
      Intrinsics.checkNotNullParameter(var1, "matchResult");
      Intrinsics.checkNotNullParameter(var2, "name");
      throw new UnsupportedOperationException("Retrieving groups by name is not supported on this platform.");
   }

   @NotNull
   public Random defaultPlatformRandom() {
      return (Random)(new FallbackThreadLocalRandom());
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0006"},
      d2 = {"Lga/strikepractice/kotlin/internal/PlatformImplementations$ReflectThrowable;", "", "()V", "addSuppressed", "Ljava/lang/reflect/Method;", "getSuppressed", "ga.strikepractice.kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nPlatformImplementations.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlatformImplementations.kt\nkotlin/internal/PlatformImplementations$ReflectThrowable\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,93:1\n1#2:94\n*E\n"})
   private static final class ReflectThrowable {
      @NotNull
      public static final PlatformImplementations.ReflectThrowable INSTANCE = new PlatformImplementations.ReflectThrowable();
      @JvmField
      @Nullable
      public static final Method addSuppressed;
      @JvmField
      @Nullable
      public static final Method getSuppressed;

      static {
         Class var0 = Throwable.class;
         Method[] var1 = var0.getMethods();
         Intrinsics.checkNotNullExpressionValue(var1, "throwableMethods");
         Method[] var2 = var1;
         int var3 = 0;
         int var4 = var1.length;

         Method var5;
         boolean var7;
         Method var9;
         while(true) {
            if (var3 >= var4) {
               var9 = null;
               break;
            }

            boolean var8;
            label36: {
               var5 = var2[var3];
               var7 = false;
               if (Intrinsics.areEqual((Object)var5.getName(), (Object)"addSuppressed")) {
                  Class[] var10000 = var5.getParameterTypes();
                  Intrinsics.checkNotNullExpressionValue(var10000, "it.parameterTypes");
                  if (Intrinsics.areEqual((Object)ArraysKt.singleOrNull((Object[])var10000), (Object)var0)) {
                     var8 = true;
                     break label36;
                  }
               }

               var8 = false;
            }

            if (var8) {
               var9 = var5;
               break;
            }

            ++var3;
         }

         addSuppressed = var9;
         var2 = var1;
         var3 = 0;
         var4 = var1.length;

         while(true) {
            if (var3 >= var4) {
               var9 = null;
               break;
            }

            var5 = var2[var3];
            var7 = false;
            if (Intrinsics.areEqual((Object)var5.getName(), (Object)"getSuppressed")) {
               var9 = var5;
               break;
            }

            ++var3;
         }

         getSuppressed = var9;
      }
   }
}
