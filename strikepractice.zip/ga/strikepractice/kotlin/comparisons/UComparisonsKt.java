package ga.strikepractice.kotlin.comparisons;

import ga.strikepractice.kotlin.Metadata;

@Metadata(
   mv = {1, 8, 0},
   k = 4,
   xi = 49,
   d1 = {"ga/strikepractice/kotlin/comparisons/UComparisonsKt___UComparisonsKt"}
)
public final class UComparisonsKt extends UComparisonsKt___UComparisonsKt {
   private UComparisonsKt() {
   }
}
