package ga.strikepractice.kotlin.comparisons;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.functions.Function2;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.util.Comparator;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000<\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0010\u0000\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a>\u0010\u0000\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u00022\u001a\b\u0004\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u0005H\u0087\bø\u0001\u0000\u001aY\u0010\u0000\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u000226\u0010\u0007\u001a\u001c\u0012\u0018\b\u0001\u0012\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u00050\b\"\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u0005¢\u0006\u0002\u0010\t\u001aZ\u0010\u0000\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\n2\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\n0\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\n`\u00032\u0014\b\u0004\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\n0\u0005H\u0087\bø\u0001\u0000\u001a>\u0010\f\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u00022\u001a\b\u0004\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u0005H\u0087\bø\u0001\u0000\u001aZ\u0010\f\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\n2\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\n0\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\n`\u00032\u0014\b\u0004\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\n0\u0005H\u0087\bø\u0001\u0000\u001a-\u0010\r\u001a\u00020\u000e\"\f\b\u0000\u0010\u0002*\u0006\u0012\u0002\b\u00030\u00062\b\u0010\u000f\u001a\u0004\u0018\u0001H\u00022\b\u0010\u0010\u001a\u0004\u0018\u0001H\u0002¢\u0006\u0002\u0010\u0011\u001aA\u0010\u0012\u001a\u00020\u000e\"\u0004\b\u0000\u0010\u00022\u0006\u0010\u000f\u001a\u0002H\u00022\u0006\u0010\u0010\u001a\u0002H\u00022\u0018\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u0005H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0013\u001aY\u0010\u0012\u001a\u00020\u000e\"\u0004\b\u0000\u0010\u00022\u0006\u0010\u000f\u001a\u0002H\u00022\u0006\u0010\u0010\u001a\u0002H\u000226\u0010\u0007\u001a\u001c\u0012\u0018\b\u0001\u0012\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u00050\b\"\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u0005¢\u0006\u0002\u0010\u0014\u001a]\u0010\u0012\u001a\u00020\u000e\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\n2\u0006\u0010\u000f\u001a\u0002H\u00022\u0006\u0010\u0010\u001a\u0002H\u00022\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\n0\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\n`\u00032\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\n0\u0005H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0015\u001aG\u0010\u0016\u001a\u00020\u000e\"\u0004\b\u0000\u0010\u00022\u0006\u0010\u000f\u001a\u0002H\u00022\u0006\u0010\u0010\u001a\u0002H\u00022 \u0010\u0007\u001a\u001c\u0012\u0018\b\u0001\u0012\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u00050\bH\u0002¢\u0006\u0004\b\u0017\u0010\u0014\u001a&\u0010\u0018\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u000e\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0006\u001a-\u0010\u0019\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u0001H\u00020\u0001j\n\u0012\u0006\u0012\u0004\u0018\u0001H\u0002`\u0003\"\u000e\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0006H\u0087\b\u001a@\u0010\u0019\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u0001H\u00020\u0001j\n\u0012\u0006\u0012\u0004\u0018\u0001H\u0002`\u0003\"\b\b\u0000\u0010\u0002*\u00020\u001a2\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u00020\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\u0002`\u0003\u001a-\u0010\u001b\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u0001H\u00020\u0001j\n\u0012\u0006\u0012\u0004\u0018\u0001H\u0002`\u0003\"\u000e\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0006H\u0087\b\u001a@\u0010\u001b\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u0001H\u00020\u0001j\n\u0012\u0006\u0012\u0004\u0018\u0001H\u0002`\u0003\"\b\b\u0000\u0010\u0002*\u00020\u001a2\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u00020\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\u0002`\u0003\u001a&\u0010\u001c\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u000e\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0006\u001a0\u0010\u001d\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002*\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\u001aO\u0010\u001e\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002*\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u00032\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u00020\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\u0002`\u0003H\u0086\u0004\u001aR\u0010\u001f\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002*\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u00032\u001a\b\u0004\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u0005H\u0087\bø\u0001\u0000\u001an\u0010\u001f\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\n*\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u00032\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\n0\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\n`\u00032\u0014\b\u0004\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\n0\u0005H\u0087\bø\u0001\u0000\u001aR\u0010 \u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002*\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u00032\u001a\b\u0004\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00060\u0005H\u0087\bø\u0001\u0000\u001an\u0010 \u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\n*\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u00032\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\n0\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\n`\u00032\u0014\b\u0004\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\n0\u0005H\u0087\bø\u0001\u0000\u001ap\u0010!\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002*\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u000328\b\u0004\u0010\"\u001a2\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b$\u0012\b\b%\u0012\u0004\b\b(\u000f\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b$\u0012\b\b%\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u000e0#H\u0087\bø\u0001\u0000\u001aO\u0010&\u001a\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u0003\"\u0004\b\u0000\u0010\u0002*\u0012\u0012\u0004\u0012\u0002H\u00020\u0001j\b\u0012\u0004\u0012\u0002H\u0002`\u00032\u001a\u0010\u000b\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u00020\u0001j\n\u0012\u0006\b\u0000\u0012\u0002H\u0002`\u0003H\u0086\u0004\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006'"},
   d2 = {"compareBy", "Ljava/util/Comparator;", "T", "Lga/strikepractice/kotlin/Comparator;", "selector", "Lga/strikepractice/kotlin/Function1;", "", "selectors", "", "([Lkotlin/jvm/functions/Function1;)Ljava/util/Comparator;", "K", "comparator", "compareByDescending", "compareValues", "", "a", "b", "(Ljava/lang/Comparable;Ljava/lang/Comparable;)I", "compareValuesBy", "(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)I", "(Ljava/lang/Object;Ljava/lang/Object;[Lkotlin/jvm/functions/Function1;)I", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;Lkotlin/jvm/functions/Function1;)I", "compareValuesByImpl", "compareValuesByImpl$ComparisonsKt__ComparisonsKt", "naturalOrder", "nullsFirst", "", "nullsLast", "reverseOrder", "reversed", "then", "thenBy", "thenByDescending", "thenComparator", "comparison", "Lga/strikepractice/kotlin/Function2;", "Lga/strikepractice/kotlin/ParameterName;", "name", "thenDescending", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/comparisons/ComparisonsKt"
)
class ComparisonsKt__ComparisonsKt {
   public static final <T> int compareValuesBy(T var0, T var1, @NotNull Function1<? super T, ? extends Comparable<?>>... var2) {
      Intrinsics.checkNotNullParameter(var2, "selectors");
      boolean var3 = var2.length > 0;
      if (!var3) {
         String var4 = "Failed requirement.";
         throw new IllegalArgumentException(var4.toString());
      } else {
         return compareValuesByImpl$ComparisonsKt__ComparisonsKt(var0, var1, var2);
      }
   }

   private static final <T> int compareValuesByImpl$ComparisonsKt__ComparisonsKt(T var0, T var1, Function1<? super T, ? extends Comparable<?>>[] var2) {
      int var3 = 0;

      for(int var4 = var2.length; var3 < var4; ++var3) {
         Function1 var5 = var2[var3];
         Comparable var6 = (Comparable)var5.invoke(var0);
         Comparable var7 = (Comparable)var5.invoke(var1);
         int var8 = ComparisonsKt.compareValues(var6, var7);
         if (var8 != 0) {
            return var8;
         }
      }

      return 0;
   }

   @InlineOnly
   private static final <T> int compareValuesBy(T var0, T var1, Function1<? super T, ? extends Comparable<?>> var2) {
      Intrinsics.checkNotNullParameter(var2, "selector");
      return ComparisonsKt.compareValues((Comparable)var2.invoke(var0), (Comparable)var2.invoke(var1));
   }

   @InlineOnly
   private static final <T, K> int compareValuesBy(T var0, T var1, Comparator<? super K> var2, Function1<? super T, ? extends K> var3) {
      Intrinsics.checkNotNullParameter(var2, "comparator");
      Intrinsics.checkNotNullParameter(var3, "selector");
      return var2.compare(var3.invoke(var0), var3.invoke(var1));
   }

   public static final <T extends Comparable<?>> int compareValues(@Nullable T var0, @Nullable T var1) {
      if (var0 == var1) {
         return 0;
      } else if (var0 == null) {
         return -1;
      } else {
         return var1 == null ? 1 : var0.compareTo(var1);
      }
   }

   @NotNull
   public static final <T> Comparator<T> compareBy(@NotNull Function1<? super T, ? extends Comparable<?>>... var0) {
      Intrinsics.checkNotNullParameter(var0, "selectors");
      boolean var1 = var0.length > 0;
      if (!var1) {
         String var2 = "Failed requirement.";
         throw new IllegalArgumentException(var2.toString());
      } else {
         return ComparisonsKt__ComparisonsKt::compareBy$lambda$0$ComparisonsKt__ComparisonsKt;
      }
   }

   @InlineOnly
   private static final <T> Comparator<T> compareBy(final Function1<? super T, ? extends Comparable<?>> var0) {
      Intrinsics.checkNotNullParameter(var0, "selector");
      return (Comparator)(new Comparator() {
         public final int compare(T var1, T var2) {
            Function1 var3 = var0;
            return ComparisonsKt.compareValues((Comparable)var3.invoke(var1), (Comparable)var3.invoke(var2));
         }
      });
   }

   @InlineOnly
   private static final <T, K> Comparator<T> compareBy(final Comparator<? super K> var0, final Function1<? super T, ? extends K> var1) {
      Intrinsics.checkNotNullParameter(var0, "comparator");
      Intrinsics.checkNotNullParameter(var1, "selector");
      return (Comparator)(new Comparator() {
         public final int compare(T var1x, T var2) {
            Comparator var3 = var0;
            Function1 var4 = var1;
            return var3.compare(var4.invoke(var1x), var4.invoke(var2));
         }
      });
   }

   @InlineOnly
   private static final <T> Comparator<T> compareByDescending(final Function1<? super T, ? extends Comparable<?>> var0) {
      Intrinsics.checkNotNullParameter(var0, "selector");
      return (Comparator)(new Comparator() {
         public final int compare(T var1, T var2) {
            Function1 var3 = var0;
            return ComparisonsKt.compareValues((Comparable)var3.invoke(var2), (Comparable)var3.invoke(var1));
         }
      });
   }

   @InlineOnly
   private static final <T, K> Comparator<T> compareByDescending(final Comparator<? super K> var0, final Function1<? super T, ? extends K> var1) {
      Intrinsics.checkNotNullParameter(var0, "comparator");
      Intrinsics.checkNotNullParameter(var1, "selector");
      return (Comparator)(new Comparator() {
         public final int compare(T var1x, T var2) {
            Comparator var3 = var0;
            Function1 var4 = var1;
            return var3.compare(var4.invoke(var2), var4.invoke(var1x));
         }
      });
   }

   @InlineOnly
   private static final <T> Comparator<T> thenBy(final Comparator<T> var0, final Function1<? super T, ? extends Comparable<?>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      return (Comparator)(new Comparator() {
         public final int compare(T var1x, T var2) {
            int var3 = var0.compare(var1x, var2);
            int var10000;
            if (var3 != 0) {
               var10000 = var3;
            } else {
               Function1 var4 = var1;
               var10000 = ComparisonsKt.compareValues((Comparable)var4.invoke(var1x), (Comparable)var4.invoke(var2));
            }

            return var10000;
         }
      });
   }

   @InlineOnly
   private static final <T, K> Comparator<T> thenBy(final Comparator<T> var0, final Comparator<? super K> var1, final Function1<? super T, ? extends K> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      Intrinsics.checkNotNullParameter(var2, "selector");
      return (Comparator)(new Comparator() {
         public final int compare(T var1x, T var2x) {
            int var3 = var0.compare(var1x, var2x);
            int var10000;
            if (var3 != 0) {
               var10000 = var3;
            } else {
               Comparator var4 = var1;
               Function1 var5 = var2;
               var10000 = var4.compare(var5.invoke(var1x), var5.invoke(var2x));
            }

            return var10000;
         }
      });
   }

   @InlineOnly
   private static final <T> Comparator<T> thenByDescending(final Comparator<T> var0, final Function1<? super T, ? extends Comparable<?>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      return (Comparator)(new Comparator() {
         public final int compare(T var1x, T var2) {
            int var3 = var0.compare(var1x, var2);
            int var10000;
            if (var3 != 0) {
               var10000 = var3;
            } else {
               Function1 var4 = var1;
               var10000 = ComparisonsKt.compareValues((Comparable)var4.invoke(var2), (Comparable)var4.invoke(var1x));
            }

            return var10000;
         }
      });
   }

   @InlineOnly
   private static final <T, K> Comparator<T> thenByDescending(final Comparator<T> var0, final Comparator<? super K> var1, final Function1<? super T, ? extends K> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      Intrinsics.checkNotNullParameter(var2, "selector");
      return (Comparator)(new Comparator() {
         public final int compare(T var1x, T var2x) {
            int var3 = var0.compare(var1x, var2x);
            int var10000;
            if (var3 != 0) {
               var10000 = var3;
            } else {
               Comparator var4 = var1;
               Function1 var5 = var2;
               var10000 = var4.compare(var5.invoke(var2x), var5.invoke(var1x));
            }

            return var10000;
         }
      });
   }

   @InlineOnly
   private static final <T> Comparator<T> thenComparator(final Comparator<T> var0, final Function2<? super T, ? super T, Integer> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparison");
      return (Comparator)(new Comparator() {
         public final int compare(T var1x, T var2) {
            int var3 = var0.compare(var1x, var2);
            return var3 != 0 ? var3 : ((Number)var1.invoke(var1x, var2)).intValue();
         }
      });
   }

   @NotNull
   public static final <T> Comparator<T> then(@NotNull Comparator<T> var0, @NotNull Comparator<? super T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return ComparisonsKt__ComparisonsKt::then$lambda$1$ComparisonsKt__ComparisonsKt;
   }

   @NotNull
   public static final <T> Comparator<T> thenDescending(@NotNull Comparator<T> var0, @NotNull Comparator<? super T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return ComparisonsKt__ComparisonsKt::thenDescending$lambda$2$ComparisonsKt__ComparisonsKt;
   }

   @NotNull
   public static final <T> Comparator<T> nullsFirst(@NotNull Comparator<? super T> var0) {
      Intrinsics.checkNotNullParameter(var0, "comparator");
      return ComparisonsKt__ComparisonsKt::nullsFirst$lambda$3$ComparisonsKt__ComparisonsKt;
   }

   @InlineOnly
   private static final <T extends Comparable<? super T>> Comparator<T> nullsFirst() {
      return ComparisonsKt.nullsFirst(ComparisonsKt.naturalOrder());
   }

   @NotNull
   public static final <T> Comparator<T> nullsLast(@NotNull Comparator<? super T> var0) {
      Intrinsics.checkNotNullParameter(var0, "comparator");
      return ComparisonsKt__ComparisonsKt::nullsLast$lambda$4$ComparisonsKt__ComparisonsKt;
   }

   @InlineOnly
   private static final <T extends Comparable<? super T>> Comparator<T> nullsLast() {
      return ComparisonsKt.nullsLast(ComparisonsKt.naturalOrder());
   }

   @NotNull
   public static final <T extends Comparable<? super T>> Comparator<T> naturalOrder() {
      NaturalOrderComparator var10000 = NaturalOrderComparator.INSTANCE;
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type java.util.Comparator<T of kotlin.comparisons.ComparisonsKt__ComparisonsKt.naturalOrder>{ kotlin.TypeAliasesKt.Comparator<T of kotlin.comparisons.ComparisonsKt__ComparisonsKt.naturalOrder> }");
      return (Comparator)var10000;
   }

   @NotNull
   public static final <T extends Comparable<? super T>> Comparator<T> reverseOrder() {
      ReverseOrderComparator var10000 = ReverseOrderComparator.INSTANCE;
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type java.util.Comparator<T of kotlin.comparisons.ComparisonsKt__ComparisonsKt.reverseOrder>{ kotlin.TypeAliasesKt.Comparator<T of kotlin.comparisons.ComparisonsKt__ComparisonsKt.reverseOrder> }");
      return (Comparator)var10000;
   }

   @NotNull
   public static final <T> Comparator<T> reversed(@NotNull Comparator<T> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Comparator var10000;
      if (var0 instanceof ReversedComparator) {
         var10000 = ((ReversedComparator)var0).getComparator();
      } else if (Intrinsics.areEqual((Object)var0, (Object)NaturalOrderComparator.INSTANCE)) {
         ReverseOrderComparator var2 = ReverseOrderComparator.INSTANCE;
         Intrinsics.checkNotNull(var2, "null cannot be cast to non-null type java.util.Comparator<T of kotlin.comparisons.ComparisonsKt__ComparisonsKt.reversed>{ kotlin.TypeAliasesKt.Comparator<T of kotlin.comparisons.ComparisonsKt__ComparisonsKt.reversed> }");
         var10000 = (Comparator)var2;
      } else if (Intrinsics.areEqual((Object)var0, (Object)ReverseOrderComparator.INSTANCE)) {
         NaturalOrderComparator var3 = NaturalOrderComparator.INSTANCE;
         Intrinsics.checkNotNull(var3, "null cannot be cast to non-null type java.util.Comparator<T of kotlin.comparisons.ComparisonsKt__ComparisonsKt.reversed>{ kotlin.TypeAliasesKt.Comparator<T of kotlin.comparisons.ComparisonsKt__ComparisonsKt.reversed> }");
         var10000 = (Comparator)var3;
      } else {
         var10000 = (Comparator)(new ReversedComparator(var0));
      }

      return var10000;
   }

   private static final int compareBy$lambda$0$ComparisonsKt__ComparisonsKt(Function1[] var0, Object var1, Object var2) {
      Intrinsics.checkNotNullParameter(var0, "$selectors");
      return compareValuesByImpl$ComparisonsKt__ComparisonsKt(var1, var2, var0);
   }

   private static final int then$lambda$1$ComparisonsKt__ComparisonsKt(Comparator var0, Comparator var1, Object var2, Object var3) {
      Intrinsics.checkNotNullParameter(var0, "$this_then");
      Intrinsics.checkNotNullParameter(var1, "$comparator");
      int var4 = var0.compare(var2, var3);
      return var4 != 0 ? var4 : var1.compare(var2, var3);
   }

   private static final int thenDescending$lambda$2$ComparisonsKt__ComparisonsKt(Comparator var0, Comparator var1, Object var2, Object var3) {
      Intrinsics.checkNotNullParameter(var0, "$this_thenDescending");
      Intrinsics.checkNotNullParameter(var1, "$comparator");
      int var4 = var0.compare(var2, var3);
      return var4 != 0 ? var4 : var1.compare(var3, var2);
   }

   private static final int nullsFirst$lambda$3$ComparisonsKt__ComparisonsKt(Comparator var0, Object var1, Object var2) {
      Intrinsics.checkNotNullParameter(var0, "$comparator");
      return var1 == var2 ? 0 : (var1 == null ? -1 : (var2 == null ? 1 : var0.compare(var1, var2)));
   }

   private static final int nullsLast$lambda$4$ComparisonsKt__ComparisonsKt(Comparator var0, Object var1, Object var2) {
      Intrinsics.checkNotNullParameter(var0, "$comparator");
      return var1 == var2 ? 0 : (var1 == null ? 1 : (var2 == null ? -1 : var0.compare(var1, var2)));
   }

   public ComparisonsKt__ComparisonsKt() {
   }
}
