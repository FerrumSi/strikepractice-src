package ga.strikepractice.kotlin;

import ga.strikepractice.kotlin.internal.HidesMembers;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.internal.PlatformImplementationsKt;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u00004\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u001a\u0014\u0010\r\u001a\u00020\u000e*\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0003H\u0007\u001a\r\u0010\u0010\u001a\u00020\u000e*\u00020\u0003H\u0087\b\u001a\u0015\u0010\u0010\u001a\u00020\u000e*\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u0012H\u0087\b\u001a\u0015\u0010\u0010\u001a\u00020\u000e*\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u0014H\u0087\b\u001a\f\u0010\u0015\u001a\u00020\u0016*\u00020\u0003H\u0007\"!\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u00038F¢\u0006\f\u0012\u0004\b\u0004\u0010\u0005\u001a\u0004\b\u0006\u0010\u0007\"$\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00030\t*\u00020\u00038FX\u0087\u0004¢\u0006\f\u0012\u0004\b\n\u0010\u0005\u001a\u0004\b\u000b\u0010\f¨\u0006\u0017"},
   d2 = {"stackTrace", "", "Ljava/lang/StackTraceElement;", "", "getStackTrace$annotations", "(Ljava/lang/Throwable;)V", "getStackTrace", "(Ljava/lang/Throwable;)[Ljava/lang/StackTraceElement;", "suppressedExceptions", "", "getSuppressedExceptions$annotations", "getSuppressedExceptions", "(Ljava/lang/Throwable;)Ljava/util/List;", "addSuppressed", "", "exception", "printStackTrace", "stream", "Ljava/io/PrintStream;", "writer", "Ljava/io/PrintWriter;", "stackTraceToString", "", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/ExceptionsKt"
)
class ExceptionsKt__ExceptionsKt {
   @InlineOnly
   private static final void printStackTrace(Throwable var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      var0.printStackTrace();
   }

   @InlineOnly
   private static final void printStackTrace(Throwable var0, PrintWriter var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "writer");
      var0.printStackTrace(var1);
   }

   @InlineOnly
   private static final void printStackTrace(Throwable var0, PrintStream var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "stream");
      var0.printStackTrace(var1);
   }

   @NotNull
   public static final StackTraceElement[] getStackTrace(@NotNull Throwable var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      StackTraceElement[] var10000 = var0.getStackTrace();
      Intrinsics.checkNotNull(var10000);
      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void getStackTrace$annotations(Throwable var0) {
   }

   @SinceKotlin(
      version = "1.4"
   )
   @NotNull
   public static final String stackTraceToString(@NotNull Throwable var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      StringWriter var1 = new StringWriter();
      PrintWriter var2 = new PrintWriter((Writer)var1);
      var0.printStackTrace(var2);
      var2.flush();
      String var10000 = var1.toString();
      Intrinsics.checkNotNullExpressionValue(var10000, "sw.toString()");
      return var10000;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @HidesMembers
   public static final void addSuppressed(@NotNull Throwable var0, @NotNull Throwable var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "exception");
      if (var0 != var1) {
         PlatformImplementationsKt.IMPLEMENTATIONS.addSuppressed(var0, var1);
      }

   }

   @NotNull
   public static final List<Throwable> getSuppressedExceptions(@NotNull Throwable var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return PlatformImplementationsKt.IMPLEMENTATIONS.getSuppressed(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.4"
   )
   public static void getSuppressedExceptions$annotations(Throwable var0) {
   }

   public ExceptionsKt__ExceptionsKt() {
   }
}
