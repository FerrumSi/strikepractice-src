package ga.strikepractice.kotlin;

import ga.strikepractice.kotlin.jvm.internal.Intrinsics;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0011\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a!\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u000b\b\u0000\u0010\u0002\u0018\u0001¢\u0006\u0002\b\u0003H\u0086\b¢\u0006\u0002\u0010\u0004¨\u0006\u0005"},
   d2 = {"emptyArray", "", "T", "Lga/strikepractice/kotlin/internal/PureReifiable;", "()[Ljava/lang/Object;", "ga.strikepractice.kotlin-stdlib"}
)
public final class ArrayIntrinsicsKt {
   // $FF: synthetic method
   public static final <T> T[] emptyArray() {
      boolean var0 = false;
      Intrinsics.reifiedOperationMarker(0, "T?");
      return new Object[0];
   }
}
