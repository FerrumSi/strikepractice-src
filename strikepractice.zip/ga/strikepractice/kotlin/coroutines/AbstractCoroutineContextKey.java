package ga.strikepractice.kotlin.coroutines;

import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0006\b'\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u0002*\b\b\u0001\u0010\u0003*\u0002H\u00012\b\u0012\u0004\u0012\u0002H\u00030\u0004B8\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\u0012#\u0010\u0006\u001a\u001f\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0006\u0012\u0004\u0018\u00018\u00010\u0007¢\u0006\u0002\u0010\u000bJ\u0019\u0010\r\u001a\u00020\u000e2\n\u0010\u000f\u001a\u0006\u0012\u0002\b\u00030\u0004H\u0000¢\u0006\u0002\b\u0010J\u0019\u0010\u0011\u001a\u0004\u0018\u00018\u00012\u0006\u0010\n\u001a\u00020\u0002H\u0000¢\u0006\u0004\b\u0012\u0010\u0013R+\u0010\u0006\u001a\u001f\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0006\u0012\u0004\u0018\u00018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\f\u001a\u0006\u0012\u0002\b\u00030\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0014"},
   d2 = {"Lga/strikepractice/kotlin/coroutines/AbstractCoroutineContextKey;", "B", "Lga/strikepractice/kotlin/coroutines/CoroutineContext$Element;", "E", "Lga/strikepractice/kotlin/coroutines/CoroutineContext$Key;", "baseKey", "safeCast", "Lga/strikepractice/kotlin/Function1;", "Lga/strikepractice/kotlin/ParameterName;", "name", "element", "(Lkotlin/coroutines/CoroutineContext$Key;Lkotlin/jvm/functions/Function1;)V", "topmostKey", "isSubKey", "", "key", "isSubKey$kotlin_stdlib", "tryCast", "tryCast$kotlin_stdlib", "(Lkotlin/coroutines/CoroutineContext$Element;)Lkotlin/coroutines/CoroutineContext$Element;", "ga.strikepractice.kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.3"
)
@ExperimentalStdlibApi
public abstract class AbstractCoroutineContextKey<B extends CoroutineContext.Element, E extends B> implements CoroutineContext.Key<E> {
   @NotNull
   private final Function1<CoroutineContext.Element, E> safeCast;
   @NotNull
   private final CoroutineContext.Key<?> topmostKey;

   public AbstractCoroutineContextKey(@NotNull CoroutineContext.Key<B> var1, @NotNull Function1<? super CoroutineContext.Element, ? extends E> var2) {
      Intrinsics.checkNotNullParameter(var1, "baseKey");
      Intrinsics.checkNotNullParameter(var2, "safeCast");
      super();
      this.safeCast = var2;
      this.topmostKey = var1 instanceof AbstractCoroutineContextKey ? ((AbstractCoroutineContextKey)var1).topmostKey : var1;
   }

   @Nullable
   public final E tryCast$kotlin_stdlib(@NotNull CoroutineContext.Element var1) {
      Intrinsics.checkNotNullParameter(var1, "element");
      return (CoroutineContext.Element)this.safeCast.invoke(var1);
   }

   public final boolean isSubKey$kotlin_stdlib(@NotNull CoroutineContext.Key<?> var1) {
      Intrinsics.checkNotNullParameter(var1, "key");
      return var1 == this || this.topmostKey == var1;
   }
}
