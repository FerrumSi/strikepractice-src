package ga.strikepractice.kotlin.coroutines.cancellation;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.util.concurrent.CancellationException;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a!\u0010\u0000\u001a\u00060\u0001j\u0002`\u00022\b\u0010\u0003\u001a\u0004\u0018\u00010\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0087\b\u001a\u0017\u0010\u0000\u001a\u00060\u0001j\u0002`\u00022\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0087\b*\u001a\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t¨\u0006\n"},
   d2 = {"CancellationException", "Ljava/util/concurrent/CancellationException;", "Lga/strikepractice/kotlin/coroutines/cancellation/CancellationException;", "message", "", "cause", "", "Lga/strikepractice/kotlin/SinceKotlin;", "version", "1.4", "ga.strikepractice.kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nCancellationException.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CancellationException.kt\nkotlin/coroutines/cancellation/CancellationExceptionKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,22:1\n1#2:23\n*E\n"})
public final class CancellationExceptionKt {
   @InlineOnly
   @SinceKotlin(
      version = "1.4"
   )
   private static final CancellationException CancellationException(String var0, Throwable var1) {
      CancellationException var2 = new CancellationException(var0);
      boolean var4 = false;
      var2.initCause(var1);
      return var2;
   }

   @InlineOnly
   @SinceKotlin(
      version = "1.4"
   )
   private static final CancellationException CancellationException(Throwable var0) {
      CancellationException var1 = new CancellationException(var0 != null ? var0.toString() : null);
      boolean var3 = false;
      var1.initCause(var0);
      return var1;
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.4"
   )
   public static void CancellationException$annotations() {
   }
}
