package ga.strikepractice.kotlin.coroutines;

import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u001a+\u0010\u0000\u001a\u0004\u0018\u0001H\u0001\"\b\b\u0000\u0010\u0001*\u00020\u0002*\u00020\u00022\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00010\u0004H\u0007¢\u0006\u0002\u0010\u0005\u001a\u0018\u0010\u0006\u001a\u00020\u0007*\u00020\u00022\n\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0004H\u0007¨\u0006\b"},
   d2 = {"getPolymorphicElement", "E", "Lga/strikepractice/kotlin/coroutines/CoroutineContext$Element;", "key", "Lga/strikepractice/kotlin/coroutines/CoroutineContext$Key;", "(Lkotlin/coroutines/CoroutineContext$Element;Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext$Element;", "minusPolymorphicKey", "Lga/strikepractice/kotlin/coroutines/CoroutineContext;", "ga.strikepractice.kotlin-stdlib"}
)
public final class CoroutineContextImplKt {
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalStdlibApi
   @Nullable
   public static final <E extends CoroutineContext.Element> E getPolymorphicElement(@NotNull CoroutineContext.Element var0, @NotNull CoroutineContext.Key<E> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "key");
      if (var1 instanceof AbstractCoroutineContextKey) {
         CoroutineContext.Element var10000;
         if (((AbstractCoroutineContextKey)var1).isSubKey$kotlin_stdlib(var0.getKey())) {
            CoroutineContext.Element var2 = ((AbstractCoroutineContextKey)var1).tryCast$kotlin_stdlib(var0);
            var10000 = var2 instanceof CoroutineContext.Element ? var2 : null;
         } else {
            var10000 = null;
         }

         return var10000;
      } else {
         return var0.getKey() == var1 ? var0 : null;
      }
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalStdlibApi
   @NotNull
   public static final CoroutineContext minusPolymorphicKey(@NotNull CoroutineContext.Element var0, @NotNull CoroutineContext.Key<?> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "key");
      if (!(var1 instanceof AbstractCoroutineContextKey)) {
         return var0.getKey() == var1 ? (CoroutineContext)EmptyCoroutineContext.INSTANCE : (CoroutineContext)var0;
      } else {
         return ((AbstractCoroutineContextKey)var1).isSubKey$kotlin_stdlib(var0.getKey()) && ((AbstractCoroutineContextKey)var1).tryCast$kotlin_stdlib(var0) != null ? (CoroutineContext)EmptyCoroutineContext.INSTANCE : (CoroutineContext)var0;
      }
   }
}
