package ga.strikepractice.kotlin.coroutines.intrinsics;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.ResultKt;
import ga.strikepractice.kotlin.coroutines.Continuation;
import ga.strikepractice.kotlin.coroutines.CoroutineContext;
import ga.strikepractice.kotlin.coroutines.jvm.internal.ContinuationImpl;
import ga.strikepractice.kotlin.jvm.functions.Function2;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.jvm.internal.TypeIntrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\"\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u000e\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0007H\u0014ø\u0001\u0000¢\u0006\u0002\u0010\bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\t¸\u0006\u0000"},
   d2 = {"ga/strikepractice/kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsJvmKt$createCoroutineFromSuspendFunction$2", "Lga/strikepractice/kotlin/coroutines/jvm/internal/ContinuationImpl;", "label", "", "invokeSuspend", "", "result", "Lga/strikepractice/kotlin/Result;", "(Ljava/lang/Object;)Ljava/lang/Object;", "ga.strikepractice.kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nIntrinsicsJvm.kt\nKotlin\n*S Kotlin\n*F\n+ 1 IntrinsicsJvm.kt\nkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsJvmKt$createCoroutineFromSuspendFunction$2\n+ 2 IntrinsicsJvm.kt\nkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsJvmKt\n*L\n1#1,204:1\n127#2:205\n*E\n"})
public final class IntrinsicsKt__IntrinsicsJvmKt$createCoroutineUnintercepted$$inlined$createCoroutineFromSuspendFunction$IntrinsicsKt__IntrinsicsJvmKt$4 extends ContinuationImpl {
   private int label;
   // $FF: synthetic field
   final Function2 $this_createCoroutineUnintercepted$inlined;
   // $FF: synthetic field
   final Object $receiver$inlined;

   public IntrinsicsKt__IntrinsicsJvmKt$createCoroutineUnintercepted$$inlined$createCoroutineFromSuspendFunction$IntrinsicsKt__IntrinsicsJvmKt$4(Continuation var1, CoroutineContext var2, Function2 var3, Object var4) {
      this.$this_createCoroutineUnintercepted$inlined = var3;
      this.$receiver$inlined = var4;
      Intrinsics.checkNotNull(var1, "null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
      super(var1, var2);
   }

   @Nullable
   protected Object invokeSuspend(@NotNull Object var1) {
      Object var10000;
      switch(this.label) {
      case 0:
         this.label = 1;
         ResultKt.throwOnFailure(var1);
         Continuation var2 = (Continuation)this;
         boolean var3 = false;
         Intrinsics.checkNotNull(this.$this_createCoroutineUnintercepted$inlined, "null cannot be cast to non-null type kotlin.Function2<R of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1, kotlin.coroutines.Continuation<T of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1>, kotlin.Any?>");
         var10000 = ((Function2)TypeIntrinsics.beforeCheckcastToFunctionOfArity(this.$this_createCoroutineUnintercepted$inlined, 2)).invoke(this.$receiver$inlined, var2);
         break;
      case 1:
         this.label = 2;
         ResultKt.throwOnFailure(var1);
         var10000 = var1;
         break;
      default:
         throw new IllegalStateException("This coroutine had already completed".toString());
      }

      return var10000;
   }
}
