package ga.strikepractice.kotlin.coroutines.intrinsics;

import ga.strikepractice.kotlin.Metadata;

@Metadata(
   mv = {1, 8, 0},
   k = 4,
   xi = 49,
   d1 = {"ga/strikepractice/kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsJvmKt", "ga/strikepractice/kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt"}
)
public final class IntrinsicsKt extends IntrinsicsKt__IntrinsicsKt {
   private IntrinsicsKt() {
   }
}
