package ga.strikepractice.kotlin.coroutines.jvm.internal;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Result;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.coroutines.Continuation;
import ga.strikepractice.kotlin.coroutines.CoroutineContext;
import ga.strikepractice.kotlin.coroutines.EmptyCoroutineContext;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0003J\u0006\u0010\u000e\u001a\u00020\u0002J\u001e\u0010\u000f\u001a\u00020\u00022\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00020\tH\u0016ø\u0001\u0000¢\u0006\u0002\u0010\u0010R\u0014\u0010\u0004\u001a\u00020\u00058VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007R(\u0010\b\u001a\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\tX\u0086\u000eø\u0001\u0000ø\u0001\u0001¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\r\u0082\u0002\b\n\u0002\b\u0019\n\u0002\b!¨\u0006\u0011"},
   d2 = {"Lga/strikepractice/kotlin/coroutines/jvm/internal/RunSuspend;", "Lga/strikepractice/kotlin/coroutines/Continuation;", "", "()V", "context", "Lga/strikepractice/kotlin/coroutines/CoroutineContext;", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "result", "Lga/strikepractice/kotlin/Result;", "getResult-xLWZpok", "()Lkotlin/Result;", "setResult", "(Lkotlin/Result;)V", "await", "resumeWith", "(Ljava/lang/Object;)V", "ga.strikepractice.kotlin-stdlib"}
)
final class RunSuspend implements Continuation<Unit> {
   @Nullable
   private Result<Unit> result;

   public RunSuspend() {
   }

   @NotNull
   public CoroutineContext getContext() {
      return (CoroutineContext)EmptyCoroutineContext.INSTANCE;
   }

   @Nullable
   public final Result<Unit> getResult_xLWZpok/* $FF was: getResult-xLWZpok*/() {
      return this.result;
   }

   public final void setResult(@Nullable Result<Unit> var1) {
      this.result = var1;
   }

   public void resumeWith(@NotNull Object var1) {
      synchronized(this) {
         boolean var3 = false;
         this.result = Result.box-impl(var1);
         Intrinsics.checkNotNull(this, "null cannot be cast to non-null type java.lang.Object");
         ((Object)this).notifyAll();
         Unit var5 = Unit.INSTANCE;
      }
   }

   public final void await() {
      // $FF: Couldn't be decompiled
   }
}
