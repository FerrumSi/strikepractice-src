package ga.strikepractice.kotlin.coroutines.jvm.internal;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.JvmField;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.lang.reflect.Method;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001:\u0001\u000bB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u0010\u0010\t\u001a\u0004\u0018\u00010\n2\u0006\u0010\u0007\u001a\u00020\bR\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"},
   d2 = {"Lga/strikepractice/kotlin/coroutines/jvm/internal/ModuleNameRetriever;", "", "()V", "cache", "Lga/strikepractice/kotlin/coroutines/jvm/internal/ModuleNameRetriever$Cache;", "notOnJava9", "buildCache", "continuation", "Lga/strikepractice/kotlin/coroutines/jvm/internal/BaseContinuationImpl;", "getModuleName", "", "Cache", "ga.strikepractice.kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nDebugMetadata.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DebugMetadata.kt\nkotlin/coroutines/jvm/internal/ModuleNameRetriever\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,134:1\n1#2:135\n*E\n"})
final class ModuleNameRetriever {
   @NotNull
   public static final ModuleNameRetriever INSTANCE = new ModuleNameRetriever();
   @NotNull
   private static final ModuleNameRetriever.Cache notOnJava9 = new ModuleNameRetriever.Cache((Method)null, (Method)null, (Method)null);
   @Nullable
   private static ModuleNameRetriever.Cache cache;

   private ModuleNameRetriever() {
   }

   @Nullable
   public final String getModuleName(@NotNull BaseContinuationImpl var1) {
      Intrinsics.checkNotNullParameter(var1, "continuation");
      ModuleNameRetriever.Cache var10000 = cache;
      if (var10000 == null) {
         var10000 = this.buildCache(var1);
      }

      ModuleNameRetriever.Cache var2 = var10000;
      if (var2 == notOnJava9) {
         return null;
      } else {
         Method var6 = var2.getModuleMethod;
         Object var7 = var6 != null ? var6.invoke(var1.getClass()) : null;
         if (var7 == null) {
            return null;
         } else {
            Object var3 = var7;
            var6 = var2.getDescriptorMethod;
            var7 = var6 != null ? var6.invoke(var3) : null;
            if (var7 == null) {
               return null;
            } else {
               Object var4 = var7;
               var6 = var2.nameMethod;
               Object var5 = var6 != null ? var6.invoke(var4) : null;
               return var5 instanceof String ? (String)var5 : null;
            }
         }
      }
   }

   private final ModuleNameRetriever.Cache buildCache(BaseContinuationImpl var1) {
      ModuleNameRetriever var10000;
      try {
         Method var2 = Class.class.getDeclaredMethod("getModule");
         Class var11 = var1.getClass().getClassLoader().loadClass("java.lang.Module");
         Method var4 = var11.getDeclaredMethod("getDescriptor");
         Class var12 = var1.getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor");
         Method var6 = var12.getDeclaredMethod("name");
         ModuleNameRetriever.Cache var7 = new ModuleNameRetriever.Cache(var2, var4, var6);
         boolean var9 = false;
         var10000 = INSTANCE;
         cache = var7;
         return var7;
      } catch (Exception var10) {
         ModuleNameRetriever.Cache var3 = notOnJava9;
         boolean var5 = false;
         var10000 = INSTANCE;
         cache = var3;
         return var3;
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0002\u0018\u00002\u00020\u0001B#\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0006R\u0012\u0010\u0004\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0002\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0005\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0007"},
      d2 = {"Lga/strikepractice/kotlin/coroutines/jvm/internal/ModuleNameRetriever$Cache;", "", "getModuleMethod", "Ljava/lang/reflect/Method;", "getDescriptorMethod", "nameMethod", "(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V", "ga.strikepractice.kotlin-stdlib"}
   )
   private static final class Cache {
      @JvmField
      @Nullable
      public final Method getModuleMethod;
      @JvmField
      @Nullable
      public final Method getDescriptorMethod;
      @JvmField
      @Nullable
      public final Method nameMethod;

      public Cache(@Nullable Method var1, @Nullable Method var2, @Nullable Method var3) {
         this.getModuleMethod = var1;
         this.getDescriptorMethod = var2;
         this.nameMethod = var3;
      }
   }
}
