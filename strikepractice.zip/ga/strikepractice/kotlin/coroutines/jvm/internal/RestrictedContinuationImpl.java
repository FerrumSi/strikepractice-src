package ga.strikepractice.kotlin.coroutines.jvm.internal;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.coroutines.Continuation;
import ga.strikepractice.kotlin.coroutines.CoroutineContext;
import ga.strikepractice.kotlin.coroutines.EmptyCoroutineContext;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b!\u0018\u00002\u00020\u0001B\u0017\u0012\u0010\u0010\u0002\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0005R\u0014\u0010\u0006\u001a\u00020\u00078VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\t¨\u0006\n"},
   d2 = {"Lga/strikepractice/kotlin/coroutines/jvm/internal/RestrictedContinuationImpl;", "Lga/strikepractice/kotlin/coroutines/jvm/internal/BaseContinuationImpl;", "completion", "Lga/strikepractice/kotlin/coroutines/Continuation;", "", "(Lkotlin/coroutines/Continuation;)V", "context", "Lga/strikepractice/kotlin/coroutines/CoroutineContext;", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "ga.strikepractice.kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.3"
)
public abstract class RestrictedContinuationImpl extends BaseContinuationImpl {
   public RestrictedContinuationImpl(@Nullable Continuation<Object> var1) {
      super(var1);
      if (var1 != null) {
         boolean var4 = false;
         boolean var5 = var1.getContext() == EmptyCoroutineContext.INSTANCE;
         if (!var5) {
            boolean var6 = false;
            String var7 = "Coroutines with restricted suspension must have EmptyCoroutineContext";
            throw new IllegalArgumentException(var7.toString());
         }
      }

   }

   @NotNull
   public CoroutineContext getContext() {
      return (CoroutineContext)EmptyCoroutineContext.INSTANCE;
   }
}
