package ga.strikepractice.kotlin.coroutines.jvm.internal;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.coroutines.Continuation;
import ga.strikepractice.kotlin.coroutines.ContinuationInterceptor;
import ga.strikepractice.kotlin.coroutines.CoroutineContext;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\b!\u0018\u00002\u00020\u0001B\u0019\b\u0016\u0012\u0010\u0010\u0002\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0005B!\u0012\u0010\u0010\u0002\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0018\u00010\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0002\u0010\bJ\u000e\u0010\f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0003J\b\u0010\r\u001a\u00020\u000eH\u0014R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u00020\u00078VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u0018\u0010\f\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000f"},
   d2 = {"Lga/strikepractice/kotlin/coroutines/jvm/internal/ContinuationImpl;", "Lga/strikepractice/kotlin/coroutines/jvm/internal/BaseContinuationImpl;", "completion", "Lga/strikepractice/kotlin/coroutines/Continuation;", "", "(Lkotlin/coroutines/Continuation;)V", "_context", "Lga/strikepractice/kotlin/coroutines/CoroutineContext;", "(Lkotlin/coroutines/Continuation;Lkotlin/coroutines/CoroutineContext;)V", "context", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "intercepted", "releaseIntercepted", "", "ga.strikepractice.kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.3"
)
@SourceDebugExtension({"SMAP\nContinuationImpl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ContinuationImpl.kt\nkotlin/coroutines/jvm/internal/ContinuationImpl\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,168:1\n1#2:169\n*E\n"})
public abstract class ContinuationImpl extends BaseContinuationImpl {
   @Nullable
   private final CoroutineContext _context;
   @Nullable
   private transient Continuation<Object> intercepted;

   public ContinuationImpl(@Nullable Continuation<Object> var1, @Nullable CoroutineContext var2) {
      super(var1);
      this._context = var2;
   }

   public ContinuationImpl(@Nullable Continuation<Object> var1) {
      this(var1, var1 != null ? var1.getContext() : null);
   }

   @NotNull
   public CoroutineContext getContext() {
      CoroutineContext var10000 = this._context;
      Intrinsics.checkNotNull(var10000);
      return var10000;
   }

   @NotNull
   public final Continuation<Object> intercepted() {
      Continuation var10000 = this.intercepted;
      if (var10000 == null) {
         label13: {
            ContinuationInterceptor var4 = (ContinuationInterceptor)this.getContext().get((CoroutineContext.Key)ContinuationInterceptor.Key);
            if (var4 != null) {
               var10000 = var4.interceptContinuation((Continuation)this);
               if (var10000 != null) {
                  break label13;
               }
            }

            var10000 = (Continuation)this;
         }

         Continuation var1 = var10000;
         boolean var3 = false;
         this.intercepted = var1;
         var10000 = var1;
      }

      return var10000;
   }

   protected void releaseIntercepted() {
      Continuation var1 = this.intercepted;
      if (var1 != null && var1 != this) {
         CoroutineContext.Element var10000 = this.getContext().get((CoroutineContext.Key)ContinuationInterceptor.Key);
         Intrinsics.checkNotNull(var10000);
         ((ContinuationInterceptor)var10000).releaseInterceptedContinuation(var1);
      }

      this.intercepted = (Continuation)CompletedContinuation.INSTANCE;
   }
}
