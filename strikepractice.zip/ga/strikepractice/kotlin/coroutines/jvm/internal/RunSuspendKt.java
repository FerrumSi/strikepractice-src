package ga.strikepractice.kotlin.coroutines.jvm.internal;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.coroutines.Continuation;
import ga.strikepractice.kotlin.coroutines.ContinuationKt;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\u001a.\u0010\u0000\u001a\u00020\u00012\u001c\u0010\u0002\u001a\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0003H\u0001ø\u0001\u0000¢\u0006\u0002\u0010\u0006\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007"},
   d2 = {"runSuspend", "", "block", "Lga/strikepractice/kotlin/Function1;", "Lga/strikepractice/kotlin/coroutines/Continuation;", "", "(Lkotlin/jvm/functions/Function1;)V", "ga.strikepractice.kotlin-stdlib"}
)
public final class RunSuspendKt {
   @SinceKotlin(
      version = "1.3"
   )
   public static final void runSuspend(@NotNull Function1<? super Continuation<? super Unit>, ? extends Object> var0) {
      Intrinsics.checkNotNullParameter(var0, "block");
      RunSuspend var1 = new RunSuspend();
      ContinuationKt.startCoroutine(var0, (Continuation)var1);
      var1.await();
   }
}
