package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.OverloadResolutionByLambdaReturnType;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.internal.HidesMembers;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.JvmName;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.functions.Function2;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.sequences.Sequence;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Map.Entry;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000\u0082\u0001\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010&\n\u0002\b\u0002\n\u0002\u0010\u001c\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0010\u001f\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0010\u000f\n\u0002\b\u0005\n\u0002\u0010\u0006\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\u001aJ\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010\u0005\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020\u00010\u0006H\u0086\bø\u0001\u0000\u001a$\u0010\b\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0004\u001aJ\u0010\b\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010\u0005\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020\u00010\u0006H\u0086\bø\u0001\u0000\u001a9\u0010\t\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00070\n\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0004H\u0087\b\u001a6\u0010\u000b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00070\f\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0004\u001a'\u0010\r\u001a\u00020\u000e\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0004H\u0087\b\u001aJ\u0010\r\u001a\u00020\u000e\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010\u0005\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020\u00010\u0006H\u0086\bø\u0001\u0000\u001a[\u0010\u000f\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\b\b\u0002\u0010\u0010*\u00020\u0011*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042 \u0010\u0012\u001a\u001c\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0006\u0012\u0004\u0018\u0001H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0013\u001a]\u0010\u0014\u001a\u0004\u0018\u0001H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\b\b\u0002\u0010\u0010*\u00020\u0011*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042 \u0010\u0012\u001a\u001c\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0006\u0012\u0004\u0018\u0001H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0013\u001a\\\u0010\u0015\u001a\b\u0012\u0004\u0012\u0002H\u00100\u0016\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042$\u0010\u0012\u001a \u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100\n0\u0006H\u0086\bø\u0001\u0000\u001aa\u0010\u0015\u001a\b\u0012\u0004\u0012\u0002H\u00100\u0016\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042$\u0010\u0012\u001a \u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100\f0\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\b\u0017\u001au\u0010\u0018\u001a\u0002H\u0019\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010\"\u0010\b\u0003\u0010\u0019*\n\u0012\u0006\b\u0000\u0012\u0002H\u00100\u001a*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u0006\u0010\u001b\u001a\u0002H\u00192$\u0010\u0012\u001a \u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100\n0\u0006H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001aw\u0010\u0018\u001a\u0002H\u0019\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010\"\u0010\b\u0003\u0010\u0019*\n\u0012\u0006\b\u0000\u0012\u0002H\u00100\u001a*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u0006\u0010\u001b\u001a\u0002H\u00192$\u0010\u0012\u001a \u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100\f0\u0006H\u0087\bø\u0001\u0000¢\u0006\u0004\b\u001d\u0010\u001c\u001aJ\u0010\u001e\u001a\u00020\u001f\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010 \u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020\u001f0\u0006H\u0087\bø\u0001\u0000\u001aV\u0010!\u001a\b\u0012\u0004\u0012\u0002H\u00100\u0016\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010\u0012\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0086\bø\u0001\u0000\u001a\\\u0010\"\u001a\b\u0012\u0004\u0012\u0002H\u00100\u0016\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\b\b\u0002\u0010\u0010*\u00020\u0011*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042 \u0010\u0012\u001a\u001c\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0006\u0012\u0004\u0018\u0001H\u00100\u0006H\u0086\bø\u0001\u0000\u001au\u0010#\u001a\u0002H\u0019\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\b\b\u0002\u0010\u0010*\u00020\u0011\"\u0010\b\u0003\u0010\u0019*\n\u0012\u0006\b\u0000\u0012\u0002H\u00100\u001a*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u0006\u0010\u001b\u001a\u0002H\u00192 \u0010\u0012\u001a\u001c\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0006\u0012\u0004\u0018\u0001H\u00100\u0006H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001ao\u0010$\u001a\u0002H\u0019\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010\"\u0010\b\u0003\u0010\u0019*\n\u0012\u0006\b\u0000\u0012\u0002H\u00100\u001a*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u0006\u0010\u001b\u001a\u0002H\u00192\u001e\u0010\u0012\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001ak\u0010%\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u000e\b\u0002\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100&*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\b(\u001ah\u0010)\u001a\u0010\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003\u0018\u00010\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u000e\b\u0002\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100&*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000\u001a_\u0010*\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u000e\b\u0002\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100&*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010+\u001aJ\u0010*\u001a\u00020,\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020,0\u0006H\u0087\bø\u0001\u0000\u001aJ\u0010*\u001a\u00020-\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020-0\u0006H\u0087\bø\u0001\u0000\u001aa\u0010.\u001a\u0004\u0018\u0001H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u000e\b\u0002\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100&*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010+\u001aQ\u0010.\u001a\u0004\u0018\u00010,\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020,0\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010/\u001aQ\u0010.\u001a\u0004\u0018\u00010-\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020-0\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u00100\u001aq\u00101\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001a\u00102\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u001003j\n\u0012\u0006\b\u0000\u0012\u0002H\u0010`42\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u00105\u001as\u00106\u001a\u0004\u0018\u0001H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001a\u00102\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u001003j\n\u0012\u0006\b\u0000\u0012\u0002H\u0010`42\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u00105\u001al\u00107\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u000422\u00102\u001a.\u0012\u0012\b\u0000\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u000703j\u0016\u0012\u0012\b\u0000\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007`4H\u0087\b¢\u0006\u0002\b8\u001ai\u00109\u001a\u0010\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003\u0018\u00010\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u000422\u00102\u001a.\u0012\u0012\b\u0000\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u000703j\u0016\u0012\u0012\b\u0000\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007`4H\u0087\b\u001ak\u0010:\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u000e\b\u0002\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100&*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\b;\u001ah\u0010<\u001a\u0010\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003\u0018\u00010\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u000e\b\u0002\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100&*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000\u001a_\u0010=\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u000e\b\u0002\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100&*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010+\u001aJ\u0010=\u001a\u00020,\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020,0\u0006H\u0087\bø\u0001\u0000\u001aJ\u0010=\u001a\u00020-\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020-0\u0006H\u0087\bø\u0001\u0000\u001aa\u0010>\u001a\u0004\u0018\u0001H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u000e\b\u0002\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100&*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010+\u001aQ\u0010>\u001a\u0004\u0018\u00010,\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020,0\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010/\u001aQ\u0010>\u001a\u0004\u0018\u00010-\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020-0\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u00100\u001aq\u0010?\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001a\u00102\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u001003j\n\u0012\u0006\b\u0000\u0012\u0002H\u0010`42\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u00105\u001as\u0010@\u001a\u0004\u0018\u0001H\u0010\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001a\u00102\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u001003j\n\u0012\u0006\b\u0000\u0012\u0002H\u0010`42\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u0002H\u00100\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u00105\u001al\u0010A\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u000422\u00102\u001a.\u0012\u0012\b\u0000\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u000703j\u0016\u0012\u0012\b\u0000\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007`4H\u0087\b¢\u0006\u0002\bB\u001ai\u0010C\u001a\u0010\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003\u0018\u00010\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u000422\u00102\u001a.\u0012\u0012\b\u0000\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u000703j\u0016\u0012\u0012\b\u0000\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007`4H\u0087\b\u001a$\u0010D\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0004\u001aJ\u0010D\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00042\u001e\u0010\u0005\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020\u00010\u0006H\u0086\bø\u0001\u0000\u001aY\u0010E\u001a\u0002HF\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0016\b\u0002\u0010F*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0004*\u0002HF2\u001e\u0010 \u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020\u001f0\u0006H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010G\u001an\u0010H\u001a\u0002HF\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0016\b\u0002\u0010F*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0004*\u0002HF23\u0010 \u001a/\u0012\u0013\u0012\u00110\u000e¢\u0006\f\bJ\u0012\b\bK\u0012\u0004\b\b(L\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0007\u0012\u0004\u0012\u00020\u001f0IH\u0087\bø\u0001\u0000¢\u0006\u0002\u0010M\u001a6\u0010N\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030O0\u0016\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0004\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006P"},
   d2 = {"all", "", "K", "V", "", "predicate", "Lga/strikepractice/kotlin/Function1;", "", "any", "asIterable", "", "asSequence", "Lga/strikepractice/kotlin/sequences/Sequence;", "count", "", "firstNotNullOf", "R", "", "transform", "(Ljava/util/Map;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "firstNotNullOfOrNull", "flatMap", "", "flatMapSequence", "flatMapTo", "C", "", "destination", "(Ljava/util/Map;Ljava/util/Collection;Lkotlin/jvm/functions/Function1;)Ljava/util/Collection;", "flatMapSequenceTo", "forEach", "", "action", "map", "mapNotNull", "mapNotNullTo", "mapTo", "maxBy", "", "selector", "maxByOrThrow", "maxByOrNull", "maxOf", "(Ljava/util/Map;Lkotlin/jvm/functions/Function1;)Ljava/lang/Comparable;", "", "", "maxOfOrNull", "(Ljava/util/Map;Lkotlin/jvm/functions/Function1;)Ljava/lang/Double;", "(Ljava/util/Map;Lkotlin/jvm/functions/Function1;)Ljava/lang/Float;", "maxOfWith", "comparator", "Ljava/util/Comparator;", "Lga/strikepractice/kotlin/Comparator;", "(Ljava/util/Map;Ljava/util/Comparator;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "maxOfWithOrNull", "maxWith", "maxWithOrThrow", "maxWithOrNull", "minBy", "minByOrThrow", "minByOrNull", "minOf", "minOfOrNull", "minOfWith", "minOfWithOrNull", "minWith", "minWithOrThrow", "minWithOrNull", "none", "onEach", "M", "(Ljava/util/Map;Lkotlin/jvm/functions/Function1;)Ljava/util/Map;", "onEachIndexed", "Lga/strikepractice/kotlin/Function2;", "Lga/strikepractice/kotlin/ParameterName;", "name", "index", "(Ljava/util/Map;Lkotlin/jvm/functions/Function2;)Ljava/util/Map;", "toList", "Lga/strikepractice/kotlin/Pair;", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/collections/MapsKt"
)
@SourceDebugExtension({"SMAP\n_Maps.kt\nKotlin\n*S Kotlin\n*F\n+ 1 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,594:1\n96#1,5:595\n111#1,5:600\n152#1,3:605\n143#1:608\n215#1:609\n216#1:611\n144#1:612\n215#1:613\n216#1:615\n1#2:610\n1#2:614\n1940#3,14:616\n1963#3,14:630\n2310#3,14:644\n2333#3,14:658\n1864#3,3:672\n*S KotlinDebug\n*F\n+ 1 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n76#1:595,5\n89#1:600,5\n125#1:605,3\n135#1:608\n135#1:609\n135#1:611\n135#1:612\n143#1:613\n143#1:615\n135#1:610\n230#1:616,14\n241#1:630,14\n390#1:644,14\n401#1:658,14\n574#1:672,3\n*E\n"})
class MapsKt___MapsKt extends MapsKt___MapsJvmKt {
   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final <K, V, R> R firstNotNullOf(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "transform");
      Iterator var2 = var0.entrySet().iterator();

      Object var10000;
      do {
         if (!var2.hasNext()) {
            var10000 = null;
            break;
         }

         var10000 = var1.invoke((Entry)var2.next());
      } while(var10000 == null);

      if (var10000 == null) {
         throw new NoSuchElementException("No element of the map was transformed to a non-null value.");
      } else {
         return var10000;
      }
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final <K, V, R> R firstNotNullOfOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "transform");
      Iterator var2 = var0.entrySet().iterator();

      Object var4;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         Entry var3 = (Entry)var2.next();
         var4 = var1.invoke(var3);
      } while(var4 == null);

      return var4;
   }

   @NotNull
   public static final <K, V> List<Pair<K, V>> toList(@NotNull Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      if (var0.size() == 0) {
         return CollectionsKt.emptyList();
      } else {
         Iterator var1 = var0.entrySet().iterator();
         if (!var1.hasNext()) {
            return CollectionsKt.emptyList();
         } else {
            Entry var2 = (Entry)var1.next();
            if (!var1.hasNext()) {
               return CollectionsKt.listOf(new Pair(var2.getKey(), var2.getValue()));
            } else {
               ArrayList var3 = new ArrayList(var0.size());
               var3.add(new Pair(var2.getKey(), var2.getValue()));

               do {
                  Entry var4 = (Entry)var1.next();
                  var3.add(new Pair(var4.getKey(), var4.getValue()));
               } while(var1.hasNext());

               return (List)var3;
            }
         }
      }
   }

   @NotNull
   public static final <K, V, R> List<R> flatMap(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends Iterable<? extends R>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "transform");
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList());
      boolean var5 = false;
      Iterator var6 = var0.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var7 = (Entry)var6.next();
         Iterable var8 = (Iterable)var1.invoke(var7);
         CollectionsKt.addAll(var4, var8);
      }

      return (List)var4;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "flatMapSequence"
   )
   @NotNull
   public static final <K, V, R> List<R> flatMapSequence(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends Sequence<? extends R>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "transform");
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList());
      boolean var5 = false;
      Iterator var6 = var0.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var7 = (Entry)var6.next();
         Sequence var8 = (Sequence)var1.invoke(var7);
         CollectionsKt.addAll(var4, var8);
      }

      return (List)var4;
   }

   @NotNull
   public static final <K, V, R, C extends Collection<? super R>> C flatMapTo(@NotNull Map<? extends K, ? extends V> var0, @NotNull C var1, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends Iterable<? extends R>> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "transform");
      boolean var3 = false;
      Iterator var4 = var0.entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         Iterable var6 = (Iterable)var2.invoke(var5);
         CollectionsKt.addAll(var1, var6);
      }

      return var1;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "flatMapSequenceTo"
   )
   @NotNull
   public static final <K, V, R, C extends Collection<? super R>> C flatMapSequenceTo(@NotNull Map<? extends K, ? extends V> var0, @NotNull C var1, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends Sequence<? extends R>> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "transform");
      boolean var3 = false;
      Iterator var4 = var0.entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         Sequence var6 = (Sequence)var2.invoke(var5);
         CollectionsKt.addAll(var1, var6);
      }

      return var1;
   }

   @NotNull
   public static final <K, V, R> List<R> map(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "transform");
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList(var0.size()));
      boolean var5 = false;
      Iterator var6 = var0.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var7 = (Entry)var6.next();
         var4.add(var1.invoke(var7));
      }

      return (List)var4;
   }

   @NotNull
   public static final <K, V, R> List<R> mapNotNull(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "transform");
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList());
      boolean var5 = false;
      boolean var7 = false;
      Iterator var8 = var0.entrySet().iterator();

      while(var8.hasNext()) {
         Entry var9 = (Entry)var8.next();
         boolean var11 = false;
         Object var10000 = var1.invoke(var9);
         if (var10000 != null) {
            Object var12 = var10000;
            boolean var14 = false;
            var4.add(var12);
         }
      }

      return (List)var4;
   }

   @NotNull
   public static final <K, V, R, C extends Collection<? super R>> C mapNotNullTo(@NotNull Map<? extends K, ? extends V> var0, @NotNull C var1, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "transform");
      boolean var3 = false;
      boolean var5 = false;
      Iterator var6 = var0.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var7 = (Entry)var6.next();
         boolean var9 = false;
         Object var10000 = var2.invoke(var7);
         if (var10000 != null) {
            Object var10 = var10000;
            boolean var12 = false;
            var1.add(var10);
         }
      }

      return var1;
   }

   @NotNull
   public static final <K, V, R, C extends Collection<? super R>> C mapTo(@NotNull Map<? extends K, ? extends V> var0, @NotNull C var1, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "transform");
      boolean var3 = false;
      Iterator var4 = var0.entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         var1.add(var2.invoke(var5));
      }

      return var1;
   }

   public static final <K, V> boolean all(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      boolean var2 = false;
      if (var0.isEmpty()) {
         return true;
      } else {
         Iterator var3 = var0.entrySet().iterator();

         Entry var4;
         do {
            if (!var3.hasNext()) {
               return true;
            }

            var4 = (Entry)var3.next();
         } while((Boolean)var1.invoke(var4));

         return false;
      }
   }

   public static final <K, V> boolean any(@NotNull Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return !var0.isEmpty();
   }

   public static final <K, V> boolean any(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      boolean var2 = false;
      if (var0.isEmpty()) {
         return false;
      } else {
         Iterator var3 = var0.entrySet().iterator();

         Entry var4;
         do {
            if (!var3.hasNext()) {
               return false;
            }

            var4 = (Entry)var3.next();
         } while(!(Boolean)var1.invoke(var4));

         return true;
      }
   }

   @InlineOnly
   private static final <K, V> int count(Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.size();
   }

   public static final <K, V> int count(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      boolean var2 = false;
      if (var0.isEmpty()) {
         return 0;
      } else {
         int var3 = 0;
         Iterator var4 = var0.entrySet().iterator();

         while(var4.hasNext()) {
            Entry var5 = (Entry)var4.next();
            if ((Boolean)var1.invoke(var5)) {
               ++var3;
            }
         }

         return var3;
      }
   }

   @HidesMembers
   public static final <K, V> void forEach(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, Unit> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "action");
      boolean var2 = false;
      Iterator var3 = var0.entrySet().iterator();

      while(var3.hasNext()) {
         Entry var4 = (Entry)var3.next();
         var1.invoke(var4);
      }

   }

   @SinceKotlin(
      version = "1.7"
   )
   @JvmName(
      name = "maxByOrThrow"
   )
   @InlineOnly
   private static final <K, V, R extends Comparable<? super R>> Entry<K, V> maxByOrThrow(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterable var2 = (Iterable)var0.entrySet();
      boolean var3 = false;
      Iterator var4 = var2.iterator();
      if (!var4.hasNext()) {
         throw new NoSuchElementException();
      } else {
         Object var5 = var4.next();
         Object var10000;
         if (!var4.hasNext()) {
            var10000 = var5;
         } else {
            Comparable var6 = (Comparable)var1.invoke(var5);

            do {
               Object var7 = var4.next();
               Comparable var8 = (Comparable)var1.invoke(var7);
               if (var6.compareTo(var8) < 0) {
                  var5 = var7;
                  var6 = var8;
               }
            } while(var4.hasNext());

            var10000 = var5;
         }

         return (Entry)var10000;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @InlineOnly
   private static final <K, V, R extends Comparable<? super R>> Entry<K, V> maxByOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterable var2 = (Iterable)var0.entrySet();
      boolean var3 = false;
      Iterator var4 = var2.iterator();
      Object var10000;
      if (!var4.hasNext()) {
         var10000 = null;
      } else {
         Object var5 = var4.next();
         if (!var4.hasNext()) {
            var10000 = var5;
         } else {
            Comparable var6 = (Comparable)var1.invoke(var5);

            do {
               Object var7 = var4.next();
               Comparable var8 = (Comparable)var1.invoke(var7);
               if (var6.compareTo(var8) < 0) {
                  var5 = var7;
                  var6 = var8;
               }
            } while(var4.hasNext());

            var10000 = var5;
         }
      }

      return (Entry)var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V> double maxOf(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, Double> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      if (!var2.hasNext()) {
         throw new NoSuchElementException();
      } else {
         double var3;
         double var5;
         for(var3 = ((Number)var1.invoke(var2.next())).doubleValue(); var2.hasNext(); var3 = Math.max(var3, var5)) {
            var5 = ((Number)var1.invoke(var2.next())).doubleValue();
         }

         return var3;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V> float maxOf(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, Float> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      if (!var2.hasNext()) {
         throw new NoSuchElementException();
      } else {
         float var3;
         float var4;
         for(var3 = ((Number)var1.invoke(var2.next())).floatValue(); var2.hasNext(); var3 = Math.max(var3, var4)) {
            var4 = ((Number)var1.invoke(var2.next())).floatValue();
         }

         return var3;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V, R extends Comparable<? super R>> R maxOf(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      if (!var2.hasNext()) {
         throw new NoSuchElementException();
      } else {
         Comparable var3 = (Comparable)var1.invoke(var2.next());

         while(var2.hasNext()) {
            Comparable var4 = (Comparable)var1.invoke(var2.next());
            if (var3.compareTo(var4) < 0) {
               var3 = var4;
            }
         }

         return var3;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V> Double maxOfOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, Double> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      Double var10000;
      if (!var2.hasNext()) {
         var10000 = null;
      } else {
         double var3;
         double var5;
         for(var3 = ((Number)var1.invoke(var2.next())).doubleValue(); var2.hasNext(); var3 = Math.max(var3, var5)) {
            var5 = ((Number)var1.invoke(var2.next())).doubleValue();
         }

         var10000 = var3;
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V> Float maxOfOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, Float> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      Float var10000;
      if (!var2.hasNext()) {
         var10000 = null;
      } else {
         float var3;
         float var4;
         for(var3 = ((Number)var1.invoke(var2.next())).floatValue(); var2.hasNext(); var3 = Math.max(var3, var4)) {
            var4 = ((Number)var1.invoke(var2.next())).floatValue();
         }

         var10000 = var3;
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V, R extends Comparable<? super R>> R maxOfOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      Comparable var10000;
      if (!var2.hasNext()) {
         var10000 = null;
      } else {
         Comparable var3 = (Comparable)var1.invoke(var2.next());

         while(var2.hasNext()) {
            Comparable var4 = (Comparable)var1.invoke(var2.next());
            if (var3.compareTo(var4) < 0) {
               var3 = var4;
            }
         }

         var10000 = var3;
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V, R> R maxOfWith(Map<? extends K, ? extends V> var0, Comparator<? super R> var1, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      Intrinsics.checkNotNullParameter(var2, "selector");
      Iterator var3 = ((Iterable)var0.entrySet()).iterator();
      if (!var3.hasNext()) {
         throw new NoSuchElementException();
      } else {
         Object var4 = var2.invoke(var3.next());

         while(var3.hasNext()) {
            Object var5 = var2.invoke(var3.next());
            if (var1.compare(var4, var5) < 0) {
               var4 = var5;
            }
         }

         return var4;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V, R> R maxOfWithOrNull(Map<? extends K, ? extends V> var0, Comparator<? super R> var1, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      Intrinsics.checkNotNullParameter(var2, "selector");
      Iterator var3 = ((Iterable)var0.entrySet()).iterator();
      Object var10000;
      if (!var3.hasNext()) {
         var10000 = null;
      } else {
         Object var4 = var2.invoke(var3.next());

         while(var3.hasNext()) {
            Object var5 = var2.invoke(var3.next());
            if (var1.compare(var4, var5) < 0) {
               var4 = var5;
            }
         }

         var10000 = var4;
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.7"
   )
   @JvmName(
      name = "maxWithOrThrow"
   )
   @InlineOnly
   private static final <K, V> Entry<K, V> maxWithOrThrow(Map<? extends K, ? extends V> var0, Comparator<? super Entry<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return (Entry)CollectionsKt.maxWithOrThrow((Iterable)var0.entrySet(), var1);
   }

   @SinceKotlin(
      version = "1.4"
   )
   @InlineOnly
   private static final <K, V> Entry<K, V> maxWithOrNull(Map<? extends K, ? extends V> var0, Comparator<? super Entry<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return (Entry)CollectionsKt.maxWithOrNull((Iterable)var0.entrySet(), var1);
   }

   @SinceKotlin(
      version = "1.7"
   )
   @JvmName(
      name = "minByOrThrow"
   )
   @InlineOnly
   private static final <K, V, R extends Comparable<? super R>> Entry<K, V> minByOrThrow(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterable var2 = (Iterable)var0.entrySet();
      boolean var3 = false;
      Iterator var4 = var2.iterator();
      if (!var4.hasNext()) {
         throw new NoSuchElementException();
      } else {
         Object var5 = var4.next();
         Object var10000;
         if (!var4.hasNext()) {
            var10000 = var5;
         } else {
            Comparable var6 = (Comparable)var1.invoke(var5);

            do {
               Object var7 = var4.next();
               Comparable var8 = (Comparable)var1.invoke(var7);
               if (var6.compareTo(var8) > 0) {
                  var5 = var7;
                  var6 = var8;
               }
            } while(var4.hasNext());

            var10000 = var5;
         }

         return (Entry)var10000;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @InlineOnly
   private static final <K, V, R extends Comparable<? super R>> Entry<K, V> minByOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterable var2 = (Iterable)var0.entrySet();
      boolean var3 = false;
      Iterator var4 = var2.iterator();
      Object var10000;
      if (!var4.hasNext()) {
         var10000 = null;
      } else {
         Object var5 = var4.next();
         if (!var4.hasNext()) {
            var10000 = var5;
         } else {
            Comparable var6 = (Comparable)var1.invoke(var5);

            do {
               Object var7 = var4.next();
               Comparable var8 = (Comparable)var1.invoke(var7);
               if (var6.compareTo(var8) > 0) {
                  var5 = var7;
                  var6 = var8;
               }
            } while(var4.hasNext());

            var10000 = var5;
         }
      }

      return (Entry)var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V> double minOf(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, Double> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      if (!var2.hasNext()) {
         throw new NoSuchElementException();
      } else {
         double var3;
         double var5;
         for(var3 = ((Number)var1.invoke(var2.next())).doubleValue(); var2.hasNext(); var3 = Math.min(var3, var5)) {
            var5 = ((Number)var1.invoke(var2.next())).doubleValue();
         }

         return var3;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V> float minOf(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, Float> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      if (!var2.hasNext()) {
         throw new NoSuchElementException();
      } else {
         float var3;
         float var4;
         for(var3 = ((Number)var1.invoke(var2.next())).floatValue(); var2.hasNext(); var3 = Math.min(var3, var4)) {
            var4 = ((Number)var1.invoke(var2.next())).floatValue();
         }

         return var3;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V, R extends Comparable<? super R>> R minOf(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      if (!var2.hasNext()) {
         throw new NoSuchElementException();
      } else {
         Comparable var3 = (Comparable)var1.invoke(var2.next());

         while(var2.hasNext()) {
            Comparable var4 = (Comparable)var1.invoke(var2.next());
            if (var3.compareTo(var4) > 0) {
               var3 = var4;
            }
         }

         return var3;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V> Double minOfOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, Double> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      Double var10000;
      if (!var2.hasNext()) {
         var10000 = null;
      } else {
         double var3;
         double var5;
         for(var3 = ((Number)var1.invoke(var2.next())).doubleValue(); var2.hasNext(); var3 = Math.min(var3, var5)) {
            var5 = ((Number)var1.invoke(var2.next())).doubleValue();
         }

         var10000 = var3;
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V> Float minOfOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, Float> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      Float var10000;
      if (!var2.hasNext()) {
         var10000 = null;
      } else {
         float var3;
         float var4;
         for(var3 = ((Number)var1.invoke(var2.next())).floatValue(); var2.hasNext(); var3 = Math.min(var3, var4)) {
            var4 = ((Number)var1.invoke(var2.next())).floatValue();
         }

         var10000 = var3;
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V, R extends Comparable<? super R>> R minOfOrNull(Map<? extends K, ? extends V> var0, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "selector");
      Iterator var2 = ((Iterable)var0.entrySet()).iterator();
      Comparable var10000;
      if (!var2.hasNext()) {
         var10000 = null;
      } else {
         Comparable var3 = (Comparable)var1.invoke(var2.next());

         while(var2.hasNext()) {
            Comparable var4 = (Comparable)var1.invoke(var2.next());
            if (var3.compareTo(var4) > 0) {
               var3 = var4;
            }
         }

         var10000 = var3;
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V, R> R minOfWith(Map<? extends K, ? extends V> var0, Comparator<? super R> var1, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      Intrinsics.checkNotNullParameter(var2, "selector");
      Iterator var3 = ((Iterable)var0.entrySet()).iterator();
      if (!var3.hasNext()) {
         throw new NoSuchElementException();
      } else {
         Object var4 = var2.invoke(var3.next());

         while(var3.hasNext()) {
            Object var5 = var2.invoke(var3.next());
            if (var1.compare(var4, var5) > 0) {
               var4 = var5;
            }
         }

         return var4;
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @InlineOnly
   private static final <K, V, R> R minOfWithOrNull(Map<? extends K, ? extends V> var0, Comparator<? super R> var1, Function1<? super Entry<? extends K, ? extends V>, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      Intrinsics.checkNotNullParameter(var2, "selector");
      Iterator var3 = ((Iterable)var0.entrySet()).iterator();
      Object var10000;
      if (!var3.hasNext()) {
         var10000 = null;
      } else {
         Object var4 = var2.invoke(var3.next());

         while(var3.hasNext()) {
            Object var5 = var2.invoke(var3.next());
            if (var1.compare(var4, var5) > 0) {
               var4 = var5;
            }
         }

         var10000 = var4;
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.7"
   )
   @JvmName(
      name = "minWithOrThrow"
   )
   @InlineOnly
   private static final <K, V> Entry<K, V> minWithOrThrow(Map<? extends K, ? extends V> var0, Comparator<? super Entry<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return (Entry)CollectionsKt.minWithOrThrow((Iterable)var0.entrySet(), var1);
   }

   @SinceKotlin(
      version = "1.4"
   )
   @InlineOnly
   private static final <K, V> Entry<K, V> minWithOrNull(Map<? extends K, ? extends V> var0, Comparator<? super Entry<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return (Entry)CollectionsKt.minWithOrNull((Iterable)var0.entrySet(), var1);
   }

   public static final <K, V> boolean none(@NotNull Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.isEmpty();
   }

   public static final <K, V> boolean none(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      boolean var2 = false;
      if (var0.isEmpty()) {
         return true;
      } else {
         Iterator var3 = var0.entrySet().iterator();

         Entry var4;
         do {
            if (!var3.hasNext()) {
               return true;
            }

            var4 = (Entry)var3.next();
         } while(!(Boolean)var1.invoke(var4));

         return false;
      }
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <K, V, M extends Map<? extends K, ? extends V>> M onEach(@NotNull M var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, Unit> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "action");
      boolean var2 = false;
      boolean var5 = false;
      Iterator var6 = var0.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var7 = (Entry)var6.next();
         var1.invoke(var7);
      }

      return var0;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @NotNull
   public static final <K, V, M extends Map<? extends K, ? extends V>> M onEachIndexed(@NotNull M var0, @NotNull Function2<? super Integer, ? super Entry<? extends K, ? extends V>, Unit> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "action");
      boolean var2 = false;
      boolean var5 = false;
      Iterable var6 = (Iterable)var0.entrySet();
      boolean var7 = false;
      int var8 = 0;

      Object var10;
      int var11;
      for(Iterator var9 = var6.iterator(); var9.hasNext(); var1.invoke(var11, var10)) {
         var10 = var9.next();
         var11 = var8++;
         if (var11 < 0) {
            CollectionsKt.throwIndexOverflow();
         }
      }

      return var0;
   }

   @InlineOnly
   private static final <K, V> Iterable<Entry<K, V>> asIterable(Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return (Iterable)var0.entrySet();
   }

   @NotNull
   public static final <K, V> Sequence<Entry<K, V>> asSequence(@NotNull Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return CollectionsKt.asSequence((Iterable)var0.entrySet());
   }

   public MapsKt___MapsKt() {
   }
}
