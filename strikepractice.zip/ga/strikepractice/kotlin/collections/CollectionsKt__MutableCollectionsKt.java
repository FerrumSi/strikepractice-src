package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Deprecated;
import ga.strikepractice.kotlin.DeprecationLevel;
import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.ReplaceWith;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.WasExperimental;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.TypeIntrinsics;
import ga.strikepractice.kotlin.ranges.IntRange;
import ga.strikepractice.kotlin.sequences.Sequence;
import ga.strikepractice.kotlin.sequences.SequencesKt;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.RandomAccess;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000P\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u001f\n\u0000\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u001e\n\u0000\n\u0002\u0010\u001d\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000b\u001a-\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\u000e\u0010\u0004\u001a\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u0005¢\u0006\u0002\u0010\u0006\u001a&\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0007\u001a&\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\b\u001a\u001e\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\u00020\n\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0007H\u0000\u001a9\u0010\u000b\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\f2\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00010\u000e2\u0006\u0010\u000f\u001a\u00020\u0001H\u0002¢\u0006\u0002\b\u0010\u001a9\u0010\u000b\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00112\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00010\u000e2\u0006\u0010\u000f\u001a\u00020\u0001H\u0002¢\u0006\u0002\b\u0010\u001a(\u0010\u0012\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\u0006\u0010\u0014\u001a\u0002H\u0002H\u0087\n¢\u0006\u0002\u0010\u0015\u001a.\u0010\u0012\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0005H\u0087\n¢\u0006\u0002\u0010\u0016\u001a)\u0010\u0012\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0007H\u0087\n\u001a)\u0010\u0012\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\bH\u0087\n\u001a(\u0010\u0017\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\u0006\u0010\u0014\u001a\u0002H\u0002H\u0087\n¢\u0006\u0002\u0010\u0015\u001a.\u0010\u0017\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0005H\u0087\n¢\u0006\u0002\u0010\u0016\u001a)\u0010\u0017\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0007H\u0087\n\u001a)\u0010\u0017\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\bH\u0087\n\u001a-\u0010\u0018\u001a\u00020\u0001\"\t\b\u0000\u0010\u0002¢\u0006\u0002\b\u0019*\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u00032\u0006\u0010\u0014\u001a\u0002H\u0002H\u0087\b¢\u0006\u0002\u0010\u001a\u001a&\u0010\u0018\u001a\u0002H\u0002\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00112\u0006\u0010\u001b\u001a\u00020\u001cH\u0087\b¢\u0006\u0002\u0010\u001d\u001a-\u0010\u001e\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\u000e\u0010\u0004\u001a\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u0005¢\u0006\u0002\u0010\u0006\u001a&\u0010\u001e\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0007\u001a&\u0010\u001e\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\b\u001a.\u0010\u001e\u001a\u00020\u0001\"\t\b\u0000\u0010\u0002¢\u0006\u0002\b\u0019*\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\nH\u0087\b\u001a*\u0010\u001e\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\f2\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00010\u000e\u001a*\u0010\u001e\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00112\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00010\u000e\u001a\u001d\u0010\u001f\u001a\u0002H\u0002\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0011H\u0007¢\u0006\u0002\u0010 \u001a\u001f\u0010!\u001a\u0004\u0018\u0001H\u0002\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0011H\u0007¢\u0006\u0002\u0010 \u001a\u001d\u0010\"\u001a\u0002H\u0002\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0011H\u0007¢\u0006\u0002\u0010 \u001a\u001f\u0010#\u001a\u0004\u0018\u0001H\u0002\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0011H\u0007¢\u0006\u0002\u0010 \u001a-\u0010$\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\u000e\u0010\u0004\u001a\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u0005¢\u0006\u0002\u0010\u0006\u001a&\u0010$\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0007\u001a&\u0010$\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\b\u001a.\u0010$\u001a\u00020\u0001\"\t\b\u0000\u0010\u0002¢\u0006\u0002\b\u0019*\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00020\nH\u0087\b\u001a*\u0010$\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\f2\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00010\u000e\u001a*\u0010$\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00112\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00010\u000e\u001a\u0015\u0010%\u001a\u00020\u0001*\u0006\u0012\u0002\b\u00030\u0003H\u0002¢\u0006\u0002\b&¨\u0006'"},
   d2 = {"addAll", "", "T", "", "elements", "", "(Ljava/util/Collection;[Ljava/lang/Object;)Z", "", "Lga/strikepractice/kotlin/sequences/Sequence;", "convertToListIfNotCollection", "", "filterInPlace", "", "predicate", "Lga/strikepractice/kotlin/Function1;", "predicateResultToRemove", "filterInPlace$CollectionsKt__MutableCollectionsKt", "", "minusAssign", "", "element", "(Ljava/util/Collection;Ljava/lang/Object;)V", "(Ljava/util/Collection;[Ljava/lang/Object;)V", "plusAssign", "remove", "Lga/strikepractice/kotlin/internal/OnlyInputTypes;", "(Ljava/util/Collection;Ljava/lang/Object;)Z", "index", "", "(Ljava/util/List;I)Ljava/lang/Object;", "removeAll", "removeFirst", "(Ljava/util/List;)Ljava/lang/Object;", "removeFirstOrNull", "removeLast", "removeLastOrNull", "retainAll", "retainNothing", "retainNothing$CollectionsKt__MutableCollectionsKt", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/collections/CollectionsKt"
)
class CollectionsKt__MutableCollectionsKt extends CollectionsKt__MutableCollectionsJVMKt {
   @InlineOnly
   private static final <T> boolean remove(Collection<? extends T> var0, T var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return TypeIntrinsics.asMutableCollection(var0).remove(var1);
   }

   @InlineOnly
   private static final <T> boolean removeAll(Collection<? extends T> var0, Collection<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      return TypeIntrinsics.asMutableCollection(var0).removeAll(var1);
   }

   @InlineOnly
   private static final <T> boolean retainAll(Collection<? extends T> var0, Collection<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      return TypeIntrinsics.asMutableCollection(var0).retainAll(var1);
   }

   @InlineOnly
   private static final <T> void plusAssign(Collection<? super T> var0, T var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      var0.add(var1);
   }

   @InlineOnly
   private static final <T> void plusAssign(Collection<? super T> var0, Iterable<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      CollectionsKt.addAll(var0, var1);
   }

   @InlineOnly
   private static final <T> void plusAssign(Collection<? super T> var0, T[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      CollectionsKt.addAll(var0, var1);
   }

   @InlineOnly
   private static final <T> void plusAssign(Collection<? super T> var0, Sequence<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      CollectionsKt.addAll(var0, var1);
   }

   @InlineOnly
   private static final <T> void minusAssign(Collection<? super T> var0, T var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      var0.remove(var1);
   }

   @InlineOnly
   private static final <T> void minusAssign(Collection<? super T> var0, Iterable<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      CollectionsKt.removeAll(var0, var1);
   }

   @InlineOnly
   private static final <T> void minusAssign(Collection<? super T> var0, T[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      CollectionsKt.removeAll(var0, var1);
   }

   @InlineOnly
   private static final <T> void minusAssign(Collection<? super T> var0, Sequence<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      CollectionsKt.removeAll(var0, var1);
   }

   public static final <T> boolean addAll(@NotNull Collection<? super T> var0, @NotNull Iterable<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      if (var1 instanceof Collection) {
         return var0.addAll((Collection)var1);
      } else {
         boolean var2 = false;
         Iterator var3 = var1.iterator();

         while(var3.hasNext()) {
            Object var4 = var3.next();
            if (var0.add(var4)) {
               var2 = true;
            }
         }

         return var2;
      }
   }

   public static final <T> boolean addAll(@NotNull Collection<? super T> var0, @NotNull Sequence<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      boolean var2 = false;
      Iterator var3 = var1.iterator();

      while(var3.hasNext()) {
         Object var4 = var3.next();
         if (var0.add(var4)) {
            var2 = true;
         }
      }

      return var2;
   }

   public static final <T> boolean addAll(@NotNull Collection<? super T> var0, @NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      return var0.addAll((Collection)ArraysKt.asList(var1));
   }

   @NotNull
   public static final <T> Collection<T> convertToListIfNotCollection(@NotNull Iterable<? extends T> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0 instanceof Collection ? (Collection)var0 : (Collection)CollectionsKt.toList(var0);
   }

   public static final <T> boolean removeAll(@NotNull Collection<? super T> var0, @NotNull Iterable<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      return var0.removeAll(CollectionsKt.convertToListIfNotCollection(var1));
   }

   public static final <T> boolean removeAll(@NotNull Collection<? super T> var0, @NotNull Sequence<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      List var2 = SequencesKt.toList(var1);
      return !((Collection)var2).isEmpty() && var0.removeAll((Collection)var2);
   }

   public static final <T> boolean removeAll(@NotNull Collection<? super T> var0, @NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      return var1.length != 0 && var0.removeAll((Collection)ArraysKt.asList(var1));
   }

   public static final <T> boolean retainAll(@NotNull Collection<? super T> var0, @NotNull Iterable<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      return var0.retainAll(CollectionsKt.convertToListIfNotCollection(var1));
   }

   public static final <T> boolean retainAll(@NotNull Collection<? super T> var0, @NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      return var1.length != 0 ? var0.retainAll((Collection)ArraysKt.asList(var1)) : retainNothing$CollectionsKt__MutableCollectionsKt(var0);
   }

   public static final <T> boolean retainAll(@NotNull Collection<? super T> var0, @NotNull Sequence<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      List var2 = SequencesKt.toList(var1);
      return !((Collection)var2).isEmpty() ? var0.retainAll((Collection)var2) : retainNothing$CollectionsKt__MutableCollectionsKt(var0);
   }

   private static final boolean retainNothing$CollectionsKt__MutableCollectionsKt(Collection<?> var0) {
      boolean var1 = !var0.isEmpty();
      var0.clear();
      return var1;
   }

   public static final <T> boolean removeAll(@NotNull Iterable<? extends T> var0, @NotNull Function1<? super T, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      return filterInPlace$CollectionsKt__MutableCollectionsKt(var0, var1, true);
   }

   public static final <T> boolean retainAll(@NotNull Iterable<? extends T> var0, @NotNull Function1<? super T, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      return filterInPlace$CollectionsKt__MutableCollectionsKt(var0, var1, false);
   }

   private static final <T> boolean filterInPlace$CollectionsKt__MutableCollectionsKt(Iterable<? extends T> var0, Function1<? super T, Boolean> var1, boolean var2) {
      boolean var3 = false;
      Iterator var4 = var0.iterator();
      Iterator var5 = var4;
      boolean var6 = false;

      while(var5.hasNext()) {
         if ((Boolean)var1.invoke(var5.next()) == var2) {
            var5.remove();
            var3 = true;
         }
      }

      return var3;
   }

   /** @deprecated */
   @Deprecated(
      message = "Use removeAt(index) instead.",
      replaceWith = @ReplaceWith(
   expression = "removeAt(index)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @InlineOnly
   private static final <T> T remove(List<T> var0, int var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.remove(var1);
   }

   @SinceKotlin(
      version = "1.4"
   )
   @WasExperimental(
      markerClass = {ExperimentalStdlibApi.class}
   )
   public static final <T> T removeFirst(@NotNull List<T> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      if (var0.isEmpty()) {
         throw new NoSuchElementException("List is empty.");
      } else {
         return var0.remove(0);
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @WasExperimental(
      markerClass = {ExperimentalStdlibApi.class}
   )
   @Nullable
   public static final <T> T removeFirstOrNull(@NotNull List<T> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.isEmpty() ? null : var0.remove(0);
   }

   @SinceKotlin(
      version = "1.4"
   )
   @WasExperimental(
      markerClass = {ExperimentalStdlibApi.class}
   )
   public static final <T> T removeLast(@NotNull List<T> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      if (var0.isEmpty()) {
         throw new NoSuchElementException("List is empty.");
      } else {
         return var0.remove(CollectionsKt.getLastIndex(var0));
      }
   }

   @SinceKotlin(
      version = "1.4"
   )
   @WasExperimental(
      markerClass = {ExperimentalStdlibApi.class}
   )
   @Nullable
   public static final <T> T removeLastOrNull(@NotNull List<T> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.isEmpty() ? null : var0.remove(CollectionsKt.getLastIndex(var0));
   }

   public static final <T> boolean removeAll(@NotNull List<T> var0, @NotNull Function1<? super T, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      return filterInPlace$CollectionsKt__MutableCollectionsKt(var0, var1, true);
   }

   public static final <T> boolean retainAll(@NotNull List<T> var0, @NotNull Function1<? super T, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      return filterInPlace$CollectionsKt__MutableCollectionsKt(var0, var1, false);
   }

   private static final <T> boolean filterInPlace$CollectionsKt__MutableCollectionsKt(List<T> var0, Function1<? super T, Boolean> var1, boolean var2) {
      if (!(var0 instanceof RandomAccess)) {
         Intrinsics.checkNotNull(var0, "null cannot be cast to non-null type kotlin.collections.MutableIterable<T of kotlin.collections.CollectionsKt__MutableCollectionsKt.filterInPlace>");
         return filterInPlace$CollectionsKt__MutableCollectionsKt(TypeIntrinsics.asMutableIterable(var0), var1, var2);
      } else {
         int var3 = 0;
         IntIterator var4 = (new IntRange(0, CollectionsKt.getLastIndex(var0))).iterator();

         int var5;
         while(var4.hasNext()) {
            var5 = var4.nextInt();
            Object var6 = var0.get(var5);
            if ((Boolean)var1.invoke(var6) != var2) {
               if (var3 != var5) {
                  var0.set(var3, var6);
               }

               ++var3;
            }
         }

         if (var3 >= var0.size()) {
            return false;
         } else {
            int var7 = CollectionsKt.getLastIndex(var0);
            var5 = var3;
            if (var3 <= var7) {
               while(true) {
                  var0.remove(var7);
                  if (var7 == var5) {
                     break;
                  }

                  --var7;
               }
            }

            return true;
         }
      }
   }

   public CollectionsKt__MutableCollectionsKt() {
   }
}
