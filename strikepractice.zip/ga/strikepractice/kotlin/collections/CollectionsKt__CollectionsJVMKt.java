package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.PublishedApi;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.collections.builders.ListBuilder;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.internal.PlatformImplementationsKt;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.CollectionToArray;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000T\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u001e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u001c\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\"\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u00022\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0004H\u0001\u001a?\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u00022\u0006\u0010\u0006\u001a\u00020\u00072\u001d\u0010\b\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0002\b\u000bH\u0081\bø\u0001\u0000\u001a7\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u00022\u001d\u0010\b\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0002\b\u000bH\u0081\bø\u0001\u0000\u001a\u0011\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u0007H\u0081\b\u001a\u0011\u0010\u000e\u001a\u00020\u00072\u0006\u0010\u000f\u001a\u00020\u0007H\u0081\b\u001a\"\u0010\u0010\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u00112\n\u0010\u0013\u001a\u0006\u0012\u0002\b\u00030\u0014H\u0081\b¢\u0006\u0002\u0010\u0015\u001a4\u0010\u0010\u001a\b\u0012\u0004\u0012\u0002H\u00160\u0011\"\u0004\b\u0000\u0010\u00162\n\u0010\u0013\u001a\u0006\u0012\u0002\b\u00030\u00142\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u0002H\u00160\u0011H\u0081\b¢\u0006\u0002\u0010\u0018\u001a\u0014\u0010\u0019\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0004\"\u0004\b\u0000\u0010\u0002H\u0001\u001a\u001c\u0010\u0019\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0004\"\u0004\b\u0000\u0010\u00022\u0006\u0010\u0006\u001a\u00020\u0007H\u0001\u001a\u001f\u0010\u001a\u001a\b\u0012\u0004\u0012\u0002H\u00160\u0001\"\u0004\b\u0000\u0010\u00162\u0006\u0010\u001b\u001a\u0002H\u0016¢\u0006\u0002\u0010\u001c\u001a1\u0010\u001d\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00120\u0011\"\u0004\b\u0000\u0010\u0016*\n\u0012\u0006\b\u0001\u0012\u0002H\u00160\u00112\u0006\u0010\u001e\u001a\u00020\u001fH\u0000¢\u0006\u0002\u0010 \u001a\u001e\u0010!\u001a\b\u0012\u0004\u0012\u0002H\u00160\u0001\"\u0004\b\u0000\u0010\u0016*\b\u0012\u0004\u0012\u0002H\u00160\"H\u0007\u001a&\u0010!\u001a\b\u0012\u0004\u0012\u0002H\u00160\u0001\"\u0004\b\u0000\u0010\u0016*\b\u0012\u0004\u0012\u0002H\u00160\"2\u0006\u0010#\u001a\u00020$H\u0007\u001a\u001f\u0010%\u001a\b\u0012\u0004\u0012\u0002H\u00160\u0001\"\u0004\b\u0000\u0010\u0016*\b\u0012\u0004\u0012\u0002H\u00160&H\u0087\b\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006'"},
   d2 = {"build", "", "E", "builder", "", "buildListInternal", "capacity", "", "builderAction", "Lga/strikepractice/kotlin/Function1;", "", "Lga/strikepractice/kotlin/ExtensionFunctionType;", "checkCountOverflow", "count", "checkIndexOverflow", "index", "copyToArrayImpl", "", "", "collection", "", "(Ljava/util/Collection;)[Ljava/lang/Object;", "T", "array", "(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;", "createListBuilder", "listOf", "element", "(Ljava/lang/Object;)Ljava/util/List;", "copyToArrayOfAny", "isVarargs", "", "([Ljava/lang/Object;Z)[Ljava/lang/Object;", "shuffled", "", "random", "Ljava/util/Random;", "toList", "Ljava/util/Enumeration;", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/collections/CollectionsKt"
)
@SourceDebugExtension({"SMAP\nCollectionsJVM.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CollectionsJVM.kt\nkotlin/collections/CollectionsKt__CollectionsJVMKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,120:1\n1#2:121\n*E\n"})
class CollectionsKt__CollectionsJVMKt {
   @NotNull
   public static final <T> List<T> listOf(T var0) {
      List var10000 = Collections.singletonList(var0);
      Intrinsics.checkNotNullExpressionValue(var10000, "singletonList(element)");
      return var10000;
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   @InlineOnly
   private static final <E> List<E> buildListInternal(Function1<? super List<E>, Unit> var0) {
      Intrinsics.checkNotNullParameter(var0, "builderAction");
      List var1 = CollectionsKt.createListBuilder();
      var0.invoke(var1);
      return CollectionsKt.build(var1);
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   @InlineOnly
   private static final <E> List<E> buildListInternal(int var0, Function1<? super List<E>, Unit> var1) {
      Intrinsics.checkNotNullParameter(var1, "builderAction");
      List var2 = CollectionsKt.createListBuilder(var0);
      var1.invoke(var2);
      return CollectionsKt.build(var2);
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   @NotNull
   public static final <E> List<E> createListBuilder() {
      return (List)(new ListBuilder());
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   @NotNull
   public static final <E> List<E> createListBuilder(int var0) {
      return (List)(new ListBuilder(var0));
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   @NotNull
   public static final <E> List<E> build(@NotNull List<E> var0) {
      Intrinsics.checkNotNullParameter(var0, "builder");
      return ((ListBuilder)var0).build();
   }

   @InlineOnly
   private static final <T> List<T> toList(Enumeration<T> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      ArrayList var10000 = Collections.list(var0);
      Intrinsics.checkNotNullExpressionValue(var10000, "list(this)");
      return (List)var10000;
   }

   @SinceKotlin(
      version = "1.2"
   )
   @NotNull
   public static final <T> List<T> shuffled(@NotNull Iterable<? extends T> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      List var1 = CollectionsKt.toMutableList(var0);
      boolean var3 = false;
      Collections.shuffle(var1);
      return var1;
   }

   @SinceKotlin(
      version = "1.2"
   )
   @NotNull
   public static final <T> List<T> shuffled(@NotNull Iterable<? extends T> var0, @NotNull Random var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "random");
      List var2 = CollectionsKt.toMutableList(var0);
      boolean var4 = false;
      Collections.shuffle(var2, var1);
      return var2;
   }

   @InlineOnly
   private static final Object[] copyToArrayImpl(Collection<?> var0) {
      Intrinsics.checkNotNullParameter(var0, "collection");
      return CollectionToArray.toArray(var0);
   }

   @InlineOnly
   private static final <T> T[] copyToArrayImpl(Collection<?> var0, T[] var1) {
      Intrinsics.checkNotNullParameter(var0, "collection");
      Intrinsics.checkNotNullParameter(var1, "array");
      return CollectionToArray.toArray(var0, var1);
   }

   @NotNull
   public static final <T> Object[] copyToArrayOfAny(@NotNull T[] var0, boolean var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Object[] var10000;
      if (var1 && Intrinsics.areEqual((Object)var0.getClass(), (Object)Object[].class)) {
         var10000 = var0;
      } else {
         var10000 = Arrays.copyOf(var0, var0.length, Object[].class);
         Intrinsics.checkNotNullExpressionValue(var10000, "copyOf(this, this.size, Array<Any?>::class.java)");
      }

      return var10000;
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   @InlineOnly
   private static final int checkIndexOverflow(int var0) {
      if (var0 < 0) {
         if (!PlatformImplementationsKt.apiVersionIsAtLeast(1, 3, 0)) {
            throw new ArithmeticException("Index overflow has happened.");
         }

         CollectionsKt.throwIndexOverflow();
      }

      return var0;
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   @InlineOnly
   private static final int checkCountOverflow(int var0) {
      if (var0 < 0) {
         if (!PlatformImplementationsKt.apiVersionIsAtLeast(1, 3, 0)) {
            throw new ArithmeticException("Count overflow has happened.");
         }

         CollectionsKt.throwCountOverflow();
      }

      return var0;
   }

   public CollectionsKt__CollectionsJVMKt() {
   }
}
