package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.functions.Function0;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.markers.KMappedMarker;
import java.util.Iterator;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010(\n\u0002\b\u0003\b\u0000\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00010\u00030\u0002B\u0019\u0012\u0012\u0010\u0004\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00060\u0005¢\u0006\u0002\u0010\u0007J\u0015\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00030\u0006H\u0096\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\t"},
   d2 = {"Lga/strikepractice/kotlin/collections/IndexingIterable;", "T", "", "Lga/strikepractice/kotlin/collections/IndexedValue;", "iteratorFactory", "Lga/strikepractice/kotlin/Function0;", "", "(Lkotlin/jvm/functions/Function0;)V", "iterator", "ga.strikepractice.kotlin-stdlib"}
)
public final class IndexingIterable<T> implements KMappedMarker, Iterable<IndexedValue<? extends T>> {
   @NotNull
   private final Function0<Iterator<T>> iteratorFactory;

   public IndexingIterable(@NotNull Function0<? extends Iterator<? extends T>> var1) {
      Intrinsics.checkNotNullParameter(var1, "iteratorFactory");
      super();
      this.iteratorFactory = var1;
   }

   @NotNull
   public Iterator<IndexedValue<T>> iterator() {
      return (Iterator)(new IndexingIterator((Iterator)this.iteratorFactory.invoke()));
   }
}
