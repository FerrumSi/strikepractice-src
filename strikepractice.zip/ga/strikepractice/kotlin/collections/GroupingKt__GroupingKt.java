package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.jvm.functions.Function2;
import ga.strikepractice.kotlin.jvm.functions.Function3;
import ga.strikepractice.kotlin.jvm.functions.Function4;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000@\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\u001a\u009e\u0001\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052b\u0010\u0006\u001a^\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0015\u0012\u0013\u0018\u0001H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0013\u0012\u00110\r¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000e\u0012\u0004\u0012\u0002H\u00030\u0007H\u0087\bø\u0001\u0000\u001a·\u0001\u0010\u000f\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003\"\u0016\b\u0003\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u00102b\u0010\u0006\u001a^\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0015\u0012\u0013\u0018\u0001H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0013\u0012\u00110\r¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000e\u0012\u0004\u0012\u0002H\u00030\u0007H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0013\u001aI\u0010\u0014\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0016\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00150\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u0010H\u0007¢\u0006\u0002\u0010\u0016\u001a¿\u0001\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u000526\u0010\u0018\u001a2\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u00192K\u0010\u0006\u001aG\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u001aH\u0087\bø\u0001\u0000\u001a\u007f\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u001b\u001a\u0002H\u000326\u0010\u0006\u001a2\u0012\u0013\u0012\u0011H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u0019H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001aØ\u0001\u0010\u001d\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003\"\u0016\b\u0003\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u001026\u0010\u0018\u001a2\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u00192K\u0010\u0006\u001aG\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u001aH\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u001e\u001a\u0093\u0001\u0010\u001d\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003\"\u0016\b\u0003\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u00102\u0006\u0010\u001b\u001a\u0002H\u000326\u0010\u0006\u001a2\u0012\u0013\u0012\u0011H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u0019H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u001f\u001a\u008b\u0001\u0010 \u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H!0\u0001\"\u0004\b\u0000\u0010!\"\b\b\u0001\u0010\u0004*\u0002H!\"\u0004\b\u0002\u0010\u0002*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052K\u0010\u0006\u001aG\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H!¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H!0\u001aH\u0087\bø\u0001\u0000\u001a¤\u0001\u0010\"\u001a\u0002H\u0010\"\u0004\b\u0000\u0010!\"\b\b\u0001\u0010\u0004*\u0002H!\"\u0004\b\u0002\u0010\u0002\"\u0016\b\u0003\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H!0\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u00102K\u0010\u0006\u001aG\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H!¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H!0\u001aH\u0087\bø\u0001\u0000¢\u0006\u0002\u0010#\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006$"},
   d2 = {"aggregate", "", "K", "R", "T", "Lga/strikepractice/kotlin/collections/Grouping;", "operation", "Lga/strikepractice/kotlin/Function4;", "Lga/strikepractice/kotlin/ParameterName;", "name", "key", "accumulator", "element", "", "first", "aggregateTo", "M", "", "destination", "(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function4;)Ljava/util/Map;", "eachCountTo", "", "(Lkotlin/collections/Grouping;Ljava/util/Map;)Ljava/util/Map;", "fold", "initialValueSelector", "Lga/strikepractice/kotlin/Function2;", "Lga/strikepractice/kotlin/Function3;", "initialValue", "(Lkotlin/collections/Grouping;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/util/Map;", "foldTo", "(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function3;)Ljava/util/Map;", "(Lkotlin/collections/Grouping;Ljava/util/Map;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/util/Map;", "reduce", "S", "reduceTo", "(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function3;)Ljava/util/Map;", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/collections/GroupingKt"
)
@SourceDebugExtension({"SMAP\nGrouping.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Grouping.kt\nkotlin/collections/GroupingKt__GroupingKt\n*L\n1#1,291:1\n80#1,6:292\n53#1:298\n80#1,6:299\n80#1,6:305\n53#1:311\n80#1,6:312\n80#1,6:318\n53#1:324\n80#1,6:325\n80#1,6:331\n189#1:337\n80#1,6:338\n*S KotlinDebug\n*F\n+ 1 Grouping.kt\nkotlin/collections/GroupingKt__GroupingKt\n*L\n53#1:292,6\n112#1:298\n112#1:299,6\n143#1:305,6\n164#1:311\n164#1:312,6\n189#1:318,6\n211#1:324\n211#1:325,6\n239#1:331,6\n257#1:337\n257#1:338,6\n*E\n"})
class GroupingKt__GroupingKt extends GroupingKt__GroupingJVMKt {
   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <T, K, R> Map<K, R> aggregate(@NotNull Grouping<T, ? extends K> var0, @NotNull Function4<? super K, ? super R, ? super T, ? super Boolean, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "operation");
      boolean var2 = false;
      Grouping var3 = var0;
      Map var4 = (Map)(new LinkedHashMap());
      boolean var5 = false;
      Iterator var6 = var0.sourceIterator();

      while(var6.hasNext()) {
         Object var7 = var6.next();
         Object var8 = var3.keyOf(var7);
         Object var9 = var4.get(var8);
         var4.put(var8, var1.invoke(var8, var9, var7, var9 == null && !var4.containsKey(var8)));
      }

      return var4;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <T, K, R, M extends Map<? super K, R>> M aggregateTo(@NotNull Grouping<T, ? extends K> var0, @NotNull M var1, @NotNull Function4<? super K, ? super R, ? super T, ? super Boolean, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "operation");
      boolean var3 = false;
      Iterator var4 = var0.sourceIterator();

      while(var4.hasNext()) {
         Object var5 = var4.next();
         Object var6 = var0.keyOf(var5);
         Object var7 = var1.get(var6);
         var1.put(var6, var2.invoke(var6, var7, var5, var7 == null && !var1.containsKey(var6)));
      }

      return var1;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <T, K, R> Map<K, R> fold(@NotNull Grouping<T, ? extends K> var0, @NotNull Function2<? super K, ? super T, ? extends R> var1, @NotNull Function3<? super K, ? super R, ? super T, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "initialValueSelector");
      Intrinsics.checkNotNullParameter(var2, "operation");
      boolean var3 = false;
      boolean var5 = false;
      Grouping var6 = var0;
      Map var7 = (Map)(new LinkedHashMap());
      boolean var8 = false;
      Iterator var9 = var0.sourceIterator();

      while(var9.hasNext()) {
         Object var10 = var9.next();
         Object var11 = var6.keyOf(var10);
         Object var12 = var7.get(var11);
         boolean var13 = var12 == null && !var7.containsKey(var11);
         boolean var17 = false;
         Object var20 = var2.invoke(var11, var13 ? var1.invoke(var11, var10) : var12, var10);
         var7.put(var11, var20);
      }

      return var7;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <T, K, R, M extends Map<? super K, R>> M foldTo(@NotNull Grouping<T, ? extends K> var0, @NotNull M var1, @NotNull Function2<? super K, ? super T, ? extends R> var2, @NotNull Function3<? super K, ? super R, ? super T, ? extends R> var3) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "initialValueSelector");
      Intrinsics.checkNotNullParameter(var3, "operation");
      boolean var4 = false;
      Grouping var5 = var0;
      boolean var6 = false;
      Iterator var7 = var0.sourceIterator();

      while(var7.hasNext()) {
         Object var8 = var7.next();
         Object var9 = var5.keyOf(var8);
         Object var10 = var1.get(var9);
         boolean var11 = var10 == null && !var1.containsKey(var9);
         boolean var15 = false;
         Object var18 = var3.invoke(var9, var11 ? var2.invoke(var9, var8) : var10, var8);
         var1.put(var9, var18);
      }

      return var1;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <T, K, R> Map<K, R> fold(@NotNull Grouping<T, ? extends K> var0, R var1, @NotNull Function2<? super R, ? super T, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var2, "operation");
      boolean var3 = false;
      boolean var5 = false;
      Grouping var6 = var0;
      Map var7 = (Map)(new LinkedHashMap());
      boolean var8 = false;
      Iterator var9 = var0.sourceIterator();

      while(var9.hasNext()) {
         Object var10 = var9.next();
         Object var11 = var6.keyOf(var10);
         Object var12 = var7.get(var11);
         boolean var13 = var12 == null && !var7.containsKey(var11);
         boolean var16 = false;
         Object var19 = var2.invoke(var13 ? var1 : var12, var10);
         var7.put(var11, var19);
      }

      return var7;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <T, K, R, M extends Map<? super K, R>> M foldTo(@NotNull Grouping<T, ? extends K> var0, @NotNull M var1, R var2, @NotNull Function2<? super R, ? super T, ? extends R> var3) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var3, "operation");
      boolean var4 = false;
      Grouping var5 = var0;
      boolean var6 = false;
      Iterator var7 = var0.sourceIterator();

      while(var7.hasNext()) {
         Object var8 = var7.next();
         Object var9 = var5.keyOf(var8);
         Object var10 = var1.get(var9);
         boolean var11 = var10 == null && !var1.containsKey(var9);
         boolean var14 = false;
         Object var17 = var3.invoke(var11 ? var2 : var10, var8);
         var1.put(var9, var17);
      }

      return var1;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <S, T extends S, K> Map<K, S> reduce(@NotNull Grouping<T, ? extends K> var0, @NotNull Function3<? super K, ? super S, ? super T, ? extends S> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "operation");
      boolean var2 = false;
      boolean var4 = false;
      Grouping var5 = var0;
      Map var6 = (Map)(new LinkedHashMap());
      boolean var7 = false;
      Iterator var8 = var0.sourceIterator();

      while(var8.hasNext()) {
         Object var9 = var8.next();
         Object var10 = var5.keyOf(var9);
         Object var11 = var6.get(var10);
         boolean var12 = var11 == null && !var6.containsKey(var10);
         boolean var16 = false;
         Object var19 = var12 ? var9 : var1.invoke(var10, var11, var9);
         var6.put(var10, var19);
      }

      return var6;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <S, T extends S, K, M extends Map<? super K, S>> M reduceTo(@NotNull Grouping<T, ? extends K> var0, @NotNull M var1, @NotNull Function3<? super K, ? super S, ? super T, ? extends S> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "operation");
      boolean var3 = false;
      Grouping var4 = var0;
      boolean var5 = false;
      Iterator var6 = var0.sourceIterator();

      while(var6.hasNext()) {
         Object var7 = var6.next();
         Object var8 = var4.keyOf(var7);
         Object var9 = var1.get(var8);
         boolean var10 = var9 == null && !var1.containsKey(var8);
         boolean var14 = false;
         Object var17 = var10 ? var7 : var2.invoke(var8, var9, var7);
         var1.put(var8, var17);
      }

      return var1;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <T, K, M extends Map<? super K, Integer>> M eachCountTo(@NotNull Grouping<T, ? extends K> var0, @NotNull M var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Integer var3 = 0;
      boolean var4 = false;
      Grouping var5 = var0;
      boolean var6 = false;
      Iterator var7 = var0.sourceIterator();

      while(var7.hasNext()) {
         Object var8 = var7.next();
         Object var9 = var5.keyOf(var8);
         Object var10 = var1.get(var9);
         boolean var11 = var10 == null && !var1.containsKey(var9);
         boolean var16 = false;
         int var17 = ((Number)(var11 ? var3 : var10)).intValue();
         boolean var18 = false;
         Integer var19 = var17 + 1;
         var1.put(var9, var19);
      }

      return var1;
   }

   public GroupingKt__GroupingKt() {
   }
}
