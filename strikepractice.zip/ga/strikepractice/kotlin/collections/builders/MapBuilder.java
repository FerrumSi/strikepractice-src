package ga.strikepractice.kotlin.collections.builders;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.collections.ArraysKt;
import ga.strikepractice.kotlin.collections.IntIterator;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.jvm.internal.markers.KMutableIterator;
import ga.strikepractice.kotlin.jvm.internal.markers.KMutableMap;
import ga.strikepractice.kotlin.ranges.IntRange;
import ga.strikepractice.kotlin.ranges.RangesKt;
import java.io.NotSerializableException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000¨\u0001\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0002\b\b\n\u0002\u0010#\n\u0002\u0010'\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u001f\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010$\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u001e\n\u0002\b\u0003\n\u0002\u0010&\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u001a\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\b\u0000\u0018\u0000 }*\u0004\b\u0000\u0010\u0001*\u0004\b\u0001\u0010\u00022\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u00032\u00060\u0004j\u0002`\u0005:\t}~\u007f\u0080\u0001\u0081\u0001\u0082\u0001B\u0007\b\u0016¢\u0006\u0002\u0010\u0006B\u000f\b\u0016\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tBE\b\u0002\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00000\u000b\u0012\u000e\u0010\f\u001a\n\u0012\u0004\u0012\u00028\u0001\u0018\u00010\u000b\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\u0006\u0010\u000f\u001a\u00020\u000e\u0012\u0006\u0010\u0010\u001a\u00020\b\u0012\u0006\u0010\u0011\u001a\u00020\b¢\u0006\u0002\u0010\u0012J\u0017\u00102\u001a\u00020\b2\u0006\u00103\u001a\u00028\u0000H\u0000¢\u0006\u0004\b4\u00105J\u0013\u00106\u001a\b\u0012\u0004\u0012\u00028\u00010\u000bH\u0002¢\u0006\u0002\u00107J\u0012\u00108\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u000109J\r\u0010:\u001a\u00020;H\u0000¢\u0006\u0002\b<J\b\u0010=\u001a\u00020;H\u0016J\b\u0010>\u001a\u00020;H\u0002J\u0019\u0010?\u001a\u00020!2\n\u0010@\u001a\u0006\u0012\u0002\b\u00030AH\u0000¢\u0006\u0002\bBJ!\u0010C\u001a\u00020!2\u0012\u0010D\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010EH\u0000¢\u0006\u0002\bFJ\u0015\u0010G\u001a\u00020!2\u0006\u00103\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010HJ\u0015\u0010I\u001a\u00020!2\u0006\u0010J\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010HJ\u0018\u0010K\u001a\u00020!2\u000e\u0010L\u001a\n\u0012\u0002\b\u0003\u0012\u0002\b\u000309H\u0002J\u0010\u0010M\u001a\u00020;2\u0006\u0010\u0013\u001a\u00020\bH\u0002J\u0010\u0010N\u001a\u00020;2\u0006\u0010O\u001a\u00020\bH\u0002J\u0019\u0010P\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010QH\u0000¢\u0006\u0002\bRJ\u0013\u0010S\u001a\u00020!2\b\u0010L\u001a\u0004\u0018\u00010TH\u0096\u0002J\u0015\u0010U\u001a\u00020\b2\u0006\u00103\u001a\u00028\u0000H\u0002¢\u0006\u0002\u00105J\u0015\u0010V\u001a\u00020\b2\u0006\u0010J\u001a\u00028\u0001H\u0002¢\u0006\u0002\u00105J\u0018\u0010W\u001a\u0004\u0018\u00018\u00012\u0006\u00103\u001a\u00028\u0000H\u0096\u0002¢\u0006\u0002\u0010XJ\u0015\u0010Y\u001a\u00020\b2\u0006\u00103\u001a\u00028\u0000H\u0002¢\u0006\u0002\u00105J\b\u0010Z\u001a\u00020\bH\u0016J\b\u0010[\u001a\u00020!H\u0016J\u0019\u0010\\\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010]H\u0000¢\u0006\u0002\b^J\u001f\u0010_\u001a\u0004\u0018\u00018\u00012\u0006\u00103\u001a\u00028\u00002\u0006\u0010J\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010`J\u001e\u0010a\u001a\u00020;2\u0014\u0010b\u001a\u0010\u0012\u0006\b\u0001\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u000109H\u0016J\"\u0010c\u001a\u00020!2\u0018\u0010b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010E0AH\u0002J\u001c\u0010d\u001a\u00020!2\u0012\u0010D\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010EH\u0002J\u0010\u0010e\u001a\u00020!2\u0006\u0010f\u001a\u00020\bH\u0002J\u0010\u0010g\u001a\u00020;2\u0006\u0010h\u001a\u00020\bH\u0002J\u0017\u0010i\u001a\u0004\u0018\u00018\u00012\u0006\u00103\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010XJ!\u0010j\u001a\u00020!2\u0012\u0010D\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010EH\u0000¢\u0006\u0002\bkJ\u0010\u0010l\u001a\u00020;2\u0006\u0010m\u001a\u00020\bH\u0002J\u0017\u0010n\u001a\u00020\b2\u0006\u00103\u001a\u00028\u0000H\u0000¢\u0006\u0004\bo\u00105J\u0010\u0010p\u001a\u00020;2\u0006\u0010q\u001a\u00020\bH\u0002J\u0017\u0010r\u001a\u00020!2\u0006\u0010s\u001a\u00028\u0001H\u0000¢\u0006\u0004\bt\u0010HJ\u0010\u0010u\u001a\u00020!2\u0006\u0010v\u001a\u00020\bH\u0002J\b\u0010w\u001a\u00020xH\u0016J\u0019\u0010y\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010zH\u0000¢\u0006\u0002\b{J\b\u0010|\u001a\u00020TH\u0002R\u0014\u0010\u0013\u001a\u00020\b8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R&\u0010\u0016\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010\u00180\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u001aR\u001c\u0010\u001b\u001a\u0010\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u0001\u0018\u00010\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001e\u001a\u00020\b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u001f\u0010\u0015R\u001e\u0010\"\u001a\u00020!2\u0006\u0010 \u001a\u00020!@BX\u0080\u000e¢\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u001a\u0010%\u001a\b\u0012\u0004\u0012\u00028\u00000\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b&\u0010\u001aR\u0016\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00000\u000bX\u0082\u000e¢\u0006\u0004\n\u0002\u0010'R\u0016\u0010(\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010)X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010*\u001a\u00020\b2\u0006\u0010 \u001a\u00020\b@RX\u0096\u000e¢\u0006\b\n\u0000\u001a\u0004\b+\u0010\u0015R\u001a\u0010,\u001a\b\u0012\u0004\u0012\u00028\u00010-8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b.\u0010/R\u0018\u0010\f\u001a\n\u0012\u0004\u0012\u00028\u0001\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0004\n\u0002\u0010'R\u0016\u00100\u001a\n\u0012\u0004\u0012\u00028\u0001\u0018\u000101X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0083\u0001"},
   d2 = {"Lga/strikepractice/kotlin/collections/builders/MapBuilder;", "K", "V", "", "Ljava/io/Serializable;", "Lga/strikepractice/kotlin/io/Serializable;", "()V", "initialCapacity", "", "(I)V", "keysArray", "", "valuesArray", "presenceArray", "", "hashArray", "maxProbeDistance", "length", "([Ljava/lang/Object;[Ljava/lang/Object;[I[III)V", "capacity", "getCapacity$kotlin_stdlib", "()I", "entries", "", "", "getEntries", "()Ljava/util/Set;", "entriesView", "Lga/strikepractice/kotlin/collections/builders/MapBuilderEntries;", "hashShift", "hashSize", "getHashSize", "<set-?>", "", "isReadOnly", "isReadOnly$kotlin_stdlib", "()Z", "keys", "getKeys", "[Ljava/lang/Object;", "keysView", "Lga/strikepractice/kotlin/collections/builders/MapBuilderKeys;", "size", "getSize", "values", "", "getValues", "()Ljava/util/Collection;", "valuesView", "Lga/strikepractice/kotlin/collections/builders/MapBuilderValues;", "addKey", "key", "addKey$kotlin_stdlib", "(Ljava/lang/Object;)I", "allocateValuesArray", "()[Ljava/lang/Object;", "build", "", "checkIsMutable", "", "checkIsMutable$kotlin_stdlib", "clear", "compact", "containsAllEntries", "m", "", "containsAllEntries$kotlin_stdlib", "containsEntry", "entry", "", "containsEntry$kotlin_stdlib", "containsKey", "(Ljava/lang/Object;)Z", "containsValue", "value", "contentEquals", "other", "ensureCapacity", "ensureExtraCapacity", "n", "entriesIterator", "Lga/strikepractice/kotlin/collections/builders/MapBuilder$EntriesItr;", "entriesIterator$kotlin_stdlib", "equals", "", "findKey", "findValue", "get", "(Ljava/lang/Object;)Ljava/lang/Object;", "hash", "hashCode", "isEmpty", "keysIterator", "Lga/strikepractice/kotlin/collections/builders/MapBuilder$KeysItr;", "keysIterator$kotlin_stdlib", "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "putAll", "from", "putAllEntries", "putEntry", "putRehash", "i", "rehash", "newHashSize", "remove", "removeEntry", "removeEntry$kotlin_stdlib", "removeHashAt", "removedHash", "removeKey", "removeKey$kotlin_stdlib", "removeKeyAt", "index", "removeValue", "element", "removeValue$kotlin_stdlib", "shouldCompact", "extraCapacity", "toString", "", "valuesIterator", "Lga/strikepractice/kotlin/collections/builders/MapBuilder$ValuesItr;", "valuesIterator$kotlin_stdlib", "writeReplace", "Companion", "EntriesItr", "EntryRef", "Itr", "KeysItr", "ValuesItr", "ga.strikepractice.kotlin-stdlib"}
)
public final class MapBuilder<K, V> implements KMutableMap, Serializable, Map<K, V> {
   @NotNull
   private static final MapBuilder.Companion Companion = new MapBuilder.Companion((DefaultConstructorMarker)null);
   @NotNull
   private K[] keysArray;
   @Nullable
   private V[] valuesArray;
   @NotNull
   private int[] presenceArray;
   @NotNull
   private int[] hashArray;
   private int maxProbeDistance;
   private int length;
   private int hashShift;
   private int size;
   @Nullable
   private MapBuilderKeys<K> keysView;
   @Nullable
   private MapBuilderValues<V> valuesView;
   @Nullable
   private MapBuilderEntries<K, V> entriesView;
   private boolean isReadOnly;
   private static final int MAGIC = -1640531527;
   private static final int INITIAL_CAPACITY = 8;
   private static final int INITIAL_MAX_PROBE_DISTANCE = 2;
   private static final int TOMBSTONE = -1;

   private MapBuilder(K[] var1, V[] var2, int[] var3, int[] var4, int var5, int var6) {
      this.keysArray = var1;
      this.valuesArray = var2;
      this.presenceArray = var3;
      this.hashArray = var4;
      this.maxProbeDistance = var5;
      this.length = var6;
      this.hashShift = Companion.computeShift(this.getHashSize());
   }

   public int getSize() {
      return this.size;
   }

   public final boolean isReadOnly$kotlin_stdlib() {
      return this.isReadOnly;
   }

   public MapBuilder() {
      this(8);
   }

   public MapBuilder(int var1) {
      this(ListBuilderKt.arrayOfUninitializedElements(var1), (Object[])null, new int[var1], new int[Companion.computeHashSize(var1)], 2, 0);
   }

   @NotNull
   public final Map<K, V> build() {
      this.checkIsMutable$kotlin_stdlib();
      this.isReadOnly = true;
      return (Map)this;
   }

   private final Object writeReplace() {
      if (this.isReadOnly) {
         return new SerializedMap((Map)this);
      } else {
         throw new NotSerializableException("The map cannot be serialized while it is being built.");
      }
   }

   public boolean isEmpty() {
      return this.size() == 0;
   }

   public boolean containsKey(Object var1) {
      return this.findKey(var1) >= 0;
   }

   public boolean containsValue(Object var1) {
      return this.findValue(var1) >= 0;
   }

   @Nullable
   public V get(Object var1) {
      int var2 = this.findKey(var1);
      if (var2 < 0) {
         return null;
      } else {
         Object[] var10000 = this.valuesArray;
         Intrinsics.checkNotNull(var10000);
         return var10000[var2];
      }
   }

   @Nullable
   public V put(K var1, V var2) {
      this.checkIsMutable$kotlin_stdlib();
      int var3 = this.addKey$kotlin_stdlib(var1);
      Object[] var4 = this.allocateValuesArray();
      if (var3 < 0) {
         Object var5 = var4[-var3 - 1];
         var4[-var3 - 1] = var2;
         return var5;
      } else {
         var4[var3] = var2;
         return null;
      }
   }

   public void putAll(@NotNull Map<? extends K, ? extends V> var1) {
      Intrinsics.checkNotNullParameter(var1, "from");
      this.checkIsMutable$kotlin_stdlib();
      this.putAllEntries((Collection)var1.entrySet());
   }

   @Nullable
   public V remove(Object var1) {
      int var2 = this.removeKey$kotlin_stdlib(var1);
      if (var2 < 0) {
         return null;
      } else {
         Object[] var10000 = this.valuesArray;
         Intrinsics.checkNotNull(var10000);
         Object[] var3 = var10000;
         Object var4 = var3[var2];
         ListBuilderKt.resetAt(var3, var2);
         return var4;
      }
   }

   public void clear() {
      this.checkIsMutable$kotlin_stdlib();
      IntIterator var1 = (new IntRange(0, this.length - 1)).iterator();

      while(var1.hasNext()) {
         int var2 = var1.nextInt();
         int var3 = this.presenceArray[var2];
         if (var3 >= 0) {
            this.hashArray[var3] = 0;
            this.presenceArray[var2] = -1;
         }
      }

      ListBuilderKt.resetRange(this.keysArray, 0, this.length);
      Object[] var10000 = this.valuesArray;
      if (var10000 != null) {
         ListBuilderKt.resetRange(var10000, 0, this.length);
      }

      this.size = 0;
      this.length = 0;
   }

   @NotNull
   public Set<K> getKeys() {
      MapBuilderKeys var1 = this.keysView;
      Set var10000;
      if (var1 == null) {
         MapBuilderKeys var2 = new MapBuilderKeys(this);
         this.keysView = var2;
         var10000 = (Set)var2;
      } else {
         var10000 = (Set)var1;
      }

      return var10000;
   }

   @NotNull
   public Collection<V> getValues() {
      MapBuilderValues var1 = this.valuesView;
      Collection var10000;
      if (var1 == null) {
         MapBuilderValues var2 = new MapBuilderValues(this);
         this.valuesView = var2;
         var10000 = (Collection)var2;
      } else {
         var10000 = (Collection)var1;
      }

      return var10000;
   }

   @NotNull
   public Set<java.util.Map.Entry<K, V>> getEntries() {
      MapBuilderEntries var1 = this.entriesView;
      if (var1 == null) {
         MapBuilderEntries var2 = new MapBuilderEntries(this);
         this.entriesView = var2;
         return (Set)var2;
      } else {
         return (Set)var1;
      }
   }

   public boolean equals(@Nullable Object var1) {
      return var1 == this || var1 instanceof Map && this.contentEquals((Map)var1);
   }

   public int hashCode() {
      int var1 = 0;

      for(MapBuilder.EntriesItr var2 = this.entriesIterator$kotlin_stdlib(); var2.hasNext(); var1 += var2.nextHashCode$kotlin_stdlib()) {
      }

      return var1;
   }

   @NotNull
   public String toString() {
      StringBuilder var1 = new StringBuilder(2 + this.size() * 3);
      var1.append("{");
      int var2 = 0;

      for(MapBuilder.EntriesItr var3 = this.entriesIterator$kotlin_stdlib(); var3.hasNext(); ++var2) {
         if (var2 > 0) {
            var1.append(", ");
         }

         var3.nextAppendString(var1);
      }

      var1.append("}");
      String var10000 = var1.toString();
      Intrinsics.checkNotNullExpressionValue(var10000, "sb.toString()");
      return var10000;
   }

   public final int getCapacity$kotlin_stdlib() {
      return this.keysArray.length;
   }

   private final int getHashSize() {
      return this.hashArray.length;
   }

   public final void checkIsMutable$kotlin_stdlib() {
      if (this.isReadOnly) {
         throw new UnsupportedOperationException();
      }
   }

   private final void ensureExtraCapacity(int var1) {
      if (this.shouldCompact(var1)) {
         this.rehash(this.getHashSize());
      } else {
         this.ensureCapacity(this.length + var1);
      }

   }

   private final boolean shouldCompact(int var1) {
      int var2 = this.getCapacity$kotlin_stdlib() - this.length;
      int var3 = this.length - this.size();
      return var2 < var1 && var3 + var2 >= var1 && var3 >= this.getCapacity$kotlin_stdlib() / 4;
   }

   private final void ensureCapacity(int var1) {
      if (var1 < 0) {
         throw new OutOfMemoryError();
      } else {
         if (var1 > this.getCapacity$kotlin_stdlib()) {
            int var2 = this.getCapacity$kotlin_stdlib() * 3 / 2;
            if (var1 > var2) {
               var2 = var1;
            }

            this.keysArray = ListBuilderKt.copyOfUninitializedElements(this.keysArray, var2);
            Object[] var10001 = this.valuesArray;
            this.valuesArray = var10001 != null ? ListBuilderKt.copyOfUninitializedElements(var10001, var2) : null;
            int[] var4 = Arrays.copyOf(this.presenceArray, var2);
            Intrinsics.checkNotNullExpressionValue(var4, "copyOf(this, newSize)");
            this.presenceArray = var4;
            int var3 = Companion.computeHashSize(var2);
            if (var3 > this.getHashSize()) {
               this.rehash(var3);
            }
         }

      }
   }

   private final V[] allocateValuesArray() {
      Object[] var1 = this.valuesArray;
      if (var1 != null) {
         return var1;
      } else {
         Object[] var2 = ListBuilderKt.arrayOfUninitializedElements(this.getCapacity$kotlin_stdlib());
         this.valuesArray = var2;
         return var2;
      }
   }

   private final int hash(K var1) {
      return (var1 != null ? var1.hashCode() : 0) * -1640531527 >>> this.hashShift;
   }

   private final void compact() {
      int var1 = 0;
      int var2 = 0;

      Object[] var3;
      for(var3 = this.valuesArray; var1 < this.length; ++var1) {
         if (this.presenceArray[var1] >= 0) {
            this.keysArray[var2] = this.keysArray[var1];
            if (var3 != null) {
               var3[var2] = var3[var1];
            }

            ++var2;
         }
      }

      ListBuilderKt.resetRange(this.keysArray, var2, this.length);
      if (var3 != null) {
         ListBuilderKt.resetRange(var3, var2, this.length);
      }

      this.length = var2;
   }

   private final void rehash(int var1) {
      if (this.length > this.size()) {
         this.compact();
      }

      if (var1 != this.getHashSize()) {
         this.hashArray = new int[var1];
         this.hashShift = Companion.computeShift(var1);
      } else {
         ArraysKt.fill(this.hashArray, 0, 0, this.getHashSize());
      }

      int var2 = 0;

      do {
         if (var2 >= this.length) {
            return;
         }
      } while(this.putRehash(var2++));

      throw new IllegalStateException("This cannot happen with fixed magic multiplier and grow-only hash array. Have object hashCodes changed?");
   }

   private final boolean putRehash(int var1) {
      int var2 = this.hash(this.keysArray[var1]);
      int var3 = this.maxProbeDistance;

      while(true) {
         int var4 = this.hashArray[var2];
         if (var4 == 0) {
            this.hashArray[var2] = var1 + 1;
            this.presenceArray[var1] = var2;
            return true;
         }

         --var3;
         if (var3 < 0) {
            return false;
         }

         if (var2-- == 0) {
            var2 = this.getHashSize() - 1;
         }
      }
   }

   private final int findKey(K var1) {
      int var2 = this.hash(var1);
      int var3 = this.maxProbeDistance;

      while(true) {
         int var4 = this.hashArray[var2];
         if (var4 == 0) {
            return -1;
         }

         if (var4 > 0 && Intrinsics.areEqual(this.keysArray[var4 - 1], var1)) {
            return var4 - 1;
         }

         --var3;
         if (var3 < 0) {
            return -1;
         }

         if (var2-- == 0) {
            var2 = this.getHashSize() - 1;
         }
      }
   }

   private final int findValue(V var1) {
      int var2 = this.length;

      while(true) {
         --var2;
         if (var2 < 0) {
            return -1;
         }

         if (this.presenceArray[var2] >= 0) {
            Object[] var10000 = this.valuesArray;
            Intrinsics.checkNotNull(var10000);
            if (Intrinsics.areEqual(var10000[var2], var1)) {
               return var2;
            }
         }
      }
   }

   public final int addKey$kotlin_stdlib(K var1) {
      this.checkIsMutable$kotlin_stdlib();

      while(true) {
         while(true) {
            int var2 = this.hash(var1);
            int var3 = RangesKt.coerceAtMost(this.maxProbeDistance * 2, this.getHashSize() / 2);
            int var4 = 0;

            while(true) {
               int var5 = this.hashArray[var2];
               if (var5 <= 0) {
                  if (this.length < this.getCapacity$kotlin_stdlib()) {
                     int var7 = this.length++;
                     int var6 = var7;
                     this.keysArray[var7] = var1;
                     this.presenceArray[var7] = var2;
                     this.hashArray[var2] = var7 + 1;
                     var7 = this.size();
                     this.size = var7 + 1;
                     if (var4 > this.maxProbeDistance) {
                        this.maxProbeDistance = var4;
                     }

                     return var6;
                  }

                  this.ensureExtraCapacity(1);
                  break;
               }

               if (Intrinsics.areEqual(this.keysArray[var5 - 1], var1)) {
                  return -var5;
               }

               ++var4;
               if (var4 > var3) {
                  this.rehash(this.getHashSize() * 2);
                  break;
               }

               if (var2-- == 0) {
                  var2 = this.getHashSize() - 1;
               }
            }
         }
      }
   }

   public final int removeKey$kotlin_stdlib(K var1) {
      this.checkIsMutable$kotlin_stdlib();
      int var2 = this.findKey(var1);
      if (var2 < 0) {
         return -1;
      } else {
         this.removeKeyAt(var2);
         return var2;
      }
   }

   private final void removeKeyAt(int var1) {
      ListBuilderKt.resetAt(this.keysArray, var1);
      this.removeHashAt(this.presenceArray[var1]);
      this.presenceArray[var1] = -1;
      int var2 = this.size();
      this.size = var2 + -1;
   }

   private final void removeHashAt(int var1) {
      int var2 = var1;
      int var3 = var1;
      int var4 = 0;
      int var5 = RangesKt.coerceAtMost(this.maxProbeDistance * 2, this.getHashSize() / 2);

      do {
         if (var2-- == 0) {
            var2 = this.getHashSize() - 1;
         }

         ++var4;
         if (var4 > this.maxProbeDistance) {
            this.hashArray[var3] = 0;
            return;
         }

         int var6 = this.hashArray[var2];
         if (var6 == 0) {
            this.hashArray[var3] = 0;
            return;
         }

         if (var6 < 0) {
            this.hashArray[var3] = -1;
            var3 = var2;
            var4 = 0;
         } else {
            int var7 = this.hash(this.keysArray[var6 - 1]);
            if ((var7 - var2 & this.getHashSize() - 1) >= var4) {
               this.hashArray[var3] = var6;
               this.presenceArray[var6 - 1] = var3;
               var3 = var2;
               var4 = 0;
            }
         }

         --var5;
      } while(var5 >= 0);

      this.hashArray[var3] = -1;
   }

   public final boolean containsEntry$kotlin_stdlib(@NotNull java.util.Map.Entry<? extends K, ? extends V> var1) {
      Intrinsics.checkNotNullParameter(var1, "entry");
      int var2 = this.findKey(var1.getKey());
      if (var2 < 0) {
         return false;
      } else {
         Object[] var10000 = this.valuesArray;
         Intrinsics.checkNotNull(var10000);
         return Intrinsics.areEqual(var10000[var2], var1.getValue());
      }
   }

   private final boolean contentEquals(Map<?, ?> var1) {
      return this.size() == var1.size() && this.containsAllEntries$kotlin_stdlib((Collection)var1.entrySet());
   }

   public final boolean containsAllEntries$kotlin_stdlib(@NotNull Collection<?> var1) {
      Intrinsics.checkNotNullParameter(var1, "m");
      Iterator var2 = var1.iterator();

      while(true) {
         if (var2.hasNext()) {
            Object var3 = var2.next();

            try {
               if (var3 != null && this.containsEntry$kotlin_stdlib((java.util.Map.Entry)var3)) {
                  continue;
               }

               return false;
            } catch (ClassCastException var5) {
               return false;
            }
         }

         return true;
      }
   }

   private final boolean putEntry(java.util.Map.Entry<? extends K, ? extends V> var1) {
      int var2 = this.addKey$kotlin_stdlib(var1.getKey());
      Object[] var3 = this.allocateValuesArray();
      if (var2 >= 0) {
         var3[var2] = var1.getValue();
         return true;
      } else {
         Object var4 = var3[-var2 - 1];
         if (!Intrinsics.areEqual(var1.getValue(), var4)) {
            var3[-var2 - 1] = var1.getValue();
            return true;
         } else {
            return false;
         }
      }
   }

   private final boolean putAllEntries(Collection<? extends java.util.Map.Entry<? extends K, ? extends V>> var1) {
      if (var1.isEmpty()) {
         return false;
      } else {
         this.ensureExtraCapacity(var1.size());
         Iterator var2 = var1.iterator();
         boolean var3 = false;

         while(var2.hasNext()) {
            if (this.putEntry((java.util.Map.Entry)var2.next())) {
               var3 = true;
            }
         }

         return var3;
      }
   }

   public final boolean removeEntry$kotlin_stdlib(@NotNull java.util.Map.Entry<? extends K, ? extends V> var1) {
      Intrinsics.checkNotNullParameter(var1, "entry");
      this.checkIsMutable$kotlin_stdlib();
      int var2 = this.findKey(var1.getKey());
      if (var2 < 0) {
         return false;
      } else {
         Object[] var10000 = this.valuesArray;
         Intrinsics.checkNotNull(var10000);
         if (!Intrinsics.areEqual(var10000[var2], var1.getValue())) {
            return false;
         } else {
            this.removeKeyAt(var2);
            return true;
         }
      }
   }

   public final boolean removeValue$kotlin_stdlib(V var1) {
      this.checkIsMutable$kotlin_stdlib();
      int var2 = this.findValue(var1);
      if (var2 < 0) {
         return false;
      } else {
         this.removeKeyAt(var2);
         return true;
      }
   }

   @NotNull
   public final MapBuilder.KeysItr<K, V> keysIterator$kotlin_stdlib() {
      return new MapBuilder.KeysItr(this);
   }

   @NotNull
   public final MapBuilder.ValuesItr<K, V> valuesIterator$kotlin_stdlib() {
      return new MapBuilder.ValuesItr(this);
   }

   @NotNull
   public final MapBuilder.EntriesItr<K, V> entriesIterator$kotlin_stdlib() {
      return new MapBuilder.EntriesItr(this);
   }

   public final int size() {
      return this.getSize();
   }

   public final Set<K> keySet() {
      return this.getKeys();
   }

   public final Collection<V> values() {
      return this.getValues();
   }

   public final Set<java.util.Map.Entry<K, V>> entrySet() {
      return this.getEntries();
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\b\u0082\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004H\u0002J\u0010\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\f"},
      d2 = {"Lga/strikepractice/kotlin/collections/builders/MapBuilder$Companion;", "", "()V", "INITIAL_CAPACITY", "", "INITIAL_MAX_PROBE_DISTANCE", "MAGIC", "TOMBSTONE", "computeHashSize", "capacity", "computeShift", "hashSize", "ga.strikepractice.kotlin-stdlib"}
   )
   private static final class Companion {
      private Companion() {
      }

      private final int computeHashSize(int var1) {
         return Integer.highestOneBit(RangesKt.coerceAtLeast(var1, 1) * 3);
      }

      private final int computeShift(int var1) {
         return Integer.numberOfLeadingZeros(var1) + 1;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker var1) {
         this();
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0010\u0018\u0000*\u0004\b\u0002\u0010\u0001*\u0004\b\u0003\u0010\u00022\u00020\u0003B\u0019\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00028\u0002\u0012\u0004\u0012\u00028\u00030\u0005¢\u0006\u0002\u0010\u0006J\u0006\u0010\u0012\u001a\u00020\u0013J\r\u0010\u0014\u001a\u00020\u0015H\u0000¢\u0006\u0002\b\u0016J\u0006\u0010\u0017\u001a\u00020\u0015R\u001a\u0010\u0007\u001a\u00020\bX\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001a\u0010\r\u001a\u00020\bX\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\n\"\u0004\b\u000f\u0010\fR \u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00028\u0002\u0012\u0004\u0012\u00028\u00030\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u0018"},
      d2 = {"Lga/strikepractice/kotlin/collections/builders/MapBuilder$Itr;", "K", "V", "", "map", "Lga/strikepractice/kotlin/collections/builders/MapBuilder;", "(Lkotlin/collections/builders/MapBuilder;)V", "index", "", "getIndex$kotlin_stdlib", "()I", "setIndex$kotlin_stdlib", "(I)V", "lastIndex", "getLastIndex$kotlin_stdlib", "setLastIndex$kotlin_stdlib", "getMap$kotlin_stdlib", "()Lkotlin/collections/builders/MapBuilder;", "hasNext", "", "initNext", "", "initNext$kotlin_stdlib", "remove", "ga.strikepractice.kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nMapBuilder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MapBuilder.kt\nkotlin/collections/builders/MapBuilder$Itr\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,694:1\n1#2:695\n*E\n"})
   public static class Itr<K, V> {
      @NotNull
      private final MapBuilder<K, V> map;
      private int index;
      private int lastIndex;

      public Itr(@NotNull MapBuilder<K, V> var1) {
         Intrinsics.checkNotNullParameter(var1, "map");
         super();
         this.map = var1;
         this.lastIndex = -1;
         this.initNext$kotlin_stdlib();
      }

      @NotNull
      public final MapBuilder<K, V> getMap$kotlin_stdlib() {
         return this.map;
      }

      public final int getIndex$kotlin_stdlib() {
         return this.index;
      }

      public final void setIndex$kotlin_stdlib(int var1) {
         this.index = var1;
      }

      public final int getLastIndex$kotlin_stdlib() {
         return this.lastIndex;
      }

      public final void setLastIndex$kotlin_stdlib(int var1) {
         this.lastIndex = var1;
      }

      public final void initNext$kotlin_stdlib() {
         while(this.index < this.map.length && this.map.presenceArray[this.index] < 0) {
            int var1 = this.index++;
         }

      }

      public final boolean hasNext() {
         return this.index < this.map.length;
      }

      public final void remove() {
         boolean var1 = this.lastIndex != -1;
         if (!var1) {
            boolean var2 = false;
            String var3 = "Call next() before removing element from the iterator.";
            throw new IllegalStateException(var3.toString());
         } else {
            this.map.checkIsMutable$kotlin_stdlib();
            this.map.removeKeyAt(this.lastIndex);
            this.lastIndex = -1;
         }
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010)\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u0000*\u0004\b\u0002\u0010\u0001*\u0004\b\u0003\u0010\u00022\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u00032\b\u0012\u0004\u0012\u0002H\u00010\u0004B\u0019\u0012\u0012\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00028\u0002\u0012\u0004\u0012\u00028\u00030\u0006¢\u0006\u0002\u0010\u0007J\u000e\u0010\b\u001a\u00028\u0002H\u0096\u0002¢\u0006\u0002\u0010\t¨\u0006\n"},
      d2 = {"Lga/strikepractice/kotlin/collections/builders/MapBuilder$KeysItr;", "K", "V", "Lga/strikepractice/kotlin/collections/builders/MapBuilder$Itr;", "", "map", "Lga/strikepractice/kotlin/collections/builders/MapBuilder;", "(Lkotlin/collections/builders/MapBuilder;)V", "next", "()Ljava/lang/Object;", "ga.strikepractice.kotlin-stdlib"}
   )
   public static final class KeysItr<K, V> extends MapBuilder.Itr<K, V> implements KMutableIterator, Iterator<K> {
      public KeysItr(@NotNull MapBuilder<K, V> var1) {
         Intrinsics.checkNotNullParameter(var1, "map");
         super(var1);
      }

      public K next() {
         if (this.getIndex$kotlin_stdlib() >= this.getMap$kotlin_stdlib().length) {
            throw new NoSuchElementException();
         } else {
            int var1 = this.getIndex$kotlin_stdlib();
            this.setIndex$kotlin_stdlib(var1 + 1);
            this.setLastIndex$kotlin_stdlib(var1);
            Object var2 = this.getMap$kotlin_stdlib().keysArray[this.getLastIndex$kotlin_stdlib()];
            this.initNext$kotlin_stdlib();
            return var2;
         }
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010)\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u0000*\u0004\b\u0002\u0010\u0001*\u0004\b\u0003\u0010\u00022\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u00032\b\u0012\u0004\u0012\u0002H\u00020\u0004B\u0019\u0012\u0012\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00028\u0002\u0012\u0004\u0012\u00028\u00030\u0006¢\u0006\u0002\u0010\u0007J\u000e\u0010\b\u001a\u00028\u0003H\u0096\u0002¢\u0006\u0002\u0010\t¨\u0006\n"},
      d2 = {"Lga/strikepractice/kotlin/collections/builders/MapBuilder$ValuesItr;", "K", "V", "Lga/strikepractice/kotlin/collections/builders/MapBuilder$Itr;", "", "map", "Lga/strikepractice/kotlin/collections/builders/MapBuilder;", "(Lkotlin/collections/builders/MapBuilder;)V", "next", "()Ljava/lang/Object;", "ga.strikepractice.kotlin-stdlib"}
   )
   public static final class ValuesItr<K, V> extends MapBuilder.Itr<K, V> implements KMutableIterator, Iterator<V> {
      public ValuesItr(@NotNull MapBuilder<K, V> var1) {
         Intrinsics.checkNotNullParameter(var1, "map");
         super(var1);
      }

      public V next() {
         if (this.getIndex$kotlin_stdlib() >= this.getMap$kotlin_stdlib().length) {
            throw new NoSuchElementException();
         } else {
            int var1 = this.getIndex$kotlin_stdlib();
            this.setIndex$kotlin_stdlib(var1 + 1);
            this.setLastIndex$kotlin_stdlib(var1);
            Object[] var10000 = this.getMap$kotlin_stdlib().valuesArray;
            Intrinsics.checkNotNull(var10000);
            Object var2 = var10000[this.getLastIndex$kotlin_stdlib()];
            this.initNext$kotlin_stdlib();
            return var2;
         }
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010)\n\u0002\u0010'\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0000\u0018\u0000*\u0004\b\u0002\u0010\u0001*\u0004\b\u0003\u0010\u00022\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u00032\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u00050\u0004B\u0019\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00028\u0002\u0012\u0004\u0012\u00028\u00030\u0007¢\u0006\u0002\u0010\bJ\u0015\u0010\t\u001a\u000e\u0012\u0004\u0012\u00028\u0002\u0012\u0004\u0012\u00028\u00030\nH\u0096\u0002J\u0012\u0010\u000b\u001a\u00020\f2\n\u0010\r\u001a\u00060\u000ej\u0002`\u000fJ\r\u0010\u0010\u001a\u00020\u0011H\u0000¢\u0006\u0002\b\u0012¨\u0006\u0013"},
      d2 = {"Lga/strikepractice/kotlin/collections/builders/MapBuilder$EntriesItr;", "K", "V", "Lga/strikepractice/kotlin/collections/builders/MapBuilder$Itr;", "", "", "map", "Lga/strikepractice/kotlin/collections/builders/MapBuilder;", "(Lkotlin/collections/builders/MapBuilder;)V", "next", "Lga/strikepractice/kotlin/collections/builders/MapBuilder$EntryRef;", "nextAppendString", "", "sb", "Ljava/lang/StringBuilder;", "Lga/strikepractice/kotlin/text/StringBuilder;", "nextHashCode", "", "nextHashCode$kotlin_stdlib", "ga.strikepractice.kotlin-stdlib"}
   )
   public static final class EntriesItr<K, V> extends MapBuilder.Itr<K, V> implements KMutableIterator, Iterator<java.util.Map.Entry<K, V>> {
      public EntriesItr(@NotNull MapBuilder<K, V> var1) {
         Intrinsics.checkNotNullParameter(var1, "map");
         super(var1);
      }

      @NotNull
      public MapBuilder.EntryRef<K, V> next() {
         if (this.getIndex$kotlin_stdlib() >= this.getMap$kotlin_stdlib().length) {
            throw new NoSuchElementException();
         } else {
            int var1 = this.getIndex$kotlin_stdlib();
            this.setIndex$kotlin_stdlib(var1 + 1);
            this.setLastIndex$kotlin_stdlib(var1);
            MapBuilder.EntryRef var2 = new MapBuilder.EntryRef(this.getMap$kotlin_stdlib(), this.getLastIndex$kotlin_stdlib());
            this.initNext$kotlin_stdlib();
            return var2;
         }
      }

      public final int nextHashCode$kotlin_stdlib() {
         if (this.getIndex$kotlin_stdlib() >= this.getMap$kotlin_stdlib().length) {
            throw new NoSuchElementException();
         } else {
            int var1 = this.getIndex$kotlin_stdlib();
            this.setIndex$kotlin_stdlib(var1 + 1);
            this.setLastIndex$kotlin_stdlib(var1);
            Object var10000 = this.getMap$kotlin_stdlib().keysArray[this.getLastIndex$kotlin_stdlib()];
            int var2 = var10000 != null ? var10000.hashCode() : 0;
            Object[] var10001 = this.getMap$kotlin_stdlib().valuesArray;
            Intrinsics.checkNotNull(var10001);
            Object var3 = var10001[this.getLastIndex$kotlin_stdlib()];
            var1 = var2 ^ (var3 != null ? var3.hashCode() : 0);
            this.initNext$kotlin_stdlib();
            return var1;
         }
      }

      public final void nextAppendString(@NotNull StringBuilder var1) {
         Intrinsics.checkNotNullParameter(var1, "sb");
         if (this.getIndex$kotlin_stdlib() >= this.getMap$kotlin_stdlib().length) {
            throw new NoSuchElementException();
         } else {
            int var2 = this.getIndex$kotlin_stdlib();
            this.setIndex$kotlin_stdlib(var2 + 1);
            this.setLastIndex$kotlin_stdlib(var2);
            Object var4 = this.getMap$kotlin_stdlib().keysArray[this.getLastIndex$kotlin_stdlib()];
            if (Intrinsics.areEqual((Object)var4, (Object)this.getMap$kotlin_stdlib())) {
               var1.append("(this Map)");
            } else {
               var1.append(var4);
            }

            var1.append('=');
            Object[] var10000 = this.getMap$kotlin_stdlib().valuesArray;
            Intrinsics.checkNotNull(var10000);
            Object var3 = var10000[this.getLastIndex$kotlin_stdlib()];
            if (Intrinsics.areEqual((Object)var3, (Object)this.getMap$kotlin_stdlib())) {
               var1.append("(this Map)");
            } else {
               var1.append(var3);
            }

            this.initNext$kotlin_stdlib();
         }
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010'\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\b\u0000\u0018\u0000*\u0004\b\u0002\u0010\u0001*\u0004\b\u0003\u0010\u00022\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u0003B!\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00028\u0002\u0012\u0004\u0012\u00028\u00030\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0096\u0002J\b\u0010\u0012\u001a\u00020\u0007H\u0016J\u0015\u0010\u0013\u001a\u00028\u00032\u0006\u0010\u0014\u001a\u00028\u0003H\u0016¢\u0006\u0002\u0010\u0015J\b\u0010\u0016\u001a\u00020\u0017H\u0016R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u00028\u00028VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00028\u0002\u0012\u0004\u0012\u00028\u00030\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00028\u00038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000b¨\u0006\u0018"},
      d2 = {"Lga/strikepractice/kotlin/collections/builders/MapBuilder$EntryRef;", "K", "V", "", "map", "Lga/strikepractice/kotlin/collections/builders/MapBuilder;", "index", "", "(Lkotlin/collections/builders/MapBuilder;I)V", "key", "getKey", "()Ljava/lang/Object;", "value", "getValue", "equals", "", "other", "", "hashCode", "setValue", "newValue", "(Ljava/lang/Object;)Ljava/lang/Object;", "toString", "", "ga.strikepractice.kotlin-stdlib"}
   )
   public static final class EntryRef<K, V> implements KMutableMap.Entry, java.util.Map.Entry<K, V> {
      @NotNull
      private final MapBuilder<K, V> map;
      private final int index;

      public EntryRef(@NotNull MapBuilder<K, V> var1, int var2) {
         Intrinsics.checkNotNullParameter(var1, "map");
         super();
         this.map = var1;
         this.index = var2;
      }

      public K getKey() {
         return this.map.keysArray[this.index];
      }

      public V getValue() {
         Object[] var10000 = this.map.valuesArray;
         Intrinsics.checkNotNull(var10000);
         return var10000[this.index];
      }

      public V setValue(V var1) {
         this.map.checkIsMutable$kotlin_stdlib();
         Object[] var2 = this.map.allocateValuesArray();
         Object var3 = var2[this.index];
         var2[this.index] = var1;
         return var3;
      }

      public boolean equals(@Nullable Object var1) {
         return var1 instanceof java.util.Map.Entry && Intrinsics.areEqual(((java.util.Map.Entry)var1).getKey(), this.getKey()) && Intrinsics.areEqual(((java.util.Map.Entry)var1).getValue(), this.getValue());
      }

      public int hashCode() {
         Object var10000 = this.getKey();
         int var1 = var10000 != null ? var10000.hashCode() : 0;
         Object var10001 = this.getValue();
         return var1 ^ (var10001 != null ? var10001.hashCode() : 0);
      }

      @NotNull
      public String toString() {
         return "" + this.getKey() + '=' + this.getValue();
      }
   }
}
