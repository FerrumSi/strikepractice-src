package ga.strikepractice.kotlin.collections.builders;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.collections.CollectionsKt;
import ga.strikepractice.kotlin.collections.SetsKt;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import java.io.Externalizable;
import java.io.InvalidObjectException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u001e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u0000 \u00112\u00020\u0001:\u0001\u0011B\u0007\b\u0016¢\u0006\u0002\u0010\u0002B\u0019\u0012\n\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016J\b\u0010\f\u001a\u00020\rH\u0002J\u0010\u0010\u000e\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016R\u0012\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"},
   d2 = {"Lga/strikepractice/kotlin/collections/builders/SerializedCollection;", "Ljava/io/Externalizable;", "()V", "collection", "", "tag", "", "(Ljava/util/Collection;I)V", "readExternal", "", "input", "Ljava/io/ObjectInput;", "readResolve", "", "writeExternal", "output", "Ljava/io/ObjectOutput;", "Companion", "ga.strikepractice.kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nListBuilder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ListBuilder.kt\nkotlin/collections/builders/SerializedCollection\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,429:1\n1#2:430\n*E\n"})
public final class SerializedCollection implements Externalizable {
   @NotNull
   public static final SerializedCollection.Companion Companion = new SerializedCollection.Companion((DefaultConstructorMarker)null);
   @NotNull
   private Collection<?> collection;
   private final int tag;
   private static final long serialVersionUID = 0L;
   public static final int tagList = 0;
   public static final int tagSet = 1;

   public SerializedCollection(@NotNull Collection<?> var1, int var2) {
      Intrinsics.checkNotNullParameter(var1, "collection");
      super();
      this.collection = var1;
      this.tag = var2;
   }

   public SerializedCollection() {
      this((Collection)CollectionsKt.emptyList(), 0);
   }

   public void writeExternal(@NotNull ObjectOutput var1) {
      Intrinsics.checkNotNullParameter(var1, "output");
      var1.writeByte(this.tag);
      var1.writeInt(this.collection.size());
      Iterator var2 = this.collection.iterator();

      while(var2.hasNext()) {
         Object var3 = var2.next();
         var1.writeObject(var3);
      }

   }

   public void readExternal(@NotNull ObjectInput var1) {
      Intrinsics.checkNotNullParameter(var1, "input");
      byte var2 = var1.readByte();
      int var3 = var2 & 1;
      int var4 = var2 & -2;
      if (var4 != 0) {
         throw new InvalidObjectException("Unsupported flags value: " + var2 + '.');
      } else {
         int var5 = var1.readInt();
         if (var5 < 0) {
            throw new InvalidObjectException("Illegal size value: " + var5 + '.');
         } else {
            boolean var8;
            int var9;
            boolean var11;
            SerializedCollection var10000;
            Collection var10001;
            switch(var3) {
            case 0:
               List var13 = CollectionsKt.createListBuilder(var5);
               List var14 = var13;
               var8 = false;

               for(var9 = 0; var9 < var5; ++var9) {
                  var11 = false;
                  var14.add(var1.readObject());
               }

               var10000 = this;
               var10001 = (Collection)CollectionsKt.build(var13);
               break;
            case 1:
               Set var6 = SetsKt.createSetBuilder(var5);
               Set var7 = var6;
               var8 = false;

               for(var9 = 0; var9 < var5; ++var9) {
                  var11 = false;
                  var7.add(var1.readObject());
               }

               var10000 = this;
               var10001 = (Collection)SetsKt.build(var6);
               break;
            default:
               throw new InvalidObjectException("Unsupported collection type tag: " + var3 + '.');
            }

            var10000.collection = var10001;
         }
      }
   }

   private final Object readResolve() {
      return this.collection;
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0086T¢\u0006\u0002\n\u0000¨\u0006\b"},
      d2 = {"Lga/strikepractice/kotlin/collections/builders/SerializedCollection$Companion;", "", "()V", "serialVersionUID", "", "tagList", "", "tagSet", "ga.strikepractice.kotlin-stdlib"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker var1) {
         this();
      }
   }
}
