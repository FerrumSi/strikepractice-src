package ga.strikepractice.kotlin.collections.builders;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.collections.AbstractList;
import ga.strikepractice.kotlin.collections.AbstractMutableList;
import ga.strikepractice.kotlin.collections.ArrayDeque;
import ga.strikepractice.kotlin.collections.ArraysKt;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.jvm.internal.markers.KMutableList;
import ga.strikepractice.kotlin.jvm.internal.markers.KMutableListIterator;
import java.io.NotSerializableException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.RandomAccess;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\f\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u001e\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\b\b\n\u0002\u0010\u0000\n\u0002\b\b\n\u0002\u0010)\n\u0002\b\u0002\n\u0002\u0010+\n\u0002\b\u0015\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u00022\u00060\u0003j\u0002`\u00042\b\u0012\u0004\u0012\u0002H\u00010\u00052\u00060\u0006j\u0002`\u0007:\u0001VB\u0007\b\u0016¢\u0006\u0002\u0010\bB\u000f\b\u0016\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0002\u0010\u000bBM\b\u0002\u0012\f\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\r\u0012\u0006\u0010\u000e\u001a\u00020\n\u0012\u0006\u0010\u000f\u001a\u00020\n\u0012\u0006\u0010\u0010\u001a\u00020\u0011\u0012\u000e\u0010\u0012\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u0000\u0012\u000e\u0010\u0013\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u0000¢\u0006\u0002\u0010\u0014J\u0015\u0010\u001b\u001a\u00020\u00112\u0006\u0010\u001c\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u001dJ\u001d\u0010\u001b\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010 J\u001e\u0010!\u001a\u00020\u00112\u0006\u0010\u001f\u001a\u00020\n2\f\u0010\"\u001a\b\u0012\u0004\u0012\u00028\u00000#H\u0016J\u0016\u0010!\u001a\u00020\u00112\f\u0010\"\u001a\b\u0012\u0004\u0012\u00028\u00000#H\u0016J&\u0010$\u001a\u00020\u001e2\u0006\u0010%\u001a\u00020\n2\f\u0010\"\u001a\b\u0012\u0004\u0012\u00028\u00000#2\u0006\u0010&\u001a\u00020\nH\u0002J\u001d\u0010'\u001a\u00020\u001e2\u0006\u0010%\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00028\u0000H\u0002¢\u0006\u0002\u0010 J\f\u0010(\u001a\b\u0012\u0004\u0012\u00028\u00000)J\b\u0010*\u001a\u00020\u001eH\u0002J\b\u0010+\u001a\u00020\u001eH\u0016J\u0014\u0010,\u001a\u00020\u00112\n\u0010-\u001a\u0006\u0012\u0002\b\u00030)H\u0002J\u0010\u0010.\u001a\u00020\u001e2\u0006\u0010/\u001a\u00020\nH\u0002J\u0010\u00100\u001a\u00020\u001e2\u0006\u0010&\u001a\u00020\nH\u0002J\u0013\u00101\u001a\u00020\u00112\b\u0010-\u001a\u0004\u0018\u000102H\u0096\u0002J\u0016\u00103\u001a\u00028\u00002\u0006\u0010\u001f\u001a\u00020\nH\u0096\u0002¢\u0006\u0002\u00104J\b\u00105\u001a\u00020\nH\u0016J\u0015\u00106\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00028\u0000H\u0016¢\u0006\u0002\u00107J\u0018\u00108\u001a\u00020\u001e2\u0006\u0010%\u001a\u00020\n2\u0006\u0010&\u001a\u00020\nH\u0002J\b\u00109\u001a\u00020\u0011H\u0016J\u000f\u0010:\u001a\b\u0012\u0004\u0012\u00028\u00000;H\u0096\u0002J\u0015\u0010<\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00028\u0000H\u0016¢\u0006\u0002\u00107J\u000e\u0010=\u001a\b\u0012\u0004\u0012\u00028\u00000>H\u0016J\u0016\u0010=\u001a\b\u0012\u0004\u0012\u00028\u00000>2\u0006\u0010\u001f\u001a\u00020\nH\u0016J\u0015\u0010?\u001a\u00020\u00112\u0006\u0010\u001c\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u001dJ\u0016\u0010@\u001a\u00020\u00112\f\u0010\"\u001a\b\u0012\u0004\u0012\u00028\u00000#H\u0016J\u0015\u0010A\u001a\u00028\u00002\u0006\u0010\u001f\u001a\u00020\nH\u0016¢\u0006\u0002\u00104J\u0015\u0010B\u001a\u00028\u00002\u0006\u0010%\u001a\u00020\nH\u0002¢\u0006\u0002\u00104J\u0018\u0010C\u001a\u00020\u001e2\u0006\u0010D\u001a\u00020\n2\u0006\u0010E\u001a\u00020\nH\u0002J\u0016\u0010F\u001a\u00020\u00112\f\u0010\"\u001a\b\u0012\u0004\u0012\u00028\u00000#H\u0016J.\u0010G\u001a\u00020\n2\u0006\u0010D\u001a\u00020\n2\u0006\u0010E\u001a\u00020\n2\f\u0010\"\u001a\b\u0012\u0004\u0012\u00028\u00000#2\u0006\u0010H\u001a\u00020\u0011H\u0002J\u001e\u0010I\u001a\u00028\u00002\u0006\u0010\u001f\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00028\u0000H\u0096\u0002¢\u0006\u0002\u0010JJ\u001e\u0010K\u001a\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010L\u001a\u00020\n2\u0006\u0010M\u001a\u00020\nH\u0016J\u0015\u0010N\u001a\n\u0012\u0006\u0012\u0004\u0018\u0001020\rH\u0016¢\u0006\u0002\u0010OJ'\u0010N\u001a\b\u0012\u0004\u0012\u0002HP0\r\"\u0004\b\u0001\u0010P2\f\u0010Q\u001a\b\u0012\u0004\u0012\u0002HP0\rH\u0016¢\u0006\u0002\u0010RJ\b\u0010S\u001a\u00020TH\u0016J\b\u0010U\u001a\u000202H\u0002R\u0016\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\rX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0015R\u0016\u0010\u0012\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0016\u001a\u00020\u00118BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0013\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0018\u001a\u00020\n8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u001a¨\u0006W"},
   d2 = {"Lga/strikepractice/kotlin/collections/builders/ListBuilder;", "E", "", "Ljava/util/RandomAccess;", "Lga/strikepractice/kotlin/collections/RandomAccess;", "Lga/strikepractice/kotlin/collections/AbstractMutableList;", "Ljava/io/Serializable;", "Lga/strikepractice/kotlin/io/Serializable;", "()V", "initialCapacity", "", "(I)V", "array", "", "offset", "length", "isReadOnly", "", "backing", "root", "([Ljava/lang/Object;IIZLkotlin/collections/builders/ListBuilder;Lkotlin/collections/builders/ListBuilder;)V", "[Ljava/lang/Object;", "isEffectivelyReadOnly", "()Z", "size", "getSize", "()I", "add", "element", "(Ljava/lang/Object;)Z", "", "index", "(ILjava/lang/Object;)V", "addAll", "elements", "", "addAllInternal", "i", "n", "addAtInternal", "build", "", "checkIsMutable", "clear", "contentEquals", "other", "ensureCapacity", "minCapacity", "ensureExtraCapacity", "equals", "", "get", "(I)Ljava/lang/Object;", "hashCode", "indexOf", "(Ljava/lang/Object;)I", "insertAtInternal", "isEmpty", "iterator", "", "lastIndexOf", "listIterator", "", "remove", "removeAll", "removeAt", "removeAtInternal", "removeRangeInternal", "rangeOffset", "rangeLength", "retainAll", "retainOrRemoveAllInternal", "retain", "set", "(ILjava/lang/Object;)Ljava/lang/Object;", "subList", "fromIndex", "toIndex", "toArray", "()[Ljava/lang/Object;", "T", "destination", "([Ljava/lang/Object;)[Ljava/lang/Object;", "toString", "", "writeReplace", "Itr", "ga.strikepractice.kotlin-stdlib"}
)
public final class ListBuilder<E> extends AbstractMutableList<E> implements KMutableList, Serializable, List<E>, RandomAccess {
   @NotNull
   private E[] array;
   private int offset;
   private int length;
   private boolean isReadOnly;
   @Nullable
   private final ListBuilder<E> backing;
   @Nullable
   private final ListBuilder<E> root;

   private ListBuilder(E[] var1, int var2, int var3, boolean var4, ListBuilder<E> var5, ListBuilder<E> var6) {
      this.array = var1;
      this.offset = var2;
      this.length = var3;
      this.isReadOnly = var4;
      this.backing = var5;
      this.root = var6;
   }

   public ListBuilder() {
      this(10);
   }

   public ListBuilder(int var1) {
      this(ListBuilderKt.arrayOfUninitializedElements(var1), 0, 0, false, (ListBuilder)null, (ListBuilder)null);
   }

   @NotNull
   public final List<E> build() {
      if (this.backing != null) {
         throw new IllegalStateException();
      } else {
         this.checkIsMutable();
         this.isReadOnly = true;
         return (List)this;
      }
   }

   private final Object writeReplace() {
      if (this.isEffectivelyReadOnly()) {
         return new SerializedCollection((Collection)this, 0);
      } else {
         throw new NotSerializableException("The list cannot be serialized while it is being built.");
      }
   }

   public int getSize() {
      return this.length;
   }

   public boolean isEmpty() {
      return this.length == 0;
   }

   public E get(int var1) {
      AbstractList.Companion.checkElementIndex$kotlin_stdlib(var1, this.length);
      return this.array[this.offset + var1];
   }

   public E set(int var1, E var2) {
      this.checkIsMutable();
      AbstractList.Companion.checkElementIndex$kotlin_stdlib(var1, this.length);
      Object var3 = this.array[this.offset + var1];
      this.array[this.offset + var1] = var2;
      return var3;
   }

   public int indexOf(Object var1) {
      for(int var2 = 0; var2 < this.length; ++var2) {
         if (Intrinsics.areEqual(this.array[this.offset + var2], var1)) {
            return var2;
         }
      }

      return -1;
   }

   public int lastIndexOf(Object var1) {
      for(int var2 = this.length - 1; var2 >= 0; --var2) {
         if (Intrinsics.areEqual(this.array[this.offset + var2], var1)) {
            return var2;
         }
      }

      return -1;
   }

   @NotNull
   public Iterator<E> iterator() {
      return (Iterator)(new ListBuilder.Itr(this, 0));
   }

   @NotNull
   public ListIterator<E> listIterator() {
      return (ListIterator)(new ListBuilder.Itr(this, 0));
   }

   @NotNull
   public ListIterator<E> listIterator(int var1) {
      AbstractList.Companion.checkPositionIndex$kotlin_stdlib(var1, this.length);
      return (ListIterator)(new ListBuilder.Itr(this, var1));
   }

   public boolean add(E var1) {
      this.checkIsMutable();
      this.addAtInternal(this.offset + this.length, var1);
      return true;
   }

   public void add(int var1, E var2) {
      this.checkIsMutable();
      AbstractList.Companion.checkPositionIndex$kotlin_stdlib(var1, this.length);
      this.addAtInternal(this.offset + var1, var2);
   }

   public boolean addAll(@NotNull Collection<? extends E> var1) {
      Intrinsics.checkNotNullParameter(var1, "elements");
      this.checkIsMutable();
      int var2 = var1.size();
      this.addAllInternal(this.offset + this.length, var1, var2);
      return var2 > 0;
   }

   public boolean addAll(int var1, @NotNull Collection<? extends E> var2) {
      Intrinsics.checkNotNullParameter(var2, "elements");
      this.checkIsMutable();
      AbstractList.Companion.checkPositionIndex$kotlin_stdlib(var1, this.length);
      int var3 = var2.size();
      this.addAllInternal(this.offset + var1, var2, var3);
      return var3 > 0;
   }

   public void clear() {
      this.checkIsMutable();
      this.removeRangeInternal(this.offset, this.length);
   }

   public E removeAt(int var1) {
      this.checkIsMutable();
      AbstractList.Companion.checkElementIndex$kotlin_stdlib(var1, this.length);
      return this.removeAtInternal(this.offset + var1);
   }

   public boolean remove(Object var1) {
      this.checkIsMutable();
      int var2 = this.indexOf(var1);
      if (var2 >= 0) {
         this.remove(var2);
      }

      return var2 >= 0;
   }

   public boolean removeAll(@NotNull Collection<? extends Object> var1) {
      Intrinsics.checkNotNullParameter(var1, "elements");
      this.checkIsMutable();
      return this.retainOrRemoveAllInternal(this.offset, this.length, var1, false) > 0;
   }

   public boolean retainAll(@NotNull Collection<? extends Object> var1) {
      Intrinsics.checkNotNullParameter(var1, "elements");
      this.checkIsMutable();
      return this.retainOrRemoveAllInternal(this.offset, this.length, var1, true) > 0;
   }

   @NotNull
   public List<E> subList(int var1, int var2) {
      AbstractList.Companion.checkRangeIndexes$kotlin_stdlib(var1, var2, this.length);
      ListBuilder var10000 = new ListBuilder;
      Object[] var10002 = this.array;
      int var10003 = this.offset + var1;
      int var10004 = var2 - var1;
      boolean var10005 = this.isReadOnly;
      ListBuilder var10007 = this.root;
      if (var10007 == null) {
         var10007 = this;
      }

      var10000.<init>(var10002, var10003, var10004, var10005, this, var10007);
      return (List)var10000;
   }

   @NotNull
   public <T> T[] toArray(@NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var1, "destination");
      if (var1.length < this.length) {
         Object[] var10000 = Arrays.copyOfRange(this.array, this.offset, this.offset + this.length, var1.getClass());
         Intrinsics.checkNotNullExpressionValue(var10000, "copyOfRange(array, offse…h, destination.javaClass)");
         return var10000;
      } else {
         ArraysKt.copyInto(this.array, var1, 0, this.offset, this.offset + this.length);
         if (var1.length > this.length) {
            var1[this.length] = null;
         }

         return var1;
      }
   }

   @NotNull
   public Object[] toArray() {
      Object[] var1 = this.array;
      int var2 = this.offset;
      int var3 = this.offset + this.length;
      return ArraysKt.copyOfRange(var1, var2, var3);
   }

   public boolean equals(@Nullable Object var1) {
      return var1 == this || var1 instanceof List && this.contentEquals((List)var1);
   }

   public int hashCode() {
      return ListBuilderKt.access$subarrayContentHashCode(this.array, this.offset, this.length);
   }

   @NotNull
   public String toString() {
      return ListBuilderKt.access$subarrayContentToString(this.array, this.offset, this.length);
   }

   private final void ensureCapacity(int var1) {
      if (this.backing != null) {
         throw new IllegalStateException();
      } else if (var1 < 0) {
         throw new OutOfMemoryError();
      } else {
         if (var1 > this.array.length) {
            int var2 = ArrayDeque.Companion.newCapacity$kotlin_stdlib(this.array.length, var1);
            this.array = ListBuilderKt.copyOfUninitializedElements(this.array, var2);
         }

      }
   }

   private final void checkIsMutable() {
      if (this.isEffectivelyReadOnly()) {
         throw new UnsupportedOperationException();
      }
   }

   private final boolean isEffectivelyReadOnly() {
      return this.isReadOnly || this.root != null && this.root.isReadOnly;
   }

   private final void ensureExtraCapacity(int var1) {
      this.ensureCapacity(this.length + var1);
   }

   private final boolean contentEquals(List<?> var1) {
      return ListBuilderKt.access$subarrayContentEquals(this.array, this.offset, this.length, var1);
   }

   private final void insertAtInternal(int var1, int var2) {
      this.ensureExtraCapacity(var2);
      Object[] var3 = this.array;
      Object[] var4 = this.array;
      int var5 = this.offset + this.length;
      int var6 = var1 + var2;
      ArraysKt.copyInto(var3, var4, var6, var1, var5);
      this.length += var2;
   }

   private final void addAtInternal(int var1, E var2) {
      if (this.backing != null) {
         this.backing.addAtInternal(var1, var2);
         this.array = this.backing.array;
         int var3 = this.length++;
      } else {
         this.insertAtInternal(var1, 1);
         this.array[var1] = var2;
      }

   }

   private final void addAllInternal(int var1, Collection<? extends E> var2, int var3) {
      if (this.backing != null) {
         this.backing.addAllInternal(var1, var2, var3);
         this.array = this.backing.array;
         this.length += var3;
      } else {
         this.insertAtInternal(var1, var3);
         int var4 = 0;

         for(Iterator var5 = var2.iterator(); var4 < var3; ++var4) {
            this.array[var1 + var4] = var5.next();
         }
      }

   }

   private final E removeAtInternal(int var1) {
      Object var2;
      int var7;
      if (this.backing != null) {
         var2 = this.backing.removeAtInternal(var1);
         var7 = this.length;
         this.length = var7 + -1;
         return var2;
      } else {
         var2 = this.array[var1];
         Object[] var3 = this.array;
         Object[] var4 = this.array;
         int var5 = var1 + 1;
         int var6 = this.offset + this.length;
         ArraysKt.copyInto(var3, var4, var1, var5, var6);
         ListBuilderKt.resetAt(this.array, this.offset + this.length - 1);
         var7 = this.length;
         this.length = var7 + -1;
         return var2;
      }
   }

   private final void removeRangeInternal(int var1, int var2) {
      if (this.backing != null) {
         this.backing.removeRangeInternal(var1, var2);
      } else {
         Object[] var3 = this.array;
         Object[] var4 = this.array;
         int var5 = var1 + var2;
         int var6 = this.length;
         ArraysKt.copyInto(var3, var4, var1, var5, var6);
         ListBuilderKt.resetRange(this.array, this.length - var2, this.length);
      }

      this.length -= var2;
   }

   private final int retainOrRemoveAllInternal(int var1, int var2, Collection<? extends E> var3, boolean var4) {
      int var5;
      if (this.backing != null) {
         var5 = this.backing.retainOrRemoveAllInternal(var1, var2, var3, var4);
         this.length -= var5;
         return var5;
      } else {
         var5 = 0;
         int var6 = 0;

         while(var5 < var2) {
            if (var3.contains(this.array[var1 + var5]) == var4) {
               this.array[var1 + var6++] = this.array[var1 + var5++];
            } else {
               ++var5;
            }
         }

         int var7 = var2 - var6;
         Object[] var8 = this.array;
         Object[] var9 = this.array;
         int var10 = var1 + var2;
         int var11 = this.length;
         int var12 = var1 + var6;
         ArraysKt.copyInto(var8, var9, var12, var10, var11);
         ListBuilderKt.resetRange(this.array, this.length - var7, this.length);
         this.length -= var7;
         return var7;
      }
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010+\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\t\b\u0002\u0018\u0000*\u0004\b\u0001\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u001d\b\u0016\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\u0015\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010\fJ\t\u0010\r\u001a\u00020\u000eH\u0096\u0002J\b\u0010\u000f\u001a\u00020\u000eH\u0016J\u000e\u0010\u0010\u001a\u00028\u0001H\u0096\u0002¢\u0006\u0002\u0010\u0011J\b\u0010\u0012\u001a\u00020\u0006H\u0016J\r\u0010\u0013\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010\u0011J\b\u0010\u0014\u001a\u00020\u0006H\u0016J\b\u0010\u0015\u001a\u00020\nH\u0016J\u0015\u0010\u0016\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010\fR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"},
      d2 = {"Lga/strikepractice/kotlin/collections/builders/ListBuilder$Itr;", "E", "", "list", "Lga/strikepractice/kotlin/collections/builders/ListBuilder;", "index", "", "(Lkotlin/collections/builders/ListBuilder;I)V", "lastIndex", "add", "", "element", "(Ljava/lang/Object;)V", "hasNext", "", "hasPrevious", "next", "()Ljava/lang/Object;", "nextIndex", "previous", "previousIndex", "remove", "set", "ga.strikepractice.kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nListBuilder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ListBuilder.kt\nkotlin/collections/builders/ListBuilder$Itr\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,429:1\n1#2:430\n*E\n"})
   private static final class Itr<E> implements KMutableListIterator, ListIterator<E> {
      @NotNull
      private final ListBuilder<E> list;
      private int index;
      private int lastIndex;

      public Itr(@NotNull ListBuilder<E> var1, int var2) {
         Intrinsics.checkNotNullParameter(var1, "list");
         super();
         this.list = var1;
         this.index = var2;
         this.lastIndex = -1;
      }

      public boolean hasPrevious() {
         return this.index > 0;
      }

      public boolean hasNext() {
         return this.index < this.list.length;
      }

      public int previousIndex() {
         return this.index - 1;
      }

      public int nextIndex() {
         return this.index;
      }

      public E previous() {
         if (this.index <= 0) {
            throw new NoSuchElementException();
         } else {
            this.index += -1;
            this.lastIndex = this.index;
            return this.list.array[this.list.offset + this.lastIndex];
         }
      }

      public E next() {
         if (this.index >= this.list.length) {
            throw new NoSuchElementException();
         } else {
            int var1 = this.index++;
            this.lastIndex = var1;
            return this.list.array[this.list.offset + this.lastIndex];
         }
      }

      public void set(E var1) {
         boolean var2 = this.lastIndex != -1;
         if (!var2) {
            boolean var3 = false;
            String var4 = "Call next() or previous() before replacing element from the iterator.";
            throw new IllegalStateException(var4.toString());
         } else {
            this.list.set(this.lastIndex, var1);
         }
      }

      public void add(E var1) {
         ListBuilder var10000 = this.list;
         int var2 = this.index++;
         var10000.add(var2, var1);
         this.lastIndex = -1;
      }

      public void remove() {
         boolean var1 = this.lastIndex != -1;
         if (!var1) {
            boolean var2 = false;
            String var3 = "Call next() or previous() before removing element from the iterator.";
            throw new IllegalStateException(var3.toString());
         } else {
            this.list.remove(this.lastIndex);
            this.index = this.lastIndex;
            this.lastIndex = -1;
         }
      }
   }
}
