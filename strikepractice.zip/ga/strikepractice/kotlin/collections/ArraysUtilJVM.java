package ga.strikepractice.kotlin.collections;

import java.util.Arrays;
import java.util.List;

class ArraysUtilJVM {
   static <T> List<T> asList(T[] var0) {
      return Arrays.asList(var0);
   }
}
