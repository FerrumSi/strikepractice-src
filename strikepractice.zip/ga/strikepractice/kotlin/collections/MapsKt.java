package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;

@Metadata(
   mv = {1, 8, 0},
   k = 4,
   xi = 49,
   d1 = {"ga/strikepractice/kotlin/collections/MapsKt__MapWithDefaultKt", "ga/strikepractice/kotlin/collections/MapsKt__MapsJVMKt", "ga/strikepractice/kotlin/collections/MapsKt__MapsKt", "ga/strikepractice/kotlin/collections/MapsKt___MapsJvmKt", "ga/strikepractice/kotlin/collections/MapsKt___MapsKt"}
)
public final class MapsKt extends MapsKt___MapsKt {
   private MapsKt() {
   }
}
