package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.WasExperimental;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.functions.Function2;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.ranges.RangesKt;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u001e\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u001b\b\u0007\u0018\u0000 P*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002:\u0001PB\u000f\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005B\u0007\b\u0016¢\u0006\u0002\u0010\u0006B\u0015\b\u0016\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b¢\u0006\u0002\u0010\tJ\u0015\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u0016J\u001d\u0010\u0013\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00042\u0006\u0010\u0015\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u0019J\u001e\u0010\u001a\u001a\u00020\u00142\u0006\u0010\u0018\u001a\u00020\u00042\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\bH\u0016J\u0016\u0010\u001a\u001a\u00020\u00142\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\bH\u0016J\u0013\u0010\u001b\u001a\u00020\u00172\u0006\u0010\u0015\u001a\u00028\u0000¢\u0006\u0002\u0010\u001cJ\u0013\u0010\u001d\u001a\u00020\u00172\u0006\u0010\u0015\u001a\u00028\u0000¢\u0006\u0002\u0010\u001cJ\b\u0010\u001e\u001a\u00020\u0017H\u0016J\u0016\u0010\u001f\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00028\u0000H\u0096\u0002¢\u0006\u0002\u0010\u0016J\u001e\u0010 \u001a\u00020\u00172\u0006\u0010!\u001a\u00020\u00042\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\bH\u0002J\u0010\u0010\"\u001a\u00020\u00172\u0006\u0010#\u001a\u00020\u0004H\u0002J\u0010\u0010$\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004H\u0002J\u0010\u0010%\u001a\u00020\u00172\u0006\u0010&\u001a\u00020\u0004H\u0002J\u001d\u0010'\u001a\u00020\u00142\u0012\u0010(\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u00140)H\u0082\bJ\u000b\u0010*\u001a\u00028\u0000¢\u0006\u0002\u0010+J\r\u0010,\u001a\u0004\u0018\u00018\u0000¢\u0006\u0002\u0010+J\u0016\u0010-\u001a\u00028\u00002\u0006\u0010\u0018\u001a\u00020\u0004H\u0096\u0002¢\u0006\u0002\u0010.J\u0010\u0010/\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004H\u0002J\u0015\u00100\u001a\u00020\u00042\u0006\u0010\u0015\u001a\u00028\u0000H\u0016¢\u0006\u0002\u00101J\u0016\u00102\u001a\u00028\u00002\u0006\u0010!\u001a\u00020\u0004H\u0083\b¢\u0006\u0002\u0010.J\u0011\u0010!\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004H\u0083\bJM\u00103\u001a\u00020\u00172>\u00104\u001a:\u0012\u0013\u0012\u00110\u0004¢\u0006\f\b6\u0012\b\b7\u0012\u0004\b\b(\u000e\u0012\u001b\u0012\u0019\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000b¢\u0006\f\b6\u0012\b\b7\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\u001705H\u0000¢\u0006\u0002\b8J\b\u00109\u001a\u00020\u0014H\u0016J\u000b\u0010:\u001a\u00028\u0000¢\u0006\u0002\u0010+J\u0015\u0010;\u001a\u00020\u00042\u0006\u0010\u0015\u001a\u00028\u0000H\u0016¢\u0006\u0002\u00101J\r\u0010<\u001a\u0004\u0018\u00018\u0000¢\u0006\u0002\u0010+J\u0010\u0010=\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004H\u0002J\u0010\u0010>\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004H\u0002J\u0015\u0010?\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u0016J\u0016\u0010@\u001a\u00020\u00142\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\bH\u0016J\u0015\u0010A\u001a\u00028\u00002\u0006\u0010\u0018\u001a\u00020\u0004H\u0016¢\u0006\u0002\u0010.J\u000b\u0010B\u001a\u00028\u0000¢\u0006\u0002\u0010+J\r\u0010C\u001a\u0004\u0018\u00018\u0000¢\u0006\u0002\u0010+J\u000b\u0010D\u001a\u00028\u0000¢\u0006\u0002\u0010+J\r\u0010E\u001a\u0004\u0018\u00018\u0000¢\u0006\u0002\u0010+J\u0016\u0010F\u001a\u00020\u00142\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\bH\u0016J\u001e\u0010G\u001a\u00028\u00002\u0006\u0010\u0018\u001a\u00020\u00042\u0006\u0010\u0015\u001a\u00028\u0000H\u0096\u0002¢\u0006\u0002\u0010HJ\u0017\u0010I\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000bH\u0000¢\u0006\u0004\bJ\u0010KJ)\u0010I\u001a\b\u0012\u0004\u0012\u0002HL0\u000b\"\u0004\b\u0001\u0010L2\f\u0010M\u001a\b\u0012\u0004\u0012\u0002HL0\u000bH\u0000¢\u0006\u0004\bJ\u0010NJ\u0015\u0010O\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000bH\u0016¢\u0006\u0002\u0010KJ'\u0010O\u001a\b\u0012\u0004\u0012\u0002HL0\u000b\"\u0004\b\u0001\u0010L2\f\u0010M\u001a\b\u0012\u0004\u0012\u0002HL0\u000bH\u0016¢\u0006\u0002\u0010NR\u0018\u0010\n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000bX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\rR\u000e\u0010\u000e\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u0004@RX\u0096\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006Q"},
   d2 = {"Lga/strikepractice/kotlin/collections/ArrayDeque;", "E", "Lga/strikepractice/kotlin/collections/AbstractMutableList;", "initialCapacity", "", "(I)V", "()V", "elements", "", "(Ljava/util/Collection;)V", "elementData", "", "", "[Ljava/lang/Object;", "head", "<set-?>", "size", "getSize", "()I", "add", "", "element", "(Ljava/lang/Object;)Z", "", "index", "(ILjava/lang/Object;)V", "addAll", "addFirst", "(Ljava/lang/Object;)V", "addLast", "clear", "contains", "copyCollectionElements", "internalIndex", "copyElements", "newCapacity", "decremented", "ensureCapacity", "minCapacity", "filterInPlace", "predicate", "Lga/strikepractice/kotlin/Function1;", "first", "()Ljava/lang/Object;", "firstOrNull", "get", "(I)Ljava/lang/Object;", "incremented", "indexOf", "(Ljava/lang/Object;)I", "internalGet", "internalStructure", "structure", "Lga/strikepractice/kotlin/Function2;", "Lga/strikepractice/kotlin/ParameterName;", "name", "internalStructure$kotlin_stdlib", "isEmpty", "last", "lastIndexOf", "lastOrNull", "negativeMod", "positiveMod", "remove", "removeAll", "removeAt", "removeFirst", "removeFirstOrNull", "removeLast", "removeLastOrNull", "retainAll", "set", "(ILjava/lang/Object;)Ljava/lang/Object;", "testToArray", "testToArray$kotlin_stdlib", "()[Ljava/lang/Object;", "T", "array", "([Ljava/lang/Object;)[Ljava/lang/Object;", "toArray", "Companion", "ga.strikepractice.kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.4"
)
@WasExperimental(
   markerClass = {ExperimentalStdlibApi.class}
)
@SourceDebugExtension({"SMAP\nArrayDeque.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ArrayDeque.kt\nkotlin/collections/ArrayDeque\n+ 2 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 3 ArrayIntrinsics.kt\nkotlin/ArrayIntrinsicsKt\n*L\n1#1,583:1\n467#1,51:586\n467#1,51:637\n37#2,2:584\n26#3:688\n*S KotlinDebug\n*F\n+ 1 ArrayDeque.kt\nkotlin/collections/ArrayDeque\n*L\n462#1:586,51\n464#1:637,51\n47#1:584,2\n562#1:688\n*E\n"})
public final class ArrayDeque<E> extends AbstractMutableList<E> {
   @NotNull
   public static final ArrayDeque.Companion Companion = new ArrayDeque.Companion((DefaultConstructorMarker)null);
   private int head;
   @NotNull
   private Object[] elementData;
   private int size;
   @NotNull
   private static final Object[] emptyElementData;
   private static final int maxArraySize = 2147483639;
   private static final int defaultMinCapacity = 10;

   public int getSize() {
      return this.size;
   }

   public ArrayDeque(int var1) {
      Object[] var10001;
      if (var1 == 0) {
         var10001 = emptyElementData;
      } else {
         if (var1 <= 0) {
            throw new IllegalArgumentException("Illegal Capacity: " + var1);
         }

         var10001 = new Object[var1];
      }

      this.elementData = var10001;
   }

   public ArrayDeque() {
      this.elementData = emptyElementData;
   }

   public ArrayDeque(@NotNull Collection<? extends E> var1) {
      Intrinsics.checkNotNullParameter(var1, "elements");
      super();
      boolean var3 = false;
      this.elementData = var1.toArray(new Object[0]);
      this.size = this.elementData.length;
      if (this.elementData.length == 0) {
         this.elementData = emptyElementData;
      }

   }

   private final void ensureCapacity(int var1) {
      if (var1 < 0) {
         throw new IllegalStateException("Deque is too big.");
      } else if (var1 > this.elementData.length) {
         if (this.elementData == emptyElementData) {
            this.elementData = new Object[RangesKt.coerceAtLeast(var1, 10)];
         } else {
            int var2 = Companion.newCapacity$kotlin_stdlib(this.elementData.length, var1);
            this.copyElements(var2);
         }
      }
   }

   private final void copyElements(int var1) {
      Object[] var2 = new Object[var1];
      ArraysKt.copyInto(this.elementData, var2, 0, this.head, this.elementData.length);
      ArraysKt.copyInto(this.elementData, var2, this.elementData.length - this.head, 0, this.head);
      this.head = 0;
      this.elementData = var2;
   }

   @InlineOnly
   private final E internalGet(int var1) {
      return this.elementData[var1];
   }

   private final int positiveMod(int var1) {
      return var1 >= this.elementData.length ? var1 - this.elementData.length : var1;
   }

   private final int negativeMod(int var1) {
      return var1 < 0 ? var1 + this.elementData.length : var1;
   }

   @InlineOnly
   private final int internalIndex(int var1) {
      return this.positiveMod(this.head + var1);
   }

   private final int incremented(int var1) {
      return var1 == ArraysKt.getLastIndex(this.elementData) ? 0 : var1 + 1;
   }

   private final int decremented(int var1) {
      return var1 == 0 ? ArraysKt.getLastIndex(this.elementData) : var1 - 1;
   }

   public boolean isEmpty() {
      return this.size() == 0;
   }

   public final E first() {
      if (this.isEmpty()) {
         throw new NoSuchElementException("ArrayDeque is empty.");
      } else {
         return this.elementData[this.head];
      }
   }

   @Nullable
   public final E firstOrNull() {
      return this.isEmpty() ? null : this.elementData[this.head];
   }

   public final E last() {
      if (this.isEmpty()) {
         throw new NoSuchElementException("ArrayDeque is empty.");
      } else {
         return this.elementData[this.positiveMod(this.head + CollectionsKt.getLastIndex((List)this))];
      }
   }

   @Nullable
   public final E lastOrNull() {
      return this.isEmpty() ? null : this.elementData[this.positiveMod(this.head + CollectionsKt.getLastIndex((List)this))];
   }

   public final void addFirst(E var1) {
      this.ensureCapacity(this.size() + 1);
      this.head = this.decremented(this.head);
      this.elementData[this.head] = var1;
      this.size = this.size() + 1;
   }

   public final void addLast(E var1) {
      this.ensureCapacity(this.size() + 1);
      this.elementData[this.positiveMod(this.head + this.size())] = var1;
      this.size = this.size() + 1;
   }

   public final E removeFirst() {
      if (this.isEmpty()) {
         throw new NoSuchElementException("ArrayDeque is empty.");
      } else {
         Object var1 = this.elementData[this.head];
         this.elementData[this.head] = null;
         this.head = this.incremented(this.head);
         this.size = this.size() - 1;
         return var1;
      }
   }

   @Nullable
   public final E removeFirstOrNull() {
      return this.isEmpty() ? null : this.removeFirst();
   }

   public final E removeLast() {
      if (this.isEmpty()) {
         throw new NoSuchElementException("ArrayDeque is empty.");
      } else {
         int var1 = this.positiveMod(this.head + CollectionsKt.getLastIndex((List)this));
         Object var2 = this.elementData[var1];
         this.elementData[var1] = null;
         this.size = this.size() - 1;
         return var2;
      }
   }

   @Nullable
   public final E removeLastOrNull() {
      return this.isEmpty() ? null : this.removeLast();
   }

   public boolean add(E var1) {
      this.addLast(var1);
      return true;
   }

   public void add(int var1, E var2) {
      AbstractList.Companion.checkPositionIndex$kotlin_stdlib(var1, this.size());
      if (var1 == this.size()) {
         this.addLast(var2);
      } else if (var1 == 0) {
         this.addFirst(var2);
      } else {
         this.ensureCapacity(this.size() + 1);
         int var3 = this.positiveMod(this.head + var1);
         int var4;
         if (var1 < this.size() + 1 >> 1) {
            var4 = this.decremented(var3);
            int var5 = this.decremented(this.head);
            if (var4 >= this.head) {
               this.elementData[var5] = this.elementData[this.head];
               ArraysKt.copyInto(this.elementData, this.elementData, this.head, this.head + 1, var4 + 1);
            } else {
               ArraysKt.copyInto(this.elementData, this.elementData, this.head - 1, this.head, this.elementData.length);
               this.elementData[this.elementData.length - 1] = this.elementData[0];
               ArraysKt.copyInto(this.elementData, this.elementData, 0, 1, var4 + 1);
            }

            this.elementData[var4] = var2;
            this.head = var5;
         } else {
            var4 = this.positiveMod(this.head + this.size());
            if (var3 < var4) {
               ArraysKt.copyInto(this.elementData, this.elementData, var3 + 1, var3, var4);
            } else {
               ArraysKt.copyInto(this.elementData, this.elementData, 1, 0, var4);
               this.elementData[0] = this.elementData[this.elementData.length - 1];
               ArraysKt.copyInto(this.elementData, this.elementData, var3 + 1, var3, this.elementData.length - 1);
            }

            this.elementData[var3] = var2;
         }

         this.size = this.size() + 1;
      }
   }

   private final void copyCollectionElements(int var1, Collection<? extends E> var2) {
      Iterator var3 = var2.iterator();
      int var4 = var1;

      int var5;
      for(var5 = this.elementData.length; var4 < var5 && var3.hasNext(); ++var4) {
         this.elementData[var4] = var3.next();
      }

      var4 = 0;

      for(var5 = this.head; var4 < var5 && var3.hasNext(); ++var4) {
         this.elementData[var4] = var3.next();
      }

      this.size = this.size() + var2.size();
   }

   public boolean addAll(@NotNull Collection<? extends E> var1) {
      Intrinsics.checkNotNullParameter(var1, "elements");
      if (var1.isEmpty()) {
         return false;
      } else {
         this.ensureCapacity(this.size() + var1.size());
         this.copyCollectionElements(this.positiveMod(this.head + this.size()), var1);
         return true;
      }
   }

   public boolean addAll(int var1, @NotNull Collection<? extends E> var2) {
      Intrinsics.checkNotNullParameter(var2, "elements");
      AbstractList.Companion.checkPositionIndex$kotlin_stdlib(var1, this.size());
      if (var2.isEmpty()) {
         return false;
      } else if (var1 == this.size()) {
         return this.addAll(var2);
      } else {
         this.ensureCapacity(this.size() + var2.size());
         int var3 = this.positiveMod(this.head + this.size());
         int var4 = this.positiveMod(this.head + var1);
         int var5 = var2.size();
         int var6;
         int var7;
         if (var1 < this.size() + 1 >> 1) {
            var6 = this.head - var5;
            if (var4 >= this.head) {
               if (var6 >= 0) {
                  ArraysKt.copyInto(this.elementData, this.elementData, var6, this.head, var4);
               } else {
                  var6 += this.elementData.length;
                  var7 = var4 - this.head;
                  int var8 = this.elementData.length - var6;
                  if (var8 >= var7) {
                     ArraysKt.copyInto(this.elementData, this.elementData, var6, this.head, var4);
                  } else {
                     ArraysKt.copyInto(this.elementData, this.elementData, var6, this.head, this.head + var8);
                     ArraysKt.copyInto(this.elementData, this.elementData, 0, this.head + var8, var4);
                  }
               }
            } else {
               ArraysKt.copyInto(this.elementData, this.elementData, var6, this.head, this.elementData.length);
               if (var5 >= var4) {
                  ArraysKt.copyInto(this.elementData, this.elementData, this.elementData.length - var5, 0, var4);
               } else {
                  ArraysKt.copyInto(this.elementData, this.elementData, this.elementData.length - var5, 0, var5);
                  ArraysKt.copyInto(this.elementData, this.elementData, 0, var5, var4);
               }
            }

            this.head = var6;
            this.copyCollectionElements(this.negativeMod(var4 - var5), var2);
         } else {
            var6 = var4 + var5;
            if (var4 < var3) {
               if (var3 + var5 <= this.elementData.length) {
                  ArraysKt.copyInto(this.elementData, this.elementData, var6, var4, var3);
               } else if (var6 >= this.elementData.length) {
                  ArraysKt.copyInto(this.elementData, this.elementData, var6 - this.elementData.length, var4, var3);
               } else {
                  var7 = var3 + var5 - this.elementData.length;
                  ArraysKt.copyInto(this.elementData, this.elementData, 0, var3 - var7, var3);
                  ArraysKt.copyInto(this.elementData, this.elementData, var6, var4, var3 - var7);
               }
            } else {
               ArraysKt.copyInto(this.elementData, this.elementData, var5, 0, var3);
               if (var6 >= this.elementData.length) {
                  ArraysKt.copyInto(this.elementData, this.elementData, var6 - this.elementData.length, var4, this.elementData.length);
               } else {
                  ArraysKt.copyInto(this.elementData, this.elementData, 0, this.elementData.length - var5, this.elementData.length);
                  ArraysKt.copyInto(this.elementData, this.elementData, var6, var4, this.elementData.length - var5);
               }
            }

            this.copyCollectionElements(var4, var2);
         }

         return true;
      }
   }

   public E get(int var1) {
      AbstractList.Companion.checkElementIndex$kotlin_stdlib(var1, this.size());
      return this.elementData[this.positiveMod(this.head + var1)];
   }

   public E set(int var1, E var2) {
      AbstractList.Companion.checkElementIndex$kotlin_stdlib(var1, this.size());
      int var3 = this.positiveMod(this.head + var1);
      Object var4 = this.elementData[var3];
      this.elementData[var3] = var2;
      return var4;
   }

   public boolean contains(Object var1) {
      return this.indexOf(var1) != -1;
   }

   public int indexOf(Object var1) {
      int var2 = this.positiveMod(this.head + this.size());
      int var3;
      if (this.head < var2) {
         for(var3 = this.head; var3 < var2; ++var3) {
            if (Intrinsics.areEqual(var1, this.elementData[var3])) {
               return var3 - this.head;
            }
         }
      } else if (this.head >= var2) {
         var3 = this.head;

         for(int var4 = this.elementData.length; var3 < var4; ++var3) {
            if (Intrinsics.areEqual(var1, this.elementData[var3])) {
               return var3 - this.head;
            }
         }

         for(var3 = 0; var3 < var2; ++var3) {
            if (Intrinsics.areEqual(var1, this.elementData[var3])) {
               return var3 + this.elementData.length - this.head;
            }
         }
      }

      return -1;
   }

   public int lastIndexOf(Object var1) {
      int var2 = this.positiveMod(this.head + this.size());
      int var3;
      int var4;
      if (this.head < var2) {
         var3 = var2 - 1;
         var4 = this.head;
         if (var4 <= var3) {
            while(true) {
               if (Intrinsics.areEqual(var1, this.elementData[var3])) {
                  return var3 - this.head;
               }

               if (var3 == var4) {
                  break;
               }

               --var3;
            }
         }
      } else if (this.head > var2) {
         for(var3 = var2 - 1; -1 < var3; --var3) {
            if (Intrinsics.areEqual(var1, this.elementData[var3])) {
               return var3 + this.elementData.length - this.head;
            }
         }

         var3 = ArraysKt.getLastIndex(this.elementData);
         var4 = this.head;
         if (var4 <= var3) {
            while(true) {
               if (Intrinsics.areEqual(var1, this.elementData[var3])) {
                  return var3 - this.head;
               }

               if (var3 == var4) {
                  break;
               }

               --var3;
            }
         }
      }

      return -1;
   }

   public boolean remove(Object var1) {
      int var2 = this.indexOf(var1);
      if (var2 == -1) {
         return false;
      } else {
         this.remove(var2);
         return true;
      }
   }

   public E removeAt(int var1) {
      AbstractList.Companion.checkElementIndex$kotlin_stdlib(var1, this.size());
      if (var1 == CollectionsKt.getLastIndex((List)this)) {
         return this.removeLast();
      } else if (var1 == 0) {
         return this.removeFirst();
      } else {
         int var2 = this.positiveMod(this.head + var1);
         Object var3 = this.elementData[var2];
         if (var1 < this.size() >> 1) {
            if (var2 >= this.head) {
               ArraysKt.copyInto(this.elementData, this.elementData, this.head + 1, this.head, var2);
            } else {
               ArraysKt.copyInto(this.elementData, this.elementData, 1, 0, var2);
               this.elementData[0] = this.elementData[this.elementData.length - 1];
               ArraysKt.copyInto(this.elementData, this.elementData, this.head + 1, this.head, this.elementData.length - 1);
            }

            this.elementData[this.head] = null;
            this.head = this.incremented(this.head);
         } else {
            int var4 = this.positiveMod(this.head + CollectionsKt.getLastIndex((List)this));
            if (var2 <= var4) {
               ArraysKt.copyInto(this.elementData, this.elementData, var2, var2 + 1, var4 + 1);
            } else {
               ArraysKt.copyInto(this.elementData, this.elementData, var2, var2 + 1, this.elementData.length);
               this.elementData[this.elementData.length - 1] = this.elementData[0];
               ArraysKt.copyInto(this.elementData, this.elementData, 0, 1, var4 + 1);
            }

            this.elementData[var4] = null;
         }

         this.size = this.size() - 1;
         return var3;
      }
   }

   public boolean removeAll(@NotNull Collection<? extends Object> var1) {
      Intrinsics.checkNotNullParameter(var1, "elements");
      ArrayDeque var2 = this;
      boolean var3 = false;
      boolean var10000;
      if (!this.isEmpty() && this.elementData.length != 0) {
         int var4 = this.positiveMod(this.head + this.size());
         int var5 = this.head;
         boolean var6 = false;
         int var7;
         Object var12;
         if (this.head < var4) {
            for(var7 = this.head; var7 < var4; ++var7) {
               var12 = var2.elementData[var7];
               boolean var10 = false;
               if (!var1.contains(var12)) {
                  var2.elementData[var5++] = var12;
               } else {
                  var6 = true;
               }
            }

            ArraysKt.fill(var2.elementData, (Object)null, var5, var4);
         } else {
            var7 = this.head;

            boolean var11;
            for(int var8 = this.elementData.length; var7 < var8; ++var7) {
               Object var9 = var2.elementData[var7];
               var2.elementData[var7] = null;
               var11 = false;
               if (!var1.contains(var9)) {
                  var2.elementData[var5++] = var9;
               } else {
                  var6 = true;
               }
            }

            var5 = var2.positiveMod(var5);

            for(var7 = 0; var7 < var4; ++var7) {
               var12 = var2.elementData[var7];
               var2.elementData[var7] = null;
               var11 = false;
               if (!var1.contains(var12)) {
                  var2.elementData[var5] = var12;
                  var5 = var2.incremented(var5);
               } else {
                  var6 = true;
               }
            }
         }

         if (var6) {
            var2.size = var2.negativeMod(var5 - var2.head);
         }

         var10000 = var6;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean retainAll(@NotNull Collection<? extends Object> var1) {
      Intrinsics.checkNotNullParameter(var1, "elements");
      ArrayDeque var2 = this;
      boolean var3 = false;
      boolean var10000;
      if (!this.isEmpty() && this.elementData.length != 0) {
         int var4 = this.positiveMod(this.head + this.size());
         int var5 = this.head;
         boolean var6 = false;
         int var7;
         Object var12;
         if (this.head < var4) {
            for(var7 = this.head; var7 < var4; ++var7) {
               var12 = var2.elementData[var7];
               boolean var10 = false;
               if (var1.contains(var12)) {
                  var2.elementData[var5++] = var12;
               } else {
                  var6 = true;
               }
            }

            ArraysKt.fill(var2.elementData, (Object)null, var5, var4);
         } else {
            var7 = this.head;

            boolean var11;
            for(int var8 = this.elementData.length; var7 < var8; ++var7) {
               Object var9 = var2.elementData[var7];
               var2.elementData[var7] = null;
               var11 = false;
               if (var1.contains(var9)) {
                  var2.elementData[var5++] = var9;
               } else {
                  var6 = true;
               }
            }

            var5 = var2.positiveMod(var5);

            for(var7 = 0; var7 < var4; ++var7) {
               var12 = var2.elementData[var7];
               var2.elementData[var7] = null;
               var11 = false;
               if (var1.contains(var12)) {
                  var2.elementData[var5] = var12;
                  var5 = var2.incremented(var5);
               } else {
                  var6 = true;
               }
            }
         }

         if (var6) {
            var2.size = var2.negativeMod(var5 - var2.head);
         }

         var10000 = var6;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private final boolean filterInPlace(Function1<? super E, Boolean> var1) {
      boolean var2 = false;
      if (!this.isEmpty() && this.elementData.length != 0) {
         int var3 = this.positiveMod(this.head + this.size());
         int var4 = this.head;
         boolean var5 = false;
         int var6;
         Object var7;
         if (this.head < var3) {
            for(var6 = this.head; var6 < var3; ++var6) {
               var7 = this.elementData[var6];
               if ((Boolean)var1.invoke(var7)) {
                  this.elementData[var4++] = var7;
               } else {
                  var5 = true;
               }
            }

            ArraysKt.fill(this.elementData, (Object)null, var4, var3);
         } else {
            var6 = this.head;

            for(int var9 = this.elementData.length; var6 < var9; ++var6) {
               Object var8 = this.elementData[var6];
               this.elementData[var6] = null;
               if ((Boolean)var1.invoke(var8)) {
                  this.elementData[var4++] = var8;
               } else {
                  var5 = true;
               }
            }

            var4 = this.positiveMod(var4);

            for(var6 = 0; var6 < var3; ++var6) {
               var7 = this.elementData[var6];
               this.elementData[var6] = null;
               if ((Boolean)var1.invoke(var7)) {
                  this.elementData[var4] = var7;
                  var4 = this.incremented(var4);
               } else {
                  var5 = true;
               }
            }
         }

         if (var5) {
            this.size = this.negativeMod(var4 - this.head);
         }

         return var5;
      } else {
         return false;
      }
   }

   public void clear() {
      int var1 = this.positiveMod(this.head + this.size());
      if (this.head < var1) {
         ArraysKt.fill(this.elementData, (Object)null, this.head, var1);
      } else if (!((Collection)this).isEmpty()) {
         ArraysKt.fill(this.elementData, (Object)null, this.head, this.elementData.length);
         ArraysKt.fill(this.elementData, (Object)null, 0, var1);
      }

      this.head = 0;
      this.size = 0;
   }

   @NotNull
   public <T> T[] toArray(@NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var1, "array");
      Object[] var2 = var1.length >= this.size() ? var1 : ArraysKt.arrayOfNulls(var1, this.size());
      int var3 = this.positiveMod(this.head + this.size());
      if (this.head < var3) {
         ArraysKt.copyInto$default(this.elementData, var2, 0, this.head, var3, 2, (Object)null);
      } else if (!((Collection)this).isEmpty()) {
         ArraysKt.copyInto(this.elementData, var2, 0, this.head, this.elementData.length);
         ArraysKt.copyInto(this.elementData, var2, this.elementData.length - this.head, 0, var3);
      }

      if (var2.length > this.size()) {
         var2[this.size()] = null;
      }

      return var2;
   }

   @NotNull
   public Object[] toArray() {
      return this.toArray(new Object[this.size()]);
   }

   @NotNull
   public final <T> T[] testToArray$kotlin_stdlib(@NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var1, "array");
      return this.toArray(var1);
   }

   @NotNull
   public final Object[] testToArray$kotlin_stdlib() {
      return this.toArray();
   }

   public final void internalStructure$kotlin_stdlib(@NotNull Function2<? super Integer, ? super Object[], Unit> var1) {
      Intrinsics.checkNotNullParameter(var1, "structure");
      int var2 = this.positiveMod(this.head + this.size());
      int var3 = !this.isEmpty() && this.head >= var2 ? this.head - this.elementData.length : this.head;
      var1.invoke(var3, this.toArray());
   }

   static {
      boolean var0 = false;
      emptyElementData = new Object[0];
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0007\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001d\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u0004H\u0000¢\u0006\u0002\b\fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u0018\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u0006X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0007R\u000e\u0010\b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\r"},
      d2 = {"Lga/strikepractice/kotlin/collections/ArrayDeque$Companion;", "", "()V", "defaultMinCapacity", "", "emptyElementData", "", "[Ljava/lang/Object;", "maxArraySize", "newCapacity", "oldCapacity", "minCapacity", "newCapacity$kotlin_stdlib", "ga.strikepractice.kotlin-stdlib"}
   )
   public static final class Companion {
      private Companion() {
      }

      public final int newCapacity$kotlin_stdlib(int var1, int var2) {
         int var3 = var1 + (var1 >> 1);
         if (var3 - var2 < 0) {
            var3 = var2;
         }

         if (var3 - 2147483639 > 0) {
            var3 = var2 > 2147483639 ? Integer.MAX_VALUE : 2147483639;
         }

         return var3;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker var1) {
         this();
      }
   }
}
