package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.markers.KMappedMarker;
import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\u0010\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\u0010&\n\u0002\b\u0005\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u001e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0010\u000e\n\u0000\bÂ\u0002\u0018\u00002\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u00060\u0004j\u0002`\u0005B\u0007\b\u0002¢\u0006\u0002\u0010\u0006J\u0012\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0002H\u0016J\u0010\u0010\u001b\u001a\u00020\u00192\u0006\u0010\u001c\u001a\u00020\u0003H\u0016J\u0013\u0010\u001d\u001a\u00020\u00192\b\u0010\u001e\u001a\u0004\u0018\u00010\u0002H\u0096\u0002J\u0015\u0010\u001f\u001a\u0004\u0018\u00010\u00032\b\u0010\u001a\u001a\u0004\u0018\u00010\u0002H\u0096\u0002J\b\u0010 \u001a\u00020\u0011H\u0016J\b\u0010!\u001a\u00020\u0019H\u0016J\b\u0010\"\u001a\u00020\u0002H\u0002J\b\u0010#\u001a\u00020$H\u0016R(\u0010\u0007\u001a\u0016\u0012\u0012\u0012\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\u0004\u0012\u00020\u00030\t0\b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u001c\u0010\f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000bR\u000e\u0010\u000e\u001a\u00020\u000fX\u0082T¢\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\u00020\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00030\u00158VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017¨\u0006%"},
   d2 = {"Lga/strikepractice/kotlin/collections/EmptyMap;", "", "", "", "Ljava/io/Serializable;", "Lga/strikepractice/kotlin/io/Serializable;", "()V", "entries", "", "", "getEntries", "()Ljava/util/Set;", "keys", "getKeys", "serialVersionUID", "", "size", "", "getSize", "()I", "values", "", "getValues", "()Ljava/util/Collection;", "containsKey", "", "key", "containsValue", "value", "equals", "other", "get", "hashCode", "isEmpty", "readResolve", "toString", "", "ga.strikepractice.kotlin-stdlib"}
)
final class EmptyMap implements KMappedMarker, Serializable, Map {
   @NotNull
   public static final EmptyMap INSTANCE = new EmptyMap();
   private static final long serialVersionUID = 8246714829545688274L;

   private EmptyMap() {
   }

   public boolean equals(@Nullable Object var1) {
      return var1 instanceof Map && ((Map)var1).isEmpty();
   }

   public int hashCode() {
      return 0;
   }

   @NotNull
   public String toString() {
      return "{}";
   }

   public int getSize() {
      return 0;
   }

   public boolean isEmpty() {
      return true;
   }

   public boolean containsKey(@Nullable Object var1) {
      return false;
   }

   public boolean containsValue(@NotNull Void var1) {
      Intrinsics.checkNotNullParameter(var1, "value");
      return false;
   }

   @Nullable
   public Void get(@Nullable Object var1) {
      return null;
   }

   @NotNull
   public Set<Entry> getEntries() {
      return (Set)EmptySet.INSTANCE;
   }

   @NotNull
   public Set<Object> getKeys() {
      return (Set)EmptySet.INSTANCE;
   }

   @NotNull
   public Collection getValues() {
      return (Collection)EmptyList.INSTANCE;
   }

   private final Object readResolve() {
      return INSTANCE;
   }

   public void clear() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public Void put(Object var1, Void var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public void putAll(Map var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public Void remove(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public final int size() {
      return this.getSize();
   }

   public final Set<Entry> entrySet() {
      return this.getEntries();
   }

   public final Set<Object> keySet() {
      return this.getKeys();
   }

   public final Collection values() {
      return this.getValues();
   }

   // $FF: synthetic method
   public Object put(Object var1, Object var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }
}
