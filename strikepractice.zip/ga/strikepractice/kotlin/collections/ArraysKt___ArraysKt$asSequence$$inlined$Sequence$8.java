package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.ArrayIteratorsKt;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.sequences.Sequence;
import java.util.Iterator;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010(\n\u0000*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u000f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00028\u00000\u0003H\u0096\u0002¨\u0006\u0004¸\u0006\u0000"},
   d2 = {"ga/strikepractice/kotlin/sequences/SequencesKt__SequencesKt$Sequence$1", "Lga/strikepractice/kotlin/sequences/Sequence;", "iterator", "", "ga.strikepractice.kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nSequences.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Sequences.kt\nkotlin/sequences/SequencesKt__SequencesKt$Sequence$1\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,680:1\n24380#2:681\n*E\n"})
public final class ArraysKt___ArraysKt$asSequence$$inlined$Sequence$8 implements Sequence<Boolean> {
   // $FF: synthetic field
   final boolean[] $this_asSequence$inlined;

   public ArraysKt___ArraysKt$asSequence$$inlined$Sequence$8(boolean[] var1) {
      this.$this_asSequence$inlined = var1;
   }

   @NotNull
   public Iterator<Boolean> iterator() {
      boolean var1 = false;
      return (Iterator)ArrayIteratorsKt.iterator(this.$this_asSequence$inlined);
   }
}
