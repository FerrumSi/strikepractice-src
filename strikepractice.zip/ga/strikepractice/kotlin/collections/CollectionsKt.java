package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;

@Metadata(
   mv = {1, 8, 0},
   k = 4,
   xi = 49,
   d1 = {"ga/strikepractice/kotlin/collections/CollectionsKt__CollectionsJVMKt", "ga/strikepractice/kotlin/collections/CollectionsKt__CollectionsKt", "ga/strikepractice/kotlin/collections/CollectionsKt__IterablesKt", "ga/strikepractice/kotlin/collections/CollectionsKt__IteratorsJVMKt", "ga/strikepractice/kotlin/collections/CollectionsKt__IteratorsKt", "ga/strikepractice/kotlin/collections/CollectionsKt__MutableCollectionsJVMKt", "ga/strikepractice/kotlin/collections/CollectionsKt__MutableCollectionsKt", "ga/strikepractice/kotlin/collections/CollectionsKt__ReversedViewsKt", "ga/strikepractice/kotlin/collections/CollectionsKt___CollectionsJvmKt", "ga/strikepractice/kotlin/collections/CollectionsKt___CollectionsKt"}
)
public final class CollectionsKt extends CollectionsKt___CollectionsKt {
   private CollectionsKt() {
   }
}
