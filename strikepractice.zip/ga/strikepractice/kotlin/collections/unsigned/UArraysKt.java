package ga.strikepractice.kotlin.collections.unsigned;

import ga.strikepractice.kotlin.Metadata;

@Metadata(
   mv = {1, 8, 0},
   k = 4,
   xi = 49,
   d1 = {"ga/strikepractice/kotlin/collections/unsigned/UArraysKt___UArraysJvmKt", "ga/strikepractice/kotlin/collections/unsigned/UArraysKt___UArraysKt"},
   pn = "ga.strikepractice.kotlin.collections"
)
public final class UArraysKt extends UArraysKt___UArraysKt {
   private UArraysKt() {
   }
}
