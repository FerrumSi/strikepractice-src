package ga.strikepractice.kotlin.collections.unsigned;

import ga.strikepractice.kotlin.Deprecated;
import ga.strikepractice.kotlin.DeprecatedSinceKotlin;
import ga.strikepractice.kotlin.ExperimentalUnsignedTypes;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.OverloadResolutionByLambdaReturnType;
import ga.strikepractice.kotlin.ReplaceWith;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.UByte;
import ga.strikepractice.kotlin.UByteArray;
import ga.strikepractice.kotlin.UInt;
import ga.strikepractice.kotlin.UIntArray;
import ga.strikepractice.kotlin.ULong;
import ga.strikepractice.kotlin.ULongArray;
import ga.strikepractice.kotlin.UShort;
import ga.strikepractice.kotlin.UShortArray;
import ga.strikepractice.kotlin.UnsignedKt;
import ga.strikepractice.kotlin.collections.AbstractList;
import ga.strikepractice.kotlin.collections.ArraysKt;
import ga.strikepractice.kotlin.collections.IntIterator;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.JvmName;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.ranges.IntRange;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Comparator;
import java.util.List;
import java.util.RandomAccess;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000h\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b \n\u0002\u0010\u000f\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\u001a\u001c\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0003H\u0007ø\u0001\u0000¢\u0006\u0004\b\u0004\u0010\u0005\u001a\u001c\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00060\u0001*\u00020\u0007H\u0007ø\u0001\u0000¢\u0006\u0004\b\b\u0010\t\u001a\u001c\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\n0\u0001*\u00020\u000bH\u0007ø\u0001\u0000¢\u0006\u0004\b\f\u0010\r\u001a\u001c\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0001*\u00020\u000fH\u0007ø\u0001\u0000¢\u0006\u0004\b\u0010\u0010\u0011\u001a2\u0010\u0012\u001a\u00020\u0013*\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u00022\b\b\u0002\u0010\u0015\u001a\u00020\u00132\b\b\u0002\u0010\u0016\u001a\u00020\u0013H\u0007ø\u0001\u0000¢\u0006\u0004\b\u0017\u0010\u0018\u001a2\u0010\u0012\u001a\u00020\u0013*\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u00062\b\b\u0002\u0010\u0015\u001a\u00020\u00132\b\b\u0002\u0010\u0016\u001a\u00020\u0013H\u0007ø\u0001\u0000¢\u0006\u0004\b\u0019\u0010\u001a\u001a2\u0010\u0012\u001a\u00020\u0013*\u00020\u000b2\u0006\u0010\u0014\u001a\u00020\n2\b\b\u0002\u0010\u0015\u001a\u00020\u00132\b\b\u0002\u0010\u0016\u001a\u00020\u0013H\u0007ø\u0001\u0000¢\u0006\u0004\b\u001b\u0010\u001c\u001a2\u0010\u0012\u001a\u00020\u0013*\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u000e2\b\b\u0002\u0010\u0015\u001a\u00020\u00132\b\b\u0002\u0010\u0016\u001a\u00020\u0013H\u0007ø\u0001\u0000¢\u0006\u0004\b\u001d\u0010\u001e\u001a\u001f\u0010\u001f\u001a\u00020\u0002*\u00020\u00032\u0006\u0010 \u001a\u00020\u0013H\u0087\bø\u0001\u0000¢\u0006\u0004\b!\u0010\"\u001a\u001f\u0010\u001f\u001a\u00020\u0006*\u00020\u00072\u0006\u0010 \u001a\u00020\u0013H\u0087\bø\u0001\u0000¢\u0006\u0004\b#\u0010$\u001a\u001f\u0010\u001f\u001a\u00020\n*\u00020\u000b2\u0006\u0010 \u001a\u00020\u0013H\u0087\bø\u0001\u0000¢\u0006\u0004\b%\u0010&\u001a\u001f\u0010\u001f\u001a\u00020\u000e*\u00020\u000f2\u0006\u0010 \u001a\u00020\u0013H\u0087\bø\u0001\u0000¢\u0006\u0004\b'\u0010(\u001a\u0018\u0010)\u001a\u0004\u0018\u00010\u0002*\u00020\u0003H\u0007ø\u0001\u0000¢\u0006\u0004\b*\u0010+\u001a\u0018\u0010)\u001a\u0004\u0018\u00010\u0006*\u00020\u0007H\u0007ø\u0001\u0000¢\u0006\u0004\b,\u0010-\u001a\u0018\u0010)\u001a\u0004\u0018\u00010\n*\u00020\u000bH\u0007ø\u0001\u0000¢\u0006\u0004\b.\u0010/\u001a\u0018\u0010)\u001a\u0004\u0018\u00010\u000e*\u00020\u000fH\u0007ø\u0001\u0000¢\u0006\u0004\b0\u00101\u001a@\u00102\u001a\u0004\u0018\u00010\u0002\"\u000e\b\u0000\u00103*\b\u0012\u0004\u0012\u0002H304*\u00020\u00032\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u0002H306H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b7\u00108\u001a@\u00102\u001a\u0004\u0018\u00010\u0006\"\u000e\b\u0000\u00103*\b\u0012\u0004\u0012\u0002H304*\u00020\u00072\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u0002H306H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b9\u0010:\u001a@\u00102\u001a\u0004\u0018\u00010\n\"\u000e\b\u0000\u00103*\b\u0012\u0004\u0012\u0002H304*\u00020\u000b2\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u0002H306H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b;\u0010<\u001a@\u00102\u001a\u0004\u0018\u00010\u000e\"\u000e\b\u0000\u00103*\b\u0012\u0004\u0012\u0002H304*\u00020\u000f2\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u0002H306H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b=\u0010>\u001a4\u0010?\u001a\u0004\u0018\u00010\u0002*\u00020\u00032\u001a\u0010@\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\u00020Aj\n\u0012\u0006\b\u0000\u0012\u00020\u0002`BH\u0007ø\u0001\u0000¢\u0006\u0004\bC\u0010D\u001a4\u0010?\u001a\u0004\u0018\u00010\u0006*\u00020\u00072\u001a\u0010@\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\u00060Aj\n\u0012\u0006\b\u0000\u0012\u00020\u0006`BH\u0007ø\u0001\u0000¢\u0006\u0004\bE\u0010F\u001a4\u0010?\u001a\u0004\u0018\u00010\n*\u00020\u000b2\u001a\u0010@\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\n0Aj\n\u0012\u0006\b\u0000\u0012\u00020\n`BH\u0007ø\u0001\u0000¢\u0006\u0004\bG\u0010H\u001a4\u0010?\u001a\u0004\u0018\u00010\u000e*\u00020\u000f2\u001a\u0010@\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\u000e0Aj\n\u0012\u0006\b\u0000\u0012\u00020\u000e`BH\u0007ø\u0001\u0000¢\u0006\u0004\bI\u0010J\u001a\u0018\u0010K\u001a\u0004\u0018\u00010\u0002*\u00020\u0003H\u0007ø\u0001\u0000¢\u0006\u0004\bL\u0010+\u001a\u0018\u0010K\u001a\u0004\u0018\u00010\u0006*\u00020\u0007H\u0007ø\u0001\u0000¢\u0006\u0004\bM\u0010-\u001a\u0018\u0010K\u001a\u0004\u0018\u00010\n*\u00020\u000bH\u0007ø\u0001\u0000¢\u0006\u0004\bN\u0010/\u001a\u0018\u0010K\u001a\u0004\u0018\u00010\u000e*\u00020\u000fH\u0007ø\u0001\u0000¢\u0006\u0004\bO\u00101\u001a@\u0010P\u001a\u0004\u0018\u00010\u0002\"\u000e\b\u0000\u00103*\b\u0012\u0004\u0012\u0002H304*\u00020\u00032\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u0002H306H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\bQ\u00108\u001a@\u0010P\u001a\u0004\u0018\u00010\u0006\"\u000e\b\u0000\u00103*\b\u0012\u0004\u0012\u0002H304*\u00020\u00072\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u0002H306H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\bR\u0010:\u001a@\u0010P\u001a\u0004\u0018\u00010\n\"\u000e\b\u0000\u00103*\b\u0012\u0004\u0012\u0002H304*\u00020\u000b2\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u0002H306H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\bS\u0010<\u001a@\u0010P\u001a\u0004\u0018\u00010\u000e\"\u000e\b\u0000\u00103*\b\u0012\u0004\u0012\u0002H304*\u00020\u000f2\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u0002H306H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\bT\u0010>\u001a4\u0010U\u001a\u0004\u0018\u00010\u0002*\u00020\u00032\u001a\u0010@\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\u00020Aj\n\u0012\u0006\b\u0000\u0012\u00020\u0002`BH\u0007ø\u0001\u0000¢\u0006\u0004\bV\u0010D\u001a4\u0010U\u001a\u0004\u0018\u00010\u0006*\u00020\u00072\u001a\u0010@\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\u00060Aj\n\u0012\u0006\b\u0000\u0012\u00020\u0006`BH\u0007ø\u0001\u0000¢\u0006\u0004\bW\u0010F\u001a4\u0010U\u001a\u0004\u0018\u00010\n*\u00020\u000b2\u001a\u0010@\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\n0Aj\n\u0012\u0006\b\u0000\u0012\u00020\n`BH\u0007ø\u0001\u0000¢\u0006\u0004\bX\u0010H\u001a4\u0010U\u001a\u0004\u0018\u00010\u000e*\u00020\u000f2\u001a\u0010@\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\u000e0Aj\n\u0012\u0006\b\u0000\u0012\u00020\u000e`BH\u0007ø\u0001\u0000¢\u0006\u0004\bY\u0010J\u001a.\u0010Z\u001a\u00020[*\u00020\u00032\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020[06H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b\\\u0010]\u001a.\u0010Z\u001a\u00020^*\u00020\u00032\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020^06H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b_\u0010`\u001a.\u0010Z\u001a\u00020[*\u00020\u00072\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020[06H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b\\\u0010a\u001a.\u0010Z\u001a\u00020^*\u00020\u00072\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020^06H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b_\u0010b\u001a.\u0010Z\u001a\u00020[*\u00020\u000b2\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020[06H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b\\\u0010c\u001a.\u0010Z\u001a\u00020^*\u00020\u000b2\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020^06H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b_\u0010d\u001a.\u0010Z\u001a\u00020[*\u00020\u000f2\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020[06H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b\\\u0010e\u001a.\u0010Z\u001a\u00020^*\u00020\u000f2\u0012\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020^06H\u0087\bø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b_\u0010f\u0082\u0002\u000b\n\u0002\b\u0019\n\u0005\b\u009920\u0001¨\u0006g"},
   d2 = {"asList", "", "Lga/strikepractice/kotlin/UByte;", "Lga/strikepractice/kotlin/UByteArray;", "asList-GBYM_sE", "([B)Ljava/util/List;", "Lga/strikepractice/kotlin/UInt;", "Lga/strikepractice/kotlin/UIntArray;", "asList--ajY-9A", "([I)Ljava/util/List;", "Lga/strikepractice/kotlin/ULong;", "Lga/strikepractice/kotlin/ULongArray;", "asList-QwZRm1k", "([J)Ljava/util/List;", "Lga/strikepractice/kotlin/UShort;", "Lga/strikepractice/kotlin/UShortArray;", "asList-rL5Bavg", "([S)Ljava/util/List;", "binarySearch", "", "element", "fromIndex", "toIndex", "binarySearch-WpHrYlw", "([BBII)I", "binarySearch-2fe2U9s", "([IIII)I", "binarySearch-K6DWlUc", "([JJII)I", "binarySearch-EtDCXyQ", "([SSII)I", "elementAt", "index", "elementAt-PpDY95g", "([BI)B", "elementAt-qFRl0hI", "([II)I", "elementAt-r7IrZao", "([JI)J", "elementAt-nggk6HY", "([SI)S", "max", "max-GBYM_sE", "([B)Lkotlin/UByte;", "max--ajY-9A", "([I)Lkotlin/UInt;", "max-QwZRm1k", "([J)Lkotlin/ULong;", "max-rL5Bavg", "([S)Lkotlin/UShort;", "maxBy", "R", "", "selector", "Lga/strikepractice/kotlin/Function1;", "maxBy-JOV_ifY", "([BLkotlin/jvm/functions/Function1;)Lkotlin/UByte;", "maxBy-jgv0xPQ", "([ILkotlin/jvm/functions/Function1;)Lkotlin/UInt;", "maxBy-MShoTSo", "([JLkotlin/jvm/functions/Function1;)Lkotlin/ULong;", "maxBy-xTcfx_M", "([SLkotlin/jvm/functions/Function1;)Lkotlin/UShort;", "maxWith", "comparator", "Ljava/util/Comparator;", "Lga/strikepractice/kotlin/Comparator;", "maxWith-XMRcp5o", "([BLjava/util/Comparator;)Lkotlin/UByte;", "maxWith-YmdZ_VM", "([ILjava/util/Comparator;)Lkotlin/UInt;", "maxWith-zrEWJaI", "([JLjava/util/Comparator;)Lkotlin/ULong;", "maxWith-eOHTfZs", "([SLjava/util/Comparator;)Lkotlin/UShort;", "min", "min-GBYM_sE", "min--ajY-9A", "min-QwZRm1k", "min-rL5Bavg", "minBy", "minBy-JOV_ifY", "minBy-jgv0xPQ", "minBy-MShoTSo", "minBy-xTcfx_M", "minWith", "minWith-XMRcp5o", "minWith-YmdZ_VM", "minWith-zrEWJaI", "minWith-eOHTfZs", "sumOf", "Ljava/math/BigDecimal;", "sumOfBigDecimal", "([BLkotlin/jvm/functions/Function1;)Ljava/math/BigDecimal;", "Ljava/math/BigInteger;", "sumOfBigInteger", "([BLkotlin/jvm/functions/Function1;)Ljava/math/BigInteger;", "([ILkotlin/jvm/functions/Function1;)Ljava/math/BigDecimal;", "([ILkotlin/jvm/functions/Function1;)Ljava/math/BigInteger;", "([JLkotlin/jvm/functions/Function1;)Ljava/math/BigDecimal;", "([JLkotlin/jvm/functions/Function1;)Ljava/math/BigInteger;", "([SLkotlin/jvm/functions/Function1;)Ljava/math/BigDecimal;", "([SLkotlin/jvm/functions/Function1;)Ljava/math/BigInteger;", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/collections/unsigned/UArraysKt",
   pn = "ga.strikepractice.kotlin.collections"
)
class UArraysKt___UArraysJvmKt {
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final int elementAt_qFRl0hI/* $FF was: elementAt-qFRl0hI*/(int[] var0, int var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$elementAt");
      return UIntArray.get-pVg5ArA(var0, var1);
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final long elementAt_r7IrZao/* $FF was: elementAt-r7IrZao*/(long[] var0, int var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$elementAt");
      return ULongArray.get-s-VKNKU(var0, var1);
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final byte elementAt_PpDY95g/* $FF was: elementAt-PpDY95g*/(byte[] var0, int var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$elementAt");
      return UByteArray.get-w2LRezQ(var0, var1);
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final short elementAt_nggk6HY/* $FF was: elementAt-nggk6HY*/(short[] var0, int var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$elementAt");
      return UShortArray.get-Mh2AYeg(var0, var1);
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @NotNull
   public static final List<UInt> asList__ajY_9A/* $FF was: asList--ajY-9A*/(@NotNull final int[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$asList");
      return (List)(new RandomAccess() {
         public int getSize() {
            return UIntArray.getSize-impl(var0);
         }

         public boolean isEmpty() {
            return UIntArray.isEmpty-impl(var0);
         }

         public boolean contains_WZ4Q5Ns/* $FF was: contains-WZ4Q5Ns*/(int var1) {
            return UIntArray.contains-WZ4Q5Ns(var0, var1);
         }

         public int get_pVg5ArA/* $FF was: get-pVg5ArA*/(int var1) {
            return UIntArray.get-pVg5ArA(var0, var1);
         }

         public int indexOf_WZ4Q5Ns/* $FF was: indexOf-WZ4Q5Ns*/(int var1) {
            return ArraysKt.indexOf(var0, var1);
         }

         public int lastIndexOf_WZ4Q5Ns/* $FF was: lastIndexOf-WZ4Q5Ns*/(int var1) {
            return ArraysKt.lastIndexOf(var0, var1);
         }

         public final boolean contains(Object var1) {
            return !(var1 instanceof UInt) ? false : this.contains-WZ4Q5Ns(((UInt)var1).unbox-impl());
         }

         // $FF: synthetic method
         public Object get(int var1) {
            return UInt.box-impl(this.get-pVg5ArA(var1));
         }

         public final int indexOf(Object var1) {
            return !(var1 instanceof UInt) ? -1 : this.indexOf-WZ4Q5Ns(((UInt)var1).unbox-impl());
         }

         public final int lastIndexOf(Object var1) {
            return !(var1 instanceof UInt) ? -1 : this.lastIndexOf-WZ4Q5Ns(((UInt)var1).unbox-impl());
         }
      });
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @NotNull
   public static final List<ULong> asList_QwZRm1k/* $FF was: asList-QwZRm1k*/(@NotNull final long[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$asList");
      return (List)(new RandomAccess() {
         public int getSize() {
            return ULongArray.getSize-impl(var0);
         }

         public boolean isEmpty() {
            return ULongArray.isEmpty-impl(var0);
         }

         public boolean contains_VKZWuLQ/* $FF was: contains-VKZWuLQ*/(long var1) {
            return ULongArray.contains-VKZWuLQ(var0, var1);
         }

         public long get_s_VKNKU/* $FF was: get-s-VKNKU*/(int var1) {
            return ULongArray.get-s-VKNKU(var0, var1);
         }

         public int indexOf_VKZWuLQ/* $FF was: indexOf-VKZWuLQ*/(long var1) {
            return ArraysKt.indexOf(var0, var1);
         }

         public int lastIndexOf_VKZWuLQ/* $FF was: lastIndexOf-VKZWuLQ*/(long var1) {
            return ArraysKt.lastIndexOf(var0, var1);
         }

         public final boolean contains(Object var1) {
            return !(var1 instanceof ULong) ? false : this.contains-VKZWuLQ(((ULong)var1).unbox-impl());
         }

         // $FF: synthetic method
         public Object get(int var1) {
            return ULong.box-impl(this.get-s-VKNKU(var1));
         }

         public final int indexOf(Object var1) {
            return !(var1 instanceof ULong) ? -1 : this.indexOf-VKZWuLQ(((ULong)var1).unbox-impl());
         }

         public final int lastIndexOf(Object var1) {
            return !(var1 instanceof ULong) ? -1 : this.lastIndexOf-VKZWuLQ(((ULong)var1).unbox-impl());
         }
      });
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @NotNull
   public static final List<UByte> asList_GBYM_sE/* $FF was: asList-GBYM_sE*/(@NotNull final byte[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$asList");
      return (List)(new RandomAccess() {
         public int getSize() {
            return UByteArray.getSize-impl(var0);
         }

         public boolean isEmpty() {
            return UByteArray.isEmpty-impl(var0);
         }

         public boolean contains_7apg3OU/* $FF was: contains-7apg3OU*/(byte var1) {
            return UByteArray.contains-7apg3OU(var0, var1);
         }

         public byte get_w2LRezQ/* $FF was: get-w2LRezQ*/(int var1) {
            return UByteArray.get-w2LRezQ(var0, var1);
         }

         public int indexOf_7apg3OU/* $FF was: indexOf-7apg3OU*/(byte var1) {
            return ArraysKt.indexOf(var0, var1);
         }

         public int lastIndexOf_7apg3OU/* $FF was: lastIndexOf-7apg3OU*/(byte var1) {
            return ArraysKt.lastIndexOf(var0, var1);
         }

         public final boolean contains(Object var1) {
            return !(var1 instanceof UByte) ? false : this.contains-7apg3OU(((UByte)var1).unbox-impl());
         }

         // $FF: synthetic method
         public Object get(int var1) {
            return UByte.box-impl(this.get-w2LRezQ(var1));
         }

         public final int indexOf(Object var1) {
            return !(var1 instanceof UByte) ? -1 : this.indexOf-7apg3OU(((UByte)var1).unbox-impl());
         }

         public final int lastIndexOf(Object var1) {
            return !(var1 instanceof UByte) ? -1 : this.lastIndexOf-7apg3OU(((UByte)var1).unbox-impl());
         }
      });
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @NotNull
   public static final List<UShort> asList_rL5Bavg/* $FF was: asList-rL5Bavg*/(@NotNull final short[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$asList");
      return (List)(new RandomAccess() {
         public int getSize() {
            return UShortArray.getSize-impl(var0);
         }

         public boolean isEmpty() {
            return UShortArray.isEmpty-impl(var0);
         }

         public boolean contains_xj2QHRw/* $FF was: contains-xj2QHRw*/(short var1) {
            return UShortArray.contains-xj2QHRw(var0, var1);
         }

         public short get_Mh2AYeg/* $FF was: get-Mh2AYeg*/(int var1) {
            return UShortArray.get-Mh2AYeg(var0, var1);
         }

         public int indexOf_xj2QHRw/* $FF was: indexOf-xj2QHRw*/(short var1) {
            return ArraysKt.indexOf(var0, var1);
         }

         public int lastIndexOf_xj2QHRw/* $FF was: lastIndexOf-xj2QHRw*/(short var1) {
            return ArraysKt.lastIndexOf(var0, var1);
         }

         public final boolean contains(Object var1) {
            return !(var1 instanceof UShort) ? false : this.contains-xj2QHRw(((UShort)var1).unbox-impl());
         }

         // $FF: synthetic method
         public Object get(int var1) {
            return UShort.box-impl(this.get-Mh2AYeg(var1));
         }

         public final int indexOf(Object var1) {
            return !(var1 instanceof UShort) ? -1 : this.indexOf-xj2QHRw(((UShort)var1).unbox-impl());
         }

         public final int lastIndexOf(Object var1) {
            return !(var1 instanceof UShort) ? -1 : this.lastIndexOf-xj2QHRw(((UShort)var1).unbox-impl());
         }
      });
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final int binarySearch_2fe2U9s/* $FF was: binarySearch-2fe2U9s*/(@NotNull int[] var0, int var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var0, "$this$binarySearch");
      AbstractList.Companion.checkRangeIndexes$kotlin_stdlib(var2, var3, UIntArray.getSize-impl(var0));
      int var4 = var1;
      int var5 = var2;
      int var6 = var3 - 1;

      while(var5 <= var6) {
         int var7 = var5 + var6 >>> 1;
         int var8 = var0[var7];
         int var9 = UnsignedKt.uintCompare(var8, var4);
         if (var9 < 0) {
            var5 = var7 + 1;
         } else {
            if (var9 <= 0) {
               return var7;
            }

            var6 = var7 - 1;
         }
      }

      return -(var5 + 1);
   }

   // $FF: synthetic method
   public static int binarySearch_2fe2U9s$default/* $FF was: binarySearch-2fe2U9s$default*/(int[] var0, int var1, int var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = UIntArray.getSize-impl(var0);
      }

      return UArraysKt.binarySearch-2fe2U9s(var0, var1, var2, var3);
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final int binarySearch_K6DWlUc/* $FF was: binarySearch-K6DWlUc*/(@NotNull long[] var0, long var1, int var3, int var4) {
      Intrinsics.checkNotNullParameter(var0, "$this$binarySearch");
      AbstractList.Companion.checkRangeIndexes$kotlin_stdlib(var3, var4, ULongArray.getSize-impl(var0));
      long var5 = var1;
      int var7 = var3;
      int var8 = var4 - 1;

      while(var7 <= var8) {
         int var9 = var7 + var8 >>> 1;
         long var10 = var0[var9];
         int var12 = UnsignedKt.ulongCompare(var10, var5);
         if (var12 < 0) {
            var7 = var9 + 1;
         } else {
            if (var12 <= 0) {
               return var9;
            }

            var8 = var9 - 1;
         }
      }

      return -(var7 + 1);
   }

   // $FF: synthetic method
   public static int binarySearch_K6DWlUc$default/* $FF was: binarySearch-K6DWlUc$default*/(long[] var0, long var1, int var3, int var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var3 = 0;
      }

      if ((var5 & 4) != 0) {
         var4 = ULongArray.getSize-impl(var0);
      }

      return UArraysKt.binarySearch-K6DWlUc(var0, var1, var3, var4);
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final int binarySearch_WpHrYlw/* $FF was: binarySearch-WpHrYlw*/(@NotNull byte[] var0, byte var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var0, "$this$binarySearch");
      AbstractList.Companion.checkRangeIndexes$kotlin_stdlib(var2, var3, UByteArray.getSize-impl(var0));
      int var4 = var1 & 255;
      int var5 = var2;
      int var6 = var3 - 1;

      while(var5 <= var6) {
         int var7 = var5 + var6 >>> 1;
         byte var8 = var0[var7];
         int var9 = UnsignedKt.uintCompare(var8, var4);
         if (var9 < 0) {
            var5 = var7 + 1;
         } else {
            if (var9 <= 0) {
               return var7;
            }

            var6 = var7 - 1;
         }
      }

      return -(var5 + 1);
   }

   // $FF: synthetic method
   public static int binarySearch_WpHrYlw$default/* $FF was: binarySearch-WpHrYlw$default*/(byte[] var0, byte var1, int var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = UByteArray.getSize-impl(var0);
      }

      return UArraysKt.binarySearch-WpHrYlw(var0, var1, var2, var3);
   }

   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final int binarySearch_EtDCXyQ/* $FF was: binarySearch-EtDCXyQ*/(@NotNull short[] var0, short var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var0, "$this$binarySearch");
      AbstractList.Companion.checkRangeIndexes$kotlin_stdlib(var2, var3, UShortArray.getSize-impl(var0));
      int var4 = var1 & '\uffff';
      int var5 = var2;
      int var6 = var3 - 1;

      while(var5 <= var6) {
         int var7 = var5 + var6 >>> 1;
         short var8 = var0[var7];
         int var9 = UnsignedKt.uintCompare(var8, var4);
         if (var9 < 0) {
            var5 = var7 + 1;
         } else {
            if (var9 <= 0) {
               return var7;
            }

            var6 = var7 - 1;
         }
      }

      return -(var5 + 1);
   }

   // $FF: synthetic method
   public static int binarySearch_EtDCXyQ$default/* $FF was: binarySearch-EtDCXyQ$default*/(short[] var0, short var1, int var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = UShortArray.getSize-impl(var0);
      }

      return UArraysKt.binarySearch-EtDCXyQ(var0, var1, var2, var3);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxOrNull()",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UInt max__ajY_9A/* $FF was: max--ajY-9A*/(int[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$max");
      return UArraysKt.maxOrNull--ajY-9A(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxOrNull()",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final ULong max_QwZRm1k/* $FF was: max-QwZRm1k*/(long[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$max");
      return UArraysKt.maxOrNull-QwZRm1k(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxOrNull()",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UByte max_GBYM_sE/* $FF was: max-GBYM_sE*/(byte[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$max");
      return UArraysKt.maxOrNull-GBYM_sE(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxOrNull()",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UShort max_rL5Bavg/* $FF was: max-rL5Bavg*/(short[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$max");
      return UArraysKt.maxOrNull-rL5Bavg(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxByOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxByOrNull(selector)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final <R extends Comparable<? super R>> UInt maxBy_jgv0xPQ/* $FF was: maxBy-jgv0xPQ*/(int[] var0, Function1<? super UInt, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$maxBy");
      Intrinsics.checkNotNullParameter(var1, "selector");
      int[] var2 = var0;
      UInt var10000;
      if (UIntArray.isEmpty-impl(var0)) {
         var10000 = null;
      } else {
         int var3 = UIntArray.get-pVg5ArA(var0, 0);
         int var5 = ArraysKt.getLastIndex(var0);
         if (var5 == 0) {
            var10000 = UInt.box-impl(var3);
         } else {
            Comparable var4 = (Comparable)var1.invoke(UInt.box-impl(var3));
            IntIterator var6 = (new IntRange(1, var5)).iterator();

            while(var6.hasNext()) {
               int var7 = var6.nextInt();
               int var8 = UIntArray.get-pVg5ArA(var2, var7);
               Comparable var9 = (Comparable)var1.invoke(UInt.box-impl(var8));
               if (var4.compareTo(var9) < 0) {
                  var3 = var8;
                  var4 = var9;
               }
            }

            var10000 = UInt.box-impl(var3);
         }
      }

      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxByOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxByOrNull(selector)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final <R extends Comparable<? super R>> ULong maxBy_MShoTSo/* $FF was: maxBy-MShoTSo*/(long[] var0, Function1<? super ULong, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$maxBy");
      Intrinsics.checkNotNullParameter(var1, "selector");
      long[] var2 = var0;
      ULong var10000;
      if (ULongArray.isEmpty-impl(var0)) {
         var10000 = null;
      } else {
         long var3 = ULongArray.get-s-VKNKU(var0, 0);
         int var6 = ArraysKt.getLastIndex(var0);
         if (var6 == 0) {
            var10000 = ULong.box-impl(var3);
         } else {
            Comparable var5 = (Comparable)var1.invoke(ULong.box-impl(var3));
            IntIterator var7 = (new IntRange(1, var6)).iterator();

            while(var7.hasNext()) {
               int var8 = var7.nextInt();
               long var9 = ULongArray.get-s-VKNKU(var2, var8);
               Comparable var11 = (Comparable)var1.invoke(ULong.box-impl(var9));
               if (var5.compareTo(var11) < 0) {
                  var3 = var9;
                  var5 = var11;
               }
            }

            var10000 = ULong.box-impl(var3);
         }
      }

      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxByOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxByOrNull(selector)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final <R extends Comparable<? super R>> UByte maxBy_JOV_ifY/* $FF was: maxBy-JOV_ifY*/(byte[] var0, Function1<? super UByte, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$maxBy");
      Intrinsics.checkNotNullParameter(var1, "selector");
      byte[] var2 = var0;
      UByte var10000;
      if (UByteArray.isEmpty-impl(var0)) {
         var10000 = null;
      } else {
         byte var3 = UByteArray.get-w2LRezQ(var0, 0);
         int var5 = ArraysKt.getLastIndex(var0);
         if (var5 == 0) {
            var10000 = UByte.box-impl(var3);
         } else {
            Comparable var4 = (Comparable)var1.invoke(UByte.box-impl(var3));
            IntIterator var6 = (new IntRange(1, var5)).iterator();

            while(var6.hasNext()) {
               int var7 = var6.nextInt();
               byte var8 = UByteArray.get-w2LRezQ(var2, var7);
               Comparable var9 = (Comparable)var1.invoke(UByte.box-impl(var8));
               if (var4.compareTo(var9) < 0) {
                  var3 = var8;
                  var4 = var9;
               }
            }

            var10000 = UByte.box-impl(var3);
         }
      }

      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxByOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxByOrNull(selector)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final <R extends Comparable<? super R>> UShort maxBy_xTcfx_M/* $FF was: maxBy-xTcfx_M*/(short[] var0, Function1<? super UShort, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$maxBy");
      Intrinsics.checkNotNullParameter(var1, "selector");
      short[] var2 = var0;
      UShort var10000;
      if (UShortArray.isEmpty-impl(var0)) {
         var10000 = null;
      } else {
         short var3 = UShortArray.get-Mh2AYeg(var0, 0);
         int var5 = ArraysKt.getLastIndex(var0);
         if (var5 == 0) {
            var10000 = UShort.box-impl(var3);
         } else {
            Comparable var4 = (Comparable)var1.invoke(UShort.box-impl(var3));
            IntIterator var6 = (new IntRange(1, var5)).iterator();

            while(var6.hasNext()) {
               int var7 = var6.nextInt();
               short var8 = UShortArray.get-Mh2AYeg(var2, var7);
               Comparable var9 = (Comparable)var1.invoke(UShort.box-impl(var8));
               if (var4.compareTo(var9) < 0) {
                  var3 = var8;
                  var4 = var9;
               }
            }

            var10000 = UShort.box-impl(var3);
         }
      }

      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxWithOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxWithOrNull(comparator)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UInt maxWith_YmdZ_VM/* $FF was: maxWith-YmdZ_VM*/(int[] var0, Comparator var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$maxWith");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return UArraysKt.maxWithOrNull-YmdZ_VM(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxWithOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxWithOrNull(comparator)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final ULong maxWith_zrEWJaI/* $FF was: maxWith-zrEWJaI*/(long[] var0, Comparator var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$maxWith");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return UArraysKt.maxWithOrNull-zrEWJaI(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxWithOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxWithOrNull(comparator)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UByte maxWith_XMRcp5o/* $FF was: maxWith-XMRcp5o*/(byte[] var0, Comparator var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$maxWith");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return UArraysKt.maxWithOrNull-XMRcp5o(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use maxWithOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.maxWithOrNull(comparator)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UShort maxWith_eOHTfZs/* $FF was: maxWith-eOHTfZs*/(short[] var0, Comparator var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$maxWith");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return UArraysKt.maxWithOrNull-eOHTfZs(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minOrNull()",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UInt min__ajY_9A/* $FF was: min--ajY-9A*/(int[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$min");
      return UArraysKt.minOrNull--ajY-9A(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minOrNull()",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final ULong min_QwZRm1k/* $FF was: min-QwZRm1k*/(long[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$min");
      return UArraysKt.minOrNull-QwZRm1k(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minOrNull()",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UByte min_GBYM_sE/* $FF was: min-GBYM_sE*/(byte[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$min");
      return UArraysKt.minOrNull-GBYM_sE(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minOrNull()",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UShort min_rL5Bavg/* $FF was: min-rL5Bavg*/(short[] var0) {
      Intrinsics.checkNotNullParameter(var0, "$this$min");
      return UArraysKt.minOrNull-rL5Bavg(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minByOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minByOrNull(selector)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final <R extends Comparable<? super R>> UInt minBy_jgv0xPQ/* $FF was: minBy-jgv0xPQ*/(int[] var0, Function1<? super UInt, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$minBy");
      Intrinsics.checkNotNullParameter(var1, "selector");
      int[] var2 = var0;
      UInt var10000;
      if (UIntArray.isEmpty-impl(var0)) {
         var10000 = null;
      } else {
         int var3 = UIntArray.get-pVg5ArA(var0, 0);
         int var5 = ArraysKt.getLastIndex(var0);
         if (var5 == 0) {
            var10000 = UInt.box-impl(var3);
         } else {
            Comparable var4 = (Comparable)var1.invoke(UInt.box-impl(var3));
            IntIterator var6 = (new IntRange(1, var5)).iterator();

            while(var6.hasNext()) {
               int var7 = var6.nextInt();
               int var8 = UIntArray.get-pVg5ArA(var2, var7);
               Comparable var9 = (Comparable)var1.invoke(UInt.box-impl(var8));
               if (var4.compareTo(var9) > 0) {
                  var3 = var8;
                  var4 = var9;
               }
            }

            var10000 = UInt.box-impl(var3);
         }
      }

      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minByOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minByOrNull(selector)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final <R extends Comparable<? super R>> ULong minBy_MShoTSo/* $FF was: minBy-MShoTSo*/(long[] var0, Function1<? super ULong, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$minBy");
      Intrinsics.checkNotNullParameter(var1, "selector");
      long[] var2 = var0;
      ULong var10000;
      if (ULongArray.isEmpty-impl(var0)) {
         var10000 = null;
      } else {
         long var3 = ULongArray.get-s-VKNKU(var0, 0);
         int var6 = ArraysKt.getLastIndex(var0);
         if (var6 == 0) {
            var10000 = ULong.box-impl(var3);
         } else {
            Comparable var5 = (Comparable)var1.invoke(ULong.box-impl(var3));
            IntIterator var7 = (new IntRange(1, var6)).iterator();

            while(var7.hasNext()) {
               int var8 = var7.nextInt();
               long var9 = ULongArray.get-s-VKNKU(var2, var8);
               Comparable var11 = (Comparable)var1.invoke(ULong.box-impl(var9));
               if (var5.compareTo(var11) > 0) {
                  var3 = var9;
                  var5 = var11;
               }
            }

            var10000 = ULong.box-impl(var3);
         }
      }

      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minByOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minByOrNull(selector)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final <R extends Comparable<? super R>> UByte minBy_JOV_ifY/* $FF was: minBy-JOV_ifY*/(byte[] var0, Function1<? super UByte, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$minBy");
      Intrinsics.checkNotNullParameter(var1, "selector");
      byte[] var2 = var0;
      UByte var10000;
      if (UByteArray.isEmpty-impl(var0)) {
         var10000 = null;
      } else {
         byte var3 = UByteArray.get-w2LRezQ(var0, 0);
         int var5 = ArraysKt.getLastIndex(var0);
         if (var5 == 0) {
            var10000 = UByte.box-impl(var3);
         } else {
            Comparable var4 = (Comparable)var1.invoke(UByte.box-impl(var3));
            IntIterator var6 = (new IntRange(1, var5)).iterator();

            while(var6.hasNext()) {
               int var7 = var6.nextInt();
               byte var8 = UByteArray.get-w2LRezQ(var2, var7);
               Comparable var9 = (Comparable)var1.invoke(UByte.box-impl(var8));
               if (var4.compareTo(var9) > 0) {
                  var3 = var8;
                  var4 = var9;
               }
            }

            var10000 = UByte.box-impl(var3);
         }
      }

      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minByOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minByOrNull(selector)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final <R extends Comparable<? super R>> UShort minBy_xTcfx_M/* $FF was: minBy-xTcfx_M*/(short[] var0, Function1<? super UShort, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$minBy");
      Intrinsics.checkNotNullParameter(var1, "selector");
      short[] var2 = var0;
      UShort var10000;
      if (UShortArray.isEmpty-impl(var0)) {
         var10000 = null;
      } else {
         short var3 = UShortArray.get-Mh2AYeg(var0, 0);
         int var5 = ArraysKt.getLastIndex(var0);
         if (var5 == 0) {
            var10000 = UShort.box-impl(var3);
         } else {
            Comparable var4 = (Comparable)var1.invoke(UShort.box-impl(var3));
            IntIterator var6 = (new IntRange(1, var5)).iterator();

            while(var6.hasNext()) {
               int var7 = var6.nextInt();
               short var8 = UShortArray.get-Mh2AYeg(var2, var7);
               Comparable var9 = (Comparable)var1.invoke(UShort.box-impl(var8));
               if (var4.compareTo(var9) > 0) {
                  var3 = var8;
                  var4 = var9;
               }
            }

            var10000 = UShort.box-impl(var3);
         }
      }

      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minWithOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minWithOrNull(comparator)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UInt minWith_YmdZ_VM/* $FF was: minWith-YmdZ_VM*/(int[] var0, Comparator var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$minWith");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return UArraysKt.minWithOrNull-YmdZ_VM(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minWithOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minWithOrNull(comparator)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final ULong minWith_zrEWJaI/* $FF was: minWith-zrEWJaI*/(long[] var0, Comparator var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$minWith");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return UArraysKt.minWithOrNull-zrEWJaI(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minWithOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minWithOrNull(comparator)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UByte minWith_XMRcp5o/* $FF was: minWith-XMRcp5o*/(byte[] var0, Comparator var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$minWith");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return UArraysKt.minWithOrNull-XMRcp5o(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use minWithOrNull instead.",
      replaceWith = @ReplaceWith(
   expression = "this.minWithOrNull(comparator)",
   imports = {}
)
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.4",
      errorSince = "1.5",
      hiddenSince = "1.6"
   )
   @SinceKotlin(
      version = "1.3"
   )
   @ExperimentalUnsignedTypes
   public static final UShort minWith_eOHTfZs/* $FF was: minWith-eOHTfZs*/(short[] var0, Comparator var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$minWith");
      Intrinsics.checkNotNullParameter(var1, "comparator");
      return UArraysKt.minWithOrNull-eOHTfZs(var0, var1);
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "sumOfBigDecimal"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final BigDecimal sumOfBigDecimal(int[] var0, Function1<? super UInt, ? extends BigDecimal> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$sumOf");
      Intrinsics.checkNotNullParameter(var1, "selector");
      BigDecimal var10000 = BigDecimal.valueOf(0L);
      Intrinsics.checkNotNullExpressionValue(var10000, "valueOf(this.toLong())");
      BigDecimal var2 = var10000;
      int var3 = 0;

      for(int var4 = UIntArray.getSize-impl(var0); var3 < var4; ++var3) {
         int var5 = UIntArray.get-pVg5ArA(var0, var3);
         var10000 = var2.add((BigDecimal)var1.invoke(UInt.box-impl(var5)));
         Intrinsics.checkNotNullExpressionValue(var10000, "this.add(other)");
         var2 = var10000;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "sumOfBigDecimal"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final BigDecimal sumOfBigDecimal(long[] var0, Function1<? super ULong, ? extends BigDecimal> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$sumOf");
      Intrinsics.checkNotNullParameter(var1, "selector");
      BigDecimal var10000 = BigDecimal.valueOf(0L);
      Intrinsics.checkNotNullExpressionValue(var10000, "valueOf(this.toLong())");
      BigDecimal var2 = var10000;
      int var3 = 0;

      for(int var4 = ULongArray.getSize-impl(var0); var3 < var4; ++var3) {
         long var5 = ULongArray.get-s-VKNKU(var0, var3);
         var10000 = var2.add((BigDecimal)var1.invoke(ULong.box-impl(var5)));
         Intrinsics.checkNotNullExpressionValue(var10000, "this.add(other)");
         var2 = var10000;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "sumOfBigDecimal"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final BigDecimal sumOfBigDecimal(byte[] var0, Function1<? super UByte, ? extends BigDecimal> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$sumOf");
      Intrinsics.checkNotNullParameter(var1, "selector");
      BigDecimal var10000 = BigDecimal.valueOf(0L);
      Intrinsics.checkNotNullExpressionValue(var10000, "valueOf(this.toLong())");
      BigDecimal var2 = var10000;
      int var3 = 0;

      for(int var4 = UByteArray.getSize-impl(var0); var3 < var4; ++var3) {
         byte var5 = UByteArray.get-w2LRezQ(var0, var3);
         var10000 = var2.add((BigDecimal)var1.invoke(UByte.box-impl(var5)));
         Intrinsics.checkNotNullExpressionValue(var10000, "this.add(other)");
         var2 = var10000;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "sumOfBigDecimal"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final BigDecimal sumOfBigDecimal(short[] var0, Function1<? super UShort, ? extends BigDecimal> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$sumOf");
      Intrinsics.checkNotNullParameter(var1, "selector");
      BigDecimal var10000 = BigDecimal.valueOf(0L);
      Intrinsics.checkNotNullExpressionValue(var10000, "valueOf(this.toLong())");
      BigDecimal var2 = var10000;
      int var3 = 0;

      for(int var4 = UShortArray.getSize-impl(var0); var3 < var4; ++var3) {
         short var5 = UShortArray.get-Mh2AYeg(var0, var3);
         var10000 = var2.add((BigDecimal)var1.invoke(UShort.box-impl(var5)));
         Intrinsics.checkNotNullExpressionValue(var10000, "this.add(other)");
         var2 = var10000;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "sumOfBigInteger"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final BigInteger sumOfBigInteger(int[] var0, Function1<? super UInt, ? extends BigInteger> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$sumOf");
      Intrinsics.checkNotNullParameter(var1, "selector");
      BigInteger var10000 = BigInteger.valueOf(0L);
      Intrinsics.checkNotNullExpressionValue(var10000, "valueOf(this.toLong())");
      BigInteger var2 = var10000;
      int var3 = 0;

      for(int var4 = UIntArray.getSize-impl(var0); var3 < var4; ++var3) {
         int var5 = UIntArray.get-pVg5ArA(var0, var3);
         var10000 = var2.add((BigInteger)var1.invoke(UInt.box-impl(var5)));
         Intrinsics.checkNotNullExpressionValue(var10000, "this.add(other)");
         var2 = var10000;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "sumOfBigInteger"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final BigInteger sumOfBigInteger(long[] var0, Function1<? super ULong, ? extends BigInteger> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$sumOf");
      Intrinsics.checkNotNullParameter(var1, "selector");
      BigInteger var10000 = BigInteger.valueOf(0L);
      Intrinsics.checkNotNullExpressionValue(var10000, "valueOf(this.toLong())");
      BigInteger var2 = var10000;
      int var3 = 0;

      for(int var4 = ULongArray.getSize-impl(var0); var3 < var4; ++var3) {
         long var5 = ULongArray.get-s-VKNKU(var0, var3);
         var10000 = var2.add((BigInteger)var1.invoke(ULong.box-impl(var5)));
         Intrinsics.checkNotNullExpressionValue(var10000, "this.add(other)");
         var2 = var10000;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "sumOfBigInteger"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final BigInteger sumOfBigInteger(byte[] var0, Function1<? super UByte, ? extends BigInteger> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$sumOf");
      Intrinsics.checkNotNullParameter(var1, "selector");
      BigInteger var10000 = BigInteger.valueOf(0L);
      Intrinsics.checkNotNullExpressionValue(var10000, "valueOf(this.toLong())");
      BigInteger var2 = var10000;
      int var3 = 0;

      for(int var4 = UByteArray.getSize-impl(var0); var3 < var4; ++var3) {
         byte var5 = UByteArray.get-w2LRezQ(var0, var3);
         var10000 = var2.add((BigInteger)var1.invoke(UByte.box-impl(var5)));
         Intrinsics.checkNotNullExpressionValue(var10000, "this.add(other)");
         var2 = var10000;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @OverloadResolutionByLambdaReturnType
   @JvmName(
      name = "sumOfBigInteger"
   )
   @ExperimentalUnsignedTypes
   @InlineOnly
   private static final BigInteger sumOfBigInteger(short[] var0, Function1<? super UShort, ? extends BigInteger> var1) {
      Intrinsics.checkNotNullParameter(var0, "$this$sumOf");
      Intrinsics.checkNotNullParameter(var1, "selector");
      BigInteger var10000 = BigInteger.valueOf(0L);
      Intrinsics.checkNotNullExpressionValue(var10000, "valueOf(this.toLong())");
      BigInteger var2 = var10000;
      int var3 = 0;

      for(int var4 = UShortArray.getSize-impl(var0); var3 < var4; ++var3) {
         short var5 = UShortArray.get-Mh2AYeg(var0, var3);
         var10000 = var2.add((BigInteger)var1.invoke(UShort.box-impl(var5)));
         Intrinsics.checkNotNullExpressionValue(var10000, "this.add(other)");
         var2 = var10000;
      }

      return var2;
   }

   public UArraysKt___UArraysJvmKt() {
   }
}
