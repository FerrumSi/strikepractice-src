package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;

@Metadata(
   mv = {1, 8, 0},
   k = 4,
   xi = 49,
   d1 = {"ga/strikepractice/kotlin/collections/GroupingKt__GroupingJVMKt", "ga/strikepractice/kotlin/collections/GroupingKt__GroupingKt"}
)
public final class GroupingKt extends GroupingKt__GroupingKt {
   private GroupingKt() {
   }
}
