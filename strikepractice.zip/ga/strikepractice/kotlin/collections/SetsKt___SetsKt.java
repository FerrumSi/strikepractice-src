package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.sequences.Sequence;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000\u001c\n\u0000\n\u0002\u0010\"\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\u001c\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a,\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0003\u001a\u0002H\u0002H\u0086\u0002¢\u0006\u0002\u0010\u0004\u001a4\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u000e\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u0006H\u0086\u0002¢\u0006\u0002\u0010\u0007\u001a-\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\bH\u0086\u0002\u001a-\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\tH\u0086\u0002\u001a,\u0010\n\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0003\u001a\u0002H\u0002H\u0087\b¢\u0006\u0002\u0010\u0004\u001a,\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0003\u001a\u0002H\u0002H\u0086\u0002¢\u0006\u0002\u0010\u0004\u001a4\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u000e\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u0006H\u0086\u0002¢\u0006\u0002\u0010\u0007\u001a-\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\bH\u0086\u0002\u001a-\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\tH\u0086\u0002\u001a,\u0010\f\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0003\u001a\u0002H\u0002H\u0087\b¢\u0006\u0002\u0010\u0004¨\u0006\r"},
   d2 = {"minus", "", "T", "element", "(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/Set;", "elements", "", "(Ljava/util/Set;[Ljava/lang/Object;)Ljava/util/Set;", "", "Lga/strikepractice/kotlin/sequences/Sequence;", "minusElement", "plus", "plusElement", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/collections/SetsKt"
)
@SourceDebugExtension({"SMAP\n_Sets.kt\nKotlin\n*S Kotlin\n*F\n+ 1 _Sets.kt\nkotlin/collections/SetsKt___SetsKt\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,139:1\n857#2,2:140\n847#2,2:142\n1#3:144\n*S KotlinDebug\n*F\n+ 1 _Sets.kt\nkotlin/collections/SetsKt___SetsKt\n*L\n28#1:140,2\n52#1:142,2\n*E\n"})
class SetsKt___SetsKt extends SetsKt__SetsKt {
   @NotNull
   public static final <T> Set<T> minus(@NotNull Set<? extends T> var0, T var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      LinkedHashSet var2 = new LinkedHashSet(MapsKt.mapCapacity(var0.size()));
      boolean var3 = false;
      Iterable var4 = (Iterable)var0;
      boolean var5 = false;
      Iterator var6 = var4.iterator();

      while(var6.hasNext()) {
         Object var7 = var6.next();
         boolean var9 = false;
         boolean var10000;
         if (!var3 && Intrinsics.areEqual(var7, var1)) {
            var3 = true;
            var10000 = false;
         } else {
            var10000 = true;
         }

         if (var10000) {
            ((Collection)var2).add(var7);
         }
      }

      return (Set)((Collection)var2);
   }

   @NotNull
   public static final <T> Set<T> minus(@NotNull Set<? extends T> var0, @NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      LinkedHashSet var2 = new LinkedHashSet((Collection)var0);
      CollectionsKt.removeAll((Collection)var2, var1);
      return (Set)var2;
   }

   @NotNull
   public static final <T> Set<T> minus(@NotNull Set<? extends T> var0, @NotNull Iterable<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      Collection var2 = CollectionsKt.convertToListIfNotCollection(var1);
      if (var2.isEmpty()) {
         return CollectionsKt.toSet((Iterable)var0);
      } else if (var2 instanceof Set) {
         Iterable var10 = (Iterable)var0;
         Collection var4 = (Collection)(new LinkedHashSet());
         boolean var5 = false;
         Iterator var6 = var10.iterator();

         while(var6.hasNext()) {
            Object var7 = var6.next();
            boolean var9 = false;
            if (!var2.contains(var7)) {
               var4.add(var7);
            }
         }

         return (Set)var4;
      } else {
         LinkedHashSet var3 = new LinkedHashSet((Collection)var0);
         var3.removeAll(var2);
         return (Set)var3;
      }
   }

   @NotNull
   public static final <T> Set<T> minus(@NotNull Set<? extends T> var0, @NotNull Sequence<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      LinkedHashSet var2 = new LinkedHashSet((Collection)var0);
      CollectionsKt.removeAll((Collection)var2, var1);
      return (Set)var2;
   }

   @InlineOnly
   private static final <T> Set<T> minusElement(Set<? extends T> var0, T var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return SetsKt.minus(var0, var1);
   }

   @NotNull
   public static final <T> Set<T> plus(@NotNull Set<? extends T> var0, T var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      LinkedHashSet var2 = new LinkedHashSet(MapsKt.mapCapacity(var0.size() + 1));
      var2.addAll((Collection)var0);
      var2.add(var1);
      return (Set)var2;
   }

   @NotNull
   public static final <T> Set<T> plus(@NotNull Set<? extends T> var0, @NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      LinkedHashSet var2 = new LinkedHashSet(MapsKt.mapCapacity(var0.size() + var1.length));
      var2.addAll((Collection)var0);
      CollectionsKt.addAll((Collection)var2, var1);
      return (Set)var2;
   }

   @NotNull
   public static final <T> Set<T> plus(@NotNull Set<? extends T> var0, @NotNull Iterable<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      Integer var10000 = CollectionsKt.collectionSizeOrNull(var1);
      int var7;
      if (var10000 != null) {
         Integer var3 = var10000;
         int var4 = ((Number)var3).intValue();
         boolean var5 = false;
         var7 = var0.size() + var4;
      } else {
         var7 = var0.size() * 2;
      }

      int var6 = MapsKt.mapCapacity(var7);
      LinkedHashSet var2 = new LinkedHashSet(var6);
      var2.addAll((Collection)var0);
      CollectionsKt.addAll((Collection)var2, var1);
      return (Set)var2;
   }

   @NotNull
   public static final <T> Set<T> plus(@NotNull Set<? extends T> var0, @NotNull Sequence<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "elements");
      LinkedHashSet var2 = new LinkedHashSet(MapsKt.mapCapacity(var0.size() * 2));
      var2.addAll((Collection)var0);
      CollectionsKt.addAll((Collection)var2, var1);
      return (Set)var2;
   }

   @InlineOnly
   private static final <T> Set<T> plusElement(Set<? extends T> var0, T var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return SetsKt.plus(var0, var1);
   }

   public SetsKt___SetsKt() {
   }
}
