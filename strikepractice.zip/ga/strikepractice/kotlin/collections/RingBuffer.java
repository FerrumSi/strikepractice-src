package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.ranges.RangesKt;
import java.util.Arrays;
import java.util.Iterator;
import java.util.RandomAccess;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\b\t\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010(\n\u0002\b\b\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u00022\u00060\u0003j\u0002`\u0004B\u000f\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007B\u001d\u0012\u000e\u0010\b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\t\u0012\u0006\u0010\u000b\u001a\u00020\u0006¢\u0006\u0002\u0010\fJ\u0013\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00028\u0000¢\u0006\u0002\u0010\u0016J\u0014\u0010\u0017\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\u0006\u0010\u0018\u001a\u00020\u0006J\u0016\u0010\u0019\u001a\u00028\u00002\u0006\u0010\u001a\u001a\u00020\u0006H\u0096\u0002¢\u0006\u0002\u0010\u001bJ\u0006\u0010\u001c\u001a\u00020\u001dJ\u000f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00028\u00000\u001fH\u0096\u0002J\u000e\u0010 \u001a\u00020\u00142\u0006\u0010!\u001a\u00020\u0006J\u0015\u0010\"\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\tH\u0014¢\u0006\u0002\u0010#J'\u0010\"\u001a\b\u0012\u0004\u0012\u0002H\u00010\t\"\u0004\b\u0001\u0010\u00012\f\u0010$\u001a\b\u0012\u0004\u0012\u0002H\u00010\tH\u0014¢\u0006\u0002\u0010%J\u0015\u0010&\u001a\u00020\u0006*\u00020\u00062\u0006\u0010!\u001a\u00020\u0006H\u0082\bR\u0018\u0010\b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\tX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\rR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u0006@RX\u0096\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u000e\u0010\u0012\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006'"},
   d2 = {"Lga/strikepractice/kotlin/collections/RingBuffer;", "T", "Lga/strikepractice/kotlin/collections/AbstractList;", "Ljava/util/RandomAccess;", "Lga/strikepractice/kotlin/collections/RandomAccess;", "capacity", "", "(I)V", "buffer", "", "", "filledSize", "([Ljava/lang/Object;I)V", "[Ljava/lang/Object;", "<set-?>", "size", "getSize", "()I", "startIndex", "add", "", "element", "(Ljava/lang/Object;)V", "expanded", "maxCapacity", "get", "index", "(I)Ljava/lang/Object;", "isFull", "", "iterator", "", "removeFirst", "n", "toArray", "()[Ljava/lang/Object;", "array", "([Ljava/lang/Object;)[Ljava/lang/Object;", "forward", "ga.strikepractice.kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nSlidingWindow.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SlidingWindow.kt\nkotlin/collections/RingBuffer\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,207:1\n205#1:209\n205#1:210\n205#1:211\n1#2:208\n*S KotlinDebug\n*F\n+ 1 SlidingWindow.kt\nkotlin/collections/RingBuffer\n*L\n106#1:209\n176#1:210\n189#1:211\n*E\n"})
final class RingBuffer<T> extends AbstractList<T> implements RandomAccess {
   @NotNull
   private final Object[] buffer;
   private final int capacity;
   private int startIndex;
   private int size;

   public RingBuffer(@NotNull Object[] var1, int var2) {
      Intrinsics.checkNotNullParameter(var1, "buffer");
      super();
      this.buffer = var1;
      boolean var3 = var2 >= 0;
      boolean var4;
      String var5;
      if (!var3) {
         var4 = false;
         var5 = "ring buffer filled size should not be negative but it is " + var2;
         throw new IllegalArgumentException(var5.toString());
      } else {
         var3 = var2 <= this.buffer.length;
         if (!var3) {
            var4 = false;
            var5 = "ring buffer filled size: " + var2 + " cannot be larger than the buffer size: " + this.buffer.length;
            throw new IllegalArgumentException(var5.toString());
         } else {
            this.capacity = this.buffer.length;
            this.size = var2;
         }
      }
   }

   public RingBuffer(int var1) {
      this(new Object[var1], 0);
   }

   public int getSize() {
      return this.size;
   }

   public T get(int var1) {
      AbstractList.Companion.checkElementIndex$kotlin_stdlib(var1, this.size());
      int var3 = this.startIndex;
      boolean var4 = false;
      return this.buffer[(var3 + var1) % access$getCapacity$p(this)];
   }

   public final boolean isFull() {
      return this.size() == this.capacity;
   }

   @NotNull
   public Iterator<T> iterator() {
      return (Iterator)(new AbstractIterator<T>() {
         private int count = RingBuffer.this.size();
         private int index;

         {
            this.index = RingBuffer.this.startIndex;
         }

         protected void computeNext() {
            if (this.count == 0) {
               this.done();
            } else {
               this.setNext(RingBuffer.this.buffer[this.index]);
               RingBuffer var1 = RingBuffer.this;
               int var2 = this.index;
               byte var3 = 1;
               boolean var4 = false;
               this.index = (var2 + var3) % var1.capacity;
               int var5 = this.count;
               this.count = var5 + -1;
            }

         }
      });
   }

   @NotNull
   public <T> T[] toArray(@NotNull T[] var1) {
      Intrinsics.checkNotNullParameter(var1, "array");
      Object[] var10000;
      if (var1.length < this.size()) {
         var10000 = Arrays.copyOf(var1, this.size());
         Intrinsics.checkNotNullExpressionValue(var10000, "copyOf(this, newSize)");
      } else {
         var10000 = var1;
      }

      Object[] var2 = var10000;
      int var3 = this.size();
      int var4 = 0;

      int var5;
      for(var5 = this.startIndex; var4 < var3 && var5 < this.capacity; ++var5) {
         var2[var4] = this.buffer[var5];
         ++var4;
      }

      for(var5 = 0; var4 < var3; ++var5) {
         var2[var4] = this.buffer[var5];
         ++var4;
      }

      if (var2.length > this.size()) {
         var2[this.size()] = null;
      }

      return var2;
   }

   @NotNull
   public Object[] toArray() {
      return this.toArray(new Object[this.size()]);
   }

   @NotNull
   public final RingBuffer<T> expanded(int var1) {
      int var2 = RangesKt.coerceAtMost(this.capacity + (this.capacity >> 1) + 1, var1);
      Object[] var10000;
      if (this.startIndex == 0) {
         var10000 = Arrays.copyOf(this.buffer, var2);
         Intrinsics.checkNotNullExpressionValue(var10000, "copyOf(this, newSize)");
      } else {
         var10000 = this.toArray(new Object[var2]);
      }

      Object[] var3 = var10000;
      return new RingBuffer(var3, this.size());
   }

   public final void add(T var1) {
      if (this.isFull()) {
         throw new IllegalStateException("ring buffer is full");
      } else {
         Object[] var10000 = this.buffer;
         int var3 = this.startIndex;
         int var4 = this.size();
         boolean var5 = false;
         var10000[(var3 + var4) % access$getCapacity$p(this)] = var1;
         int var2 = this.size();
         this.size = var2 + 1;
      }
   }

   public final void removeFirst(int var1) {
      boolean var2 = var1 >= 0;
      boolean var8;
      String var9;
      if (!var2) {
         var8 = false;
         var9 = "n shouldn't be negative but it is " + var1;
         throw new IllegalArgumentException(var9.toString());
      } else {
         var2 = var1 <= this.size();
         if (!var2) {
            var8 = false;
            var9 = "n shouldn't be greater than the buffer size: n = " + var1 + ", size = " + this.size();
            throw new IllegalArgumentException(var9.toString());
         } else {
            if (var1 > 0) {
               int var7 = this.startIndex;
               boolean var6 = false;
               int var3 = (var7 + var1) % access$getCapacity$p(this);
               if (var7 > var3) {
                  ArraysKt.fill(this.buffer, (Object)null, var7, this.capacity);
                  ArraysKt.fill(this.buffer, (Object)null, 0, var3);
               } else {
                  ArraysKt.fill(this.buffer, (Object)null, var7, var3);
               }

               this.startIndex = var3;
               this.size = this.size() - var1;
            }

         }
      }
   }

   private final int forward(int var1, int var2) {
      boolean var3 = false;
      return (var1 + var2) % access$getCapacity$p(this);
   }
}
