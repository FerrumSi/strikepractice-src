package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.PublishedApi;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.TuplesKt;
import ga.strikepractice.kotlin.UByteArray;
import ga.strikepractice.kotlin.UIntArray;
import ga.strikepractice.kotlin.ULongArray;
import ga.strikepractice.kotlin.UShortArray;
import ga.strikepractice.kotlin.collections.unsigned.UArraysKt;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.JvmName;
import ga.strikepractice.kotlin.jvm.functions.Function0;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.ranges.RangesKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000H\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a5\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\f\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0018\u00010\u00032\u0010\u0010\u0004\u001a\f\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0018\u00010\u0003H\u0001¢\u0006\u0004\b\u0005\u0010\u0006\u001a#\u0010\u0007\u001a\u00020\b\"\u0004\b\u0000\u0010\u0002*\f\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0018\u00010\u0003H\u0001¢\u0006\u0004\b\t\u0010\n\u001a?\u0010\u000b\u001a\u00020\f\"\u0004\b\u0000\u0010\u0002*\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u00032\n\u0010\r\u001a\u00060\u000ej\u0002`\u000f2\u0010\u0010\u0010\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00030\u0011H\u0002¢\u0006\u0004\b\u0012\u0010\u0013\u001a+\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0015\"\u0004\b\u0000\u0010\u0002*\u0012\u0012\u000e\b\u0001\u0012\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u00030\u0003¢\u0006\u0002\u0010\u0016\u001a;\u0010\u0017\u001a\u0002H\u0018\"\u0010\b\u0000\u0010\u0019*\u0006\u0012\u0002\b\u00030\u0003*\u0002H\u0018\"\u0004\b\u0001\u0010\u0018*\u0002H\u00192\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u0002H\u00180\u001bH\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a)\u0010\u001d\u001a\u00020\u0001*\b\u0012\u0002\b\u0003\u0018\u00010\u0003H\u0087\b\u0082\u0002\u000e\n\f\b\u0000\u0012\u0002\u0018\u0001\u001a\u0004\b\u0003\u0010\u0000¢\u0006\u0002\u0010\u001e\u001aG\u0010\u001f\u001a\u001a\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0015\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00180\u00150 \"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0018*\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00180 0\u0003¢\u0006\u0002\u0010!\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\""},
   d2 = {"contentDeepEqualsImpl", "", "T", "", "other", "contentDeepEquals", "([Ljava/lang/Object;[Ljava/lang/Object;)Z", "contentDeepToStringImpl", "", "contentDeepToString", "([Ljava/lang/Object;)Ljava/lang/String;", "contentDeepToStringInternal", "", "result", "Ljava/lang/StringBuilder;", "Lga/strikepractice/kotlin/text/StringBuilder;", "processed", "", "contentDeepToStringInternal$ArraysKt__ArraysKt", "([Ljava/lang/Object;Ljava/lang/StringBuilder;Ljava/util/List;)V", "flatten", "", "([[Ljava/lang/Object;)Ljava/util/List;", "ifEmpty", "R", "C", "defaultValue", "Lga/strikepractice/kotlin/Function0;", "([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "isNullOrEmpty", "([Ljava/lang/Object;)Z", "unzip", "Lga/strikepractice/kotlin/Pair;", "([Lkotlin/Pair;)Lkotlin/Pair;", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/collections/ArraysKt"
)
@SourceDebugExtension({"SMAP\nArrays.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Arrays.kt\nkotlin/collections/ArraysKt__ArraysKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,161:1\n1#2:162\n*E\n"})
class ArraysKt__ArraysKt extends ArraysKt__ArraysJVMKt {
   @NotNull
   public static final <T> List<T> flatten(@NotNull T[][] var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Object[] var2 = (Object[])var0;
      int var3 = 0;
      int var4 = 0;

      for(int var5 = var2.length; var4 < var5; ++var4) {
         Object var6 = var2[var4];
         Object[] var7 = (Object[])var6;
         boolean var8 = false;
         int var10 = var7.length;
         var3 += var10;
      }

      ArrayList var1 = new ArrayList(var3);
      int var12 = 0;

      for(var3 = ((Object[])var0).length; var12 < var3; ++var12) {
         Object[] var13 = var0[var12];
         CollectionsKt.addAll((Collection)var1, var13);
      }

      return (List)var1;
   }

   @NotNull
   public static final <T, R> Pair<List<T>, List<R>> unzip(@NotNull Pair<? extends T, ? extends R>[] var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      ArrayList var1 = new ArrayList(var0.length);
      ArrayList var2 = new ArrayList(var0.length);
      int var3 = 0;

      for(int var4 = var0.length; var3 < var4; ++var3) {
         Pair var5 = var0[var3];
         var1.add(var5.getFirst());
         var2.add(var5.getSecond());
      }

      return TuplesKt.to(var1, var2);
   }

   @SinceKotlin(
      version = "1.3"
   )
   @InlineOnly
   private static final boolean isNullOrEmpty(Object[] var0) {
      return var0 == null || var0.length == 0;
   }

   @SinceKotlin(
      version = "1.3"
   )
   @InlineOnly
   private static final <C extends Object[] & R, R> R ifEmpty(C var0, Function0<? extends R> var1) {
      Intrinsics.checkNotNullParameter(var1, "defaultValue");
      return var0.length == 0 ? var1.invoke() : var0;
   }

   @SinceKotlin(
      version = "1.3"
   )
   @PublishedApi
   @JvmName(
      name = "contentDeepEquals"
   )
   public static final <T> boolean contentDeepEquals(@Nullable T[] var0, @Nullable T[] var1) {
      if (var0 == var1) {
         return true;
      } else if (var0 != null && var1 != null && var0.length == var1.length) {
         int var2 = 0;

         for(int var3 = var0.length; var2 < var3; ++var2) {
            Object var4 = var0[var2];
            Object var5 = var1[var2];
            if (var4 != var5) {
               if (var4 == null || var5 == null) {
                  return false;
               }

               if (var4 instanceof Object[] && var5 instanceof Object[]) {
                  Object[] var6 = (Object[])var4;
                  Object[] var7 = (Object[])var5;
                  if (!ArraysKt.contentDeepEquals(var6, var7)) {
                     return false;
                  }
               } else if (var4 instanceof byte[] && var5 instanceof byte[]) {
                  if (!Arrays.equals((byte[])var4, (byte[])var5)) {
                     return false;
                  }
               } else if (var4 instanceof short[] && var5 instanceof short[]) {
                  if (!Arrays.equals((short[])var4, (short[])var5)) {
                     return false;
                  }
               } else if (var4 instanceof int[] && var5 instanceof int[]) {
                  if (!Arrays.equals((int[])var4, (int[])var5)) {
                     return false;
                  }
               } else if (var4 instanceof long[] && var5 instanceof long[]) {
                  if (!Arrays.equals((long[])var4, (long[])var5)) {
                     return false;
                  }
               } else if (var4 instanceof float[] && var5 instanceof float[]) {
                  if (!Arrays.equals((float[])var4, (float[])var5)) {
                     return false;
                  }
               } else if (var4 instanceof double[] && var5 instanceof double[]) {
                  if (!Arrays.equals((double[])var4, (double[])var5)) {
                     return false;
                  }
               } else if (var4 instanceof char[] && var5 instanceof char[]) {
                  if (!Arrays.equals((char[])var4, (char[])var5)) {
                     return false;
                  }
               } else if (var4 instanceof boolean[] && var5 instanceof boolean[]) {
                  if (!Arrays.equals((boolean[])var4, (boolean[])var5)) {
                     return false;
                  }
               } else if (var4 instanceof UByteArray && var5 instanceof UByteArray) {
                  if (!UArraysKt.contentEquals-kV0jMPg(((UByteArray)var4).unbox-impl(), ((UByteArray)var5).unbox-impl())) {
                     return false;
                  }
               } else if (var4 instanceof UShortArray && var5 instanceof UShortArray) {
                  if (!UArraysKt.contentEquals-FGO6Aew(((UShortArray)var4).unbox-impl(), ((UShortArray)var5).unbox-impl())) {
                     return false;
                  }
               } else if (var4 instanceof UIntArray && var5 instanceof UIntArray) {
                  if (!UArraysKt.contentEquals-KJPZfPQ(((UIntArray)var4).unbox-impl(), ((UIntArray)var5).unbox-impl())) {
                     return false;
                  }
               } else if (var4 instanceof ULongArray && var5 instanceof ULongArray) {
                  if (!UArraysKt.contentEquals-lec5QzE(((ULongArray)var4).unbox-impl(), ((ULongArray)var5).unbox-impl())) {
                     return false;
                  }
               } else if (!Intrinsics.areEqual(var4, var5)) {
                  return false;
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   @SinceKotlin(
      version = "1.3"
   )
   @PublishedApi
   @JvmName(
      name = "contentDeepToString"
   )
   @NotNull
   public static final <T> String contentDeepToString(@Nullable T[] var0) {
      if (var0 == null) {
         return "null";
      } else {
         int var1 = RangesKt.coerceAtMost(var0.length, 429496729) * 5 + 2;
         StringBuilder var2 = new StringBuilder(var1);
         boolean var4 = false;
         contentDeepToStringInternal$ArraysKt__ArraysKt(var0, var2, (List)(new ArrayList()));
         String var10000 = var2.toString();
         Intrinsics.checkNotNullExpressionValue(var10000, "StringBuilder(capacity).…builderAction).toString()");
         return var10000;
      }
   }

   private static final <T> void contentDeepToStringInternal$ArraysKt__ArraysKt(T[] var0, StringBuilder var1, List<Object[]> var2) {
      if (var2.contains(var0)) {
         var1.append("[...]");
      } else {
         var2.add(var0);
         var1.append('[');
         int var3 = 0;

         for(int var4 = var0.length; var3 < var4; ++var3) {
            if (var3 != 0) {
               var1.append(", ");
            }

            Object var5 = var0[var3];
            if (var5 == null) {
               var1.append("null");
            } else if (var5 instanceof Object[]) {
               contentDeepToStringInternal$ArraysKt__ArraysKt((Object[])var5, var1, var2);
            } else {
               String var10001;
               if (var5 instanceof byte[]) {
                  var10001 = Arrays.toString((byte[])var5);
                  Intrinsics.checkNotNullExpressionValue(var10001, "toString(this)");
                  var1.append(var10001);
               } else if (var5 instanceof short[]) {
                  var10001 = Arrays.toString((short[])var5);
                  Intrinsics.checkNotNullExpressionValue(var10001, "toString(this)");
                  var1.append(var10001);
               } else if (var5 instanceof int[]) {
                  var10001 = Arrays.toString((int[])var5);
                  Intrinsics.checkNotNullExpressionValue(var10001, "toString(this)");
                  var1.append(var10001);
               } else if (var5 instanceof long[]) {
                  var10001 = Arrays.toString((long[])var5);
                  Intrinsics.checkNotNullExpressionValue(var10001, "toString(this)");
                  var1.append(var10001);
               } else if (var5 instanceof float[]) {
                  var10001 = Arrays.toString((float[])var5);
                  Intrinsics.checkNotNullExpressionValue(var10001, "toString(this)");
                  var1.append(var10001);
               } else if (var5 instanceof double[]) {
                  var10001 = Arrays.toString((double[])var5);
                  Intrinsics.checkNotNullExpressionValue(var10001, "toString(this)");
                  var1.append(var10001);
               } else if (var5 instanceof char[]) {
                  var10001 = Arrays.toString((char[])var5);
                  Intrinsics.checkNotNullExpressionValue(var10001, "toString(this)");
                  var1.append(var10001);
               } else if (var5 instanceof boolean[]) {
                  var10001 = Arrays.toString((boolean[])var5);
                  Intrinsics.checkNotNullExpressionValue(var10001, "toString(this)");
                  var1.append(var10001);
               } else if (var5 instanceof UByteArray) {
                  var1.append(UArraysKt.contentToString-2csIQuQ((UByteArray)var5 != null ? ((UByteArray)var5).unbox-impl() : null));
               } else if (var5 instanceof UShortArray) {
                  var1.append(UArraysKt.contentToString-d-6D3K8((UShortArray)var5 != null ? ((UShortArray)var5).unbox-impl() : null));
               } else if (var5 instanceof UIntArray) {
                  var1.append(UArraysKt.contentToString-XUkPCBk((UIntArray)var5 != null ? ((UIntArray)var5).unbox-impl() : null));
               } else if (var5 instanceof ULongArray) {
                  var1.append(UArraysKt.contentToString-uLth9ew((ULongArray)var5 != null ? ((ULongArray)var5).unbox-impl() : null));
               } else {
                  var1.append(var5.toString());
               }
            }
         }

         var1.append(']');
         var2.remove(CollectionsKt.getLastIndex(var2));
      }
   }

   public ArraysKt__ArraysKt() {
   }
}
