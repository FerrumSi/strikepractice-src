package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.ExperimentalUnsignedTypes;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.UByteArray;
import ga.strikepractice.kotlin.UIntArray;
import ga.strikepractice.kotlin.ULongArray;
import ga.strikepractice.kotlin.UShortArray;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0010\u001a*\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003ø\u0001\u0000¢\u0006\u0004\b\u0006\u0010\u0007\u001a*\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\b2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003ø\u0001\u0000¢\u0006\u0004\b\t\u0010\n\u001a*\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u000b2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003ø\u0001\u0000¢\u0006\u0004\b\f\u0010\r\u001a*\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003ø\u0001\u0000¢\u0006\u0004\b\u000f\u0010\u0010\u001a*\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003ø\u0001\u0000¢\u0006\u0004\b\u0013\u0010\u0014\u001a*\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\b2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003ø\u0001\u0000¢\u0006\u0004\b\u0015\u0010\u0016\u001a*\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u000b2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003ø\u0001\u0000¢\u0006\u0004\b\u0017\u0010\u0018\u001a*\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003ø\u0001\u0000¢\u0006\u0004\b\u0019\u0010\u001a\u001a*\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u0001H\u0001ø\u0001\u0000¢\u0006\u0004\b\u001e\u0010\u0014\u001a*\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\b2\u0006\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u0001H\u0001ø\u0001\u0000¢\u0006\u0004\b\u001f\u0010\u0016\u001a*\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u000b2\u0006\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u0001H\u0001ø\u0001\u0000¢\u0006\u0004\b \u0010\u0018\u001a*\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u000e2\u0006\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u0001H\u0001ø\u0001\u0000¢\u0006\u0004\b!\u0010\u001a\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\""},
   d2 = {"partition", "", "array", "Lga/strikepractice/kotlin/UByteArray;", "left", "right", "partition-4UcCI2c", "([BII)I", "Lga/strikepractice/kotlin/UIntArray;", "partition-oBK06Vg", "([III)I", "Lga/strikepractice/kotlin/ULongArray;", "partition--nroSd4", "([JII)I", "Lga/strikepractice/kotlin/UShortArray;", "partition-Aa5vz7o", "([SII)I", "quickSort", "", "quickSort-4UcCI2c", "([BII)V", "quickSort-oBK06Vg", "([III)V", "quickSort--nroSd4", "([JII)V", "quickSort-Aa5vz7o", "([SII)V", "sortArray", "fromIndex", "toIndex", "sortArray-4UcCI2c", "sortArray-oBK06Vg", "sortArray--nroSd4", "sortArray-Aa5vz7o", "ga.strikepractice.kotlin-stdlib"}
)
public final class UArraySortingKt {
   @ExperimentalUnsignedTypes
   private static final int partition_4UcCI2c/* $FF was: partition-4UcCI2c*/(byte[] var0, int var1, int var2) {
      int var3 = var1;
      int var4 = var2;
      byte var5 = UByteArray.get-w2LRezQ(var0, (var1 + var2) / 2);

      while(var3 <= var4) {
         while(Intrinsics.compare(UByteArray.get-w2LRezQ(var0, var3) & 255, var5 & 255) < 0) {
            ++var3;
         }

         while(Intrinsics.compare(UByteArray.get-w2LRezQ(var0, var4) & 255, var5 & 255) > 0) {
            --var4;
         }

         if (var3 <= var4) {
            byte var6 = UByteArray.get-w2LRezQ(var0, var3);
            UByteArray.set-VurrAj0(var0, var3, UByteArray.get-w2LRezQ(var0, var4));
            UByteArray.set-VurrAj0(var0, var4, var6);
            ++var3;
            --var4;
         }
      }

      return var3;
   }

   @ExperimentalUnsignedTypes
   private static final void quickSort_4UcCI2c/* $FF was: quickSort-4UcCI2c*/(byte[] var0, int var1, int var2) {
      int var3 = partition-4UcCI2c(var0, var1, var2);
      if (var1 < var3 - 1) {
         quickSort-4UcCI2c(var0, var1, var3 - 1);
      }

      if (var3 < var2) {
         quickSort-4UcCI2c(var0, var3, var2);
      }

   }

   @ExperimentalUnsignedTypes
   private static final int partition_Aa5vz7o/* $FF was: partition-Aa5vz7o*/(short[] var0, int var1, int var2) {
      int var3 = var1;
      int var4 = var2;
      short var5 = UShortArray.get-Mh2AYeg(var0, (var1 + var2) / 2);

      while(var3 <= var4) {
         while(Intrinsics.compare(UShortArray.get-Mh2AYeg(var0, var3) & '\uffff', var5 & '\uffff') < 0) {
            ++var3;
         }

         while(Intrinsics.compare(UShortArray.get-Mh2AYeg(var0, var4) & '\uffff', var5 & '\uffff') > 0) {
            --var4;
         }

         if (var3 <= var4) {
            short var6 = UShortArray.get-Mh2AYeg(var0, var3);
            UShortArray.set-01HTLdE(var0, var3, UShortArray.get-Mh2AYeg(var0, var4));
            UShortArray.set-01HTLdE(var0, var4, var6);
            ++var3;
            --var4;
         }
      }

      return var3;
   }

   @ExperimentalUnsignedTypes
   private static final void quickSort_Aa5vz7o/* $FF was: quickSort-Aa5vz7o*/(short[] var0, int var1, int var2) {
      int var3 = partition-Aa5vz7o(var0, var1, var2);
      if (var1 < var3 - 1) {
         quickSort-Aa5vz7o(var0, var1, var3 - 1);
      }

      if (var3 < var2) {
         quickSort-Aa5vz7o(var0, var3, var2);
      }

   }

   @ExperimentalUnsignedTypes
   private static final int partition_oBK06Vg/* $FF was: partition-oBK06Vg*/(int[] var0, int var1, int var2) {
      int var3 = var1;
      int var4 = var2;
      int var5 = UIntArray.get-pVg5ArA(var0, (var1 + var2) / 2);

      while(var3 <= var4) {
         while(Integer.compareUnsigned(UIntArray.get-pVg5ArA(var0, var3), var5) < 0) {
            ++var3;
         }

         while(Integer.compareUnsigned(UIntArray.get-pVg5ArA(var0, var4), var5) > 0) {
            --var4;
         }

         if (var3 <= var4) {
            int var6 = UIntArray.get-pVg5ArA(var0, var3);
            UIntArray.set-VXSXFK8(var0, var3, UIntArray.get-pVg5ArA(var0, var4));
            UIntArray.set-VXSXFK8(var0, var4, var6);
            ++var3;
            --var4;
         }
      }

      return var3;
   }

   @ExperimentalUnsignedTypes
   private static final void quickSort_oBK06Vg/* $FF was: quickSort-oBK06Vg*/(int[] var0, int var1, int var2) {
      int var3 = partition-oBK06Vg(var0, var1, var2);
      if (var1 < var3 - 1) {
         quickSort-oBK06Vg(var0, var1, var3 - 1);
      }

      if (var3 < var2) {
         quickSort-oBK06Vg(var0, var3, var2);
      }

   }

   @ExperimentalUnsignedTypes
   private static final int partition__nroSd4/* $FF was: partition--nroSd4*/(long[] var0, int var1, int var2) {
      int var3 = var1;
      int var4 = var2;
      long var5 = ULongArray.get-s-VKNKU(var0, (var1 + var2) / 2);

      while(var3 <= var4) {
         while(Long.compareUnsigned(ULongArray.get-s-VKNKU(var0, var3), var5) < 0) {
            ++var3;
         }

         while(Long.compareUnsigned(ULongArray.get-s-VKNKU(var0, var4), var5) > 0) {
            --var4;
         }

         if (var3 <= var4) {
            long var7 = ULongArray.get-s-VKNKU(var0, var3);
            ULongArray.set-k8EXiF4(var0, var3, ULongArray.get-s-VKNKU(var0, var4));
            ULongArray.set-k8EXiF4(var0, var4, var7);
            ++var3;
            --var4;
         }
      }

      return var3;
   }

   @ExperimentalUnsignedTypes
   private static final void quickSort__nroSd4/* $FF was: quickSort--nroSd4*/(long[] var0, int var1, int var2) {
      int var3 = partition--nroSd4(var0, var1, var2);
      if (var1 < var3 - 1) {
         quickSort--nroSd4(var0, var1, var3 - 1);
      }

      if (var3 < var2) {
         quickSort--nroSd4(var0, var3, var2);
      }

   }

   @ExperimentalUnsignedTypes
   public static final void sortArray_4UcCI2c/* $FF was: sortArray-4UcCI2c*/(@NotNull byte[] var0, int var1, int var2) {
      Intrinsics.checkNotNullParameter(var0, "array");
      quickSort-4UcCI2c(var0, var1, var2 - 1);
   }

   @ExperimentalUnsignedTypes
   public static final void sortArray_Aa5vz7o/* $FF was: sortArray-Aa5vz7o*/(@NotNull short[] var0, int var1, int var2) {
      Intrinsics.checkNotNullParameter(var0, "array");
      quickSort-Aa5vz7o(var0, var1, var2 - 1);
   }

   @ExperimentalUnsignedTypes
   public static final void sortArray_oBK06Vg/* $FF was: sortArray-oBK06Vg*/(@NotNull int[] var0, int var1, int var2) {
      Intrinsics.checkNotNullParameter(var0, "array");
      quickSort-oBK06Vg(var0, var1, var2 - 1);
   }

   @ExperimentalUnsignedTypes
   public static final void sortArray__nroSd4/* $FF was: sortArray--nroSd4*/(@NotNull long[] var0, int var1, int var2) {
      Intrinsics.checkNotNullParameter(var0, "array");
      quickSort--nroSd4(var0, var1, var2 - 1);
   }
}
