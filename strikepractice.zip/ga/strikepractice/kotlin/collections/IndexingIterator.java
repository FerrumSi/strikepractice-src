package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.markers.KMappedMarker;
import java.util.Iterator;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010(\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0000\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00010\u00030\u0002B\u0013\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002¢\u0006\u0002\u0010\u0005J\t\u0010\b\u001a\u00020\tH\u0086\u0002J\u000f\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00000\u0003H\u0086\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"},
   d2 = {"Lga/strikepractice/kotlin/collections/IndexingIterator;", "T", "", "Lga/strikepractice/kotlin/collections/IndexedValue;", "iterator", "(Ljava/util/Iterator;)V", "index", "", "hasNext", "", "next", "ga.strikepractice.kotlin-stdlib"}
)
public final class IndexingIterator<T> implements KMappedMarker, Iterator<IndexedValue<? extends T>> {
   @NotNull
   private final Iterator<T> iterator;
   private int index;

   public IndexingIterator(@NotNull Iterator<? extends T> var1) {
      Intrinsics.checkNotNullParameter(var1, "iterator");
      super();
      this.iterator = var1;
   }

   public final boolean hasNext() {
      return this.iterator.hasNext();
   }

   @NotNull
   public final IndexedValue<T> next() {
      IndexedValue var10000 = new IndexedValue;
      int var1 = this.index++;
      if (var1 < 0) {
         CollectionsKt.throwIndexOverflow();
      }

      var10000.<init>(var1, this.iterator.next());
      return var10000;
   }

   public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }
}
