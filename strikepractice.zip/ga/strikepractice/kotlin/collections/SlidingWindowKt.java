package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.ResultKt;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.coroutines.Continuation;
import ga.strikepractice.kotlin.coroutines.intrinsics.IntrinsicsKt;
import ga.strikepractice.kotlin.jvm.functions.Function2;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.ranges.RangesKt;
import ga.strikepractice.kotlin.sequences.Sequence;
import ga.strikepractice.kotlin.sequences.SequenceScope;
import ga.strikepractice.kotlin.sequences.SequencesKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000*\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010(\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u001a\u0018\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H\u0000\u001aH\u0010\u0005\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\b0\u00070\u0006\"\u0004\b\u0000\u0010\b2\f\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\b0\u00062\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000bH\u0000\u001aD\u0010\r\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\b0\u00070\u000e\"\u0004\b\u0000\u0010\b*\b\u0012\u0004\u0012\u0002H\b0\u000e2\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000bH\u0000¨\u0006\u000f"},
   d2 = {"checkWindowSizeStep", "", "size", "", "step", "windowedIterator", "", "", "T", "iterator", "partialWindows", "", "reuseBuffer", "windowedSequence", "Lga/strikepractice/kotlin/sequences/Sequence;", "ga.strikepractice.kotlin-stdlib"}
)
public final class SlidingWindowKt {
   public static final void checkWindowSizeStep(int var0, int var1) {
      boolean var2 = var0 > 0 && var1 > 0;
      if (!var2) {
         boolean var3 = false;
         String var4 = var0 != var1 ? "Both size " + var0 + " and step " + var1 + " must be greater than zero." : "size " + var0 + " must be greater than zero.";
         throw new IllegalArgumentException(var4.toString());
      }
   }

   @NotNull
   public static final <T> Sequence<List<T>> windowedSequence(@NotNull Sequence<? extends T> var0, int var1, int var2, boolean var3, boolean var4) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      checkWindowSizeStep(var1, var2);
      return (Sequence)(new SlidingWindowKt$windowedSequence$$inlined$Sequence$1(var0, var1, var2, var3, var4));
   }

   @NotNull
   public static final <T> Iterator<List<T>> windowedIterator(@NotNull final Iterator<? extends T> var0, final int var1, final int var2, final boolean var3, final boolean var4) {
      Intrinsics.checkNotNullParameter(var0, "iterator");
      return !var0.hasNext() ? (Iterator)EmptyIterator.INSTANCE : SequencesKt.iterator((Function2)(new Function2<SequenceScope<? super List<? extends T>>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         int I$0;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object var1x) {
            SequenceScope var2x;
            RingBuffer var5;
            Object var9;
            List var10001;
            Continuation var10002;
            label169: {
               Iterator var6;
               label189: {
                  var9 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                  int var4x;
                  Iterator var7;
                  ArrayList var10;
                  int var11;
                  switch(this.label) {
                  case 0:
                     ResultKt.throwOnFailure(var1x);
                     var2x = (SequenceScope)this.L$0;
                     int var3x = RangesKt.coerceAtMost(var1, 1024);
                     var4x = var2 - var1;
                     if (var4x < 0) {
                        var5 = new RingBuffer(var3x);
                        var6 = var0;
                        break label189;
                     }

                     var10 = new ArrayList(var3x);
                     var11 = 0;
                     var7 = var0;
                     break;
                  case 1:
                     var4x = this.I$0;
                     var7 = (Iterator)this.L$2;
                     var10 = (ArrayList)this.L$1;
                     var2x = (SequenceScope)this.L$0;
                     ResultKt.throwOnFailure(var1x);
                     if (var4) {
                        var10.clear();
                     } else {
                        var10 = new ArrayList(var1);
                     }

                     var11 = var4x;
                     break;
                  case 2:
                     ResultKt.throwOnFailure(var1x);
                     return Unit.INSTANCE;
                  case 3:
                     var6 = (Iterator)this.L$2;
                     var5 = (RingBuffer)this.L$1;
                     var2x = (SequenceScope)this.L$0;
                     ResultKt.throwOnFailure(var1x);
                     var5.removeFirst(var2);
                     break label189;
                  case 4:
                     var5 = (RingBuffer)this.L$1;
                     var2x = (SequenceScope)this.L$0;
                     ResultKt.throwOnFailure(var1x);
                     var5.removeFirst(var2);
                     break label169;
                  case 5:
                     ResultKt.throwOnFailure(var1x);
                     return Unit.INSTANCE;
                  default:
                     throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                  }

                  while(var7.hasNext()) {
                     Object var8 = var7.next();
                     if (var11 > 0) {
                        --var11;
                     } else {
                        var10.add(var8);
                        if (var10.size() == var1) {
                           var10002 = (Continuation)this;
                           this.L$0 = var2x;
                           this.L$1 = var10;
                           this.L$2 = var7;
                           this.I$0 = var4x;
                           this.label = 1;
                           if (var2x.yield(var10, var10002) == var9) {
                              return var9;
                           }

                           if (var4) {
                              var10.clear();
                           } else {
                              var10 = new ArrayList(var1);
                           }

                           var11 = var4x;
                        }
                     }
                  }

                  if (!((Collection)var10).isEmpty() && (var3 || var10.size() == var1)) {
                     var10002 = (Continuation)this;
                     this.L$0 = null;
                     this.L$1 = null;
                     this.L$2 = null;
                     this.label = 2;
                     if (var2x.yield(var10, var10002) == var9) {
                        return var9;
                     }
                  }

                  return Unit.INSTANCE;
               }

               while(var6.hasNext()) {
                  Object var12 = var6.next();
                  var5.add(var12);
                  if (var5.isFull()) {
                     if (var5.size() < var1) {
                        var5 = var5.expanded(var1);
                     } else {
                        var10001 = var4 ? (List)var5 : (List)(new ArrayList((Collection)var5));
                        var10002 = (Continuation)this;
                        this.L$0 = var2x;
                        this.L$1 = var5;
                        this.L$2 = var6;
                        this.label = 3;
                        if (var2x.yield(var10001, var10002) == var9) {
                           return var9;
                        }

                        var5.removeFirst(var2);
                     }
                  }
               }

               if (!var3) {
                  return Unit.INSTANCE;
               }
            }

            while(var5.size() > var2) {
               var10001 = var4 ? (List)var5 : (List)(new ArrayList((Collection)var5));
               var10002 = (Continuation)this;
               this.L$0 = var2x;
               this.L$1 = var5;
               this.L$2 = null;
               this.label = 4;
               if (var2x.yield(var10001, var10002) == var9) {
                  return var9;
               }

               var5.removeFirst(var2);
            }

            if (!((Collection)var5).isEmpty()) {
               var10002 = (Continuation)this;
               this.L$0 = null;
               this.L$1 = null;
               this.L$2 = null;
               this.label = 5;
               if (var2x.yield(var5, var10002) == var9) {
                  return var9;
               }
            }

            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object var1x, @NotNull Continuation<?> var2x) {
            Function2 var3x = new <anonymous constructor>(var2x);
            var3x.L$0 = var1x;
            return (Continuation)var3x;
         }

         @Nullable
         public final Object invoke(@NotNull SequenceScope<? super List<? extends T>> var1x, @Nullable Continuation<? super Unit> var2x) {
            return ((<undefinedtype>)this.create(var1x, var2x)).invokeSuspend(Unit.INSTANCE);
         }
      }));
   }
}
