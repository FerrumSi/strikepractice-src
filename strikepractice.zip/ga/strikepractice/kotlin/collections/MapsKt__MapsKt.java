package ga.strikepractice.kotlin.collections;

import ga.strikepractice.kotlin.BuilderInference;
import ga.strikepractice.kotlin.ExperimentalStdlibApi;
import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.Pair;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.Unit;
import ga.strikepractice.kotlin.WasExperimental;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.jvm.JvmName;
import ga.strikepractice.kotlin.jvm.functions.Function0;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.jvm.internal.SourceDebugExtension;
import ga.strikepractice.kotlin.jvm.internal.TypeIntrinsics;
import ga.strikepractice.kotlin.sequences.Sequence;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000~\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010%\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010&\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010(\n\u0002\u0010)\n\u0002\u0010'\n\u0002\b\n\n\u0002\u0010\u001c\n\u0002\u0018\u0002\n\u0002\b\u0017\u001a`\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032\u0006\u0010\u0004\u001a\u00020\u00052%\b\u0001\u0010\u0006\u001a\u001f\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0002\b\nH\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0001\u001aX\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032%\b\u0001\u0010\u0006\u001a\u001f\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0002\b\nH\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001\u001a\u001e\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\u001a1\u0010\f\u001a\u001e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\rj\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003`\u000e\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003H\u0087\b\u001a_\u0010\f\u001a\u001e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\rj\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003`\u000e\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032*\u0010\u000f\u001a\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u0010\"\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011¢\u0006\u0002\u0010\u0012\u001a1\u0010\u0013\u001a\u001e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0014j\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003`\u0015\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003H\u0087\b\u001a_\u0010\u0013\u001a\u001e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0014j\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003`\u0015\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032*\u0010\u000f\u001a\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u0010\"\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011¢\u0006\u0002\u0010\u0016\u001a!\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003H\u0087\b\u001aO\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032*\u0010\u000f\u001a\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u0010\"\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011¢\u0006\u0002\u0010\u0018\u001a!\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003H\u0087\b\u001aO\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032*\u0010\u000f\u001a\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u0010\"\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011¢\u0006\u0002\u0010\u0018\u001a*\u0010\u001a\u001a\u0002H\u0002\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001bH\u0087\n¢\u0006\u0002\u0010\u001c\u001a*\u0010\u001d\u001a\u0002H\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001bH\u0087\n¢\u0006\u0002\u0010\u001c\u001a9\u0010\u001e\u001a\u00020\u001f\"\t\b\u0000\u0010\u0002¢\u0006\u0002\b \"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010!\u001a\u0002H\u0002H\u0087\n¢\u0006\u0002\u0010\"\u001a1\u0010#\u001a\u00020\u001f\"\t\b\u0000\u0010\u0002¢\u0006\u0002\b *\u000e\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0002\b\u00030\u00012\u0006\u0010!\u001a\u0002H\u0002H\u0087\b¢\u0006\u0002\u0010\"\u001a7\u0010$\u001a\u00020\u001f\"\u0004\b\u0000\u0010\u0002\"\t\b\u0001\u0010\u0003¢\u0006\u0002\b *\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010%\u001a\u0002H\u0003H\u0087\b¢\u0006\u0002\u0010\"\u001aV\u0010&\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b\u0012\u0004\u0012\u00020\u001f0\u0007H\u0086\bø\u0001\u0000\u001aJ\u0010(\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0012\u0010'\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u001f0\u0007H\u0086\bø\u0001\u0000\u001aV\u0010)\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b\u0012\u0004\u0012\u00020\u001f0\u0007H\u0086\bø\u0001\u0000\u001aq\u0010*\u001a\u0002H+\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0018\b\u0002\u0010+*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010,\u001a\u0002H+2\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b\u0012\u0004\u0012\u00020\u001f0\u0007H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010-\u001aq\u0010.\u001a\u0002H+\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0018\b\u0002\u0010+*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010,\u001a\u0002H+2\u001e\u0010'\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b\u0012\u0004\u0012\u00020\u001f0\u0007H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010-\u001aJ\u0010/\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0012\u0010'\u001a\u000e\u0012\u0004\u0012\u0002H\u0003\u0012\u0004\u0012\u00020\u001f0\u0007H\u0086\bø\u0001\u0000\u001a;\u00100\u001a\u0004\u0018\u0001H\u0003\"\t\b\u0000\u0010\u0002¢\u0006\u0002\b \"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010!\u001a\u0002H\u0002H\u0087\n¢\u0006\u0002\u00101\u001aC\u00102\u001a\u0002H\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010!\u001a\u0002H\u00022\f\u00103\u001a\b\u0012\u0004\u0012\u0002H\u000304H\u0087\bø\u0001\u0000¢\u0006\u0002\u00105\u001aC\u00106\u001a\u0002H\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010!\u001a\u0002H\u00022\f\u00103\u001a\b\u0012\u0004\u0012\u0002H\u000304H\u0080\bø\u0001\u0000¢\u0006\u0002\u00105\u001aC\u00107\u001a\u0002H\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b2\u0006\u0010!\u001a\u0002H\u00022\f\u00103\u001a\b\u0012\u0004\u0012\u0002H\u000304H\u0086\bø\u0001\u0000¢\u0006\u0002\u00105\u001a1\u00108\u001a\u0002H\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010!\u001a\u0002H\u0002H\u0007¢\u0006\u0002\u00101\u001a?\u00109\u001a\u0002H:\"\u0014\b\u0000\u0010+*\n\u0012\u0002\b\u0003\u0012\u0002\b\u00030\u0001*\u0002H:\"\u0004\b\u0001\u0010:*\u0002H+2\f\u00103\u001a\b\u0012\u0004\u0012\u0002H:04H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010;\u001a'\u0010<\u001a\u00020\u001f\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001H\u0087\b\u001a:\u0010=\u001a\u00020\u001f\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003\u0018\u00010\u0001H\u0087\b\u0082\u0002\u000e\n\f\b\u0000\u0012\u0002\u0018\u0001\u001a\u0004\b\u0003\u0010\u0000\u001a9\u0010>\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b0?\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001H\u0087\n\u001a<\u0010>\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030A0@\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\bH\u0087\n¢\u0006\u0002\bB\u001a\\\u0010C\u001a\u000e\u0012\u0004\u0012\u0002H:\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010:*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u001e\u0010D\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b\u0012\u0004\u0012\u0002H:0\u0007H\u0086\bø\u0001\u0000\u001aw\u0010E\u001a\u0002H+\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010:\"\u0018\b\u0003\u0010+*\u0012\u0012\u0006\b\u0000\u0012\u0002H:\u0012\u0006\b\u0000\u0012\u0002H\u00030\b*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010,\u001a\u0002H+2\u001e\u0010D\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b\u0012\u0004\u0012\u0002H:0\u0007H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010-\u001a\\\u0010F\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H:0\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010:*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u001e\u0010D\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b\u0012\u0004\u0012\u0002H:0\u0007H\u0086\bø\u0001\u0000\u001aw\u0010G\u001a\u0002H+\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010:\"\u0018\b\u0003\u0010+*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H:0\b*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010,\u001a\u0002H+2\u001e\u0010D\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001b\u0012\u0004\u0012\u0002H:0\u0007H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010-\u001a@\u0010H\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010!\u001a\u0002H\u0002H\u0087\u0002¢\u0006\u0002\u0010I\u001aH\u0010H\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u000e\u0010J\u001a\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u0010H\u0087\u0002¢\u0006\u0002\u0010K\u001aA\u0010H\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\f\u0010J\u001a\b\u0012\u0004\u0012\u0002H\u00020LH\u0087\u0002\u001aA\u0010H\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\f\u0010J\u001a\b\u0012\u0004\u0012\u0002H\u00020MH\u0087\u0002\u001a2\u0010N\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b2\u0006\u0010!\u001a\u0002H\u0002H\u0087\n¢\u0006\u0002\u0010O\u001a:\u0010N\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b2\u000e\u0010J\u001a\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u0010H\u0087\n¢\u0006\u0002\u0010P\u001a3\u0010N\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b2\f\u0010J\u001a\b\u0012\u0004\u0012\u0002H\u00020LH\u0087\n\u001a3\u0010N\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b2\f\u0010J\u001a\b\u0012\u0004\u0012\u0002H\u00020MH\u0087\n\u001a0\u0010Q\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001H\u0000\u001a3\u0010R\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u0003\u0018\u00010\u0001H\u0087\b\u001aT\u0010S\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u001a\u0010\u000f\u001a\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u0010H\u0086\u0002¢\u0006\u0002\u0010T\u001aG\u0010S\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0012\u0010U\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011H\u0086\u0002\u001aM\u0010S\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0018\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110LH\u0086\u0002\u001aI\u0010S\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0014\u0010V\u001a\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001H\u0086\u0002\u001aM\u0010S\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0018\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110MH\u0086\u0002\u001aJ\u0010W\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b2\u001a\u0010\u000f\u001a\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u0010H\u0087\n¢\u0006\u0002\u0010X\u001a=\u0010W\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b2\u0012\u0010U\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011H\u0087\n\u001aC\u0010W\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b2\u0018\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110LH\u0087\n\u001a=\u0010W\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b2\u0012\u0010V\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001H\u0087\n\u001aC\u0010W\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b2\u0018\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110MH\u0087\n\u001aG\u0010Y\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b2\u001a\u0010\u000f\u001a\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u0010¢\u0006\u0002\u0010X\u001a@\u0010Y\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b2\u0018\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110L\u001a@\u0010Y\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b2\u0018\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110M\u001a;\u0010Z\u001a\u0004\u0018\u0001H\u0003\"\t\b\u0000\u0010\u0002¢\u0006\u0002\b \"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b2\u0006\u0010!\u001a\u0002H\u0002H\u0087\b¢\u0006\u0002\u00101\u001a:\u0010[\u001a\u00020\t\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b2\u0006\u0010!\u001a\u0002H\u00022\u0006\u0010%\u001a\u0002H\u0003H\u0087\n¢\u0006\u0002\u0010\\\u001a;\u0010]\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u0010¢\u0006\u0002\u0010\u0018\u001aQ\u0010]\u001a\u0002H+\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0018\b\u0002\u0010+*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b*\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110\u00102\u0006\u0010,\u001a\u0002H+¢\u0006\u0002\u0010^\u001a4\u0010]\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110L\u001aO\u0010]\u001a\u0002H+\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0018\b\u0002\u0010+*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b*\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110L2\u0006\u0010,\u001a\u0002H+¢\u0006\u0002\u0010_\u001a2\u0010]\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001H\u0007\u001aM\u0010]\u001a\u0002H+\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0018\b\u0002\u0010+*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00012\u0006\u0010,\u001a\u0002H+H\u0007¢\u0006\u0002\u0010`\u001a4\u0010]\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110M\u001aO\u0010]\u001a\u0002H+\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0018\b\u0002\u0010+*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0006\b\u0000\u0012\u0002H\u00030\b*\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00110M2\u0006\u0010,\u001a\u0002H+¢\u0006\u0002\u0010a\u001a2\u0010b\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\b\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u0010\u0012\u0006\b\u0001\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001H\u0007\u001a1\u0010c\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u001bH\u0087\b\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006d"},
   d2 = {"buildMap", "", "K", "V", "capacity", "", "builderAction", "Lga/strikepractice/kotlin/Function1;", "", "", "Lga/strikepractice/kotlin/ExtensionFunctionType;", "emptyMap", "hashMapOf", "Ljava/util/HashMap;", "Lga/strikepractice/kotlin/collections/HashMap;", "pairs", "", "Lga/strikepractice/kotlin/Pair;", "([Lkotlin/Pair;)Ljava/util/HashMap;", "linkedMapOf", "Ljava/util/LinkedHashMap;", "Lga/strikepractice/kotlin/collections/LinkedHashMap;", "([Lkotlin/Pair;)Ljava/util/LinkedHashMap;", "mapOf", "([Lkotlin/Pair;)Ljava/util/Map;", "mutableMapOf", "component1", "", "(Ljava/util/Map$Entry;)Ljava/lang/Object;", "component2", "contains", "", "Lga/strikepractice/kotlin/internal/OnlyInputTypes;", "key", "(Ljava/util/Map;Ljava/lang/Object;)Z", "containsKey", "containsValue", "value", "filter", "predicate", "filterKeys", "filterNot", "filterNotTo", "M", "destination", "(Ljava/util/Map;Ljava/util/Map;Lkotlin/jvm/functions/Function1;)Ljava/util/Map;", "filterTo", "filterValues", "get", "(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;", "getOrElse", "defaultValue", "Lga/strikepractice/kotlin/Function0;", "(Ljava/util/Map;Ljava/lang/Object;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "getOrElseNullable", "getOrPut", "getValue", "ifEmpty", "R", "(Ljava/util/Map;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "isNotEmpty", "isNullOrEmpty", "iterator", "", "", "", "mutableIterator", "mapKeys", "transform", "mapKeysTo", "mapValues", "mapValuesTo", "minus", "(Ljava/util/Map;Ljava/lang/Object;)Ljava/util/Map;", "keys", "(Ljava/util/Map;[Ljava/lang/Object;)Ljava/util/Map;", "", "Lga/strikepractice/kotlin/sequences/Sequence;", "minusAssign", "(Ljava/util/Map;Ljava/lang/Object;)V", "(Ljava/util/Map;[Ljava/lang/Object;)V", "optimizeReadOnlyMap", "orEmpty", "plus", "(Ljava/util/Map;[Lkotlin/Pair;)Ljava/util/Map;", "pair", "map", "plusAssign", "(Ljava/util/Map;[Lkotlin/Pair;)V", "putAll", "remove", "set", "(Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)V", "toMap", "([Lkotlin/Pair;Ljava/util/Map;)Ljava/util/Map;", "(Ljava/lang/Iterable;Ljava/util/Map;)Ljava/util/Map;", "(Ljava/util/Map;Ljava/util/Map;)Ljava/util/Map;", "(Lkotlin/sequences/Sequence;Ljava/util/Map;)Ljava/util/Map;", "toMutableMap", "toPair", "ga.strikepractice.kotlin-stdlib"},
   xs = "ga/strikepractice/kotlin/collections/MapsKt"
)
@SourceDebugExtension({"SMAP\nMaps.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,793:1\n392#1:803\n403#1:808\n500#1,6:813\n525#1,6:819\n1#2:794\n1238#3,4:795\n1238#3,4:799\n1238#3,4:804\n1238#3,4:809\n*S KotlinDebug\n*F\n+ 1 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n442#1:803\n457#1:808\n515#1:813,6\n540#1:819,6\n392#1:795,4\n403#1:799,4\n442#1:804,4\n457#1:809,4\n*E\n"})
class MapsKt__MapsKt extends MapsKt__MapsJVMKt {
   @NotNull
   public static final <K, V> Map<K, V> emptyMap() {
      EmptyMap var10000 = EmptyMap.INSTANCE;
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
      return (Map)var10000;
   }

   @NotNull
   public static final <K, V> Map<K, V> mapOf(@NotNull Pair<? extends K, ? extends V>... var0) {
      Intrinsics.checkNotNullParameter(var0, "pairs");
      return var0.length > 0 ? MapsKt.toMap(var0, (Map)(new LinkedHashMap(MapsKt.mapCapacity(var0.length)))) : MapsKt.emptyMap();
   }

   @InlineOnly
   private static final <K, V> Map<K, V> mapOf() {
      return MapsKt.emptyMap();
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final <K, V> Map<K, V> mutableMapOf() {
      return (Map)(new LinkedHashMap());
   }

   @NotNull
   public static final <K, V> Map<K, V> mutableMapOf(@NotNull Pair<? extends K, ? extends V>... var0) {
      Intrinsics.checkNotNullParameter(var0, "pairs");
      LinkedHashMap var1 = new LinkedHashMap(MapsKt.mapCapacity(var0.length));
      boolean var3 = false;
      MapsKt.putAll((Map)var1, var0);
      return (Map)var1;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final <K, V> HashMap<K, V> hashMapOf() {
      return new HashMap();
   }

   @NotNull
   public static final <K, V> HashMap<K, V> hashMapOf(@NotNull Pair<? extends K, ? extends V>... var0) {
      Intrinsics.checkNotNullParameter(var0, "pairs");
      HashMap var1 = new HashMap(MapsKt.mapCapacity(var0.length));
      boolean var3 = false;
      MapsKt.putAll((Map)var1, var0);
      return var1;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final <K, V> LinkedHashMap<K, V> linkedMapOf() {
      return new LinkedHashMap();
   }

   @NotNull
   public static final <K, V> LinkedHashMap<K, V> linkedMapOf(@NotNull Pair<? extends K, ? extends V>... var0) {
      Intrinsics.checkNotNullParameter(var0, "pairs");
      return (LinkedHashMap)MapsKt.toMap(var0, (Map)(new LinkedHashMap(MapsKt.mapCapacity(var0.length))));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalStdlibApi.class}
   )
   @InlineOnly
   private static final <K, V> Map<K, V> buildMap(@BuilderInference Function1<? super Map<K, V>, Unit> var0) {
      Intrinsics.checkNotNullParameter(var0, "builderAction");
      Map var1 = MapsKt.createMapBuilder();
      var0.invoke(var1);
      return MapsKt.build(var1);
   }

   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalStdlibApi.class}
   )
   @InlineOnly
   private static final <K, V> Map<K, V> buildMap(int var0, @BuilderInference Function1<? super Map<K, V>, Unit> var1) {
      Intrinsics.checkNotNullParameter(var1, "builderAction");
      Map var2 = MapsKt.createMapBuilder(var0);
      var1.invoke(var2);
      return MapsKt.build(var2);
   }

   @InlineOnly
   private static final <K, V> boolean isNotEmpty(Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return !var0.isEmpty();
   }

   @SinceKotlin(
      version = "1.3"
   )
   @InlineOnly
   private static final <K, V> boolean isNullOrEmpty(Map<? extends K, ? extends V> var0) {
      return var0 == null || var0.isEmpty();
   }

   @InlineOnly
   private static final <K, V> Map<K, V> orEmpty(Map<K, ? extends V> var0) {
      Map var10000 = var0;
      if (var0 == null) {
         var10000 = MapsKt.emptyMap();
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.3"
   )
   @InlineOnly
   private static final <M extends Map<?, ?> & R, R> R ifEmpty(M var0, Function0<? extends R> var1) {
      Intrinsics.checkNotNullParameter(var1, "defaultValue");
      return var0.isEmpty() ? var1.invoke() : var0;
   }

   @InlineOnly
   private static final <K, V> boolean contains(Map<? extends K, ? extends V> var0, K var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.containsKey(var1);
   }

   @InlineOnly
   private static final <K, V> V get(Map<? extends K, ? extends V> var0, K var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.get(var1);
   }

   @InlineOnly
   private static final <K, V> void set(Map<K, V> var0, K var1, V var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      var0.put(var1, var2);
   }

   @InlineOnly
   private static final <K> boolean containsKey(Map<? extends K, ?> var0, K var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.containsKey(var1);
   }

   @InlineOnly
   private static final <K, V> boolean containsValue(Map<K, ? extends V> var0, V var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.containsValue(var1);
   }

   @InlineOnly
   private static final <K, V> V remove(Map<? extends K, V> var0, K var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return TypeIntrinsics.asMutableMap(var0).remove(var1);
   }

   @InlineOnly
   private static final <K, V> K component1(Entry<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.getKey();
   }

   @InlineOnly
   private static final <K, V> V component2(Entry<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.getValue();
   }

   @InlineOnly
   private static final <K, V> Pair<K, V> toPair(Entry<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return new Pair(var0.getKey(), var0.getValue());
   }

   @InlineOnly
   private static final <K, V> V getOrElse(Map<K, ? extends V> var0, K var1, Function0<? extends V> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var2, "defaultValue");
      Object var10000 = var0.get(var1);
      if (var10000 == null) {
         var10000 = var2.invoke();
      }

      return var10000;
   }

   public static final <K, V> V getOrElseNullable(@NotNull Map<K, ? extends V> var0, K var1, @NotNull Function0<? extends V> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var2, "defaultValue");
      boolean var3 = false;
      Object var4 = var0.get(var1);
      return var4 == null && !var0.containsKey(var1) ? var2.invoke() : var4;
   }

   @SinceKotlin(
      version = "1.1"
   )
   public static final <K, V> V getValue(@NotNull Map<K, ? extends V> var0, K var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return MapsKt.getOrImplicitDefaultNullable(var0, var1);
   }

   public static final <K, V> V getOrPut(@NotNull Map<K, V> var0, K var1, @NotNull Function0<? extends V> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var2, "defaultValue");
      boolean var3 = false;
      Object var4 = var0.get(var1);
      Object var10000;
      if (var4 == null) {
         Object var5 = var2.invoke();
         var0.put(var1, var5);
         var10000 = var5;
      } else {
         var10000 = var4;
      }

      return var10000;
   }

   @InlineOnly
   private static final <K, V> Iterator<Entry<K, V>> iterator(Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.entrySet().iterator();
   }

   @JvmName(
      name = "mutableIterator"
   )
   @InlineOnly
   private static final <K, V> Iterator<Entry<K, V>> mutableIterator(Map<K, V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return var0.entrySet().iterator();
   }

   @NotNull
   public static final <K, V, R, M extends Map<? super K, ? super R>> M mapValuesTo(@NotNull Map<? extends K, ? extends V> var0, @NotNull M var1, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "transform");
      boolean var3 = false;
      Iterable var4 = (Iterable)var0.entrySet();
      boolean var5 = false;
      Iterator var6 = var4.iterator();

      while(var6.hasNext()) {
         Object var7 = var6.next();
         Entry var8 = (Entry)var7;
         boolean var9 = false;
         var1.put(var8.getKey(), var2.invoke(var7));
      }

      return var1;
   }

   @NotNull
   public static final <K, V, R, M extends Map<? super R, ? super V>> M mapKeysTo(@NotNull Map<? extends K, ? extends V> var0, @NotNull M var1, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends R> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "transform");
      boolean var3 = false;
      Iterable var4 = (Iterable)var0.entrySet();
      boolean var5 = false;
      Iterator var6 = var4.iterator();

      while(var6.hasNext()) {
         Object var7 = var6.next();
         Object var10001 = var2.invoke(var7);
         Entry var8 = (Entry)var7;
         Object var11 = var10001;
         boolean var9 = false;
         Object var12 = var8.getValue();
         var1.put(var11, var12);
      }

      return var1;
   }

   public static final <K, V> void putAll(@NotNull Map<? super K, ? super V> var0, @NotNull Pair<? extends K, ? extends V>[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      int var2 = 0;

      for(int var3 = var1.length; var2 < var3; ++var2) {
         Pair var4 = var1[var2];
         Object var5 = var4.component1();
         Object var6 = var4.component2();
         var0.put(var5, var6);
      }

   }

   public static final <K, V> void putAll(@NotNull Map<? super K, ? super V> var0, @NotNull Iterable<? extends Pair<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         Pair var3 = (Pair)var2.next();
         Object var4 = var3.component1();
         Object var5 = var3.component2();
         var0.put(var4, var5);
      }

   }

   public static final <K, V> void putAll(@NotNull Map<? super K, ? super V> var0, @NotNull Sequence<? extends Pair<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         Pair var3 = (Pair)var2.next();
         Object var4 = var3.component1();
         Object var5 = var3.component2();
         var0.put(var4, var5);
      }

   }

   @NotNull
   public static final <K, V, R> Map<K, R> mapValues(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "transform");
      boolean var2 = false;
      Map var4 = (Map)(new LinkedHashMap(MapsKt.mapCapacity(var0.size())));
      boolean var5 = false;
      Iterable var6 = (Iterable)var0.entrySet();
      boolean var7 = false;
      Iterator var8 = var6.iterator();

      while(var8.hasNext()) {
         Object var9 = var8.next();
         Entry var10 = (Entry)var9;
         boolean var12 = false;
         var4.put(var10.getKey(), var1.invoke(var9));
      }

      return var4;
   }

   @NotNull
   public static final <K, V, R> Map<R, V> mapKeys(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "transform");
      boolean var2 = false;
      Map var4 = (Map)(new LinkedHashMap(MapsKt.mapCapacity(var0.size())));
      boolean var5 = false;
      Iterable var6 = (Iterable)var0.entrySet();
      boolean var7 = false;
      Iterator var8 = var6.iterator();

      while(var8.hasNext()) {
         Object var9 = var8.next();
         Object var10001 = var1.invoke(var9);
         Entry var10 = (Entry)var9;
         Object var11 = var10001;
         boolean var13 = false;
         Object var14 = var10.getValue();
         var4.put(var11, var14);
      }

      return var4;
   }

   @NotNull
   public static final <K, V> Map<K, V> filterKeys(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super K, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      boolean var2 = false;
      LinkedHashMap var3 = new LinkedHashMap();
      Iterator var4 = var0.entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         if ((Boolean)var1.invoke(var5.getKey())) {
            var3.put(var5.getKey(), var5.getValue());
         }
      }

      return (Map)var3;
   }

   @NotNull
   public static final <K, V> Map<K, V> filterValues(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super V, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      boolean var2 = false;
      LinkedHashMap var3 = new LinkedHashMap();
      Iterator var4 = var0.entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         if ((Boolean)var1.invoke(var5.getValue())) {
            var3.put(var5.getKey(), var5.getValue());
         }
      }

      return (Map)var3;
   }

   @NotNull
   public static final <K, V, M extends Map<? super K, ? super V>> M filterTo(@NotNull Map<? extends K, ? extends V> var0, @NotNull M var1, @NotNull Function1<? super Entry<? extends K, ? extends V>, Boolean> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "predicate");
      boolean var3 = false;
      Iterator var4 = var0.entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         if ((Boolean)var2.invoke(var5)) {
            var1.put(var5.getKey(), var5.getValue());
         }
      }

      return var1;
   }

   @NotNull
   public static final <K, V> Map<K, V> filter(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      boolean var2 = false;
      Map var4 = (Map)(new LinkedHashMap());
      boolean var5 = false;
      Iterator var6 = var0.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var7 = (Entry)var6.next();
         if ((Boolean)var1.invoke(var7)) {
            var4.put(var7.getKey(), var7.getValue());
         }
      }

      return var4;
   }

   @NotNull
   public static final <K, V, M extends Map<? super K, ? super V>> M filterNotTo(@NotNull Map<? extends K, ? extends V> var0, @NotNull M var1, @NotNull Function1<? super Entry<? extends K, ? extends V>, Boolean> var2) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      Intrinsics.checkNotNullParameter(var2, "predicate");
      boolean var3 = false;
      Iterator var4 = var0.entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         if (!(Boolean)var2.invoke(var5)) {
            var1.put(var5.getKey(), var5.getValue());
         }
      }

      return var1;
   }

   @NotNull
   public static final <K, V> Map<K, V> filterNot(@NotNull Map<? extends K, ? extends V> var0, @NotNull Function1<? super Entry<? extends K, ? extends V>, Boolean> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "predicate");
      boolean var2 = false;
      Map var4 = (Map)(new LinkedHashMap());
      boolean var5 = false;
      Iterator var6 = var0.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var7 = (Entry)var6.next();
         if (!(Boolean)var1.invoke(var7)) {
            var4.put(var7.getKey(), var7.getValue());
         }
      }

      return var4;
   }

   @NotNull
   public static final <K, V> Map<K, V> toMap(@NotNull Iterable<? extends Pair<? extends K, ? extends V>> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      if (var0 instanceof Collection) {
         Map var10000;
         switch(((Collection)var0).size()) {
         case 0:
            var10000 = MapsKt.emptyMap();
            break;
         case 1:
            var10000 = MapsKt.mapOf(var0 instanceof List ? (Pair)((List)var0).get(0) : (Pair)var0.iterator().next());
            break;
         default:
            var10000 = MapsKt.toMap(var0, (Map)(new LinkedHashMap(MapsKt.mapCapacity(((Collection)var0).size()))));
         }

         return var10000;
      } else {
         return MapsKt.optimizeReadOnlyMap(MapsKt.toMap(var0, (Map)(new LinkedHashMap())));
      }
   }

   @NotNull
   public static final <K, V, M extends Map<? super K, ? super V>> M toMap(@NotNull Iterable<? extends Pair<? extends K, ? extends V>> var0, @NotNull M var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      boolean var4 = false;
      MapsKt.putAll(var1, var0);
      return var1;
   }

   @NotNull
   public static final <K, V> Map<K, V> toMap(@NotNull Pair<? extends K, ? extends V>[] var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Map var10000;
      switch(var0.length) {
      case 0:
         var10000 = MapsKt.emptyMap();
         break;
      case 1:
         var10000 = MapsKt.mapOf(var0[0]);
         break;
      default:
         var10000 = MapsKt.toMap(var0, (Map)(new LinkedHashMap(MapsKt.mapCapacity(var0.length))));
      }

      return var10000;
   }

   @NotNull
   public static final <K, V, M extends Map<? super K, ? super V>> M toMap(@NotNull Pair<? extends K, ? extends V>[] var0, @NotNull M var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      boolean var4 = false;
      MapsKt.putAll(var1, var0);
      return var1;
   }

   @NotNull
   public static final <K, V> Map<K, V> toMap(@NotNull Sequence<? extends Pair<? extends K, ? extends V>> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return MapsKt.optimizeReadOnlyMap(MapsKt.toMap(var0, (Map)(new LinkedHashMap())));
   }

   @NotNull
   public static final <K, V, M extends Map<? super K, ? super V>> M toMap(@NotNull Sequence<? extends Pair<? extends K, ? extends V>> var0, @NotNull M var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      boolean var4 = false;
      MapsKt.putAll(var1, var0);
      return var1;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <K, V> Map<K, V> toMap(@NotNull Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Map var10000;
      switch(var0.size()) {
      case 0:
         var10000 = MapsKt.emptyMap();
         break;
      case 1:
         var10000 = MapsKt.toSingletonMap(var0);
         break;
      default:
         var10000 = MapsKt.toMutableMap(var0);
      }

      return var10000;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <K, V> Map<K, V> toMutableMap(@NotNull Map<? extends K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      return (Map)(new LinkedHashMap(var0));
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <K, V, M extends Map<? super K, ? super V>> M toMap(@NotNull Map<? extends K, ? extends V> var0, @NotNull M var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "destination");
      boolean var4 = false;
      var1.putAll(var0);
      return var1;
   }

   @NotNull
   public static final <K, V> Map<K, V> plus(@NotNull Map<? extends K, ? extends V> var0, @NotNull Pair<? extends K, ? extends V> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pair");
      Map var10000;
      if (var0.isEmpty()) {
         var10000 = MapsKt.mapOf(var1);
      } else {
         LinkedHashMap var2 = new LinkedHashMap(var0);
         boolean var4 = false;
         var2.put(var1.getFirst(), var1.getSecond());
         var10000 = (Map)var2;
      }

      return var10000;
   }

   @NotNull
   public static final <K, V> Map<K, V> plus(@NotNull Map<? extends K, ? extends V> var0, @NotNull Iterable<? extends Pair<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      Map var10000;
      if (var0.isEmpty()) {
         var10000 = MapsKt.toMap(var1);
      } else {
         LinkedHashMap var2 = new LinkedHashMap(var0);
         boolean var4 = false;
         MapsKt.putAll((Map)var2, var1);
         var10000 = (Map)var2;
      }

      return var10000;
   }

   @NotNull
   public static final <K, V> Map<K, V> plus(@NotNull Map<? extends K, ? extends V> var0, @NotNull Pair<? extends K, ? extends V>[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      Map var10000;
      if (var0.isEmpty()) {
         var10000 = MapsKt.toMap(var1);
      } else {
         LinkedHashMap var2 = new LinkedHashMap(var0);
         boolean var4 = false;
         MapsKt.putAll((Map)var2, var1);
         var10000 = (Map)var2;
      }

      return var10000;
   }

   @NotNull
   public static final <K, V> Map<K, V> plus(@NotNull Map<? extends K, ? extends V> var0, @NotNull Sequence<? extends Pair<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      LinkedHashMap var2 = new LinkedHashMap(var0);
      boolean var4 = false;
      MapsKt.putAll((Map)var2, var1);
      return MapsKt.optimizeReadOnlyMap((Map)var2);
   }

   @NotNull
   public static final <K, V> Map<K, V> plus(@NotNull Map<? extends K, ? extends V> var0, @NotNull Map<? extends K, ? extends V> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "map");
      LinkedHashMap var2 = new LinkedHashMap(var0);
      boolean var4 = false;
      var2.putAll(var1);
      return (Map)var2;
   }

   @InlineOnly
   private static final <K, V> void plusAssign(Map<? super K, ? super V> var0, Pair<? extends K, ? extends V> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pair");
      var0.put(var1.getFirst(), var1.getSecond());
   }

   @InlineOnly
   private static final <K, V> void plusAssign(Map<? super K, ? super V> var0, Iterable<? extends Pair<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      MapsKt.putAll(var0, var1);
   }

   @InlineOnly
   private static final <K, V> void plusAssign(Map<? super K, ? super V> var0, Pair<? extends K, ? extends V>[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      MapsKt.putAll(var0, var1);
   }

   @InlineOnly
   private static final <K, V> void plusAssign(Map<? super K, ? super V> var0, Sequence<? extends Pair<? extends K, ? extends V>> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "pairs");
      MapsKt.putAll(var0, var1);
   }

   @InlineOnly
   private static final <K, V> void plusAssign(Map<? super K, ? super V> var0, Map<K, ? extends V> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "map");
      var0.putAll(var1);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <K, V> Map<K, V> minus(@NotNull Map<? extends K, ? extends V> var0, K var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Map var2 = MapsKt.toMutableMap(var0);
      boolean var4 = false;
      var2.remove(var1);
      return MapsKt.optimizeReadOnlyMap(var2);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <K, V> Map<K, V> minus(@NotNull Map<? extends K, ? extends V> var0, @NotNull Iterable<? extends K> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "keys");
      Map var2 = MapsKt.toMutableMap(var0);
      boolean var4 = false;
      CollectionsKt.removeAll((Collection)var2.keySet(), var1);
      return MapsKt.optimizeReadOnlyMap(var2);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <K, V> Map<K, V> minus(@NotNull Map<? extends K, ? extends V> var0, @NotNull K[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "keys");
      Map var2 = MapsKt.toMutableMap(var0);
      boolean var4 = false;
      CollectionsKt.removeAll((Collection)var2.keySet(), var1);
      return MapsKt.optimizeReadOnlyMap(var2);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @NotNull
   public static final <K, V> Map<K, V> minus(@NotNull Map<? extends K, ? extends V> var0, @NotNull Sequence<? extends K> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "keys");
      Map var2 = MapsKt.toMutableMap(var0);
      boolean var4 = false;
      CollectionsKt.removeAll((Collection)var2.keySet(), var1);
      return MapsKt.optimizeReadOnlyMap(var2);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final <K, V> void minusAssign(Map<K, V> var0, K var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      var0.remove(var1);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final <K, V> void minusAssign(Map<K, V> var0, Iterable<? extends K> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "keys");
      CollectionsKt.removeAll((Collection)var0.keySet(), var1);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final <K, V> void minusAssign(Map<K, V> var0, K[] var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "keys");
      CollectionsKt.removeAll((Collection)var0.keySet(), var1);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final <K, V> void minusAssign(Map<K, V> var0, Sequence<? extends K> var1) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Intrinsics.checkNotNullParameter(var1, "keys");
      CollectionsKt.removeAll((Collection)var0.keySet(), var1);
   }

   @NotNull
   public static final <K, V> Map<K, V> optimizeReadOnlyMap(@NotNull Map<K, ? extends V> var0) {
      Intrinsics.checkNotNullParameter(var0, "<this>");
      Map var10000;
      switch(var0.size()) {
      case 0:
         var10000 = MapsKt.emptyMap();
         break;
      case 1:
         var10000 = MapsKt.toSingletonMap(var0);
         break;
      default:
         var10000 = var0;
      }

      return var10000;
   }

   public MapsKt__MapsKt() {
   }
}
