package ga.strikepractice.kotlin.io.encoding;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.collections.AbstractList;
import ga.strikepractice.kotlin.jvm.internal.DefaultConstructorMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import ga.strikepractice.kotlin.text.CharsKt;
import ga.strikepractice.kotlin.text.Charsets;
import java.nio.charset.Charset;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0010\r\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\b\u0017\u0018\u0000 22\u00020\u0001:\u00012B\u0017\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\u0015\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH\u0000¢\u0006\u0002\b\rJ%\u0010\u000e\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0000¢\u0006\u0002\b\u0013J \u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u00112\u0006\u0010\u0018\u001a\u00020\u0011H\u0002J%\u0010\u0019\u001a\u00020\u00152\u0006\u0010\u001a\u001a\u00020\u00112\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0000¢\u0006\u0002\b\u001bJ\"\u0010\u001c\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011J\"\u0010\u001c\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\u000f2\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011J0\u0010\u001d\u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u001e\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u00112\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0002J4\u0010\u001f\u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u001e\u001a\u00020\f2\b\b\u0002\u0010\u0017\u001a\u00020\u00112\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011J4\u0010\u001f\u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\u000f2\u0006\u0010\u001e\u001a\u00020\f2\b\b\u0002\u0010\u0017\u001a\u00020\u00112\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011J \u0010 \u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0002J\"\u0010!\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011J4\u0010\"\u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u001e\u001a\u00020\f2\b\b\u0002\u0010\u0017\u001a\u00020\u00112\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011J5\u0010#\u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u001e\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u00112\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0000¢\u0006\u0002\b$J\u0010\u0010%\u001a\u00020\u00112\u0006\u0010\u001a\u001a\u00020\u0011H\u0002J=\u0010&\u001a\u0002H'\"\f\b\u0000\u0010'*\u00060(j\u0002`)2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u001e\u001a\u0002H'2\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011¢\u0006\u0002\u0010*J\"\u0010+\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011J%\u0010,\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0000¢\u0006\u0002\b-J(\u0010.\u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010/\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00112\u0006\u00100\u001a\u00020\u0011H\u0002J \u00101\u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0002R\u0014\u0010\u0004\u001a\u00020\u0003X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0014\u0010\u0002\u001a\u00020\u0003X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007¨\u00063"},
   d2 = {"Lga/strikepractice/kotlin/io/encoding/Base64;", "", "isUrlSafe", "", "isMimeScheme", "(ZZ)V", "isMimeScheme$kotlin_stdlib", "()Z", "isUrlSafe$kotlin_stdlib", "bytesToStringImpl", "", "source", "", "bytesToStringImpl$kotlin_stdlib", "charsToBytesImpl", "", "startIndex", "", "endIndex", "charsToBytesImpl$kotlin_stdlib", "checkDestinationBounds", "", "destinationSize", "destinationOffset", "capacityNeeded", "checkSourceBounds", "sourceSize", "checkSourceBounds$kotlin_stdlib", "decode", "decodeImpl", "destination", "decodeIntoByteArray", "decodeSize", "encode", "encodeIntoByteArray", "encodeIntoByteArrayImpl", "encodeIntoByteArrayImpl$kotlin_stdlib", "encodeSize", "encodeToAppendable", "A", "Ljava/lang/Appendable;", "Lga/strikepractice/kotlin/text/Appendable;", "([BLjava/lang/Appendable;II)Ljava/lang/Appendable;", "encodeToByteArray", "encodeToByteArrayImpl", "encodeToByteArrayImpl$kotlin_stdlib", "handlePaddingSymbol", "padIndex", "byteStart", "skipIllegalSymbolsIfMime", "Default", "ga.strikepractice.kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.8"
)
@ExperimentalEncodingApi
public class Base64 {
   @NotNull
   public static final Base64.Default Default = new Base64.Default((DefaultConstructorMarker)null);
   private final boolean isUrlSafe;
   private final boolean isMimeScheme;
   private static final int bitsPerByte = 8;
   private static final int bitsPerSymbol = 6;
   public static final int bytesPerGroup = 3;
   public static final int symbolsPerGroup = 4;
   public static final byte padSymbol = 61;
   public static final int mimeLineLength = 76;
   private static final int mimeGroupsPerLine = 19;
   @NotNull
   private static final byte[] mimeLineSeparatorSymbols;
   @NotNull
   private static final Base64 UrlSafe;
   @NotNull
   private static final Base64 Mime;

   private Base64(boolean var1, boolean var2) {
      this.isUrlSafe = var1;
      this.isMimeScheme = var2;
      boolean var3 = !this.isUrlSafe || !this.isMimeScheme;
      if (!var3) {
         String var4 = "Failed requirement.";
         throw new IllegalArgumentException(var4.toString());
      }
   }

   public final boolean isUrlSafe$kotlin_stdlib() {
      return this.isUrlSafe;
   }

   public final boolean isMimeScheme$kotlin_stdlib() {
      return this.isMimeScheme;
   }

   @NotNull
   public final byte[] encodeToByteArray(@NotNull byte[] var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var1, "source");
      return this.encodeToByteArrayImpl$kotlin_stdlib(var1, var2, var3);
   }

   // $FF: synthetic method
   public static byte[] encodeToByteArray$default(Base64 var0, byte[] var1, int var2, int var3, int var4, Object var5) {
      if (var5 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: encodeToByteArray");
      } else {
         if ((var4 & 2) != 0) {
            var2 = 0;
         }

         if ((var4 & 4) != 0) {
            var3 = var1.length;
         }

         return var0.encodeToByteArray(var1, var2, var3);
      }
   }

   public final int encodeIntoByteArray(@NotNull byte[] var1, @NotNull byte[] var2, int var3, int var4, int var5) {
      Intrinsics.checkNotNullParameter(var1, "source");
      Intrinsics.checkNotNullParameter(var2, "destination");
      return this.encodeIntoByteArrayImpl$kotlin_stdlib(var1, var2, var3, var4, var5);
   }

   // $FF: synthetic method
   public static int encodeIntoByteArray$default(Base64 var0, byte[] var1, byte[] var2, int var3, int var4, int var5, int var6, Object var7) {
      if (var7 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: encodeIntoByteArray");
      } else {
         if ((var6 & 4) != 0) {
            var3 = 0;
         }

         if ((var6 & 8) != 0) {
            var4 = 0;
         }

         if ((var6 & 16) != 0) {
            var5 = var1.length;
         }

         return var0.encodeIntoByteArray(var1, var2, var3, var4, var5);
      }
   }

   @NotNull
   public final String encode(@NotNull byte[] var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var1, "source");
      byte[] var4 = this.encodeToByteArrayImpl$kotlin_stdlib(var1, var2, var3);
      return new String(var4, Charsets.ISO_8859_1);
   }

   // $FF: synthetic method
   public static String encode$default(Base64 var0, byte[] var1, int var2, int var3, int var4, Object var5) {
      if (var5 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: encode");
      } else {
         if ((var4 & 2) != 0) {
            var2 = 0;
         }

         if ((var4 & 4) != 0) {
            var3 = var1.length;
         }

         return var0.encode(var1, var2, var3);
      }
   }

   @NotNull
   public final <A extends Appendable> A encodeToAppendable(@NotNull byte[] var1, @NotNull A var2, int var3, int var4) {
      Intrinsics.checkNotNullParameter(var1, "source");
      Intrinsics.checkNotNullParameter(var2, "destination");
      byte[] var6 = this.encodeToByteArrayImpl$kotlin_stdlib(var1, var3, var4);
      String var5 = new String(var6, Charsets.ISO_8859_1);
      var2.append((CharSequence)var5);
      return var2;
   }

   // $FF: synthetic method
   public static Appendable encodeToAppendable$default(Base64 var0, byte[] var1, Appendable var2, int var3, int var4, int var5, Object var6) {
      if (var6 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: encodeToAppendable");
      } else {
         if ((var5 & 4) != 0) {
            var3 = 0;
         }

         if ((var5 & 8) != 0) {
            var4 = var1.length;
         }

         return var0.encodeToAppendable(var1, var2, var3, var4);
      }
   }

   @NotNull
   public final byte[] decode(@NotNull byte[] var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var1, "source");
      this.checkSourceBounds$kotlin_stdlib(var1.length, var2, var3);
      int var4 = this.decodeSize(var1, var2, var3);
      byte[] var5 = new byte[var4];
      int var6 = this.decodeImpl(var1, var5, 0, var2, var3);
      boolean var7 = var6 == var5.length;
      if (!var7) {
         String var8 = "Check failed.";
         throw new IllegalStateException(var8.toString());
      } else {
         return var5;
      }
   }

   // $FF: synthetic method
   public static byte[] decode$default(Base64 var0, byte[] var1, int var2, int var3, int var4, Object var5) {
      if (var5 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: decode");
      } else {
         if ((var4 & 2) != 0) {
            var2 = 0;
         }

         if ((var4 & 4) != 0) {
            var3 = var1.length;
         }

         return var0.decode(var1, var2, var3);
      }
   }

   public final int decodeIntoByteArray(@NotNull byte[] var1, @NotNull byte[] var2, int var3, int var4, int var5) {
      Intrinsics.checkNotNullParameter(var1, "source");
      Intrinsics.checkNotNullParameter(var2, "destination");
      this.checkSourceBounds$kotlin_stdlib(var1.length, var4, var5);
      this.checkDestinationBounds(var2.length, var3, this.decodeSize(var1, var4, var5));
      return this.decodeImpl(var1, var2, var3, var4, var5);
   }

   // $FF: synthetic method
   public static int decodeIntoByteArray$default(Base64 var0, byte[] var1, byte[] var2, int var3, int var4, int var5, int var6, Object var7) {
      if (var7 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: decodeIntoByteArray");
      } else {
         if ((var6 & 4) != 0) {
            var3 = 0;
         }

         if ((var6 & 8) != 0) {
            var4 = 0;
         }

         if ((var6 & 16) != 0) {
            var5 = var1.length;
         }

         return var0.decodeIntoByteArray(var1, var2, var3, var4, var5);
      }
   }

   @NotNull
   public final byte[] decode(@NotNull CharSequence var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var1, "source");
      byte[] var8;
      if (var1 instanceof String) {
         this.checkSourceBounds$kotlin_stdlib(var1.length(), var2, var3);
         String var10000 = ((String)var1).substring(var2, var3);
         Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String…ing(startIndex, endIndex)");
         String var6 = var10000;
         Charset var7 = Charsets.ISO_8859_1;
         Intrinsics.checkNotNull(var6, "null cannot be cast to non-null type java.lang.String");
         var8 = var6.getBytes(var7);
         Intrinsics.checkNotNullExpressionValue(var8, "this as java.lang.String).getBytes(charset)");
      } else {
         var8 = this.charsToBytesImpl$kotlin_stdlib(var1, var2, var3);
      }

      byte[] var4 = var8;
      return decode$default(this, (byte[])var4, 0, 0, 6, (Object)null);
   }

   // $FF: synthetic method
   public static byte[] decode$default(Base64 var0, CharSequence var1, int var2, int var3, int var4, Object var5) {
      if (var5 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: decode");
      } else {
         if ((var4 & 2) != 0) {
            var2 = 0;
         }

         if ((var4 & 4) != 0) {
            var3 = var1.length();
         }

         return var0.decode(var1, var2, var3);
      }
   }

   public final int decodeIntoByteArray(@NotNull CharSequence var1, @NotNull byte[] var2, int var3, int var4, int var5) {
      Intrinsics.checkNotNullParameter(var1, "source");
      Intrinsics.checkNotNullParameter(var2, "destination");
      byte[] var10;
      if (var1 instanceof String) {
         this.checkSourceBounds$kotlin_stdlib(var1.length(), var4, var5);
         String var10000 = ((String)var1).substring(var4, var5);
         Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String…ing(startIndex, endIndex)");
         String var8 = var10000;
         Charset var9 = Charsets.ISO_8859_1;
         Intrinsics.checkNotNull(var8, "null cannot be cast to non-null type java.lang.String");
         var10 = var8.getBytes(var9);
         Intrinsics.checkNotNullExpressionValue(var10, "this as java.lang.String).getBytes(charset)");
      } else {
         var10 = this.charsToBytesImpl$kotlin_stdlib(var1, var4, var5);
      }

      byte[] var6 = var10;
      return decodeIntoByteArray$default(this, (byte[])var6, var2, var3, 0, 0, 24, (Object)null);
   }

   // $FF: synthetic method
   public static int decodeIntoByteArray$default(Base64 var0, CharSequence var1, byte[] var2, int var3, int var4, int var5, int var6, Object var7) {
      if (var7 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: decodeIntoByteArray");
      } else {
         if ((var6 & 4) != 0) {
            var3 = 0;
         }

         if ((var6 & 8) != 0) {
            var4 = 0;
         }

         if ((var6 & 16) != 0) {
            var5 = var1.length();
         }

         return var0.decodeIntoByteArray(var1, var2, var3, var4, var5);
      }
   }

   @NotNull
   public final byte[] encodeToByteArrayImpl$kotlin_stdlib(@NotNull byte[] var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var1, "source");
      this.checkSourceBounds$kotlin_stdlib(var1.length, var2, var3);
      int var4 = this.encodeSize(var3 - var2);
      byte[] var5 = new byte[var4];
      this.encodeIntoByteArrayImpl$kotlin_stdlib(var1, var5, 0, var2, var3);
      return var5;
   }

   public final int encodeIntoByteArrayImpl$kotlin_stdlib(@NotNull byte[] var1, @NotNull byte[] var2, int var3, int var4, int var5) {
      Intrinsics.checkNotNullParameter(var1, "source");
      Intrinsics.checkNotNullParameter(var2, "destination");
      this.checkSourceBounds$kotlin_stdlib(var1.length, var4, var5);
      this.checkDestinationBounds(var2.length, var3, this.encodeSize(var5 - var4));
      byte[] var6 = this.isUrlSafe ? Base64Kt.access$getBase64UrlEncodeMap$p() : Base64Kt.access$getBase64EncodeMap$p();
      int var7 = var4;
      int var8 = var3;
      int var9 = this.isMimeScheme ? 19 : Integer.MAX_VALUE;

      int var11;
      int var12;
      int var13;
      while(var7 + 2 < var5) {
         int var10 = Math.min((var5 - var7) / 3, var9);

         for(var11 = 0; var11 < var10; ++var11) {
            var12 = var1[var7++] & 255;
            var13 = var1[var7++] & 255;
            int var14 = var1[var7++] & 255;
            int var15 = var12 << 16 | var13 << 8 | var14;
            var2[var8++] = var6[var15 >>> 18];
            var2[var8++] = var6[var15 >>> 12 & 63];
            var2[var8++] = var6[var15 >>> 6 & 63];
            var2[var8++] = var6[var15 & 63];
         }

         if (var10 == var9 && var7 != var5) {
            var2[var8++] = mimeLineSeparatorSymbols[0];
            var2[var8++] = mimeLineSeparatorSymbols[1];
         }
      }

      switch(var5 - var7) {
      case 1:
         var11 = var1[var7++] & 255;
         var12 = var11 << 4;
         var2[var8++] = var6[var12 >>> 6];
         var2[var8++] = var6[var12 & 63];
         var2[var8++] = 61;
         var2[var8++] = 61;
         break;
      case 2:
         var11 = var1[var7++] & 255;
         var12 = var1[var7++] & 255;
         var13 = var11 << 10 | var12 << 2;
         var2[var8++] = var6[var13 >>> 12];
         var2[var8++] = var6[var13 >>> 6 & 63];
         var2[var8++] = var6[var13 & 63];
         var2[var8++] = 61;
      }

      boolean var16 = var7 == var5;
      if (!var16) {
         String var17 = "Check failed.";
         throw new IllegalStateException(var17.toString());
      } else {
         return var8 - var3;
      }
   }

   private final int encodeSize(int var1) {
      int var2 = (var1 + 3 - 1) / 3;
      int var3 = this.isMimeScheme ? (var2 - 1) / 19 : 0;
      int var4 = var2 * 4 + var3 * 2;
      if (var4 < 0) {
         throw new IllegalArgumentException("Input is too big");
      } else {
         return var4;
      }
   }

   private final int decodeImpl(byte[] var1, byte[] var2, int var3, int var4, int var5) {
      int[] var6 = this.isUrlSafe ? Base64Kt.access$getBase64UrlDecodeMap$p() : Base64Kt.access$getBase64DecodeMap$p();
      int var7 = 0;
      int var8 = -8;
      int var9 = var4;
      int var10 = var3;

      int var11;
      StringBuilder var16;
      String var10003;
      while(var9 < var5) {
         int var12;
         if (var8 == -8 && var9 + 3 < var5) {
            var11 = var6[var1[var9++] & 255];
            var12 = var6[var1[var9++] & 255];
            int var13 = var6[var1[var9++] & 255];
            int var14 = var6[var1[var9++] & 255];
            int var15 = var11 << 18 | var12 << 12 | var13 << 6 | var14;
            if (var15 >= 0) {
               var2[var10++] = (byte)(var15 >> 16);
               var2[var10++] = (byte)(var15 >> 8);
               var2[var10++] = (byte)var15;
               continue;
            }

            var9 -= 4;
         }

         var11 = var1[var9] & 255;
         var12 = var6[var11];
         if (var12 < 0) {
            if (var12 == -2) {
               var9 = this.handlePaddingSymbol(var1, var9, var5, var8);
               break;
            }

            if (!this.isMimeScheme) {
               var16 = (new StringBuilder()).append("Invalid symbol '").append((char)var11).append("'(");
               var10003 = Integer.toString(var11, CharsKt.checkRadix(8));
               Intrinsics.checkNotNullExpressionValue(var10003, "toString(this, checkRadix(radix))");
               throw new IllegalArgumentException(var16.append(var10003).append(") at index ").append(var9).toString());
            }

            ++var9;
         } else {
            ++var9;
            var7 = var7 << 6 | var12;
            var8 += 6;
            if (var8 >= 0) {
               var2[var10++] = (byte)(var7 >>> var8);
               var7 &= (1 << var8) - 1;
               var8 -= 8;
            }
         }
      }

      if (var8 == -2) {
         throw new IllegalArgumentException("The last unit of input does not have enough bits");
      } else {
         var9 = this.skipIllegalSymbolsIfMime(var1, var9, var5);
         if (var9 < var5) {
            var11 = var1[var9] & 255;
            var16 = (new StringBuilder()).append("Symbol '").append((char)var11).append("'(");
            var10003 = Integer.toString(var11, CharsKt.checkRadix(8));
            Intrinsics.checkNotNullExpressionValue(var10003, "toString(this, checkRadix(radix))");
            throw new IllegalArgumentException(var16.append(var10003).append(") at index ").append(var9 - 1).append(" is prohibited after the pad character").toString());
         } else {
            return var10 - var3;
         }
      }
   }

   private final int decodeSize(byte[] var1, int var2, int var3) {
      int var4 = var3 - var2;
      if (var4 == 0) {
         return 0;
      } else if (var4 == 1) {
         throw new IllegalArgumentException("Input should have at list 2 symbols for Base64 decoding, startIndex: " + var2 + ", endIndex: " + var3);
      } else {
         if (this.isMimeScheme) {
            for(int var5 = var2; var5 < var3; ++var5) {
               int var6 = var1[var5] & 255;
               int var7 = Base64Kt.access$getBase64DecodeMap$p()[var6];
               if (var7 < 0) {
                  if (var7 == -2) {
                     var4 -= var3 - var5;
                     break;
                  }

                  --var4;
               }
            }
         } else if (var1[var3 - 1] == 61) {
            --var4;
            if (var1[var3 - 2] == 61) {
               --var4;
            }
         }

         return (int)((long)var4 * (long)6 / (long)8);
      }
   }

   @NotNull
   public final byte[] charsToBytesImpl$kotlin_stdlib(@NotNull CharSequence var1, int var2, int var3) {
      Intrinsics.checkNotNullParameter(var1, "source");
      this.checkSourceBounds$kotlin_stdlib(var1.length(), var2, var3);
      byte[] var4 = new byte[var3 - var2];
      int var5 = 0;

      for(int var6 = var2; var6 < var3; ++var6) {
         char var7 = var1.charAt(var6);
         if (var7 <= 255) {
            var4[var5++] = (byte)var7;
         } else {
            var4[var5++] = 63;
         }
      }

      return var4;
   }

   @NotNull
   public final String bytesToStringImpl$kotlin_stdlib(@NotNull byte[] var1) {
      Intrinsics.checkNotNullParameter(var1, "source");
      StringBuilder var2 = new StringBuilder(var1.length);
      int var3 = 0;

      for(int var4 = var1.length; var3 < var4; ++var3) {
         byte var5 = var1[var3];
         var2.append((char)var5);
      }

      String var10000 = var2.toString();
      Intrinsics.checkNotNullExpressionValue(var10000, "stringBuilder.toString()");
      return var10000;
   }

   private final int handlePaddingSymbol(byte[] var1, int var2, int var3, int var4) {
      int var10000;
      switch(var4) {
      case -8:
         throw new IllegalArgumentException("Redundant pad character at index " + var2);
      case -7:
      case -5:
      case -3:
      default:
         throw new IllegalStateException("Unreachable".toString());
      case -6:
         var10000 = var2 + 1;
         break;
      case -4:
         int var5 = this.skipIllegalSymbolsIfMime(var1, var2 + 1, var3);
         if (var5 == var3 || var1[var5] != 61) {
            throw new IllegalArgumentException("Missing one pad character at index " + var5);
         }

         var10000 = var5 + 1;
         break;
      case -2:
         var10000 = var2 + 1;
      }

      return var10000;
   }

   private final int skipIllegalSymbolsIfMime(byte[] var1, int var2, int var3) {
      if (!this.isMimeScheme) {
         return var2;
      } else {
         int var4;
         for(var4 = var2; var4 < var3; ++var4) {
            int var5 = var1[var4] & 255;
            if (Base64Kt.access$getBase64DecodeMap$p()[var5] != -1) {
               return var4;
            }
         }

         return var4;
      }
   }

   public final void checkSourceBounds$kotlin_stdlib(int var1, int var2, int var3) {
      AbstractList.Companion.checkBoundsIndexes$kotlin_stdlib(var2, var3, var1);
   }

   private final void checkDestinationBounds(int var1, int var2, int var3) {
      if (var2 >= 0 && var2 <= var1) {
         int var4 = var2 + var3;
         if (var4 < 0 || var4 > var1) {
            throw new IndexOutOfBoundsException("The destination array does not have enough capacity, destination offset: " + var2 + ", destination size: " + var1 + ", capacity needed: " + var3);
         }
      } else {
         throw new IndexOutOfBoundsException("destination offset: " + var2 + ", destination size: " + var1);
      }
   }

   // $FF: synthetic method
   public Base64(boolean var1, boolean var2, DefaultConstructorMarker var3) {
      this(var1, var2);
   }

   static {
      byte[] var0 = new byte[]{13, 10};
      mimeLineSeparatorSymbols = var0;
      UrlSafe = new Base64(true, false);
      Mime = new Base64(false, true);
   }

   @Metadata(
      mv = {1, 8, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\u0005\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0006\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\u0005R\u000e\u0010\b\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\tX\u0080T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\tX\u0080T¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\u00020\u000fX\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u000e\u0010\u0012\u001a\u00020\u0013X\u0080T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\tX\u0080T¢\u0006\u0002\n\u0000¨\u0006\u0015"},
      d2 = {"Lga/strikepractice/kotlin/io/encoding/Base64$Default;", "Lga/strikepractice/kotlin/io/encoding/Base64;", "()V", "Mime", "getMime", "()Lkotlin/io/encoding/Base64;", "UrlSafe", "getUrlSafe", "bitsPerByte", "", "bitsPerSymbol", "bytesPerGroup", "mimeGroupsPerLine", "mimeLineLength", "mimeLineSeparatorSymbols", "", "getMimeLineSeparatorSymbols$kotlin_stdlib", "()[B", "padSymbol", "", "symbolsPerGroup", "ga.strikepractice.kotlin-stdlib"}
   )
   public static final class Default extends Base64 {
      private Default() {
         super(false, false, (DefaultConstructorMarker)null);
      }

      @NotNull
      public final byte[] getMimeLineSeparatorSymbols$kotlin_stdlib() {
         return Base64.mimeLineSeparatorSymbols;
      }

      @NotNull
      public final Base64 getUrlSafe() {
         return Base64.UrlSafe;
      }

      @NotNull
      public final Base64 getMime() {
         return Base64.Mime;
      }

      // $FF: synthetic method
      public Default(DefaultConstructorMarker var1) {
         this();
      }
   }
}
