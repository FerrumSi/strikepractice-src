package ga.strikepractice.kotlin.io;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.PublishedApi;
import ga.strikepractice.kotlin.SinceKotlin;
import ga.strikepractice.kotlin.internal.InlineOnly;
import ga.strikepractice.kotlin.internal.PlatformImplementationsKt;
import ga.strikepractice.kotlin.jvm.JvmName;
import ga.strikepractice.kotlin.jvm.functions.Function1;
import ga.strikepractice.kotlin.jvm.internal.InlineMarker;
import ga.strikepractice.kotlin.jvm.internal.Intrinsics;
import java.io.Closeable;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 8, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0018\u0010\u0000\u001a\u00020\u0001*\u0004\u0018\u00010\u00022\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\u0001\u001aH\u0010\u0005\u001a\u0002H\u0006\"\n\b\u0000\u0010\u0007*\u0004\u0018\u00010\u0002\"\u0004\b\u0001\u0010\u0006*\u0002H\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u0002H\u0007\u0012\u0004\u0012\u0002H\u00060\tH\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\n\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u000b"},
   d2 = {"closeFinally", "", "Ljava/io/Closeable;", "cause", "", "use", "R", "T", "block", "Lga/strikepractice/kotlin/Function1;", "(Ljava/io/Closeable;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "ga.strikepractice.kotlin-stdlib"}
)
@JvmName(
   name = "CloseableKt"
)
public final class CloseableKt {
   @InlineOnly
   private static final <T extends Closeable, R> R use(T var0, Function1<? super T, ? extends R> var1) {
      Intrinsics.checkNotNullParameter(var1, "block");
      Throwable var2 = null;
      boolean var8 = false;

      Object var3;
      try {
         var8 = true;
         var3 = var1.invoke(var0);
         var8 = false;
      } catch (Throwable var10) {
         var2 = var10;
         throw var10;
      } finally {
         if (var8) {
            InlineMarker.finallyStart(1);
            if (PlatformImplementationsKt.apiVersionIsAtLeast(1, 1, 0)) {
               closeFinally(var0, var2);
            } else if (var0 != null) {
               if (var2 == null) {
                  var0.close();
               } else {
                  try {
                     var0.close();
                  } catch (Throwable var9) {
                  }
               }
            }

            InlineMarker.finallyEnd(1);
         }
      }

      InlineMarker.finallyStart(1);
      if (PlatformImplementationsKt.apiVersionIsAtLeast(1, 1, 0)) {
         closeFinally(var0, var2);
      } else if (var0 != null) {
         var0.close();
      }

      InlineMarker.finallyEnd(1);
      return var3;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @PublishedApi
   public static final void closeFinally(@Nullable Closeable var0, @Nullable Throwable var1) {
      if (var0 != null) {
         if (var1 == null) {
            var0.close();
         } else {
            try {
               var0.close();
            } catch (Throwable var3) {
               ga.strikepractice.kotlin.ExceptionsKt.addSuppressed(var1, var3);
            }
         }
      }

   }
}
