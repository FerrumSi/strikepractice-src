package ga.strikepractice.kotlin.annotation;

import ga.strikepractice.kotlin.Metadata;
import ga.strikepractice.kotlin.SinceKotlin;

@Metadata(
   mv = {1, 8, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0011\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011¨\u0006\u0012"},
   d2 = {"Lga/strikepractice/kotlin/annotation/AnnotationTarget;", "", "(Ljava/lang/String;I)V", "CLASS", "ANNOTATION_CLASS", "TYPE_PARAMETER", "PROPERTY", "FIELD", "LOCAL_VARIABLE", "VALUE_PARAMETER", "CONSTRUCTOR", "FUNCTION", "PROPERTY_GETTER", "PROPERTY_SETTER", "TYPE", "EXPRESSION", "FILE", "TYPEALIAS", "ga.strikepractice.kotlin-stdlib"}
)
public enum AnnotationTarget {
   CLASS,
   ANNOTATION_CLASS,
   TYPE_PARAMETER,
   PROPERTY,
   FIELD,
   LOCAL_VARIABLE,
   VALUE_PARAMETER,
   CONSTRUCTOR,
   FUNCTION,
   PROPERTY_GETTER,
   PROPERTY_SETTER,
   TYPE,
   EXPRESSION,
   FILE,
   @SinceKotlin(
      version = "1.1"
   )
   TYPEALIAS;

   // $FF: synthetic method
   private static final AnnotationTarget[] $values() {
      AnnotationTarget[] var0 = new AnnotationTarget[]{CLASS, ANNOTATION_CLASS, TYPE_PARAMETER, PROPERTY, FIELD, LOCAL_VARIABLE, VALUE_PARAMETER, CONSTRUCTOR, FUNCTION, PROPERTY_GETTER, PROPERTY_SETTER, TYPE, EXPRESSION, FILE, TYPEALIAS};
      return var0;
   }
}
